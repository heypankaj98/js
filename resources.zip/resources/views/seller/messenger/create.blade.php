@extends('seller.messenger.template')
@section('title', 'chat with '. $chatuser->username)

@section('messenger-content')

<div class="container-fluid h-100 bg-body-tertiary">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="p-3">
                 
                    <div>
                        <h5 class="mb-3">{{ trans('global.channels') }}</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">{{ trans('global.general') }}</a></li>
                            <li><a href="#">{{ trans('global.announcements') }}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="p-3 mt-auto">
                    <h5 class=" mb-3">{{ trans('global.chat_users') }}  </h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                        <li>  <a href="{{ route('seller.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                      <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">
                                    <span>{{$singletopic->receiverOrCreator()->username}} ( {{ $singletopic->mesasgeUnreadCount() }} )</span>
                                    <p class="small text-success"> {{ trans('global.online') }} </p>
                                    @endif
                                </div>
                            </a>
                        </li>
                        @empty
                       
                        {{ trans('global.no_chat_user') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="card">
                <div class="card-header">
                    <h5>Chat with {{ $chatuser->username }}</h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">
                       <p> {{ trans('global.select_user_for_chat') }}</p>
                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">
                    <form action="{{ route("seller.messenger.storeTopic") }}" method="POST">
                        @csrf
                        <input type='hidden' name="recipient" value='{{$chatuser->id}}'>
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                <button type="submit" class="btn btn-primary"> {{ trans('global.send') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="p-3 mt-auto">
                <h5 class="mb-3"> {{ trans('global.admin_users') }} </h5>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                        @if (auth()->user()->id != $adminuser->id)
                            @if($adminuser->withChatMessages($adminuser->id) > 0)
                                <a href="{{ route('seller.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                                    <span class="badge text-bg-primary">{{ $adminuser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('seller.messenger.newMessages', [$adminuser->id]) }}">\
                                    <span class="badge text-bg-primary">{{ $adminuser->username }}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                      {{ trans('global.no_chat_and_admin_here') }}  
                    @endforelse
                </ul>
            </div>
            <!-- Mod --> 
            <div class="p-3 mt-auto">
                <h5 class=" mb-3"> {{ trans('global.mod_users') }} </h5>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                   @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('seller.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    @else
                    <a href="{{ route('seller.messenger.newMessages', [$moduser->id]) }}">     <span class="badge text-bg-primary">{{ $moduser->username}}</span></a>
               
                    @endif
                    @endif
                    @empty
                     {{ trans('global.no_chat_and_mod_user') }}  
                    
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>




@stop