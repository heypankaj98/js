@extends('layouts.seller.app')     
@section('content')

<div class="bg-card-1 p-24 br1 mt-4">
    <form method="POST" action="{{ route('seller.vacation-mode') }}">
        @csrf
        @method('PUT')
        @if(Auth::user()->vacation_mode)
            <p> {{ trans('global.you_are_on_vacation_user') }} </p>
        @endif

        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" id="vacation_mode" name="vacation_mode" {{ Auth::user()->vacation_mode ? 'checked' : '' }}>
            <label class="form-check-label" for="vacation_mode">
                <span class="fs-5 ml-3">{{ trans('global.enable_vacation_mode') }}</span>
            </label>
        </div>

        <button type="submit" class="btn btn-main mt-3">{{ trans('global.save') }}</button>
    </form>
</div>

@endsection 

<style>
    .form-check-input {
        width: 3em !important;
        height: 1.5em !important;
        margin-top: 0 !important;
    }
</style>
