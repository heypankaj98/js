<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\QaTopicCreateRequest;
use App\Http\Requests\QaTopicReplyRequest;
use App\Models\QaTopic;
use App\Models\User;
use App\Models\Message;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Notifications\NewMessageNotification;

use App\Http\Controllers\Traits\MediaUploadingTrait;


class MessengerController extends Controller {
     use MediaUploadingTrait;

    public function index() {
        $topics = Auth::user()->chatMessages()->get();

        $title = trans('global.all_messages');
        $unreads = $this->unreadTopics();

        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();

        if ($topics->first()) {
            foreach ($topics->first()->messages as $message) {
                if ($message->sender_id !== Auth::id() && $message->read_at === null) {
                    $message->read_at = Carbon::now();
                    $message->save();
                }
            }
        }
        return view('admin.messenger.index', compact('topics', 'title', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }
    public function createTopic() {
        $users = User::all()->except(Auth::id());
        $unreads = $this->unreadTopics();
        return view('admin.messenger.create', compact('users', 'unreads'));
    }

    public function storeTopic(QaTopicCreateRequest $request) {
        $subject = Str::limit($request->input('content'), $limit = 10, $end = '...');
        $topic = QaTopic::create([
                    'subject' => $subject,
                    'creator_id' => Auth::id(),
                    'receiver_id' => $request->input('recipient'),
        ]);
        $topic->messages()->create([
            'sender_id' => Auth::id(),
            'content' => $request->input('content'),
        ]);
        $receiver_user = User::findOrFail($request->input('recipient'));
        $receiver_user->notify(new NewMessageNotification($topic));
        return redirect()->route('admin.messenger.showMessages', $topic);
    }

    public function showMessages(QaTopic $topic) {
        $topics = Auth::user()->chatMessages()->get();
        $unreads = $this->unreadTopics();
        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();
        if ($topic) {
            foreach ($topic->messages as $message) {
                if ($message->sender_id !== Auth::id() && $message->read_at === null) {
                    $message->read_at = Carbon::now();
                    $message->save();
                }
                foreach (Auth::user()->unreadNotifications as $notification) {
                    if ($notification->type == 'App\Notifications\NewMessageNotification') {
                        $notification->markAsRead();
                    }
                }
            }
        }
        return view('admin.messenger.show', compact('topics', 'topic', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }
    
     public function newMessages(User $user) {

        $topics = Auth::user()->chatMessages()->get();
        $unreads = $this->unreadTopics();
        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();
        $chatuser = $user;

        return view('admin.messenger.create', compact('topics', 'chatuser', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }
    

    public function destroyTopic(QaTopic $topic) {
        $this->checkAccessRights($topic);

        $topic->delete();

        return redirect()->route('admin.messenger.index');
    }


    public function replyToTopic(QaTopicReplyRequest $request, QaTopic $topic) {
       $message = $topic->messages()->create([
            'sender_id' => Auth::id(),
            'content' => $request->input('content'),
        ]);

        if ($topic->receiver_id == Auth::id()) {
            $notification_reciver = $topic->creator_id;
        } else {
            $notification_reciver = $topic->receiver_id;
        }
        if ($request->hasFile('picture')) {
            $input['picture'] = $this->storeMedia($request, 'picture');
            if ($input['picture']) {
                $message->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
            }
        }
        
        $receiver_user = User::findOrFail($notification_reciver);
        $receiver_user->notify(new NewMessageNotification($topic));

        return redirect()->route('admin.messenger.showMessages', $topic);
    }


    public function unreadTopics(): array {
        $topics = QaTopic::where(function ($query) {
                    $query
                    ->where('creator_id', Auth::id())
                    ->orWhere('receiver_id', Auth::id());
                })
                ->with('messages')
                ->orderBy('created_at', 'DESC')
                ->get();

        $inboxUnreadCount = 0;
        $outboxUnreadCount = 0;

        foreach ($topics as $topic) {
            foreach ($topic->messages as $message) {
                if (
                        $message->sender_id !== Auth::id() && $message->read_at === null
                ) {
                    if ($topic->creator_id !== Auth::id()) {
                        $inboxUnreadCount++;
                    } else {
                        $outboxUnreadCount++;
                    }
                }
            }
        }

        return [
            'inbox' => $inboxUnreadCount,
            'outbox' => $outboxUnreadCount,
        ];
    }

    private function checkAccessRights(QaTopic $topic) {
        $user = Auth::user();

        if ($topic->creator_id !== $user->id && $topic->receiver_id !== $user->id) {
            return abort(401);
        }
    }


}
