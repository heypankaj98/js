<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up()
{
    Schema::table('product_reviews', function (Blueprint $table) {
        $table->text('feedback')->nullable()->default(null)->change();  // Default NULL for feedback
        $table->integer('rating')->default(0)->change();  // Default 0 for rating
    });
}

public function down()
{
    Schema::table('product_reviews', function (Blueprint $table) {
        $table->text('feedback')->nullable()->change();  // Remove default value for feedback
        $table->integer('rating')->nullable(false)->change();  // Remove default value for rating
    });
}

};
