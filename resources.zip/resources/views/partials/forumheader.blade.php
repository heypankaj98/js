<header class="c-home-header">

    <div class="amazon_header header-1">
        <div class="amazon_header_top">
            <div class="container-fluid">
                <div class="row">
                    <div class="nav_main_left d-flex">
                        <div class="logo_amazon">
                            <ul class="d-flex navbar-nav">
                                <li class="nav-item">
                                    <a class="navbar-brand m-0 hover_border" href="/">
                                        <img src="{{ asset('assets/shopzo_logo _white.png')}}" alt="alt" />

                                    </a>
                                </li>
                            </ul>
                        </div>

                        <div class="location">
                            <a class="location_inner  hover_border" href="">
                                <div class="location_icon">
                                    <img src="{{ asset('assets/location-image.png')}}" alt="alt" />
                                </div>

                                <div class="location_text">
                                    <span class="deliver_text"> {{ trans('auth.deliver_to') }}</span>
                                    <span class="deliver_text"> {{ trans('auth.india') }}</span>


                                </div>
                            </a>

                        </div>

                    </div>

                    <div class="search_bar_amazon">
                        <ul class="c-search-wrapper ">
                            <form class="c-search-form d-flex align-items-center" action="{{ route('search.index') }}"
                                method="GET">
                                <div class="c-search-col ">
                                    <label for="searchtype" class="visually-hidden">
                                        {{ trans('auth.product_type') }}</label>
                                    <select id="searchtype" name="filter" class="form-control">
                                        <option value="digital"> {{ trans('auth.all') }}</option>

                                        <option value="physical"> {{ trans('auth.physical') }}</option>
                                        <option value="auction">{{ trans('auth.auction')}} </option>
                                    </select>
                                </div>

                                <div class=search-bar>
                                    <label for="searchinput" class="visually-hidden">Search</label>
                                    <input type="text" class="form-control" id="searchinput" name="query"
                                        placeholder="Search...">
                                </div>

                                <div class="c-search-col">
                                    <button class="btn btn-primary c-search-btn" type="submit"> <img
                                            src="{{ asset('assets/search.png')}}" alt="alt" /> </button>
                                </div>
                            </form>

                        </ul>

                    </div>
                    <div class="nav_tools_amazon">
                        <div class="currency">
                            <ul class="d-flex navbar-nav">
                                <li class="nav-item dropdown hover_border">

                                    <a class="nav-link dropdown-toggle  " href="#" id="navbarDropdown" role="button"
                                        data-bs-toggle="dropdown" data-bs-theme="light" aria-expanded="false">
                                        <img src="{{ asset('assets/uk.png')}}" alt="alt" />
                                        {{ session('language', 'EN') }}
                                        <img src="{{ asset('assets/vector-img.png')}}" alt="alt" />
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <li><a class="dropdown-item  nav-link"
                                                href="{{route('change_language','en')}}">English</a></li>
                                        <li><a class="dropdown-item nav-link"
                                                href="{{route('change_language','ru')}}">Russian</a></li>
                                        <li><a class="dropdown-item nav-link"
                                                href="{{route('change_language','hi')}}">Hindi</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="currency">
                            <ul class="d-flex navbar-nav">
                                <li class="nav-item dropdown hover_border">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        {{ session('currency', 'USD') }}

                                        <img src="{{ asset('assets/vector-img.png')}}" alt="alt" />
                                    </a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <li><a class="dropdown-item" href="{{route('change_currency','USD')}}">USD</a>
                                        </li>
                                        <li><a class="dropdown-item" href="{{route('change_currency','EUR')}}">EUR</a>
                                        </li>
                                        <li><a class="dropdown-item" href="{{route('change_currency','GBP')}}">GBP</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--                    <div class="location">
                                            <a class="location_inner  hover_border" href="" >
                                               
                                                
                                                <div class="location_text">
                                                    <span class="deliver_text"> {{ trans('auth.returns') }}</span>
                                                    <span class="deliver_text"> {{ trans('auth.orders') }}</span>
                                                       
                                                    
                                                </div>
                                            </a>
                                            
                                        </div>-->
                        <div class="location">
                            <a class="location_inner  hover_border" href="{{ route('user.cart') }}">
                                <div class="location_icon">
                                    <img src="{{ asset('assets/cart_new.png')}}" alt="alt" />
                                    <span class="cat_no">

                                        @if(session()->has('cart'))
                                        @php
                                        $totalQuantity = 0;
                                        $cart = session()->get('cart');
                                        foreach ($cart as $item) {
                                        $totalQuantity += $item['quantity'];
                                        }
                                        @endphp
                                        {{ $totalQuantity }}
                                        @endif



                                    </span>
                                </div>

                                <div class="location_text">
                                    <!--                            <span class="deliver_text"> {{ trans('auth.returns') }}</span>-->
                                    <span class="deliver_text"> {{ trans('auth.cart') }}</span>


                                </div>
                            </a>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <nav class="c-header-bottom navbar navbar-expand-lg  c-bottom-navbar">
            <div class="container-fluid">
                <div class="inner_row w-100">

                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <!--            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>-->
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="c-nab-menu-list navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link hover_border "
                                        href="{{ url(config('forum.web.router.prefix')) }}">{{ trans('forum::general.index') }}</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link hover_border "
                                        href="{{ route('forum.recent') }}">{{ trans('forum::threads.recent') }}</a>
                                </li>

                                @can ('moveCategories')
                                <li class="nav-item ">
                                    <a class="nav-link hover_border"
                                        href="{{ route('forum.category.manage') }}">{{ trans('forum::general.manage') }}</a>
                                </li>
                                @endcan

                            </ul>

                            <ul class="d-flex navbar-nav">



                                @if (auth()->check())
                                <div class="user-menu-icon hover_border">
                                    <!-- Display the avatar based on the type -->
                                    @if (Str::startsWith(Auth::user()->avatar, 'data:image'))
                                    <!-- If avatar is a base64 string -->
                                    <img src="{{ Auth::user()->avatar }}" alt="Avatar" width="100" height="100"
                                        class="rounded-circle img-fluid">
                                    @else
                                    <!-- If avatar is a file path -->
                                    <img src="{{ asset('storage/' . Auth::user()->avatar) }}" alt="Avatar" width="100"
                                        height="100" class="rounded-circle img-fluid">
                                    @endif
                                    <span>
                                        <span class="user-menu-title">{{Auth::user()->username}}</span>
                                    </span>
                                    <img src="{{ asset('assets/icon_down-img.png')}}" alt="alt" />
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item"
                                            href="{{route('user.dashboard')}}">{{ trans('auth.user_dashbaord')}} </a>
                                        @seller
                                        <a class="dropdown-item" href="{{route('seller.dashboard')}}">
                                            {{ trans('auth.seller_dashbaord')}}</a>
                                        @endseller
                                        @admin
                                        <a class="dropdown-item" href="{{ route('admin.home') }}">
                                            {{ trans('auth.admin_dashbaord')}}</a>
                                        @endadmin
                                        <a class="dropdown-item" href="{{route('user.profile.index')}}">
                                            {{ trans('auth.edit_profile')}} </a>

                                        <form action="{{ route('logout') }}" method="POST">
                                            @csrf

                                            <button class="dropdown-item" type="submit"> {{ trans('auth.Logout')}}
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                @else
                                <div class="header-intercom">
                                    <div class="header-intercom-text"> <a class="link" href="{{ route('login') }}">
                                            {{ trans('auth.Login_link')}}</a>
                                    </div>
                                </div>
                                <div class="header-intercom">
                                    <div class="header-intercom-text"> <a class="link"
                                            href="{{ route('register.show') }}"> {{ trans('auth.register_link')}}
                                            Register</a>
                                    </div>
                                </div>
                                @endif

                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>

</header>