<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Hash , Crypt;
use App\Tools\PGP;

class ForgotController extends Controller {
    public function showForgot() {
        return view('auth.forgot.show');
    }

    public function showPGPForgot() {
        return view('auth.forgot.pgp_reset_by_mnemonic');
    }

    public function postPGPForgot(Request $request) {
        $validatedData = $request->validate([
            'username' => 'required|alpha_num|min:4|max:20',
            'mnemonic' => 'required',
            
        ]);

        $username = $validatedData['username'];
        $mnemonic = $validatedData['mnemonic'];

        // Retrieve the user by their username
        $user = User::where('username', $username)->first();

        if (!$user) {
            return redirect()->back()->withErrors(['username' => 'Invalid username']);
        }
        if (!$user->pgp_key) {
            return redirect()->back()->withErrors(['username' => 'You do not have PGP Key']);
        }


        if (!Hash::check(hash('sha256', $mnemonic), $user->mnemonic)) {
            // Handle the case where the mnemonic is incorrect
            return redirect()->back()->withErrors(['mnemonic' => 'Incorrect mnemonic']);
        }
//        session()->put('user', $user);

        return view('auth.forgot.pgp_reset_form');
    }

    public function generateVerifyPGP(Request $request) {
        $pgpKey = $request->pgp_key;

        if (is_null($pgpKey)) {
            session()->flash('Error', 'Please enter a valid PGP key for verification!');
            return redirect()->route('forgot.pgp.mnemonic');
        }

        session()->put('pgp_key', $pgpKey); #Create a new session to store the PGP key entered in the field
        PGP::verification($pgpKey, 'confirm_new_pgp_key'); #Create new verification
        return view('auth.forgot.pgp_reset_form');
    }

    public function verifyChangePGP(Request $request) {
        #Get auth user
        $user = auth()->user();
//        $user = session()->get('user');
        if (!session()->has('verification_name')) {
            session()->flash('Error', 'Oops... Cancel and try again!');
            return redirect()->route('forgot.pgp.mnemonic');
        }

        #Decrypt session verification code
        $verificationCode = Crypt::decryptString(session()->get('verification_code'));

        if ($request->verification_code !== $verificationCode) {
            session()->flash('Error', 'Invalid verification code!');
            return redirect()->route('forgot.pgp.mnemonic');
        }

        #Set new PGP key
        $user->pgp_key = session()->get('pgp_key');
        $user->save();

        #Destroy verification sessions
        session()->forget(['pgp_key', 'verification_name', 'encrypted_message', 'verification_code']);
        session()->flash('success', 'PGP key changed successfully!');
        return redirect()->route('login');
    }

    public function showPasswordMnemonic() {
        return view('auth.forgot.password_reset_mnemonic');
    }

    public function postPasswordMnemonic(Request $request) {

        $validatedData = $request->validate([
            'username' => 'required|alpha_num|min:4|max:20',
            'mnemonic' => 'required',
            'password' => 'required|min:8|max:80',
            'captcha' => 'required|captcha'
        ]);

        $username = $validatedData['username'];
        $mnemonic = $validatedData['mnemonic'];
        $user = User::where('username', $username)->first();

        if (!$user) {
            return redirect()->back()->withErrors(['username' => 'Invalid username']);
        }


        if (!Hash::check(hash('sha256', $mnemonic), $user->mnemonic)) {
            return redirect()->back()->withErrors(['mnemonic' => 'Incorrect mnemonic']);
        }
        $user->password = Hash::make($request->password);
        $user->save();

        session()->flash('success', 'Password has been changed!');
        return redirect()->route('login');
    }

}
