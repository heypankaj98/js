<?php

namespace App\Http\Middleware;

use Closure;
use Gate;
use Symfony\Component\HttpFoundation\Response;

class IsSeller {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
   public function handle($request, Closure $next) {
    // Check if the user has accessed the seller portal
    if (session()->has('accessed_seller')) {
        // Ensure the user has permission for seller staff access
        abort_if(Gate::denies('seller_staff_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return $next($request);
    }

    // Check if the user is authenticated and a seller
    if (!auth()->user()->isSeller) {
        abort(403, 'Access Denied: You are not a seller.');
    }

    // // Ensure the user is verified
    // if (!auth()->user()->is_verified) {
    //     // Redirect to a verification pending page instead of going back to the same page
    //     return redirect()->route('verification.pending')
    //                      ->with('error', 'You are not verified. Please wait for admin approval or create a support ticket.');
    // }
    
    return $next($request);
}


}
