<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Bitcoin\Utility;

class FeeCalculator {

    /**
     * Decimal fee
     *
     * @var float
     */
    private $fee;

    /**
     * Decimal rest of the fee
     *
     * @var
     */
    private $base;
    private $diffVendor;

    /**
     * Calculate fee part and base part of the amount
     *
     * FeeCalculator constructor.
     * @param float $sum
     */
    public function __construct(float $sum, $vendor = null) {
        /**
         * Fee percent must be between 0..95
         */
        if ($vendor && $vendor->commission !== null) {
            $feePercent = (int) $vendor->commission;
        } else {
            $feePercent = config('marketplace.market_fee_percent');
        }
        $feeRation = $feePercent <= 95 && $feePercent >= 0 ? $feePercent / 100 : .00;
        /**
         * Max 8 decimals for the fee, rounded on up
         */
//       $this->fee = number_format((float)$sum * $feeRation, 8, '.', ''); 
//        $valuefee = number_format($sum * $feeRation, 8, '.', '');
//        $this->fee = round($valuefee, 8, PHP_ROUND_HALF_UP);

        $valuefee = round($sum * $feeRation, 8, PHP_ROUND_HALF_UP);
        $abc = (float) number_format($valuefee, 8, '.', '');

        $this->fee = number_format(round($sum * $feeRation, 8, PHP_ROUND_HALF_UP), 8);

        /**
         * Substract fee from the sum and round to the 8  decimals for btc
         */
        $this->base = round($sum - $this->fee, 8, PHP_ROUND_HALF_DOWN);
    }

    /**
     * Returns fee sum that must be paid
     *
     * @return float
     */
    public function getFee($referralFee = false): float {
        if ($referralFee)
            return $this->fee / 2;
        return $this->fee;
    }

//    public function getFeeDiffVendor($vendor,$referralFee=false) : float
//    {
//        
//         $feePercent = config('marketplace.market_fee_percent');
//        $feeRation = $feePercent <= 95 && $feePercent >= 0
//                        ? config('marketplace.market_fee_percent') / 100
//                        : .00;
//
//        /**
//         * Max 8 decimals for the fee, rounded on up
//         */
//       $feec = round($sum * $feeRation, 8, PHP_ROUND_HALF_UP);
//        /**
//         * Substract fee from the sum and round to the 8  decimals for btc
//         */
//       $bases = round($sum - $this -> fee, 8, PHP_ROUND_HALF_DOWN);
//       
//        
//    }

    /**
     * Get amount without fee
     *
     * @return float
     */
    public function getBase() {
        return $this->base;
    }

}
