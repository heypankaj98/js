@extends('forum::layouts.master')

@section('content')
@can('admin_create_forum_access')
<a href="{{route('categories.create')}}" class="btn btn-primary create-category">
    {{ trans('forum::categories.create') }}
</a>
  @endcan
<!-- forum/categories/index.blade.php -->

@foreach ($categories as $category)
<div class="category list-group my-4">
    <div class="list-group-item shadow-sm">
        <div class="row align-items-center text-center">
            <div class="col-sm text-md-start">
                <h5 class="card-title">
                    <a href="{{ route('categories.show', $category) }}" style="color: {{ $category->color }};">{{ $category->title }}</a>
                </h5>
                <p class="card-text text-muted">{{ $category->description }}</p>
            </div>
            <div class="col-sm-2 text-md-end">
                @if ($category->accepts_threads)
                <span class="badge rounded-pill bg-primary" style="background: {{ $category->color }};">
                    {{ trans_choice('forum::threads.thread', 2) }}: {{ $category->thread_count }}
                </span>
                <br>
                <span class="badge rounded-pill bg-primary" style="background: {{ $category->color }};">
                    {{ trans_choice('forum::posts.post', 2) }}: {{ $category->post_count }}
                </span>
                @endif
            </div>
            <div class="col-sm text-md-end text-muted">
                @if ($category->accepts_threads)
                @if ($category->newestThread)
                <div>
                    <a href="{{ route('thread.show', $category->newestThread) }}">{{ $category->newestThread->title }}</a>
                    <time class="timestamp" datetime="{{ $category->newestThread->created_at }}" title="{{ $category->newestThread->created_at->toDayDateTimeString() }}">{{ $category->newestThread->created_at->diffForHumans() }}</time>
                </div>
                @endif
                @if ($category->latestActiveThread && $category->latestActiveThread->post_count > 1)
                <div>
                    <a href="{{ route('thread.show', $category->latestActiveThread->lastPost) }}">Re: {{ $category->latestActiveThread->title }}</a>
                    <time class="timestamp" datetime="{{ $category->latestActiveThread->lastPost->created_at }}" title="{{ $category->latestActiveThread->lastPost->created_at->toDayDateTimeString() }}">{{ $category->latestActiveThread->lastPost->created_at->diffForHumans() }}</time>

                </div>
                @endif
                @endif
            </div>
        </div>
    </div>
</div>
@endforeach
@endsection
