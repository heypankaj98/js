@extends('layouts.admin.master')

@section('content')



<ul class="nav nav-pills nav-justified custom-nav-pills">
    <li class="nav-item">
        <a class="nav-link {{ request()->routeIs('admin.node.info') ? 'active' : '' }}" aria-current="page" href="{{ route('admin.node.info') }}">Bitcoin</a>
    </li>

 
</ul>



    <div  class="tabcontent">
        <h3>Bitcoin</h3>
       
          
<div class="container-fluid bg-card-second mt-2">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class=" my-3">
                <div class="fs-4 text-accent mb-3">
                    Node Information
                </div>
                <div class="cardheader">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Total Balance</th>
                                    <td> 
    <?php 
        $balanceValue = is_array($balance) ? 0 : (float)$balance; // Ensure $balance is a float
    ?>
    <?php echo e(number_format($balanceValue, 8)); ?> BTC
</td>
                                </tr>
                                <tr>
                                    <th>Transaction Count</th>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>


                    <div class="bg-ter-2 mt-3">
                        <h5>Transfer Bitcoin</h5>

                        @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif

                        @if ($errors->any())
                        <div class="alert alert-danger mb-3">
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                        @endif
                        <form action="{{ route('admin.node.btctransfer') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="btcAddress">Bitcoin Address:</label>
                                <input type="text" class="form-control nav-search-input my-2" id="btcAddress" name="btcAddress" placeholder="Enter Bitcoin Address">
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount:</label>
                                <input type="float" class="form-control nav-search-input my-2" id="amount" name="amount" placeholder="Enter Amount">
                            </div>
                            <button type="submit" class="btn btn-main">Submit</button>
                        </form>
                    </div>




                    <div class="bg-ter-2 mt-3">
                        <h2>Bitcoin Private Key Dump</h2>
                        <form action="{{ route('admin.node.dumpPrivateKey') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="publicKey">Public Key:</label>
                                <input type="text" class="form-control nav-search-input my-2" id="publicKey" name="publicKey" required>
                            </div>
                            <button type="submit" class="btn btn-main">Dump Private Key</button>
                        </form>
                        <div class="result mt-4" style="display: none;">
                            <h4>Private Key:</h4>
                            <p>{{ $privateKey ?? '' }}</p>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid bg-card-second mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class=" my-3">
                <div class="fs-4 text-accent">
                    Transaction List
                </div>
                <div class="cardheader">
                    <div class="table-responsive">
                        @if($transactions)
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Address</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th>Transaction ID</th>
                                    <th>Fee</th>
                                    <th>Confirmations</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($transactions as $transaction)
                                <tr>
                                    <td>{{ $transaction['address'] }}</td>
                                    <td>{{ $transaction['category'] }}</td>
                                    <td>{{number_format( $transaction['amount'],8) }}</td>
                                    <td>{{ $transaction['txid'] }}</td>
                                    <td>
                                        @if (isset($transaction['fee']) && $transaction['fee'] != 0)
                                        {{ number_format($transaction['fee'], 8) }}
                                        @else
                                        No fee
                                        @endif
                                    </td>
                                    <td>{{ $transaction['confirmations'] }}</td>
                                    <td> {{ \Carbon\Carbon::createFromTimestamp($transaction['time'])->toDateTimeString() }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid bg-card-second mt-3">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class=" my-3">
                <div class="fs-4 text-accent">
                    Node Information
                </div>
                <div class="cardheader">
                    <div class="table-responsive">
                        @if($blockchaininfo)
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Chain</th>
                                    <td>{{ $blockchaininfo['chain'] }}</td>
                                </tr>
                                <tr>
                                    <th>Blocks</th>
                                    <td>{{ $blockchaininfo['blocks'] }}</td>
                                </tr>
                                <tr>
                                    <th>Headers</th>
                                    <td>{{ $blockchaininfo['headers'] }}</td>
                                </tr>
                                <tr>
                                    <th>Best Block Hash</th>
                                    <td>{{ $blockchaininfo['bestblockhash'] }}</td>
                                </tr>
                                <tr>
                                    <th>Difficulty</th>
                                    <td>{{ $blockchaininfo['difficulty'] }}</td>
                                </tr>
                                <tr>
                                    <th>Median Time</th>
                                    <td>{{ $blockchaininfo['mediantime'] }}</td>
                                </tr>
                                <tr>
                                    <th>Verification Progress</th>
                                    <td>{{ number_format($blockchaininfo['verificationprogress'] * 100, 4) }}%</td>
                                </tr>
                                <tr>
                                    <th>Initial Block Download</th>
                                    <td>{{ $blockchaininfo['initialblockdownload'] ? 'True' : 'False' }}</td>
                                </tr>
                                <tr>
                                    <th>Chainwork</th>
                                    <td>{{ $blockchaininfo['chainwork'] }}</td>
                                </tr>
                                <tr>
                                    <th>Size on Disk</th>
                                    <td>{{ $blockchaininfo['size_on_disk'] }}</td>
                                </tr>
                                <tr>
                                    <th>Pruned</th>
                                    <td>{{ $blockchaininfo['pruned'] ? 'True' : 'False' }}</td>
                                </tr>

                                <tr>
                                    <th>Warnings</th>
                                    <td>{{ $blockchaininfo['warnings'] }}</td>
                                </tr>
                            </tbody>
                        </table>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  
        
     
    </div>
@endsection
