<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payout extends Model {

    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';

    use HasFactory;

    protected $fillable = [
        'user_id',
        'payment_address',
        'payment_method',
        'amount',
        'status',
        'details',
    ];
public function user()
{
    return $this->belongsTo(User::class);
}
}
