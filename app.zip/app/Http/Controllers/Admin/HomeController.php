<?php

namespace App\Http\Controllers\Admin;

use App\Models\Settings;
use App\Models\User;
use App\Models\Payment;
use App\Models\ExceptionModel;
use Illuminate\Http\Request;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Gate;
use DB;

class HomeController {

    public function index() {

        $isnoderunning = PayWay::isNoderunning('Bitcoin');
      
        return view('admin.home', compact('isnoderunning'));
    }

 public function btcTransfer(Request $request) {
        
        $request->validate([
            'btcAddress' => 'required',
            'amount' => 'required|numeric|min:0',
        ]);
        $crypto = $request->transaction_type == 'Monero' ? 'Monero' : 'Bitcoin';

        $params['address'] = $request->btcAddress;
        $params['amount'] = $request->amount;
        $params['tag'] ='testuser1234';
  
    if($crypto=='Monero'){
          $transfer = PayWay::sendToAddress($crypto, $params);
    }else{
        
       $transfer = PayWay::sendToAddress($crypto, $params);
      
    }
    // dd($transfer);
        
        if (isset($transfer['error_code'])) {
            $errorCode = $transfer['error_code'];
            $errorMessage = $transfer['error_message'];
            session()->flash('error', $errorMessage . "=>" . $errorCode);
             return redirect()->back();
        } else {
            session()->flash('success', 'Payment send successfully. Thank you.txid: ' . $transfer);
            return redirect()->back();
        }
    }

    public function nodeinfo() {
        $isnoderunning = null;
        $isnoderunning = PayWay::isNoderunning('Bitcoin');
        
        $blockchaininfo = null;
        $balance = null;
        $transactions = null;

        // Check if the blockchaininfo cookie exists
        if (request()->hasCookie('blockchaininfo')) {
            // Retrieve the value of the blockchaininfo cookie
            $blockchainInfoCookie = request()->cookie('blockchaininfo');
            $blockchaininfo = json_decode($blockchainInfoCookie, true); // Pass `true` as the second argument to get an associative array
        } else {
            if ($isnoderunning) {
                $blockchaininfo = PayWay::getBlockchainInfo('Bitcoin');
                $responseString = json_encode($blockchaininfo);
                $response = new Response();
                $response->cookie('blockchaininfo', $responseString, 1); // 1 minute
            }
        }

        // Check if the node_balance cookie exists
        if (request()->hasCookie('node_balance')) {
            // Retrieve the value of the node_balance cookie
            $balance = request()->cookie('node_balance');
        } else {
            if ($isnoderunning) {
                // Retrieve the total balance
                $balance = PayWay::getWalletBalance();
                if (isset($balance['error_code'])) {
                    $errorCode = $balance['error_code'];
                    $errorMessage = $balance['error_message'];
                    session()->flash('error', $errorMessage . "=>" . $errorCode);
                } else {
                    $response = new Response();
                    $response->cookie('node_balance', $balance, 1); // 1 minute
                }
            }
        }
        if ($isnoderunning) {
            $data = PayWay::getWalletData();
            if (isset($balance['error_code'])) {
                $errorCode = $data['error_code'];
                $errorMessage = $data['error_message'];
                session()->flash('error', $errorMessage . "=>" . $errorCode);
                $transactions = null;
            } else {
                $transactions = $data['transactions'];
            }
        }
//        dd($transactions);
        return view('admin.node.index', compact('isnoderunning', 'blockchaininfo', 'balance', 'transactions'));
    }

    public function charges() {
        $settings = Settings::all();

        return view('admin.charges', compact('settings'));
    }

    public function updateCharges() {
        $setting = Settings::find($id);
        $setting->value = $request->input('value');
        $setting->save();
        return redirect()->route('admin.charges');
    }

    public function error(Request $request) {
        abort_if(Gate::denies('admin_error_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $request->validate([
            'search' => 'nullable|string|max:255',
        ]);

        $search = $request->input('search');
        $errors = ExceptionModel::latest()
                ->where(function ($query) use ($search) {
                    $query->where('error_code', 'LIKE', "%$search%")
                    ->orWhere('error_message', 'LIKE', "%$search%");
                })
                ->paginate(config('setting.pagination'));
        return view('admin.error.index', compact('errors', 'search'));
    }

    public function dumpPrivateKey(Request $request) {
        $publicKey = $request->input('publicKey');
        $privateKey = PayWay::dumpPrivateKey('BitcoinMultiSign', array('publicKey' => $publicKey));
        if (isset($privateKey['error_code'])) {
            $errorCode = $privateKey['error_code'];
            $errorMessage = $privateKey['error_message'];
            session()->flash('error', $errorMessage . "=>" . $errorCode);
        } else {
            session()->flash('success', 'Private_key: ' . $privateKey);
        }
        return redirect()->back();
    }

    public function getAddressFromPublicKey($publicKey) {
        try {
            $address = $this->bitcoind->getaddress($publicKey);
            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function canery() {
        $filePath = public_path('canary.txt');
        if (File::exists($filePath)) {
            $fileContents = File::get($filePath);
            $canary = implode(PHP_EOL, explode(PHP_EOL, $fileContents));
        } else {
            $canary = null;
        }

        return view('admin.canary', compact('canary'));
    }

    public function caneryUpdate(Request $request) {
        $request->validate([
            'canary' => 'required|string',
        ]);
        $canaryInput = $request->input('canary');
        $filePath = public_path('canary.txt');
        File::put($filePath, $canaryInput);
        return redirect()->back()->with('success', 'Canary file updated successfully.');
    }
      public function sellerrequests()
    {
        $payments = Payment::all(); // Fetch all payments
        return view('admin.sellerrequest', compact('payments')); // Pass the data to the view
    }
    
    
public function approveSeller(Payment $payment)
{
    // Check if the user associated with the payment exists
    $user = $payment->user;

    if ($user) {
        // Insert the user role into the role_user table
        DB::table('role_user')->insert([
            'user_id' => $user->id, // Use the actual user ID from the payment
            'role_id' => 3  // Assuming 3 is the role ID for sellers
        ]);

        // Update the user's isSeller status
        $user->isSeller = 1;
        $user->twofa = 1;
        $user->save();

        // Redirect back with a success message
        return redirect()->back()->with('success', 'Seller approved successfully!');
    }

    // Redirect back with an error message if the user is not found
    return redirect()->back()->with('error', 'User not found.');
}
  public function profileEdit() {
       
        return view('admin.profile');
    }
    public function getSellerFeedback($sellerId) {
    // Fetch all ratings for the seller
    $reviews = \DB::table('product_reviews')
        ->where('seller_id', $sellerId)
        ->get();

    // Calculate the average rating
    $averageRating = $reviews->avg('rating');

    // Count reviews in each category
    $positiveCount = $reviews->where('rating', '>=', 4)->count();
    $neutralCount = $reviews->where('rating', '>=', 3)->where('rating', '<', 4)->count();
    $negativeCount = $reviews->where('rating', '<', 3)->count();

    // Total reviews
    $totalReviews = $reviews->count();

    return view('partials.navbar', compact('reviews', 'averageRating', 'positiveCount', 'neutralCount', 'negativeCount', 'totalReviews'));
}

}
