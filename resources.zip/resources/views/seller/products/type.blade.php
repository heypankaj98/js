@extends('layouts.seller.app')
@section('content')
<div class="container text-center">
    <div class="row">
        <div class="col-lg-4 d-flex align-items-stretch d-flex">
            <a href="{{ route("seller.products.create", ['page' => 'digital']) }}">
                <div class="card flex-fill ">
                    <div class="card-heading">
                        <h3>{{ trans('global.product_type') }} {{ trans('global.digital') }} </h3>
                    </div>
                    {{ trans('global.digital') }}
                </div>
            </a>
        </div>
        <div class="col-lg-4 d-flex align-items-stretch">
            <a href="{{ route("seller.products.create", ['page' => 'physical']) }}">
                <div class="card">
                    <div class="card-heading">
                        <h3>{{ trans('global.product_type') }} {{ trans('global.physical') }}</h3>
                    </div>
                    {{ trans('global.physical') }}
                </div>
            </a>
        </div>
        <div class="col-lg-4 d-flex align-items-stretch">
            <a href="{{ route("seller.products.create", ['page' => 'auction']) }}">
                <div class="card">
                    <div class="card-heading">
                        <h3>{{ trans('global.product_type') }} {{ trans('global.auction') }}</h3>
                    </div>
                    {{ trans('global.auction') }}   
                </div>
            </a>
        </div>
    </div>
</div>
@endsection