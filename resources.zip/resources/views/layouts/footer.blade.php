<footer class="footer_market pt-2 pb-2 futt ">
    <div class="container cont11">
        <div class="row">
            <div class="footer_inner">
                   <div class="logo_market col-md-5 m-auto">
                    <ul class="d-flex navbar-nav">
                        <li class="nav-item">
                            <a class="navbar-brand m-0" href="/">
                                @if(session()->has('theme') && Session::get('theme') == "dark")
                                    <img src="{{ asset('assets/Alley_Cat-new.png')}}"  alt="alt"/>
                                @else
                                    <img src="{{ asset('assets/Alley_Cat-new.png')}}"  alt="alt"/>
                                @endif 
                            </a> 
                        </li>
                        
                        
                    </ul>
                </div>
                <nav class="mb-2">
                    <ul class="navbar-nav m-auto mb-2 mb-md-0 justify-content-between">
                        <li class="nav-item">
                            <a class="nav-link " href="{{ route('tnc') }}">{{ trans('footer.condition_of_use') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('privacy') }}">{{ trans('footer.privacy') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('official.pgp') }}">{{ trans('footer.pgp') }}</a>
                        </li>
                    </ul>
                </nav>
                <div class="copy_right">
                    <p class="text-center team_market">{!! trans('footer.copyright') !!} </p>
                </div>
            </div>
        </div>
    </div>
</footer>