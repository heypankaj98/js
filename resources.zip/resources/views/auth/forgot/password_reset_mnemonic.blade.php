@extends('layouts.nosidebar')   @section('content')

<div class="container">
   <div class="verification_section my-5 my-3 p-2 p-lg-5 radius-5 reset_password_section">
        <div class="row">
            <div class="col">
                <h5 class="card-title fw-bold pb-4 mb-5">{{ trans('auth.forgot') }}</h5>
            </div>
        </div>
        <form action="{{ route('forgot.password.mnemonic.post') }}" method="POST" class="row row-custom"> 
            @csrf
            <div class="verification-market-right col-md-6">
                <div class="margin_auto border_none verification-market_inner">
                    <div class="p-0">
                        @if(Session::has('error'))
                            <p class="alert alert-info">{{ Session::get('error') }}</p>
                        @endif
                        
                        <div class="col-md-12">
                            @if (session('success'))
                                <div id="alert_message" class="alert alert-success alert-block">
                                    <strong>{{ session('success') }}</strong>
                                </div>
                            @endif

                            @if ($errors->any())
                            <div id="alert_message" class="alert alert-danger alert-block">
                                <strong>{{ trans('auth.validation') }}:</strong>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                        </div>
                        <div class="form_reset_main">   
                            <p class="text-20 fw-semibold">{{ trans('auth.your_account_seed') }}</p>
                            <div class="form-group mb-3">
                                <textarea class="text-left w-100 p-4 radius-5" name="mnemonic" placeholder="{{ trans('auth.your_account_seed') }}" required></textarea>
                            </div>
                            <div class="understand d-flex">
                                <input type="checkbox" id="check2" required>&emsp;&emsp;
                                <label class="tab-label fw-medium text-14" for="check2">
                                    {{ trans('auth.confirm_text') }}
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card_main_part register-card  col-md-6">
                <div class="border_none">
                    <div class="card-body">
                        <div class="form-group mb-2">
                            <label for="username" class="pb-2 fw-bold label_main">{{ trans('auth.username')}} <span class="gold_star">{{ trans('auth.user_star') }} </sapn>
                            </label>
                            <input id="username" type="text" class="form-control fw-bold  border_radiusnone @error('username') is-invalid @enderror" placeholder="{{ trans('auth.username') }}" name="username" value="{{ old('username') }}" required>
                        </div>
                        @error('username')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div>
                        @enderror
                        <div class="form-group mb-2">
                            <label for="password" class="pb-2 fw-bold label_main">
                                {{ trans('auth.new_password')}} <span class="gold_star">{{ trans('auth.user_star') }}</sapn>
                            </label>
                            <input id="password" type="password" class="form-control  border_radiusnone @error('password') is-invalid @enderror" name="password" placeholder="••••••••" required>
                        </div>
                        @error('password')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div>
                        @enderror
                        <div class="form-group mb-2">
                            <label for="confirm-password" class="pb-2 fw-bold label_main">{{ trans('auth.confirm_user_password')}} <span class="gold_star">{{ trans('auth.user_star') }} </sapn></label>
                            <input type="password" class="form-control border_radiusnone fw-bold"  id="confirm-password" name="password_confirmation" placeholder="••••••••" required>
                        </div>
                        
                        
                        @error('password_confirmation')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div>
                        @enderror
                        
                        <div class="form-group mb-2 ">
                             <label for="password" class="pb-2 fw-bold label_main">Captcha  required <span class="gold_star">{{ trans('auth.user_star') }} </sapn></label>
            
                            <div class="form-control captch_sapce_control border_radiusnone">
                            {!! captcha_img() !!}
                            </div>
                        </div>
                        <div class="form-group mb-2">
                            <label for="password" class="pb-2 fw-bold label_main">{{ trans('auth.captcha') }} <span class="gold_star">{{ trans('auth.user_star') }} </sapn>
                            </label>
                            <input name="captcha" type="text" class="form-control border_radiusnone {{ $errors->has('captcha') ? ' is-invalid' : '' }}" required placeholder="{{ trans('auth.captcha') }}">
                        </div>
                        @error('captcha')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div>
                        @enderror
                        <div class="col-md-3 m-auto">
                        <button type="submit" class="btn btn-main w-100">{{ trans('auth.reset') }}</button>
                        </div>
                        <div class="karyx_main">
                            <div class="create_btn mt-2 text-center">
                                <a href="{{ route('login') }}" class="link-underline">
                                    {{ trans('auth.login_account') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection