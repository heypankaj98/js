@extends('layouts.admin.master')
@section('content')
<div class="mt-4">
<div class="card-header-2 w-100 mb-4">
        {{ trans('global.show') }} {{ trans('cruds.user.title') }}
    </div>
<div class="bg-card-2 br1">
    <div class="card-body">
        <div class="form-group mb-0">
            <div class="form-group">
                <a class="color-accent-2 d-flex align-items-center gap-2 btn-icon" href="{{ route('admin.users.index') }}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                    {{ trans('global.back_to_list') }}
                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.id') }}
                        </th>
                        <td>
                            {{ $user->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.username') }}
                        </th>
                        <td>
                            {{ $selected_user->username }}
                        </td>
                    </tr>
                 
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.created_at') }}
                        </th>
                        <td>
                            {{ $user->created_at }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.user.fields.roles') }}
                        </th>
                        <td>
                            @foreach($user->roles as $key => $roles)
                                <span class="label label-info">{{ $roles->title }}</span>
                            @endforeach
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group mb-0">
                <a class="btn btn-main w-max-c" href="{{ route('admin.users.index') }}">
                    {{ trans('global.back_to_list') }}
                </a>
    <!--            <form  class="" action="{{ route('admin.user.loginuser', $selected_user->id) }}" method="POST" >-->
    <!--    @csrf-->
    <!--    <button type="submit" class="btn btn-primary">Log in as {{ $user->name }}</button>-->
    <!--</form>-->

            </div>
        </div>
        
        
    </div>
</div>
</div>






@endsection