@extends('layouts.admin.master')

@section('content')

    <h1>Edit Message</h1>

    <!-- Form to edit the message -->
    <form action="{{ route('mirrorlink.update', $mirrorlink->id) }}" method="POST">
        @csrf
        @method('PUT')
        <textarea name="content" rows="4" cols="50">{{ old('content', $mirrorlink->content) }}</textarea>
        <br>
        <button type="submit">Update</button>
    </form>

    <!-- Display validation errors -->
    @if($errors->any())
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    <!-- Display success message -->
    @if(session('success'))
        <p>{{ session('success') }}</p>
    @endif

@endsection
