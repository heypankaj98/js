<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     */
    public function up() {
        Schema::create('exchange_rates', function (Blueprint $table) {
            $table->id();
            $table->string('currency');
            $table->decimal('rate', 16, 8); // rate to the base currency
            $table->timestamps();
        });

        // define exchange rates
        DB::table('exchange_rates')->insert([
            [
                'currency' => 'USD',
                'rate' => 1.0, // 1 USD = 1 USD
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'currency' => 'EUR',
                'rate' => 1.2, // 1 USD = 1.2 EUR
                'created_at' => now(),
                'updated_at' => now(),
            ],
                // add more currencies here
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('exchange_rates');
    }
};
