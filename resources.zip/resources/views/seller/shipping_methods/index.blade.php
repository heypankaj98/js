@extends('layouts.seller.app')      @section('content')

<div class="bg-card-1 p-24 br1 mt-4">
    <div class="">
        <div class="card-header-2 w-100 mb-4">
            {{ trans('common.shipping') }} {{ trans('common.methods') }} {{ trans('common.list') }}
        </div>
        <a href="{{ route('seller.shipping-methods.create') }}" class="btn btn-main my-2 col-12 col-lg-2">
            {{ trans('common.create') }} {{ trans('common.new') }}
        </a>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-prd mt-2 table-striped table-hover datatable datatable-Product text-center">
                    <thead>
                        <tr>
                            <th>{{ trans('common.no') }}.</th>
                            <th>{{ trans('common.name') }}</th>
                            <th>{{ trans('common.price') }}</th>
                            <th>{{ trans('common.delivery') }} {{ trans('common.time') }}</th>
                            <th>{{ trans('common.active') }}</th>
                            <th>{{ trans('common.countries') }}</th>
                            <th>{{ trans('common.action') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($shippingMethods as $shippingMethod)
                            <tr>
                                <td>{{ isset($a) ? ++$a : $a=1 }}.</td>
                                <td>{{ $shippingMethod->name }}</td>
                                <td>{{ $shippingMethod->is_free ? trans('common.free') : '$ ' . $shippingMethod->price }}</td>
                                <td>{{ $shippingMethod->delivery_time }} {{ trans('common.days') }}</td>
                                <td>{{ $shippingMethod->availability }}</td>
                                <td class="text-wrap">
                                    {{ is_array($shippingMethod->countries) ? implode(', ', $shippingMethod->countries) : $shippingMethod->countries }}
                                </td>
                                <td>
                                    <form method="POST" action="{{ route('seller.shipping-methods.destroy', $shippingMethod->id) }}">
                                        @csrf
                                        @method('DELETE')
                                        <a href="{{ route('seller.shipping-methods.edit', $shippingMethod->id) }}" class="btn btn-info btn-sm br-4">
                                            {{ trans('common.view') }}
                                        </a>
                                        <input type="submit" class="btn btn-danger btn-sm br-4" value="{{ trans('common.delete') }}">
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection