<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order; // Update namespace if needed
use Carbon\Carbon;

class DeleteOldCompletedOrders extends Command
{
    protected $signature = 'orders:delete-old-completed';
    protected $description = 'Delete completed orders older than 20 days';

    public function handle()
    {
        $days = 30; // Number of days to retain completed orders
        $thresholdDate = Carbon::now()->subDays($days);

        // Delete orders with status 'completed' and older than the threshold
        $deleted = Order::where('status', 'completed')
                        ->where('created_at', '<', $thresholdDate)
                        ->delete();

        $this->info("$deleted completed orders older than $days days were deleted.");
    }
}
