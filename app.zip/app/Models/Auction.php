<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;


class Auction extends Model implements HasMedia
{
    use InteractsWithMedia,HasFactory;
    protected $table = 'auctions';
    
    protected $dates = [
        'created_at',
        'updated_at'
    ];
    
    protected $fillable = [
        'type',
        'name',
        'description',
        'picture',
        'category',
        'start_time',
        'end_time',
        'isfeature',
        'stock',
        'product_measure',
        'reserve_price',
        'current_price',
        'max',
        'increment',
        'winner_id',
        'seller_id',
        'content',
        'created_at',
        'updated_at'
    ];
    
    public function bids(){
        return $this->hasMany(Bids::class,'auction_id','id');
    }
    
    public function categories() {
        return $this->belongsTo(ProductCategory::class, 'category', 'id');
    }
    
    public function seller() {
        return $this->belongsTo(User::class, 'seller_id', 'id');
    }
    
     public function registerMediaConversions(Media $media = null): void {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
        $this->addMediaConversion('preview')->fit('crop', 120, 120);
    }

    public function getPhotoAttribute() {
        $file = $this->getMedia('photo')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
        }
        return $file;
    }

}