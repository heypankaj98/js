<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyProductRequest;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\{ Product, ProductCategory };
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Order;



class ProductController extends Controller {

    use MediaUploadingTrait;

    public function index() {
        abort_if(Gate::denies('admin_product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $products = Product::latest()->paginate(config('setting.pagination'));
                
        return view('admin.products.index', compact('products'));
    }

    public function create() {
        abort_if(Gate::denies('admin_product_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = ProductCategory::pluck('name', 'id');

        $tags = ProductTag::pluck('name', 'id');

        return view('admin.products.create', compact('categories', 'tags'));
    }

    public function store(StoreProductRequest $request) {
        $product = Product::create($request->all());
        $product->categories()->sync($request->input('categories', []));
        $product->tags()->sync($request->input('tags', []));
        if ($request->input('photo', false)) {
            $product->addMedia(storage_path('tmp/uploads/' . basename($request->input('photo'))))->toMediaCollection('photo');
        }

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $product->id]);
        }

        return redirect()->route('admin.products.index');
    }
//   public function store(Request $request) {
//     $request->validate([
//         'product_id' => 'required|exists:products,id',
//         'quantity' => 'required|integer|min:1',
//     ]);

//     $product = Product::findOrFail($request->input('product_id'));

//     if ($product->stock < $request->input('quantity')) {
//         return redirect()->back()->with('error', 'Insufficient stock.');
//     }

//     // Deduct stock first
//     $product->stock -= $request->input('quantity');
//     $product->save();

//     // Create the order
//     $order = Order::create([
//         'user_id' => auth()->id(),
//         'product_id' => $product->id,
//         'quantity' => $request->input('quantity'),
//     ]);

//     return redirect()->route('orders.index')->with('success', 'Order placed successfully!');
// }

    public function edit(Product $product) {
        abort_if(Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = ProductCategory::pluck('name', 'id');

        $tags = ProductTag::pluck('name', 'id');

        $product->load('categories', 'tags');

        return view('admin.products.edit', compact('categories', 'product', 'tags'));
    }

    public function update(UpdateProductRequest $request, Product $product) {
        $product->update($request->all());
        $product->categories()->sync($request->input('categories', []));
        $product->tags()->sync($request->input('tags', []));
        if ($request->input('photo', false)) {
            if (!$product->photo || $request->input('photo') !== $product->photo->file_name) {
                if ($product->photo) {
                    $product->photo->delete();
                }
                $product->addMedia(storage_path('tmp/uploads/' . basename($request->input('photo'))))->toMediaCollection('photo');
            }
        } elseif ($product->photo) {
            $product->photo->delete();
        }

        return redirect()->route('admin.products.index');
    }

    public function show(Product $product) {
        abort_if(Gate::denies('admin_product_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $product->load('categories', 'tags');

        return view('admin.products.show', compact('product'));
    }

    public function destroy(Product $product) {
        abort_if(Gate::denies('admin_product_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $product->delete();

        return back();
    }

    public function massDestroy(MassDestroyProductRequest $request) {
        $products = Product::find(request('ids'));

        foreach ($products as $product) {
            $product->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request) {
        abort_if(Gate::denies('admin_product_create') && Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model = new Product();
        $model->id = $request->input('crud_id', 0);
        $model->exists = true;
        $media = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }

}
