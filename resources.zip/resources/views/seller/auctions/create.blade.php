@extends('layouts.seller.app')  

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header h5">
                    {{ trans('global.create') }} {{ trans('new') }} 
                    {{ trans('global.auction') }}
                    
                </div>
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form method="POST" action="{{ route('seller.auction.store') }}" enctype="multipart/form-data">
                        @method('POST')
                        @csrf
                        <div class="row flex-column flex-sm-row my-2">
                            <div class="col-sm-4">
                                <label class="form-label">{{ trans('Auction Name') }} <span class="text-danger">(*)</span></label>
                                <input type="text" class="form-control" placeholder="Auction Name" name="name" value="test123">
                                @error('name')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                            <div class="col-sm-4">
                                <label for="type" class="form-label">{{ trans('Auction Type') }} <span class="text-danger">(*)</span></label>
                                <select class="form-select" aria-label="Default select example" name="type">
                                    <option value="physical" selected>{{ trans('global.physical') }}</option>
                                    <option value="digital"> {{ trans('global.digital') }}</option>
                                </select>
                                @error('type')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                            <div class="col-sm-4">
                                <label for="category" class="form-label">{{ trans('Auction Category') }} <span class="text-danger">(*)</span></label>
                                <select class="form-select" name="category">
                                    <option value="1" selected>phones</option>
                                        @foreach($categories as $id => $category)
                                            <option value="{{ $id }}" {{ in_array($id, old('categories', [])) ? 'selected' : '' }}>{{ $category->name }}</option>
                                        @endforeach
                                </select>
                                @error('category')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>    
                        </div>
                        
                        <div class="row my-2 flex-column flex-sm-row">
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Reserve Price (USD)') }} <span class="text-danger">(*)</span></label>
                                    <input type="text" class="form-control" placeholder="$100" name="reserve_price" value="10">
                                    @error('price')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div> 
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Auction Quantity') }} <span class="text-danger">(*)</span></label>
                                    <input type="text" class="form-control" placeholder="Available stock" name="stock" value="100">
                                    @error('stock')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div> 
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Minimum Auction Increase') }}</label>
                                    <input type="text" class="form-control" placeholder="Minimum Next Increment" name="increment" value="2">
                                    @error('increment')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div> 
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Max Price/Buy Now') }} <span class="text-danger">(*)</span></label>
                                    <input type="text" class="form-control" placeholder="Available stock" name="max" value="100">
                                    @error('max')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div> 
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row my-2 flex-column flex-sm-row">
                            <div class="col-sm-3 mb-3">
                                <label for="product_measure" class="form-label">{{ trans('Auction Product Measure Unit') }} <span class="text-danger">(*)</span></label>
                                <select class="form-control" id="product_measure" name="product_measure">
                                    <option value="">None</option>
                                    <option value="Gram" selected>Gram</option>
                                    <option value="Kilogram">Kilogram</option>
                                    <option value="Litre">Litre</option>
                                    <option value="Pound">Pound</option>
                                    <option value="Custom">Custom</option>
                                </select>
                                @error('product_measure')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                            <div class="col-sm-3 mb-3">
                                <label class="form-label">{{ trans('Product Measurement') }}</label>
                                <input type="text" class="form-control" id="custom-product_measure" placeholder="Custom measure unit" name="custom_product_measure" value="">
                                @error('custom_product_measure')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row my-2 flex-column flex-sm-row">
                            <div class="col-sm-3">
                                <label class="form-label">{{ trans('Upload Picture') }} <span class="text-danger">(*)</span></label><br>
                                <input type="file" class="form-control" id="inputGroupFile02" name="picture">
                                @error('picture')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label">{{ trans('Auction Digital Product URL') }}</label>
                                <textarea class="form-control" rows="2" name="content"></textarea>
                                @error('content')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                        
                        <div class="row my-2 flex-column flex-sm-row">
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Auction Start Date') }} <span class="text-danger">(*)</span></label>
                                    <input type="datetime-local" class="form-control" name="start_time">
                                    @error('start_time')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="mb-3">
                                    <label class="form-label">{{ trans('Auction End Date') }} <span class="text-danger">(*)</span></label>
                                    <input type="datetime-local" class="form-control" name="end_time">
                                    @error('end_time')
                                        <div class="alert alert-danger" role="alert">
                                            {{ $message }}
                                        </div> 
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        <div class="row my-2 flex-column flex-sm-row">
                            <div class="mb-3 col-sm-6">
                                <label class="form-label">{{ trans('Auction Description') }} <span class="text-danger">(*)</span></label>
                                <textarea class="form-control" rows="5" name="description"></textarea>
                                @error('description')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            <div class="mb-3 col-sm-6">
                                <label class="form-label">{{ trans('Auction Buy/Return Policy*') }} <span class="text-danger">(*)</span></label>
                                <textarea class="form-control" rows="5" name="policy"></textarea>
                                @error('policy')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                        <div class="col-sm-3 my-2">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="isfeature" value="1" checked>
                                <label class="form-check-label" for="flexSwitchCheckChecked">Feature This Auction<br><small>* $10 will be charged from price</small></label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <button class="btn btn-danger my-4" type="submit">
                                {{ trans('Create Auction') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

 @endsection