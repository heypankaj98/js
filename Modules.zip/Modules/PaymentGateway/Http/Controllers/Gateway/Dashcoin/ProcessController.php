<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Dashcoin;

use App\Http\Controllers\Controller;
use Modules\PaymentGateway\Http\Controllers\Gateway\Dashcoin\DashcoinPayment;

class ProcessController extends Controller {

    public static function isNoderunning($params = array()) {
        $node = new DashcoinPayment();
        $responce = $node->isBitcoinRunning($params);
        return $responce;
    }

    public static function createNewAccount($params = array()) {
        $node = new DashcoinPayment();
        $address = $node->createNewAccount($params);
        return $address;
    }

    public static function generateAddress($params = array()) {
        $node = new DashcoinPayment();
        $address = $node->generateAddress($params);
        return $address;
    }

    public static function getBalance($params = []) {
        $node = new DashcoinPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }

    public static function getTransactionDetail($params = []) {
        $node = new DashcoinPayment();
        $fee = $node->getTransactionDetail($params);
        return $fee;
    }
    public static function GetTransactionFee($params = []) {
        $node = new DashcoinPayment();
        $fee = $node->getBalance($params);
        return $fee;
    }

    public static function getWalletBalance($params = []) {
        $node = new DashcoinPayment();
        $balance = $node->getWalletBalance($params);
        return $balance;
    }

    public static function getWalletData($params = []) {
        $node = new DashcoinPayment();
        $data = $node->getWalletData($params);
        return $data;
    }

    public static function getWalletlisttransactions($params = []) {
        $node = new DashcoinPayment();
        $balance = $node->getWalletlisttransactions($params);
        return $balance;
    }

    public static function sendToAddress($params = []) {
        $node = new DashcoinPayment();
        $status = $node->sendToAddress($params);
        return $status;
    }

    public static function sendToMany($addressesAmounts = []) {
        $node = new DashcoinPayment();
        $status = $node->sendToMany($addressesAmounts);
        return $status;
    }

    public static function getAddressStatus($address) {
        $node = new DashcoinPayment();
        $status = $node->getaddressinfo($address);
        return $status;
    }

    public static function getBlockchainInfo() {
        $node = new DashcoinPayment();
        $status = $node->getBlockchainInfo();
        return $status;
    }

}
