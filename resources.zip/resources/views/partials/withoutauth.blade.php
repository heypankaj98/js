<link href="{{ asset('///css/custom.css') }}" rel="stylesheet">
<div class="c-home-header">
<div class="c-header-top clover-navbar">
    <nav class="navbar navbar-expand-lg py-1">
        <div class="container-fluid">
           
        </div>
    </nav>
</div>


<nav class="c-header-bottom navbar navbar-expand-lg  c-bottom-
navbar">
    <div class="container-fluid">
        <div class="row w-100 align-items-center">
                <div class="col-sm-2 col-md-2 col-lg-2">
                    <a class="navbar-brand" href="/">
                        @if(session()->has('theme'))
                        <img src="{{ asset(Session::get('theme')) }}.png" height="60" alt="alt"/>
                        @else
                        <img src="{{ asset('light.png')}}" height="60" alt="alt"/>
                        @endif
                    </a>
                </div>
            <div class="col-sm-10 col-md-10 col-lg-10">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="c-nab-menu-list navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"  href="{{ route('user.cart') }}" >Cart</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"  href="{{ route('user.checkout') }}" >checkout</a>
                    </li>

                </ul>




                <ul class="c-search-wrapper navbar-nav me-auto mb-2 mb-lg-0">
                    <form class="c-search-form d-flex align-items-center" action="{{ route('search.index') }}" method="GET">
                        <div class="c-search-col">
                            <label for="searchinput" class="visually-hidden">Search</label>
                            <input type="text" class="form-control" id="searchinput" name="query" placeholder="Search...">
                        </div>
                        <div class="c-search-col mx-2">
                            <label for="searchtype" class="visually-hidden">Product Type</label>
                            <select id="searchtype" name="filter" class="form-control"  >
                                <option value="digital">Digital</option>
                                <option value="physical">Physical</option>
                                <option value="auction">Auction</option>
                            </select>
                        </div>
                        <div class="c-search-col">
                            <button class="btn btn-primary c-search-btn" type="submit">Search</button>
                        </div>
                    </form>


                </ul>
                <ul class="d-flex navbar-nav">



                    @if (auth()->check())
                    <div class="user-menu-icon">
                        <img src="{{Auth::user()->avatar}}" style="max-width:100px" alt="User Avatar">
                            <span>
                                <span class="user-menu-title">{{Auth::user()->username}}</span>
                            </span>
                            <svg  width="10" height="7" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1.5L5 5.5L9 1.5" stroke="#A2AAB4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="{{route('user.dashboard')}}">User Dashbaord</a>
                                @seller
                                <a class="dropdown-item" href="{{route('seller.dashboard')}}">Seller Dashbaord</a>
                                @endseller
                                @admin
                                <a class="dropdown-item" href="{{ route('admin.home') }}">Admin Dashbaord</a>
                                @endadmin
                                <a class="dropdown-item" href="{{route('user.profile.index')}}">Edit Profile</a>
                                <!--                    <a class="dropdown-item" href="#">Log Out</a>-->
                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf

                                    <button class="dropdown-item"  type="submit">Logout</button>
                                </form>
                            </div>
                    </div>
                    @else
                    <div class="header-intercom">
                        <div class="header-intercom-text"> <a class="link" href="{{ route('login') }}">Login</a> 
                        </div>
                    </div>
                    <div class="header-intercom">
                        <div class="header-intercom-text"> <a class="link" href="{{ route('register.show') }}" >Register</a>
                        </div>
                    </div>
                    @endif

                </ul>

            </div>
            </div>
        </div>
    </div>
</nav>
<div>
<style>
    .c-home-header .c-header-top .navbar-nav .nav-link::after{
        display:none
    }
    .c-home-header .c-header-top .navbar-nav .dropdown-menu {
        position: absolute;
        right: 0;
    }
    .c-home-header .navbar-nav .user-menu-icon .dropdown-menu {
        position: absolute;
        right: 14px;
        margin-top: 0;
        top: 35px;
    }
   .c-home-header  .header-intercom {
        border-radius: 0.5rem;
        cursor: pointer;
        padding: 0.5rem 0.75rem;
        user-select: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: 1px solid #dfe5e9;
        box-shadow: 0 1px 2px rgba(18,20,23,.06);
        margin-right: 0.5rem;
        font-family: "Inter";
        font-style: normal;
        font-weight: 500;
        font-size: 13px;
        line-height: 16px;
    }

    .c-home-header .navbar-nav {
        position: relative;
    }

    .c-home-header .dropdown:hover > .dropdown-menu {
        display: block;
    }

    .c-home-header .user-menu-icon:hover > .dropdown-menu {
        display: block;
    }
    .c-home-header .user-menu-icon img {
        width: 2rem;
        height: 2rem;
        border-radius: 100%;
        margin-right:12px
    }
    .c-home-header .user-menu-icon {
        display: flex;
        align-items: center;
        cursor: pointer;
    }
   .c-home-header  .c-user-menu-icon {
        display: flex;
        flex-direction: column;
        padding-left: 5px;
        padding-right: 5px;
        font-weight: 500;
        font-size: 14px;
    }
    .c-home-header .user-menu-subtitle {
        font-size: 12px;
        line-height: 15px;
    }
    .c-home-header .user-menu-title{
        margin-right:10px
    }
    
</style>

