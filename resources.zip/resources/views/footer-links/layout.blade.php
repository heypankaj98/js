<!doctype html>
<html lang="en" @if(session()->has('theme'))  data-bs-theme="{{ Session::get('theme') }}" @endif>
    <head> 
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/x-icon" href="{{ asset('fev.ico') }}">
        <title>{{ trans('global.site_title') }}</title>
        <link href="{{ asset('css/bootstrap-5.3/css/bootstrap.css') }}" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
        <link href="{{ asset('css/kk.css') }}" rel="stylesheet">
        <link href="{{ asset('css/main.css') }}" rel="stylesheet">
        <style>
            .bg-grey{
                background-color:grey;
            }
            .decoration{
                text-decoration:none;
            }
            .bullet{
                list-style-type:circle;
            }
        </style>
    </head>
    <body>
        <header>
            @include('partials.navbar')
        </header>
         @yield("content")
        @include('layouts.pagefooter')
    </body>
</html>