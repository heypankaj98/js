
@extends('layouts.homeapp')
@section('content')
<div class="col-md-12">
  <div class="bg-card-2 br1">
    <div class="card-header-2 w-100 mb-4 mt-2">
        Dark Allay Mail: <span>Conversation with The Administration</span>
    </div>
    <div class="content">
        <p><strong>Attention:</strong> BEFORE you start in a conversation, please read and understand the following information:</p>
        <ol>
            <li>We expect a decent tone in advance, rude language destroys credibility.</li>
            <li>Before you contact The Administration take a look into the FAQ, Marketplace Rules, and the Dark Allay Guardian. We are happy to answer questions, but not if they have already been answered in the FAQ etc.</li>
            <li>Please wait for a reply from The Administration before sending any unnecessary further messages.</li>
            <li>You can be punished if the conversation is unnecessarily spammed.</li>
        </ol>
        <p><strong>🔒 The entire Dark Allay Marketplace is multi-layer encrypted.</strong><br>
           You can also post tracking numbers and sensitive data without worrying.<br>
           Of course, you can always encrypt with PGP through Dark Allay or by yourself.</p>
    </div>
    <div class="footer">
        Start conversation with <span style="color: #ff6600;">The Administration Rulers of Dark Allay:</span>
    </div>
  <div class="card-footer mt-4 mb-4">
                    <form action="{{ route("messenger.storeTopic") }}" method="POST">
                        @csrf
                        <input type='hidden' name="recipient" value='{{$chatuser->id}}'>
                        <textarea type="text" class="form-control-textarea" name="content" placeholder="{{ trans('messages.text_placeholder') }}..."></textarea>
                        <button type="submit" class="btn btn-main mt-4">{{ trans('common.send') }}</button>
                    </form>
                </div>
</div>
</div>
@endsection