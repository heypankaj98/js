<?php

namespace Modules\Forum\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Forum\Models\Thread;
use Modules\Forum\Models\Post;
use Modules\Forum\Models\Category;
use Illuminate\View\View;
use Auth,
    Gate;

class ThreadController extends Controller {

    public function index() {
        return view('forum::forum.thread.index', compact('posts'));
        // Code logic for retrieving and returning thread index view
    }

    public function create($category) {
        $category = Category::findOrFail($category);
        return view('forum::forum.thread.create', compact('category'));
    }

    public function store(Request $request) {
        $request->validate([
            'title' => 'required|max:255',
                // Add validation rules for other fields in your form
        ]);

        $category = $request->category_id;
        $thread = new Thread();
        $thread->title = $request->input('title');
        $thread->author_id = auth()->user()->id;
        $thread->category_id = $category;
        $thread->save();
        return redirect()->route('forum.thread.index')->with('success', 'Thread created successfully.');
    }

    public function show($thread) {
        $thread = Thread::findOrFail($thread);
        $posts = $thread->posts()->get();

        return view('forum::forum.thread.index', compact('posts', 'thread'));
    }

    public function destroy(Thread $thread) {
        // Code to delete the thread
        $thread->delete();

        // Optionally, you can perform additional actions after deleting the thread

        return redirect()->back()->with('success', 'Thread deleted successfully.');
    }

    public function restore(Thread $thread) {
        // Code to restore the thread
        $thread->restore();

        // Optionally, you can perform additional actions after restoring the thread

        return redirect()->back()->with('success', 'Thread restored successfully.');
    }

    public function recent(Request $request) {
        $threadsQuery = Thread::recent()->with('category', 'users', 'lastPost', 'lastPost.author', 'lastPost.thread');

        if ($request->has('category_id')) {
            $threadsQuery->where('category_id', $request->input('category_id'));
        }

        $threads = $threadsQuery->get();

        return view('forum::forum.thread.recent', compact('threads'));
    }

   public function unread(Request $request): View {
    $threads = Thread::recent()->with('category', 'author', 'lastPost', 'lastPost.author', 'lastPost.thread');

    $accessibleCategoryIds = Category::get()->pluck('id');
//    $accessibleCategoryIds = Auth::user()->forumCategories()->pluck('id');

//    $threads = $threads->get()->filter(function ($thread) use ($request, $accessibleCategoryIds) {
//        return $thread->userReadStatus !== null && (!$thread->category->is_private || $request->user() && $accessibleCategoryIds->contains($thread->category_id) && $request->user()->can('view', $thread));
//    });

//    if ($request->user() !== null) {
//        UserViewingUnread::dispatch($request->user(), $threads);
//    }
     return view('forum::thread.unread', compact( 'threads'));

}

    public function markAsRead(MarkThreadsAsRead $request): RedirectResponse {
        $category = $request->fulfill();

        if ($category !== null) {
            Forum::alert('success', 'categories.marked_read', 1, ['category' => $category->title]);

            return new RedirectResponse(Forum::route('category.show', $category));
        }

        Forum::alert('success', 'threads.marked_read');

        return new RedirectResponse(Forum::route('unread'));
    }

}
