<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class ProductCategory extends Model implements HasMedia {

    use SoftDeletes,
        InteractsWithMedia,
        HasFactory;

    protected $appends = [
        'photo',
    ];
    public $table = 'product_categories';
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
    protected $fillable = [
        'name',
        'parent_id',
        'description',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date) {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(Media $media = null): void {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
        $this->addMediaConversion('preview')->fit('crop', 120, 120);
    }

    public function getPhotoAttribute() {
        $file = $this->getMedia('photo')->last();

        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
        }

        return $file;
    }

    public function products() {
        return $this->hasMany(Product::class, 'category');

    }



public function allChildrenProducts()
{
    $childProducts = collect();

    if ($this->subcategory) {
        foreach ($this->subcategory as $subcategory) {
            $childProducts = $childProducts->merge($subcategory->products);
            $childProducts = $childProducts->merge($subcategory->allChildrenProducts());
        }
    }

      return $childProducts->unique();
    // return $childProducts->unique()->all();
}

    public function subcategory() {
        return $this->hasMany(\App\Models\ProductCategory::class, 'parent_id');
    }

   public function parent()
{
    return $this->belongsTo(ProductCategory::class, 'parent_id'); // assuming 'parent_id' is the foreign key for the parent category
}


    public function totalProducts() {
        return $this->products()->count();
    }
    
    public function totalAllChildrenProducts()
{

    return $this->allChildrenProducts()->count();
}
public function subcategories()
    {
        return $this->hasMany(ProductCategory::class, 'parent_id', 'id');
    }

}
