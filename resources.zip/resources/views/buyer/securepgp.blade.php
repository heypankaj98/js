@extends('layouts.buyer.app')       @section('content')
<div class=" bg-card-1 security_page mt-4">
    <div class="row">
<!--<div class=" mb-4 col-md-6">-->
<!--    <div class="bg-card-2 h-100 br1">-->
<!--        <div class="card-header-2 w-100 mb-4">-->
<!--            {{ trans('common.change') }} {{ trans('auth.password') }}-->
<!--        </div>-->
        
<!--        <div class="card-body">-->
<!--            <form action="{{ route('user.profile.password') }}" method="POST" class="change_password_part">-->
<!--                @csrf-->
<!--                <div class="mb-3">-->
<!--                    <label class="mb-2">{{ trans('common.current') }} {{ trans('auth.password') }} *</label>-->
<!--                    <input type="password" class="form-control cad-my3 @error('current_password') is-invalid @enderror" name="current_password" placeholder="********">-->
<!--                    @error('current_password')-->
<!--                        <span class="text-danger">{{ $message }}</span>-->
<!--                    @enderror-->
<!--                </div>-->
<!--                <div class="mb-3">-->
<!--                    <label class="mb-2">{{ trans('common.new') }} {{ trans('auth.password') }} *</label>-->
<!--                    <input type="password" class="form-control cad-my3 @error('password') is-invalid @enderror" name="password" placeholder="********">-->
<!--                    @error('password')-->
<!--                        <span class="text-danger">{{ $message }}</span>-->
<!--                    @enderror-->
<!--                </div>-->
<!--                <div class="mb-3">-->
<!--                    <label class="mb-2">{{ trans('auth.confirm_user_password') }} *</label>-->
<!--                    <input type="password" class="form-control cad-my3  @error('current_password') is-invalid @enderror" name="password_confirmation" placeholder="********">-->
<!--                    @error('password_confirmation')-->
<!--                        <span class="text-danger">{{ $message }}</span>-->
<!--                    @enderror-->
<!--                </div>-->
<!--                <div class="col-auto">-->
<!--                    <button type="submit" class="btn btn-main mt-2">{{ trans('common.change') }} {{ trans('auth.password') }}</button>-->
<!--                </div>-->
<!--            </form>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

@if(auth()->user()->pgp_key)
    <div class=" mb-4 col-md-6">
        <div class="bg-card-2 h-100 br1">
            <div class="card-header-2 w-100 mb-4">
                {{ trans('common.current') }} {{ trans('common.pgp') }} {{ trans('common.key') }}
            </div>
            <div class="card-body">
                <textarea class="form-control-textarea" disabled rows="5">{{ auth()->user()->pgp_key ?? auth()->user()->pgp_key }}</textarea>
            </div>
        </div>
    </div>
@endif

@if(session()->has('verification_name') and session()->get('verification_name') == 'confirm_new_pgp_key')
    <div class=" mb-4 col-md-6">
        <div class="bg-card-2 h-100 br1">
            <div class="card-header-2 w-100 mb-4">
                 {{ trans('common.verify') }} {{ trans('common.pgp') }} {{ trans('common.key') }} {{ trans('common.encrypted') }} {{ trans('common.code') }}
            </div>
            <div class="card-body">
                <form action="{{ route('put.changepgpkey') }}" method="post">
                    @csrf
                    @method('PUT')
                    <textarea class="form-control-textarea"  name="pgp_key" disabled rows="5">{{ session()->get('encrypted_message') }}</textarea>
                    <div class="row">
                        <div class="col-12">
                            <label class="mt-2">{{ trans('common.verification') }} {{ trans('common.code') }} *</label>
                            <input type="text" class="form-control" name="verification_code" placeholder="{{ trans('common.verification') }} {{ trans('common.code') }}">
                        </div>
                        <div class="col-auto">
                            <button class="btn text-bg-success m-1" type="submit">{{ trans('common.verify') }}</button>
                            <a href="{{ route('cancelpgpkeychange') }}" class="btn text-bg-main mt-3">{{ trans('common.cancel')}}</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@else
    <div class=" mb-4 col-md-12">
        <div class="bg-card-2 h-100 br1">
            <div class="card-header-2 w-100 mb-4">
              {{ trans('common.pgp') }} {{ trans('common.key') }}
            </div>
            <div class="card-body">
                <form action="{{ route('post.changepgpkey') }}" method='post'>
                    @csrf
                    <h5 class="card-title mb-2">{{ trans('common.change') }} {{ trans('common.pgp') }} {{ trans('common.key') }}</h5>
    
                    @if(Session::has('error'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                    @endif
                    <textarea class="form-control-textarea" name="pgp_key" rows="5" >{{ old('pgp_key') }}</textarea>
                    <div class="info-message">* {{ trans('messages.decrypt_message') }}</div>
                    <button type="submit" class="btn btn-main mt-3">
                        {{ trans('common.add') }} {{ trans('common.pgp') }} {{ trans('common.key') }}
                    </button>
                </form>
            </div>
        </div>
    </div>
@endif

@if(auth()->user()->pgp_key)
    <div class=" mb-4 col-md-6">
        <div class="bg-card-2 h-100 br1">
            <div class="card-header-2 w-100 mb-4 ">
               {{ trans('common.2fa') }}
            </div>
            <div class="card-body">
                <h5 class="card-title">@if(auth()->user()->twofa) {{ trans('common.2fa') }} @endif</h5>
                <form class="row g-3" action="{{route('enable2fa')}}" method="POST">
                    @csrf
                    <div class="col-12">
                        <span class="f18">{{ trans('common.current') }} {{ trans('common.status') }}:</span>
                        @if(auth()->user()->twofa)
                            <span class="badge text-bg-success">{{ trans('common.on') }}</span>
                        @else
                            <span class="btn text-bg-danger">{{ trans('common.off') }}</span>
                        @endif
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-main mb-3">{{ trans('common.change') }} {{ trans('common.2fa') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class=" mb-4 col-md-6">
        @if(session()->has('verification_name') and session()->get('verification_name') == 'confirm_enable2fa_pgp_key')
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">
                     {{ trans('common.verify') }} {{ trans('common.pgp') }} {{ trans('common.key') }} {{ trans('common.encrypted') }} {{ trans('common.code') }}
                </div>
                <div class="card-body">
                    <form action="{{ route('put.changepg2fa') }}" method="post">
                        @csrf
                        @method('PUT')
                        <textarea class="form-control-textarea" name="pgp_key" disabled rows="5">{{ session()->get('encrypted_message') }}</textarea>
                        <div class="row">
                            <div class="col-12">
                                <label class="mt-2">{{ trans('common.verification') }} {{ trans('common.code') }} *</label>
                                <input type="text" class="form-control" name="verification_code" placeholder="{{ trans('common.verification') }} {{ trans('common.code') }}">
                            </div>
                            <div class="col-auto">
                                <button class="btn text-bg-main nt-3" type="submit">{{ trans('common.verify') }}</button>
                                <a href="{{ route('cancelpgpkeychange') }}" class="btn text-bg-main mt-3">{{ trans('common.cancel')}}</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        @endif
    </div>
</div>
</div>
@endif
@endsection 