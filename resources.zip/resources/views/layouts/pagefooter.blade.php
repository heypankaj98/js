 <style>
 
.footer-second {
    width: 65px;
    margin: 0 5%;
    position: relative;
}

.hover-container:hover .caard {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}


.image-conntainer {
    border-radius: 35px;
    border: 3px solid #ff7d00;
    width: 110px;
    height: 110px;
    overflow: hidden;
    background-color: black;
}
.image-conntainer img {
    max-width: 100%;
    height: auto !important;
}
.text-content.first-block{width:35%}
.text-content{
    width: 50%;
   text-align: left;
}
.text-content.first-block p:last-child {
    margin-bottom: 0;
}
.text-content.first-block p{margin-bottom:10px;}
.text-content h3{font-size:16px; color:#000; font-weight:700; margin-bottom:2px;}
.text-content p{font-size:14px; font-weight:300;letter-spacing: 1.1; margin-bottom:0px; font-family:sans-serif}
.text-content p >a{color:inherit}
.caard {
   
    display: flex;
    flex-direction: row;
    position: fixed;
    bottom: 115px; /* Positions the card below the footer section */
    right: 0;
    left:0;
    margin: 0 auto;
    max-width: 1000px;
    width: 100%; /* Adjust width as per your design */
    background: #ff0000;
    /*border: 1px solid #ccc;*/
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    opacity: 0;
    visibility: hidden;
    transform: translateY(10px); /* For smooth appearance */
    transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s ease;
    z-index: 10;
    gap:30px;
    align-items: center;
    padding: 5px 20px;
    border-radius: 20px;
}
.footer-fixed footer {
    align-items: center;
}
.footer-second .trigger-area:hover + .hover-container .caard {
    opacity: 1;
    visibility: visible;
    transform: translateY(0); /* Move into view */
}
.footer-first .trigger-area img{
   display: inline-block;
}
.trigger-area a {
    display: block;
}
.footer-first .trigger-area {
    text-align: center;
}

.footer-pro {
    margin-bottom: 5px; /* Adjust for spacing */
    max-width: 100%; /* Ensures responsive image */
    cursor: pointer;
    display: block;
}
.pre-first li.nav-item {
    margin-bottom: 0;
}
a {
    text-decoration: none;
    font-weight: bold;
    /*color: #ff202c;*/
    cursor: pointer;
}

a:hover {
    text-decoration: underline;
}


 .imge {
    width: 70px;
}
.immgg{
    display: inline !important;
   font-size: 14px; 
}
.foot-imggx {

}

     /* Scroll to Top Button */
     #scrollToTopBtn {
         display: none;
         /* Hidden by default */
         position: fixed;
         /* Fixed position */
         bottom: 20px;
         /* Position from the bottom */
         right: 30px;
         /* Position from the right */
         z-index: 99;
         /* Make sure it does not overlap */
         border: none;
         /* Remove borders */
         outline: none;
         /* Remove outline */
         background-color: #555;
         /* Dark background color */
         color: white;
         /* Text color */
         cursor: pointer;
         /* Add a mouse pointer on hover */
         padding: 15px;
         /* Some padding */
         border-radius: 10px;
         /* Rounded corners */
         font-size: 18px;
         /* Increase font size */
     }

     /* Show the button when user scrolls down */
     #scrollToTopBtn:hover {
         background-color: #000;
         /* Darker background on hover */
     }

     img.go-top-btn {
         float: right;
         width: 50px;
         background-color: #ff202c;
         border-radius: 50px;
         margin: 12px 0;
         margin-bottom: 135px;
     }

     .footer-fixed {
         position: fixed;
         bottom: 0;
         left: 0;
         width: 100%;
         margin: 0 auto;
         display: flex;
         z-index: 3;
         border-top: 1px solid #ff0000;
         background: #1a1a1a;
         padding: 10px 0;

     }

     .foot-imgg {
         position: relative;
         display: flex;
         text-align: left;
         align-items: center;
     }

     .contaainer {
         display: none;
         position: absolute;
         bottom: 100%;
         left: 0;
         color: #ffffff;
         padding: 10px;
         border-radius: 10px;
         width: 280px;
         z-index: 1;
         font-size: 14px;
         border:1px solid #ff0000;
     }

     .foot-imgg:hover .contaainer {
         display: block;
     }

     .currency-section {
         margin-bottom: 20px;
     }

     .currency-section img {
         width: 30px;
         vertical-align: middle;
     }

     .currency-section .currency {
         font-size: 24px;
         margin-left: 10px;
         vertical-align: middle;
     }

     .rate {
         margin: 10px 0;
         font-size: 16px;
     }

     .txt-clr {
         color: #ffffff;
         text-decoration: none;
     }

     .txt-clr:hover {
         text-decoration: underline;
     }

     span.crypto-s {
         background: #1a1a1a;
         padding: 4px 12px;
         border-radius: 24px;
         display: flex;
         width: max-content;
         margin: 10px 0;
         line-height: 1.6;
         align-items: center;
         gap: 8px;
         color: #fff;
         font-size: 12px;
     }

     .header {
         font-size: 18px;
     }

     .fw-custom {
         font-size: 12px;
         color: rgb(132, 142, 156);
     }

     .crypto-s img {
         width: 20px;
         height: 20px;
     }

     .icon-currency {
         display: flex;
         align-items: center;
         gap: 6px;
         margin-bottom: 5px;
         font-size: 12px;
     }
     .foot-imgg a.txt-clr {
    display:flex;
    align-items: center;
    gap: 5px;
    font-weight: 300;
    font-size: 14px;
}
.foot-imgg a.txt-clr p span {
    display: block; color:#ff7d00;
}
.foot-imgg a.txt-clr p {
    margin: 0;
    color:#fff;
}
     .icon-currency svg {
         width: 22px;
         height: 22px;
         fill: #fff;
         background: #fd7c00;
         padding: 4px;
         border-radius: 24px;
     }
 </style>
<div class="container">
<a href="#" class="go-top-btn" title="Go to Top"><img class="go-top-btn" src="{{ asset('assets/up-arrow.svg')}}"></a>
</div>
 <div class="footer-fixed">
     <div class="container">
         <footer>
             <div class="pre-first">
                   <li class="nav-item" style="list-style:none;">
                    <a class="navbar-brand m-0" href="/">
                        <img class="imge" src="{{ asset('assets/toropt.png') }}" alt="Logo" />
                    </a>
                </li>
             </div>
             <div class="footer-first">
                 <div class="footer-first-inner">
                     <div class="foot-imggx">
                        <span style="font-weight"><b>Current UTC Stamp: </b><p  class="txt-clr" style="color:#ff7d00">{{ $utcTime }}</p></span>
                     </div>
                    <div class="foot-imgg immgg">
                     
                     <a href="#" class="txt-clr"><img class="ex_rate foot-img" src="{{ asset('assets/ex_rate.png')}}" alt="PGP Keys"> <p><b>Current Crypto</b> <span>Exchange RATE</span></p></a>

                     <div class="contaainer bg-card-2">
                         <div class="header bg-card-1">
                             Rates are updated every hour.
                         </div>
                         @php
                         $exchange_rates = exchangeRates();
                         @endphp

                         <span>
                             <span class="crypto-s">
                                 <img src="{{ asset('assets/btc.png')}}" alt="BTC Logo">
                                 <span class="fw-bold">(BTC)</span>
                                 <span class="fw-custom">Bitcoin</span>
                             </span>
                             @foreach($exchange_rates as $exchange_rate)
                             @if($exchange_rate['coin_symbol'] == 'bitcoin')

                            @if($exchange_rate['currency_symbol'] == 'usd')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M160 0c17.7 0 32 14.3 32 32l0 35.7c1.6 .2 3.1 .4 4.7 .7c.4 .1 .7 .1 1.1 .2l48 8.8c17.4 3.2 28.9 19.9 25.7 37.2s-19.9 28.9-37.2 25.7l-47.5-8.7c-31.3-4.6-58.9-1.5-78.3 6.2s-27.2 18.3-29 28.1c-2 10.7-.5 16.7 1.2 20.4c1.8 3.9 5.5 8.3 12.8 13.2c16.3 10.7 41.3 17.7 73.7 26.3l2.9 .8c28.6 7.6 63.6 16.8 89.6 33.8c14.2 9.3 27.6 21.9 35.9 39.5c8.5 17.9 10.3 37.9 6.4 59.2c-6.9 38-33.1 63.4-65.6 76.7c-13.7 5.6-28.6 9.2-44.4 11l0 33.4c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-34.9c-.4-.1-.9-.1-1.3-.2l-.2 0s0 0 0 0c-24.4-3.8-64.5-14.3-91.5-26.3c-16.1-7.2-23.4-26.1-16.2-42.2s26.1-23.4 42.2-16.2c20.9 9.3 55.3 18.5 75.2 21.6c31.9 4.7 58.2 2 76-5.3c16.9-6.9 24.6-16.9 26.8-28.9c1.9-10.6 .4-16.7-1.3-20.4c-1.9-4-5.6-8.4-13-13.3c-16.4-10.7-41.5-17.7-74-26.3l-2.8-.7s0 0 0 0C119.4 279.3 84.4 270 58.4 253c-14.2-9.3-27.5-22-35.8-39.6c-8.4-17.9-10.1-37.9-6.1-59.2C23.7 116 52.3 91.2 84.8 78.3c13.3-5.3 27.9-8.9 43.2-11L128 32c0-17.7 14.3-32 32-32z" />
                                 </svg>
                                 <span class="">USD: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>

                             @elseif($exchange_rate['currency_symbol'] == 'eur')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M48.1 240c-.1 2.7-.1 5.3-.1 8l0 16c0 2.7 0 5.3 .1 8L32 272c-17.7 0-32 14.3-32 32s14.3 32 32 32l28.3 0C89.9 419.9 170 480 264 480l24 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-24 0c-57.9 0-108.2-32.4-133.9-80L256 336c17.7 0 32-14.3 32-32s-14.3-32-32-32l-143.8 0c-.1-2.6-.2-5.3-.2-8l0-16c0-2.7 .1-5.4 .2-8L256 240c17.7 0 32-14.3 32-32s-14.3-32-32-32l-125.9 0c25.7-47.6 76-80 133.9-80l24 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-24 0C170 32 89.9 92.1 60.3 176L32 176c-17.7 0-32 14.3-32 32s14.3 32 32 32l16.1 0z" />
                                 </svg>
                                 <span class="">EUR: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>
                             
                             @elseif($exchange_rate['currency_symbol'] == 'gbp')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M112 160.4c0-35.5 28.8-64.4 64.4-64.4c6.9 0 13.8 1.1 20.4 3.3l81.2 27.1c16.8 5.6 34.9-3.5 40.5-20.2s-3.5-34.9-20.2-40.5L217 38.6c-13.1-4.4-26.8-6.6-40.6-6.6C105.5 32 48 89.5 48 160.4L48 224l-16 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l16 0 0 44.5c0 17.4-4.7 34.5-13.7 49.4L4.6 431.5c-5.9 9.9-6.1 22.2-.4 32.2S20.5 480 32 480l256 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L88.5 416l.7-1.1C104.1 390 112 361.5 112 332.5l0-44.5 112 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-112 0 0-63.6z" />
                                 </svg>
                                 <span class="">GBP: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>

                             @endif
                             @endif
                             @endforeach
                         </span>
                         <span>
                             <span class="crypto-s">
                                 <img src="{{ asset('assets/xmr.png')}}" alt="XMR Logo">
                                 <span class="fw-bold">(XMR)</span>
                                 <span class="fw-custom">Monero</span>
                             </span>
                             @foreach($exchange_rates as $exchange_rate)
                             @if($exchange_rate['coin_symbol'] == 'monero')

                             @if($exchange_rate['currency_symbol'] == 'usd')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M160 0c17.7 0 32 14.3 32 32l0 35.7c1.6 .2 3.1 .4 4.7 .7c.4 .1 .7 .1 1.1 .2l48 8.8c17.4 3.2 28.9 19.9 25.7 37.2s-19.9 28.9-37.2 25.7l-47.5-8.7c-31.3-4.6-58.9-1.5-78.3 6.2s-27.2 18.3-29 28.1c-2 10.7-.5 16.7 1.2 20.4c1.8 3.9 5.5 8.3 12.8 13.2c16.3 10.7 41.3 17.7 73.7 26.3l2.9 .8c28.6 7.6 63.6 16.8 89.6 33.8c14.2 9.3 27.6 21.9 35.9 39.5c8.5 17.9 10.3 37.9 6.4 59.2c-6.9 38-33.1 63.4-65.6 76.7c-13.7 5.6-28.6 9.2-44.4 11l0 33.4c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-34.9c-.4-.1-.9-.1-1.3-.2l-.2 0s0 0 0 0c-24.4-3.8-64.5-14.3-91.5-26.3c-16.1-7.2-23.4-26.1-16.2-42.2s26.1-23.4 42.2-16.2c20.9 9.3 55.3 18.5 75.2 21.6c31.9 4.7 58.2 2 76-5.3c16.9-6.9 24.6-16.9 26.8-28.9c1.9-10.6 .4-16.7-1.3-20.4c-1.9-4-5.6-8.4-13-13.3c-16.4-10.7-41.5-17.7-74-26.3l-2.8-.7s0 0 0 0C119.4 279.3 84.4 270 58.4 253c-14.2-9.3-27.5-22-35.8-39.6c-8.4-17.9-10.1-37.9-6.1-59.2C23.7 116 52.3 91.2 84.8 78.3c13.3-5.3 27.9-8.9 43.2-11L128 32c0-17.7 14.3-32 32-32z" />
                                 </svg>
                                 <span class="">USD: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>

                             @elseif($exchange_rate['currency_symbol'] == 'eur')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M48.1 240c-.1 2.7-.1 5.3-.1 8l0 16c0 2.7 0 5.3 .1 8L32 272c-17.7 0-32 14.3-32 32s14.3 32 32 32l28.3 0C89.9 419.9 170 480 264 480l24 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-24 0c-57.9 0-108.2-32.4-133.9-80L256 336c17.7 0 32-14.3 32-32s-14.3-32-32-32l-143.8 0c-.1-2.6-.2-5.3-.2-8l0-16c0-2.7 .1-5.4 .2-8L256 240c17.7 0 32-14.3 32-32s-14.3-32-32-32l-125.9 0c25.7-47.6 76-80 133.9-80l24 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-24 0C170 32 89.9 92.1 60.3 176L32 176c-17.7 0-32 14.3-32 32s14.3 32 32 32l16.1 0z" />
                                 </svg>
                                 <span class="">EUR: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>

                             @elseif($exchange_rate['currency_symbol'] == 'gbp')
                             <span class="icon-currency">
                                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                     <path
                                         d="M112 160.4c0-35.5 28.8-64.4 64.4-64.4c6.9 0 13.8 1.1 20.4 3.3l81.2 27.1c16.8 5.6 34.9-3.5 40.5-20.2s-3.5-34.9-20.2-40.5L217 38.6c-13.1-4.4-26.8-6.6-40.6-6.6C105.5 32 48 89.5 48 160.4L48 224l-16 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l16 0 0 44.5c0 17.4-4.7 34.5-13.7 49.4L4.6 431.5c-5.9 9.9-6.1 22.2-.4 32.2S20.5 480 32 480l256 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L88.5 416l.7-1.1C104.1 390 112 361.5 112 332.5l0-44.5 112 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-112 0 0-63.6z" />
                                 </svg>
                                 <span class="">GBP: &nbsp;</span>
                                 {{ number_format($exchange_rate['rate'], 6) }}
                             </span>
                             @endif
                             @endif
                             @endforeach
                         </span>

                     </div>
                     
                     </div>



                 </div>
             </div>
           <div class="footer-second">
    <div class="trigger-area">
        <img class="footer-pro" src="{{ asset('assets/Allay-cat-logo.png') }}" alt="Footer Image">
        <a class="catt" href="#" style="color:#ff0000; font-weight:700">Alley Cat</a>
    </div>

    <div class="hover-container">
        <div class="caard">
            <div class="text-content first-block">
                <h3>The Alley Cat Private PGP Key</h3>
                <p>Always in control, always protected and updated bi-weekly.</p>
                <p  style="color:black !important; font-weight:700; font-size:16px">  <a href="{{ url('download/canary/dark_allay_canary.txt') }}">Alley Cat PGP Signed TXT Message</a></p>
            </div>
            <div class="image-conntainer">
                <img src="{{ asset('assets/d_a.png') }}" alt="Dark Alley Character" style="width:188px;">
            </div>
            <div class="text-content">
                <h3>I’m the Protector and Monarch of the Dark Alley Market</h3>
                <p>Along with my sidekick, Alley Cat, I protect our market from all technology. Rest assured that nemesis with everything that belongs to them is safe.</p>
            </div>
        </div>
    </div>
</div>


             <div class="footer-third">
                
                 <div class="footer-third-inner">
                       <div class="foot-imgg">
                         <a class="link-item" href="{{ route('pages.mirrors') }}"> <img class="mirrors foot-img icons" src="{{ asset('assets/Mirrors.png')}}" alt="Mirrors"> Mirrors</a>
                        </div>
                        <div class="foot-imgg">
                        
                         <a class="link-item" href="{{ route('aboutus') }}"> <img class="about-us foot-img icons" src="{{ asset('assets/About.png')}}" alt="About"> About Us</a>
                     </div>
                       <div class="foot-imgg">
                         
                         <a class="link-item" href="{{ route('darkrules') }}"><img class="drk-allay-rules foot-img icons" src="{{ asset('assets/Market_rules.png')}}"
                             alt="Dark Allay Rules"> Dark Allay Rules</a>
                     </div>
                      <div class="foot-imgg">
                        
                         <a class="link-item" href="{{ route('official.pgp') }}"> <img class="PGP-keys foot-img icons" src="{{ asset('assets/PGP_keys.png')}}" alt="PGP Keys"> PGP Keys</a>
                     </div>
                     
                     <div class="foot-imgg">
                         
                         <a class="link-item" href="{{ route('findus') }}"><img class="Find_us foot-img icons" src="{{ asset('assets/Find_us.png')}}" alt="Dark Allay Rules"> Find Us</a>
                     </div>
                      <div class="foot-imgg">
                         
                         <a class="link-item" href="{{ route('protector') }}"><img class="dark-allay-pro foot-img icons" src="{{ asset('assets/Prootector.png')}}"
                             alt="Dark Allay Protector"> Dark Allay Protector </a>
                     </div>
                </div>
                
         </footer>
     </div>
 </div>