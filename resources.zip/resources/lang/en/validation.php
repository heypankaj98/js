<?php
return [
    'required' => 'The :attribute field is required.',
    'min' => 'The :attribute must be at least :min characters.',
    'max' => 'The :attribute must not exceed :max characters.',
    'confirmed' => 'The :attribute confirmation does not match.',
    'attributes' => [
        'current_password' => 'Current Password',
        'password' => 'Password',
    ],
    
    'no_seller_access' => 'You do not have any Seller permission.',
    'password_invalid' => 'Password does not match.',
    'password_changed' => 'Password changed successfully.',
];