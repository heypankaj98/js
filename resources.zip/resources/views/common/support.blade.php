@php
    use Illuminate\Support\Facades\DB;
    use Carbon\Carbon;

    $userId = auth()->id(); // Get the authenticated user's ID
    $user = DB::table('users')->where('id', $userId)->first();
@endphp

@extends('layouts.homeapp')
@section('content')
<html lang="en">
<head>
    <style>
        .arrow1 { margin-top: -2px; }
        input#name { margin-left: 32px; }
        input#subject { margin-left: 21px; }
        input#email { margin-left: 35px; }
        textarea#message { width: 210px; margin-left: 9px; }
        h1 {
            background-color: #ff7d00;
            text-align: center;
            font-size: 28px;
            padding: 12px 8px;
            border-radius: 4px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    
<div class="bg-card-1 p-24">

    <h1 class="custom-title mb-4">Support - E-Commerce Website</h1>

    <div class="bg-card-2 mt-3 br1 px-3">
        <div class="card-header-2 w-100 mb-4">
            Dark Alley Market Mail: Your personal secure line to vendors and The Administration
        </div>
        <div class="card-body">
            <p>Conversations will be automatically deleted after 8 days, if no further post is posted.<br>
            The timer will be reset with every new post. You can see in the conversation when it will expire.</p>
            <p><strong>Notice:</strong> The timer will be suspended if a post was reported.</p>

            <table class="table table-bordered mt-4 table-bordered table-prd mb-2">
                <thead>
                    <tr>
                        <th>Conversation partner</th>
                        <th>Last activity date</th>
                        <th>Conversation</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            The Administration <span class="badge badge-danger">Rulers of Dark Alley Market</span>
                        </td>
                        <td>{{ $user->last_login ?? 'Never logged in' }}</td>
                        <td>
    <a href="{{ route('start_message') }}" class="btn badge">Start Conversation</a>
    @if($unreadMessagesCount > 0)
        <span class="badge badge-warning">{{ $unreadMessagesCount }}</span>
    @endif
</td>

                        <!--<td>-->
                        <!--    <a href="{{ route('start_message') }}" class="btn badge">Start: Conversation</a>-->
                        <!--</td>-->
                    </tr>
                    <tr>
                        @if ($user)
                            @php
                                $lastLogin = $user->last_login ? Carbon::parse($user->last_login) : null;
                                $now = Carbon::now();
                                $fiveDaysAgo = $now->subDays(5);
                                $daysOffline = $lastLogin ? $lastLogin->diffInDays($now) : null;
                                $lastLoginMessage = '';

                                if ($lastLogin && $lastLogin->lessThan($fiveDaysAgo)) {
                                    $lastLoginMessage = "Your last login was more than {$daysOffline} days ago.";
                                }
                            @endphp
                            
                            <td colspan="3">
                                @if ($lastLoginMessage)
                                    <p>{{ $lastLoginMessage }}</p>
                                    <p>Please notice: A customer will be informed when placing an order, how long a vendor has not been online, if this is over 5 days ago.</p>
                                    <p>It is very unlikely that a customer will then place this order with you.</p>
                                    <p>You sell non-auto-delivery items. Please always check your orders at least every 2 days; this only takes a few seconds.</p>
                                @else
                                    <p>Your last login was on: {{ $lastLogin ? $lastLogin->format('Y-m-d H:i:s') : 'Never logged in' }}</p>
                                @endif
                            </td>
                        @else
                            <td colspan="3">User not found.</td>
                        @endif
                    </tr>
                   
                </tbody>
            </table>
             <div>
                        <td colspan="3">Currently no conversations with vendors.</td>
                    </div>

            <div class="d-flex justify-content-between mt-3">
                <a href="/" class="btn btn-sm btn-main">Back to: Home</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
@endsection
