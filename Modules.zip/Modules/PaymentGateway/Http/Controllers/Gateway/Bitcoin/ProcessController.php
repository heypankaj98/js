<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Bitcoin;

use App\Http\Controllers\Controller;
use Modules\PaymentGateway\Http\Controllers\Gateway\Bitcoin\BitcoinPayment;

class ProcessController extends Controller {

    public static function isNoderunning($params = array()) {
      
        $node = new BitcoinPayment(10);
        
        $responce = $node->isBitcoinRunning($params);
        return $responce;
    }

    public static function createNewAccount($params = array()) {
        $node = new BitcoinPayment();
        $address = $node->createNewAccount($params);
        return $address;
    }

    public static function generateAddress($params = array()) {
        $node = new BitcoinPayment();
        $address = $node->generateAddress($params);
        return $address;
    }

    public static function getBalance($params = []) {
        $node = new BitcoinPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }
     public static function  getAddressBalance($params = []) {
        $node = new BitcoinPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }
   

    public static function getTransactionDetail($params = []) {
        $node = new BitcoinPayment();
        $fee = $node->getTransactionDetail($params);
        return $fee;
    }
    public static function GetTransactionFee($params = []) {
        $node = new BitcoinPayment();
        $fee = $node->getBalance($params);
        return $fee;
    }

    public static function getWalletBalance($params = []) {
        $node = new BitcoinPayment();
        $balance = $node->getWalletBalance($params);
        return $balance;
    }

    public static function getWalletData($params = []) {
        $node = new BitcoinPayment();
        $data = $node->getWalletData($params);
        return $data;
    }

    public static function getWalletlisttransactions($params = []) {
        $node = new BitcoinPayment();
        $balance = $node->getWalletlisttransactions($params);
        return $balance;
    }

    public static function sendToAddress($params = []) {
    
        $node = new BitcoinPayment();
        $status = $node->sendToAddress($params);
        return $status;
    }

    public static function sendToMany($addressesAmounts = []) {
        $node = new BitcoinPayment();
        $status = $node->sendToMany($addressesAmounts);
        return $status;
    }

    public static function getAddressStatus($address) {
        $node = new BitcoinPayment();
        $status = $node->getaddressinfo($address);
        return $status;
    }

    public static function getBlockchainInfo() {
      
        $node = new BitcoinPayment();
        $status = $node->getBlockchainInfo();
       
        return $status;
    }

}
