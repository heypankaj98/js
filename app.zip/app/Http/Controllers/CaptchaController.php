<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Intervention\Image\ImageManagerStatic as Image;

class CaptchaController extends Controller {

    public function show() {
        // Generate random rotation angles for each image
        $rotation1 = rand(0, 3) * 60;
        $rotation2 = rand(0, 3) * 60;
        $rotation3 = rand(0, 3) * 60;

        // Create three blank images with a white background
        $image1 = Image::canvas(100, 100, '#FFFFFF');
        $image2 = Image::canvas(100, 100, '#FFFFFF');
        $image3 = Image::canvas(100, 100, '#FFFFFF');

        $imagebg1 = Image::make('light.png');
        $imagebg2 = Image::make('dark.png');
        $imagebg3 = Image::make('Demo.png');

        // Resize background images to fit the circle size
        $circleSize = 60;
        $imagebg1->fit($circleSize, $circleSize);
        $imagebg2->fit($circleSize, $circleSize);
        $imagebg3->fit($circleSize, $circleSize);

        // Apply rotation to background images
        $imagebg1->rotate(-$rotation1);
        $imagebg2->rotate(-$rotation2);
        $imagebg3->rotate(-$rotation3);

        // Insert background images into each image
        $image1->insert($imagebg1, 'top-left', 20, 20);
        $image2->insert($imagebg2, 'top-left', 20, 20);
        $image3->insert($imagebg3, 'top-left', 20, 20);

        // Merge the three images into one
        $combinedImage = Image::canvas(300, 100, '#FFFFFF');
        $combinedImage->insert($image1, 'top-left');
        $combinedImage->insert($image2, 'top-left', 100);
        $combinedImage->insert($image3, 'top-left', 200);

        // Save the actual rotation values in the session
        session()->put('captcha_data', [
            'rotations' => [
                '1' => $rotation1,
                '2' => $rotation2,
                '3' => $rotation3,
            ],
            'timestamp' => now(), // Store the current timestamp
        ]);

        // Return the combined image as a response
        return Response::make($combinedImage->encode('png'))
                        ->header('Content-Type', 'image/png');
    }

    public function validateCaptcha(Request $request) {
        $captchaData = session()->get('captcha_data');

        // Check if CAPTCHA data exists
        if (!$captchaData) {
            return response()->json(['error' => 'CAPTCHA expired. Please try again.'], 400);
        }

        // Check if the CAPTCHA is within the valid time frame (e.g., 5 minutes)
        $allowedDuration = 2 * 60; // 5 minutes in seconds
        if (now()->diffInSeconds($captchaData['timestamp']) > $allowedDuration) {
            return response()->json(['error' => 'CAPTCHA expired. Please refresh.'], 400);
        }

        // Validate the user's input with stored rotations (adjust based on your input logic)
        $userRotations = $request->input('rotations');
        if ($captchaData['rotations'] === $userRotations) {
            return response()->json(['success' => 'CAPTCHA validated successfully.']);
        }

        return response()->json(['error' => 'Invalid CAPTCHA.'], 400);
    }
}
