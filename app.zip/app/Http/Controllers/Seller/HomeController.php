<?php
namespace App\Http\Controllers\Seller;

use Auth, Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{ Permission , Product };

class HomeController {

    public function index() {
        $products = Product::inRandomOrder()->get();
        
        return view('buyer.home', compact('products'));
    }
      public function profileEdit() {
        return view('seller.profile');
    }
}