@extends('layouts.seller.app')
@section('content')
<div class="container">
    <h1>Seller Requests</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Username</th>
                <th>Model Type</th>
                <th>Method</th>
                <th>Amount(usd)</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Action</th> <!-- Add a header for actions -->
            </tr>
        </thead>
        <tbody>
            @foreach ($payments as $payment)
                <tr>
               <td>{{ $payment->user ? $payment->user->username : 'N/A' }}</td>

                    <td>{{ $payment->model_type }}</td>
                    <td>{{ $payment->method }}</td>
                    <td>{{ $payment->amount }}</td>
                    <td>{{ $payment->status }}</td>
                    <td>{{ $payment->created_at }}</td>
                    <td>
   @if($payment->user && $payment->user->isSeller)
    <p>Approved</p>
@else
    <form action="{{ route('admin.approve.seller', $payment->id) }}" method="POST">
        @csrf
        <button type="submit" class="btn btn-primary">Approve as Seller</button>
    </form>
@endif

</td>

                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
