<?php ?>
@foreach($subcategories as $subcategory)

<div class="content">
    <ul class="p-2 " >
        <li class=" border-bottom list-group-item p-2 mb-0">
            <p class="mb-0">   {{  $subcategory->name }}</p>
        </li>

    </ul>
</div>

@if(count($subcategory->subcategory))
    @include('partials.subcategory-option',['subcategories' => $subcategory->subcategory])
@endif
@endforeach