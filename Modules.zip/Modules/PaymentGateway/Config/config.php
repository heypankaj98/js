<?php

return [
    'name' => 'PaymentGateway'
];
