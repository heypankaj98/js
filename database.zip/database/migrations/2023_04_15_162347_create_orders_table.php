<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration {

    public function up() {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('order_id');
            $table->tinyInteger('isauction')->unsigned()->default(0)->limit(1);
            $table->bigInteger('product_id');
            $table->bigInteger('buyer_id');
            $table->bigInteger('seller_id');
            $table->enum('payment_method', ['Bitcoin', 'Monero','Litecoin', 'BitcoinMultiSign'])->default('Bitcoin');
            $table->text('address');
            $table->smallInteger('quantity');
            $table->string('status', 10)->default('waiting');
            $table->decimal('total');
            $table->decimal('total_crypto', 8, 8)->default(00000000);
            $table->smallInteger('deleted')->nullable();
            $table->date('delivery_expected_at')->nullable();
            $table->date('delivered_at')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    public function down() {
        Schema::dropIfExists('orders');
    }

}
