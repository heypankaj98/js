<?php

namespace Coderflex\LaravelTicket\Database\Factories;

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up() {

        Schema::create('advertisement', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name', 60);
            $table->enum('size', ['540x984', '779x80', '300x250']);
            $table->string('redirect_url', 191)->nullable();
            $table->integer('impression')->nullable();
            $table->integer('click')->nullable();
            $table->string('status', 191)->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }
};
