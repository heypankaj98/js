<div class="mt-4 br1 br-4 p-24">
    <form method="POST" action="{{ route("seller.products.update", $product->id) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="col-lg-12">
            <div class="">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.edit') }} {{ trans('common.physical') }} {{ trans('common.product') }}
                </div>
                <div class="card-body">
                    
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header">
                                <label for="general_info" class="accordion-title accordion-button">
                                    {{ trans('common.general') }} {{ trans('common.details') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="product_name" class="pb-2 fw-bold label_main">
                                                {{ trans('common.product') }} {{ trans('common.name') }}*:
                                            </label>
                                            <input type="text" class="form-control" id="product_name" placeholder="Product Name" name="name" value="{{ old('name', $product->name) }}">
                                            @error('name')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                            @enderror
                                        </div>
                                        <div class="col mb-3">
                                            <label class="pb-2 fw-bold label_main">
                                                {{ trans('common.category') }}*:
                                            </label>
                                             <select class="form-select form-control py-0" id="Category" aria-label="Default select example" name="category">
                                                @foreach($categories as  $category)
                                                    <?php $dash = ''; ?>
                                                    <option value="{{$category->id}}" @if($category->parent_id  === null) disabled @endif>
                                                        {{ $category->name }}
                                                    </option>
                                                    @if(count($category->subcategory))
                                                        @include('partials.subcategorylist',['subcategories' => $category->subcategory])
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('category')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label class="pb-2 fw-bold label_main">
                                                {{ trans('common.product') }} {{ trans('common.details') }}*:
                                            </label>
                                            <textarea class="form-control form-control-textarea" rows="5" name="description">{{ old('description', $product->description) }}</textarea>
                                            @error('description')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                            @enderror
                                        </div>
                                        <div class="col mb-3">
                                            <label class="pb-2 fw-bold label_main">
                                               {{ trans('common.product') }} {{ trans('common.buy') }}/{{ trans('common.return') }} {{ trans('common.policy') }}*:
                                            </label>
                                            <textarea class="form-control form-control-textarea" rows="5" name="policy">{{ old('policy', $product->policy) }}</textarea>
                                            @error('policy')
                                            <div class="alert alert-danger" role="alert">
                                                {{ $message }}
                                            </div> 
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header">
                                <label for="Pricing-info" class="accordion-title accordion-button">{{ trans('common.price') }}</label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <table class="table table-prd table-bordered">
                                        <thead>
                                            <tr>
                                                <th scope="col">{{ trans('common.qty') }}</th>
                                                <th scope="col">{{ trans('common.discount') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @if($product->wdiscount)
                                                @php
                                                    $wdiscount = unserialize($product->wdiscount);
                                                @endphp
                        
                                                @foreach ($wdiscount as $quantity => $discount)
                                                    <tr>
                                                        <th>
                                                            <input type="number" class="form-control my-2" min="0" value="{{ old('wquantity.' . $quantity, $quantity) }}" name="wquantity[{{ $quantity }}]">
                                                            @error('wquantity.' . $quantity)
                                                                <div class="alert alert-danger" role="alert">
                                                                    {{ $message }}
                                                                </div>
                                                            @enderror
                                                        </th>
                                                        <td>
                                                            <input type="number" class="form-control my-2" min="0" value="{{ old('wdiscount.' . $quantity, $discount) }}" name="wdiscount[{{ $quantity }}]">
                                                            @error('wdiscount.' . $quantity)
                                                                <div class="alert alert-danger" role="alert">
                                                                    {{ $message }}
                                                                </div>
                                                            @enderror
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                                <tr>
                                                    <th>
                                                        <input type="number" class="form-control my-2" min="0" name="wquantity[]">
                                                        @error('wquantity')
                                                            <div class="alert alert-danger" role="alert">
                                                                {{ $message }}
                                                            </div>
                                                        @enderror
                                                    </th>
                                                    <td>
                                                        <input type="number" class="form-control my-2" min="0" name="wdiscount[]">
                                                        @error('wdiscount')
                                                            <div class="alert alert-danger" role="alert">
                                                                {{ $message }}
                                                            </div>
                                                        @enderror
                                                    </td>
                                                </tr>
                                        </tbody>
                                    </table>
                                    <div class="row">
                                        <div class="col">
                                            <div class="my-3">
                                                <label for="description" class="form-label mb-0">{{ trans('common.price') }}</label>
                                                <input type="text" class="form-control" name="price" value="{{ old('price', $product->price) }}">
                                                @error('price')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="my-3">
                                                <label for="description" class="form-label mb-0">{{ trans('Quantity') }}</label>
                                                <input type="text" class="form-control" id="product_name" placeholder="Product Unit" name="stock" value="{{ old('stock', $product->stock) }}">
                                                @error('stock')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header">
                                <label for="shipping-method" class="accordion-title accordion-button">
                                    {{ trans('common.shipping') }} {{ trans('common.method') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="shipping_methods">
                                                    {{ trans('common.shipping') }} {{ trans('common.method') }}
                                                </label>
                                                <select name="shipping_methods[]" id="shipping_methods" class="form-control form-control-textarea mb-3" multiple required>
                                                    @foreach ($shippingMethods as $method)
                                                        @php
                                                            $selected = is_array(unserialize($product->shipping_methods)) && in_array($method->id, unserialize($product->shipping_methods));
                                                        @endphp
                                                        <option value="{{ $method->id }}" {{ $selected ? 'selected' : '' }}>
                                                            {{ $method->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            @if ($shippingMethods->isNotEmpty())
                                                <table class="table table-prd table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>{{ trans('common.name') }}</th>
                                                            <th>{{ trans('common.price') }}</th>
                                                            <th>{{ trans('common.delivery') }} {{ trans('common.time') }}</th>
                                                            <th>{{ trans('common.countries') }}</th>
                                                            <th>{{ trans('common.active') }}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($shippingMethods as $shippingMethod)
                                                            <tr>
                                                                <td>{{ $shippingMethod->name }}</td>
                                                                <td>{{ $shippingMethod->is_free ? 'Free' : '$' . number_format($shippingMethod->price, 2) }}</td>
                                                                <td>{{ $shippingMethod->delivery_time }} days</td>
                                                                <td>{{ is_array($shippingMethod->countries) ? implode(', ', $shippingMethod->countries) : $shippingMethod->countries }}</td>
                                                                <td>{{ $shippingMethod->availability }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header">
                                <label for="Additional-info" class="accordion-title accordion-button">
                                    {{ trans('common.details') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col mb-3">
                                                <label for="product_measure" class="form-label">
                                                    {{ trans('common.product') }} {{ trans('common.measurement') }}
                                                </label>
                                                <select class="form-control px-0" id="product_measure" name="product_measure">
                                                    <option value="">{{ trans('common.no') }}</option>
                                                    <option value="Gram" {{ old('product_measure', $product->product_measure) == 'Gram' ? 'selected' : '' }}>{{ trans('common.gram') }}</option>
                                                    <option value="Kilogram" {{ old('product_measure', $product->product_measure) == 'Kilogram' ? 'selected' : '' }}>{{ trans('common.kilogram') }}</option>
                                                    <option value="Litre" {{ old('product_measure', $product->product_measure) == 'Litre' ? 'selected' : '' }}>{{ trans('common.litre') }}</option>
                                                    <option value="Pound" {{ old('product_measure', $product->product_measure) == 'Pound' ? 'selected' : '' }}>{{ trans('common.pound') }}</option>
                                                    <option value="Custom" {{ old('product_measure', $product->product_measure) == 'Custom' ? 'selected' : '' }}>{{ trans('common.custom') }}</option>
                                                </select>
                                                @error('product_measure')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div>
                                                @enderror
                                            </div>
                                            <div class="col mb-3">
                                                <label for="custom-product_measure" class="form-label">
                                                    {{ trans('common.custom') }} {{ trans('common.product') }} {{ trans('common.measurement') }}
                                                </label>
                                                <input type="text" class="form-control" id="custom-product_measure" name="custom_product_measure" value="{{ old('custom_product_measure', $product->custom_product_measure) }}">
                                                @error('custom_product_measure')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="accordion-item mb-3">
                                <h2 class="accordion-header">
                                    <label for="Product-info" class="accordion-title accordion-button">
                                        {{ trans('common.product') }} {{ trans('common.photo') }}
                                    </label>
                                </h2>
                                <div class="accordion-content">
                                    <div class="accordion-body">
                                        <div class="col">
                                            <label class="form-label">{{ trans('common.photo') }}</label><br>
                                            <input type="file" class="form-control p-2" id="inputGroupFile02" name="picture">
                                            @error('picture')
                                            <div class="alert alert-danger" role="alert">
                                                {{ $message }}
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if ($product->photo)
                                <div class="col-3 d-inline-block">
                                    <img class="w-100 object-fit-covern br-4" src="{{ $product->photo->getUrl('thumb') }}" alt="{{ $product->name }}">
                                </div>
                            @endif
                        </div>
                        <div class="col mt-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="isfeature" value="1" {{ $product->isfeature ? 'checked' : '' }}>
                                <label class="form-check-label" for="flexSwitchCheckChecked">
                                    {{ trans('common.feature') }} {{ trans('common.product') }}
                                </label>
                            </div>
                        </div>
                        <input type="hidden" name="type" value="physical">
                        <button type="submit" class="btn btn-main mt-3">
                            {{ trans('common.edit') }} {{ trans('common.product') }}
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>