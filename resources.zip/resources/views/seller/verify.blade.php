@extends('layouts.seller.app')     
@section('content')

<div class="container mt-4">
<form action="{{ route('seller.store') }}" method="POST">
    @csrf
        <div class="row mb-3">
            <div class="col">
                <label for="market_placename" class="card-header-2 w-100 mb-2">Marketplace Name</label>
                <input type="text" class="form-control title1 mb-2" id="market_placename" name="market_placename" required>
                @error('market_placename') 
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
            <div class="col">
                <label for="seller_name" class="card-header-2 w-100 mb-2">Name (Selling/Seller)</label>
                <input type="text" class="form-control mb-2" id="seller_name" name="seller_name" required>
                @error('seller_name') 
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
            <div class="col">
                <label for="sales" class="card-header-2 w-100 mb-2">Sales</label>
                <input type="number" class="form-control mb-2" id="sales" name="sales" required>
                @error('sales') 
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
            <div class="col">
                <label for="rating" class="card-header-2 w-100 mb-2">Rating</label>
                <input type="number" class="form-control mb-2" id="rating" name="rating" step="0.1" min="0" max="5" required>
                @error('rating') 
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

@if(session('success'))
    <div class="alert alert-success mt-4">
        {{ session('success') }}
    </div>
@endif

@endsection
