<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Product;
use App\Models\ProductCategory;
use Illuminate\Support\Facades\Storage;

class SearchController extends Controller {

   public function index(Request $request)
{
    $validator = Validator::make(request()->all(), [
        'query' => 'required|string|max:255',
        'filter' => 'string',
    ]);

    if ($validator->fails()) {
        return redirect('/')->withErrors($validator);
    }

    $categories = ProductCategory::whereNull('parent_id')->get();
    $query = $request->input('query');
    $filter = $request->input('filter');
    $queryBuilder = Product::query();

    if (!empty($query)) {
        $queryBuilder->where('name', 'LIKE', '%' . $query . '%');
    }

    if (!empty($filter) && $filter !== 'all') {
        $queryBuilder->where('type', $filter);
    }

    Storage::disk('local')->append('searches.txt', $query);
    Storage::disk('local')->append('filter.txt', $filter);

    $results = $queryBuilder->paginate(config('settings.paginate'));

    return view('common.search', compact('results', 'query', 'filter', 'categories'));
}


    public function showProductsByCategory(ProductCategory $category) {
        if (!$category) {
            abort(404);
        }
   
       if ($category->subcategory->count() > 0) {
        // Category is a parent category
        $products = $category->allChildrenProducts();
    } else {
        // Category is a child category
        $products = $category->products()->paginate(config('settings.paginate'));
    }
        // $products = $category->products()->paginate(config('settings.paginate'));
        
      
        return view('common.category_search', compact('products', 'category'));
    }

}
