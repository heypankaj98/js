<?php

namespace App\Models;

use Spatie\MediaLibrary\HasMedia;
use Spatie\Activitylog\LogOptions;
use Spatie\MediaLibrary\InteractsWithMedia;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model {

    use InteractsWithMedia;

    protected $fillable = [
        'title',
       'message', 
       'status',
       'priority',
       'assigned_to',
       'photo',
       'catagery'
      
    ];

    public function getActivitylogOptions(): LogOptions {
        return LogOptions::defaults()
                        ->logFillable();
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    /**
     * Get Assigned To User RelationShip
     */
    public function assignedToUser() {
        return $this->belongsTo(User::class);
    }

    /**
     * Get Messages RelationShip
     */
    public function messages(){
        $tableName = config('laravel_ticket.table_names.messages', 'messages');

        return $this->hasMany( TicketMessage::class,'ticket_id');
    }

    /**
     * Get Categories RelationShip
     */
    public function categories() {
        
        
         return $this->belongsTo(TicketCategory::class);
//        $table = 'ticket_categories';
//
//        return $this->belongsToMany(
//                        TicketCategory::class,
//                      
//        );
    }

    /**
     * Get Labels RelationShip
     */
    public function labels() {
//        $table = config('laravel_ticket.table_names.label_ticket', 'label_ticket');

           return $this->belongsTo(TicketLabel::class);
//        return $this->belongsToMany(
//                        Label::class,
//                        $table['table'],
//                        $table['columns']['ticket_foreign_id'],
//                        $table['columns']['label_foreign_id'],
//        );
    }

    /**
     * Get the table associated with the model.
     *
     * @return string
     */
    public function getTable() {
        return config(
                'laravel_ticket.table_names.tickets',
                parent::getTable()
        );
    }

}
