@extends('layouts.homeapp')     @section('content')

<div class="col-md-12 my-4">
    @if (session('success'))
    <div id="alert_message" class="alert alert-success alert-block">
        <strong>{{session('success')}}</strong>
    </div>
    @elseif(session('error'))
    <div id="alert_message" class="alert alert-danger alert-block">
        <strong>{{ session('error') }}</strong>
    </div>
    @endif
</div>

<h2>Auction : #{{ $auction->id }}</h2>
<div class="super_container">
    <div class="single_product">
        <div class="container-fluid" style="padding: 11px;">
            <div class="row">
                <div class="col-lg-2 order-lg-1 order-2">
                    <ul class="image_list">
                        @if($auction->photo)
                            <img class="w-100 object-fit-covern border rounded " src="{{ $auction->photo->getUrl('thumb') }}" alt="{{ $auction->name }}">
                        @else
                            <img class="w-100 object-fit-covern border rounded " src="{{ asset('assets/img/product-default.jpg')}}" alt="{{ $auction->name }}">
                        @endif
                    </ul>
                </div>
                <div class="col-lg-4 order-lg-2 order-1">
                    <div class="image_selected">
                        @if($auction->photo)
                            <img class="w-100 object-fit-covern border rounded" src="{{ $auction->photo->getUrl('preview') }}" alt="{{ $auction->name }}">
                        @else
                            <img class="w-100 object-fit-covern border rounded" src="{{ asset('assets/img/product-default.jpg')}}" alt="{{ $auction->name }}">
                        @endif
                    </div>
                </div>
                <div class="col-lg-6 order-3">
                    <div class="product_description">
                        <nav>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">{{ trans('global.home') }} </a></li>
                                <li class="breadcrumb-item active"> {{ trans('global.auctions') }} </li>
                            </ol>
                        </nav>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <h2 class="display-5">{{ ucfirst($auction->name) }}</h2> 
                            </div>
                            <div class="col">
                               {{ trans('global.seller') }}  
                                <a href="{{ route('seller.profile', $auction->seller->username) }}" class="btn btn-dark">{{ $auction->seller->username }}</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <span class="badge bg-success">{{ trans('global.bitcoin') }} </span>
                                <span class="badge bg-warning">  {{ trans('global.monero') }}   </span>
                            </div>
                        <hr>
                        <div class="row border-secondary">

                            @if(isset($diff))
                            <label> {{ trans('global.auction_will_be') }} </label>    
                            <div class='mt-2' id="timer">
    
                                <div class="days mx-2">
                                    <div class="numbers display-5">{{ $diff->d }}</div>  {{ trans('global.days') }}
                                </div>
                                <div class="hours">
                                    <div class="numbers display-5">{{ $diff->h }}</div> {{ trans('global.hours') }} 
                                </div>
                                <div class="minutes mx-2">
                                    <div class="numbers display-5">{{ $diff->i }}</div> {{ trans('global.minutes') }} 
                                </div>
                                <div class="seconds"> 
                                    <div class="numbers display-5">{{ $diff->s }}</div> {{ trans('global.seconds') }}  
                                </div>
                            </div>
                            @else
                            <div class='mt-2' id="timer">
                                <div class="col-lg-10 bg-danger display-5"> {{ trans('global.auction_is_closed') }} </div>
                            </div>
                            @endif

                        </div>
                        <hr>
                        <div class="row border-secondary">
                            <label>Current Price</label>
                            <span class="display-1 border-gray-200">
                                {{ convertCurrency($auction->current_price + ($auction->increment ?? 0), request()->currency ) }}  {{ request()->currency }} 
                            </span>
                            <label class="btn btn-warning col-5">{{ trans('global.reserve_price') }} {{ convertCurrency($auction->reserve_price, request()->currency ) }} {{ request()->currency }} </label>
                        </div>
                        <hr>

                        @if($auction->status == "active")
                        <div class="row">
                            <div class="product_quantity">
                                <form action="{{ route('user.auction.bid.buy', $auction->id) }}" method="POST">
                                    @csrf
                                    <strong class="col-6">{{ trans('global.place_a_new_bid') }} </strong>
                                    <br>
                                    <input class="col-6 h20 btn border-primary" type="number" min="{{ $auction->current_price + ($auction->increment ?? 0) }}" max="{{ $auction->max ?? 0 }}" step="{{ $auction->increment ?? 0 }}" value="{{ $auction->current_price + ($auction->increment ?? 0) }}" name="price">
                                    <br>
                                    <button type="submit" class="col-6 btn btn-primary h20 mt-2"> {{ trans('global.bid_now') }} </button>
                                </form>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="product_quantity">
                                <form action="{{ route('user.auction.buy', $auction->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="col-6 btn btn-success h20">{{ trans('global.buy_now_on') }} {{ $auction->max }} {{ request()->currency }}  </button>
                                </form>
                            </div>
                        </div>
                        
                        <hr>
                        @endif

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>{{ trans('global.sr_no') }} </th>
                                    <th>{{ trans('global.bid_price') }}</th>
                                    <th>{{ trans('global.bidder') }} </th>
                                    <th>{{ trans('global.bid_time') }} </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach( $bids as $i  => $bid)
                                <tr>
                                    <th>{{$i+1}}</th>
                                    <td> {{ convertCurrency($bid->amount, request()->currency ) }}  {{ request()->currency }}</td>
                                    <td>{{$bid->bidder->username}}</td>
                                    <td>{{$bid->updated_at}}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>
<ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Product details</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Product ratings</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="false">product reviews</button>
    </li>

</ul>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
        <p> {{ $auction->description}}</p>

    </div>
    <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">...</div>
    <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">...</div>
    <div class="tab-pane fade" id="disabled-tab-pane" role="tabpanel" aria-labelledby="disabled-tab" tabindex="0">...</div>
</div>

@endsection 