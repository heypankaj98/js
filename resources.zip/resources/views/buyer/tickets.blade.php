@extends('layouts.buyer.app')   @section('content')

<div class="bg-card-1 p-24 br1 mt-4">
    <div class="">
        <div class="">
            <div class="card-header-buyer">
                {{ trans('common.all') }} {{ trans('common.user') }} {{ trans('common.tickets') }}
            </div>
            <div class="card-body">
                <a class="btn btn-main w-max-c mb-3" href="{{ route('user.tickets.create') }}">
                    {{ trans('common.create') }} {{ trans('common.new') }} {{ trans('common.ticket') }}
                </a>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Product">
                            <thead>
                                <tr class="bg-light">
                                    <th>{{ trans('common.title') }}</th>
                                    <th>{{ trans('common.author') }}</th>
                                    <th>{{ trans('common.status') }}</th>
                                    <th>Solve/Unsolve</th>
                                    <th>Lock/Unlock</th>
                                    <th>{{ trans('common.priority') }}</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                @forelse($tickets as $ticket)
                                    <tr>
                                        <td>
                                      <a href="{{ route('user.tickets.show', $ticket) }}" class="text-decoration-none">
                                                {{ $ticket->title }}
                                            </a>
                                            
                                        </td>
                                        <td>
                                            {{ $ticket->user->username }}
                                        </td>
                                        <td>
                                            {{ $ticket->status }}
                                        </td>
                                        <td>
@if ($ticket->is_resolved == 1)
    SolveTicket
@else
    UnsolveTicket
@endif

                                            
                                        </td>
                                                                                <td>
@if ($ticket->is_locked == 1)
   Lock
@else
  Unlock
@endif
     
                                        </td>
                                        <td>
                                            {{ $ticket->priority }}
                                        </td>
                                        <td class="text-center">
                                            <!--<div class="d-inline-block">-->
                                            <!--    <a class="btn btn-primary" href="{{ route('user.tickets.edit', $ticket) }}">-->
                                            <!--        {{ trans('common.edit') }}-->
                                            <!--    </a>-->
                                            <!--</div>-->
                                            <div class="d-inline-block text-center">
                                            <a class="btn btn-main btn-sm" href="{{ route('user.tickets.show', $ticket) }}">
                                                  Show
                                                </a>
                                               
                                                    </div>
                                            <!--<div class="d-inline-block">-->
                                            <!--    <form action="{{ route('user.tickets.destroy', $ticket) }}" method="POST" onsubmit="return confirm('Are you sure?')" style="display: inline-block;">-->
                                            <!--        @csrf-->
                                            <!--        @method('DELETE')-->
                                            <!--        <button type="submit" class="btn btn-danger">{{ trans('common.delete') }}</button>-->
                                            <!--    </form>-->
                                            <!--</div>-->
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="100%">{{ trans('common.no') }} {{ trans('common.tickets') }}.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection