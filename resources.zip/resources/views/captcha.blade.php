<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Captcha</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('assets/Dark_Alley_Logo.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <style>
        body {
            background-color: #000 !important;
            font-family: "Inter", sans-serif;
            margin: 0px;
        }

        .submit-btn {
            margin-top: 300px;
            padding: 12px 30px;
            font-size: 12px;
            font-weight: 600;
            border: 1px solid #ff0000;
            background-color: #272727;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            transition: visibility 0s 60s, opacity 0s 60s;
            /* Hide after 60 seconds */
            animation: disappear 60s forwards;
            position: relative;
        }
        .submit-btn::after{
            content: '';
            height: 300px;
            width: 1px;
            position: absolute;
            top: -300px;
            left: 50%;
            background: #ff0000;
        }

        @keyframes disappear {
            0% {
                opacity: 1;
                visibility: visible;
            }

            99.99% {
                opacity: 1;
                visibility: visible;
            }

            100% {
                opacity: 0;
                visibility: hidden;
            }
        }

        .m-0 {
            margin: 0;
        }

        .timer {
            border: 1px solid #ff0000;
            border-radius: 8px;
            font-weight: 700;
        }

        .image_capthca.image_capthca12 svg text{
            color: #fff; margin:0 10px 2px 10px;
          
        }
.image_capthca.image_capthca12 svg line {
  width: 18px;
  display: inline-block;
  background: red;
  height: 1px;
  margin-left: -23px;
  margin-top: 20px;
}
        .flex.justify-center.self-center {
            background-color: #0f0f0f;
        }


        .phishing-row {
            display: flex;
        }
        .phishing-logo-wrapper.text-center {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
}
.image_capthca.image_capthca12 {
    margin-top: -60px;
}
        
.phishing-row.top-row-box {
    height: 40vh; min-height: 270px;
}
.factor-deatils{
     height: calc(60vh - 36.8px);     min-height: 390px;
}
        .phishing-col {
            width: 65%;
        }

        .phishing-col:nth-child(2) {
            width: 15%;
        }

        .phishing {
            width: 100%;
            background-color: #000;
        }

       @media all and (max-width:1580px) {
           .phishing-col:nth-child(2) {
            width: 18%;
        }
       } 

        .hidden-desktop {
            display: none;
        }

        .phishing-heading h3 {
            padding: 10px 0 !important;
        }

        .phishing-heading-2 {
            margin: 0 24px 0 auto;
            width: max-content;
        }

        .phishing-heading-3 {
            margin: 0 auto 0 24px;
            width: max-content;
        }

        @media(min-width:2400px) {
            .phishing-col {
                width: 48%;
            }

            .phishing-col:nth-child(2) {
                width: 15%;
            }
        }

        .phishing-col.mobile-disply-none.phishing-border {

            border-left: 1px solid #ff0000 !important;
            border-right: 1px solid #ff0000 !important;
        }

        .phishing-row.para1.phishing-heading {
            padding: 0 !important;
        }

        .image_capthca svg {
            width: 140px;
            height: auto;
            object-fit: contain;
        }

        /* Mobile first styles */
        @media only screen and (max-width: 768px) {
            .expire {
                width: 80% !important;
            }

            .hidden-desktop {
                display: block;
            }

            .phishing-heading {
                padding: 10px 0 !important;
                margin: 30px 0;
            }

            .mobile-disply-none {
                display: none !important;
            }

            .phishing-col.text-center.line-red {
                border-left: 0 !important;
                border-right: 0 !important;
            }

            .submit-btn {
                margin: 20px 0 !important;
            }

            .phishing-col {
                width: 100%;
                display: block;
            }

            .image_capthca svg {
                height: 100px;
            }

            .phishing-col:nth-child(2) {
                width: 100%;
            }

            .phishing-row {
                flex-flow: column;
                height: auto;
            }

            .phishing-col.line-red {
                border-left: 0 !important;
                border-right: 0 !important;
            }
        }

        /* Tablet and above */
        @media only screen and (min-width: 769px) and (max-width: 1024px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 140px;
            }

            .space-y-6.text-center {
                margin-left: 110px;
            }
        }

        /* Small desktop and above */
        @media only screen and (min-width: 1024px) and (max-width: 1199px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 190px;
            }

        }

        /* Large desktop and above */
        @media only screen and (min-width: 1200px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 175px;
            }

            .space-y-6.text-center {
                margin-left: 150px;
            }
        }

        /* Extra large desktop */
        @media only screen and (min-width: 1440px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            he {
                margin-top: 4.8px !important;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 225px;
            }

            .space-y-6.text-center {
                margin-left: 195px;
            }

        }

        /* 1441px to 1600px */
        @media only screen and (min-width: 1441px) and (max-width: 1600px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 270px;
            }

            .space-y-6.text-center {
                margin-left: 240px;
            }
        }

        /* 1601px to 1800px */
        @media only screen and (min-width: 1601px) and (max-width: 1800px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .space-y-6.text-center {
                margin-left: 240px;
            }
        }

        /* 1701px to 2048px */
        @media only screen and (min-width: 1701px) and (max-width: 2048px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 325px;
            }

            .space-y-6.text-center {
                margin-left: 290px;
            }

        }

        /* 2049px to 2561px */
        @media only screen and (min-width: 2049px) and (max-width: 2561px) {
            .container34 {
                width: 100%;
                background-color: #0f0f0f;
                display: flex;
            }

            .slide-left-ani:nth-child(2) {
                padding-left: 445px;
            }

            .space-y-6.text-center {
                margin-left: 415px;
            }

            .image_capthca {
                padding-left: 0px;
            }
        }

        /* Large desktop and above */
        @media only screen and (min-width: 768px) {
            .container {
                flex-wrap: wrap;
                /* Allow containers to wrap on smaller screens */
            }

            .form-container {
                width: 45%;
                /* Adjust width for larger screens */
                margin-bottom: 0;
                /* Remove bottom margin for better alignment */
            }
        }

        hr {
            border: 1px solid #ff0000;
            /*margin-top: 0.7vh;*/
            margin-top: 4.9px
        }

        hr.\32 sec {
            /*margin-top: 2.7vh;*/
            margin-top: 24px;
        }

        .close {
            text-align: center;
        }

        .slide-left-ani .p-12.bg-white\/10.mx-auto.rounded-3xl.w-full.shadow-base-500\/10 {
            background-color: transparent;
        }

        .container34 {
            width: 100%;
            .space-y-6.text-center background-color: #0f0f0f !important;
            display: flex;
            height: 100vh;
        }

        .phishing-img {
            width: 100%;
            height: 90px;
            display: block;
            margin: 0 auto;
            margin-top: 0;
            object-fit: contain;
            padding-top: 15px;
        }

        .select-link {
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 23px !important;
            text-align: center;
            text-transform: uppercase;
            background: #1a1e23;
            border: 1.5px solid #525b63;
            color: #e1e1e1;
            font-size: 16px;
            margin: 1px;
            width: 35px;
            height: 32px;

        }

        .lower-main {
            width: 100%;
            height: auto;
        }

        .first-in {
            margin-top: -45px;

            width: 50%;
            float: left;
            justify-content: center;
            margin-bottom: 20px;
        }

        .second-inn {
            text-align: center;
            width: 50%;
            float: right;
            justify-content: center;
            margin-bottom: 20px;
        }

        /*     .img-ima-cap {*/
        /*    height: 242px;*/
        /*    margin-top: 33px;*/
        /*    width: 205px;*/
        /*margin-left: 15.5vw;*/
        /*    background-color: #0f0f0f;*/
        /*}*/
        .lower-btn {
            clear: both;
            text-align: center;
            margin-top: 20px;
        }

        .slide-left-ani {
            padding-top: 0px;
            color: white;
            font-size: 12px;
            margin-bottom: 12px;
        }

        .slide-left-ani:nth-child(2) {

            padding-top: 79px;
        }

        .second-inn {
            margin-top: 3px;

        }

        .para1 {
            text-align: center;
            border-top: 1px solid #ff0000 !important;
            padding-top: 3px !important;
            padding-bottom: 3px !important;
            border-bottom: 1px solid #ff0000 !important;
        }

        .line-red {
            border-left: 1px solid #ff0000 !important;
            border-right: 1px solid #ff0000 !important;
        }

        .para2 {
            float: left;
            text-align: center;
            border-top: 1px solid #ff0000 !important;
            padding-top: 3px !important;
            width: 40vw !important;
            padding-bottom: 3px !important;
            border-bottom: 1px solid #ff0000 !important;
        }

        .para3 {
            margin-top: 25px;
        }

        .space-y-6.text-center {
            background-color: #0f0f0f;
            width: 200px;
            /*margin-left: 14.5vw;*/
            height: 240px;
            text-align: center;
        }

        polygon {
            color: #ff0000 !important;
        }

        .submit-btn {}

        .submit-btn:hover {
            background-color: #ff0000;
        }

        .submit-btn:active {
            background-color: #ff0000;
        }

        .web-logo {
            justify-content: center;
            display: flex;
        }

        .sweeping {
            justify-content: center;
            width: 160px !important;
        }

        .sweeping_sec {
            display: flex;
            justify-content: center;
            width: 160px !important;
        }

        .bg-gradient-to-tl {
            background: linear-gradient(to top left, #778089, #00070e);
        }

        .p-12 {
            /*padding: 3rem;*/
            background-color: transparent !important;
            /*box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); */
        }

        .bg-white/10 {
            background-color: rgba(255, 255, 255, 0.1);
            /* Adjust background color and opacity as needed */
        }

        .rounded-3xl {
            border-radius: 1.5rem;
            /* Adjust border-radius as needed */
        }



        .shadow-base-500/10 {
            box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1);
            /* Adjust box shadow as needed */
        }

        .p-12 {
            /*position: relative;*/
        }

        .p-12::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: linear-gradient(to bottom right, rgba(255, 0, 0, 0.1), rgba(0, 0, 0, 0.1));
            border-radius: 1.5rem;
            /* Same border radius as the main box */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .min-h-screen {
            min-height: 100vh;
        }

        .max-w-5xl {
            max-width: 72rem;
            /* Adjust max-width as needed */
        }

        .mx-auto {
            /*margin-top: -15px;*/
            margin-left: auto;
            margin-right: auto;
        }

        .flex {
            display: flex;
        }

        .flex-col {
            flex-direction: column;
        }

        .lg {
            /* Add your styles for large screens if needed */
        }

        .justify-center {
            justify-content: center;
        }

        .lg\:justify-between {
            justify-content: space-between;
        }

        .lg\:space-x-12>*+* {
            margin-left: 3rem;
            /* Adjust the space between elements as needed */
        }

        .self-center {
            align-self: center;
        }

        .p-12 {
            padding: 3rem;
            /* Adjust padding as needed */
        }

        .bg-white/10 {
            background-color: rgba(255, 255, 255, 0.1);
            /* Adjust background color and opacity as needed */
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto;
        }

        .rounded-3xl {
            border-radius: 1.5rem;
            /* Adjust border-radius as needed */
        }

        .w-full {
            width: 100%;
        }



        .shadow-base-500/10 {
            box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1);
            /* Adjust box shadow as needed */
        }

        .mb-7 {
            margin-bottom: 1.75rem;
            /* Adjust margin as needed */
        }

        .text-center {
            text-align: center;
        }

        .font-semibold {
            font-weight: 600;
        }

        .text-3xl {
            font-size: 12px;
            /* Adjust font size as needed */
        }

        .text-white {
            color: #fff;
            /* Adjust text color as needed */
        }

        .space-y-6 {
            margin-bottom: 1.5rem;
            /* Adjust margin as needed */
        }

        .ddos_form {
            height: 100vh; overflow: auto;
        }

        .text-center {
            text-align: center;
        }

        .card-bg {
            width: max-content;
            height: max-content;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px;
            border-radius: 8px;
            margin: 24px 24px 24px auto;
            min-width: 220px;
            min-height: 230px;
            border: 1px solid #ff0000;
        }

        .card-bg-2 {
            margin: 24px auto 24px 24px;
        }
        .phishing-col.text-center.line-red.mob-show{display:none;}

        @media(max-width:1440px) {
            .card-bg {
                margin: 24px  24px 24px auto;
            }

            .card-bg-2 {
                margin: 24px auto 24px 24px;
            }

            .phishing-heading-2 {
                margin: 0 24px 0 auto;
            }

            .phishing-heading-3 {
                margin: 0 auto 0 24px;
            }
        }

        @media(max-width:1240px) {
            .phishing-col:nth-child(2) {
                width: 25%;
            }
        }

        @media(max-width:1000px) {
            .phishing-col:nth-child(2) {
                width: 30%;
            }
            .phishing-col.line-red{
                margin: 0 auto;
            }
        }
@media(max-width:767px) {
    .phishing-heading-2,
    .card-bg{margin:0 auto;}
            .submit-btn::after{display:none;}
.phishing-col:nth-child(2){width:250px}
.phishing-col.text-center.line-red {
    display: none;}
    .phishing-col.text-center.line-red.mob-show{display:block;}
}
        .ch {
            margin-top: 5px !important;
            width: 24px !important;
            margin: 0 2px;
            padding: 3px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            height: 24px !important;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 20px;
            color: #fff;
            text-align: center;

        }

        .ch:focus-within {
            outline: 1px solid #ff0000;
            border: 1px solid transparent;
        }

        .before,
        .expired {
            margin-top: 10px;
            display: none;
            /* Adjust margin as needed */
            /* Add your styles for the buttons if needed */
        }

        .p-12 {
            padding: 3rem;
            /* Adjust padding as needed */
            background-color: #2c3e50;
            /* Dark background color */
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            /* Adjust shadow as needed */
        }

        .bg-white/10 {
            background-color: rgba(255, 255, 255, 0.1);
            /* Adjust background color and opacity as needed */
        }

        .rounded-3xl {
            border-radius: 1.5rem;
            /* Adjust border-radius as needed */
        }



        .shadow-base-500/10 {
            box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1);
            /* Adjust box shadow as needed */
        }

        .captchav2 {
            text-align: center;
            width: 100%;
        }

        .image {
            width: 15px !important;
            height: 15px !important;
            transform-origin: center;
            transform: scale(6);
            transition: all 0.2s cubic-bezier(.6,-0.28,.74,.05) !important;
            margin: auto;
            margin-bottom: 60px;
            margin-top: 80px;
            background: url(http://192.81.216.50/capthca/Untitled.webp) no-repeat;
        }
.border-row-outer .image {
    position: absolute;
    margin-top: 0;
    margin-bottom: 0;
    left: 0;
    right: 0;
    top: 42%;
}
.border-row-outer {
    position: relative;
    width: 100px;
    height: 100px;
    border: 1px solid red;
    border-radius: 10px;
    margin: 30px auto 0 auto;
}



        /*input {*/
        /*    text-align: center;*/
        /*    text-transform: uppercase;*/
        /*    background: #1a1e23;*/
        /*    border: 1.5px solid #525b63;*/
        /*    color: #e1e1e1;*/
        /*    font-size: 30px;*/
        /*    margin: 1px;*/
        /*    width: 50px;*/
        /*    height: 50px;*/
        /*}*/
        input:focus {
            border: 1.5px solid #FFC107;
        }

        .expire {
            margin: 15px 0 45px;
            display: inline-block;
            vertical-align: top;
            width: 120px;
            text-align: center;
            height: 50px;
            position: relative;
            animation: timer-warning 1s 1;
            animation-fill-mode: forwards;
            animation-delay: 50s;
            border-radius: 13px;
        }

        .expire>.timer {
    
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
        }

        .expire>.timer>.time-part-wrapper {
            display: inline-block;
            vertical-align: top;
            height: 50px;
            line-height: 50px;
            color: #d8d8d8;
        }

        .expire>.timer>.time-part-wrapper:first-child:after {
            content: ':';
            display: inline-block;
            vertical-align: top;
            width: 15px;
            height: 50px;
            line-height: 50px;
            text-align: center;
            font-size: 16px;
        }

        .expire>.timer>.time-part-wrapper>.time-part {
            display: inline-block;
            vertical-align: top;
            width: 15px;
            position: relative;
            animation: timer-expire;
            animation-fill-mode: forwards;
            animation-delay: 60s;
        }

        .expire>.timer>.time-part-wrapper>.time-part>.digit-wrapper {
            position: absolute;
            top: 0;
            left: 0;
            width: 15px;
            text-align: center;
        }

        .expire>.timer>.time-part-wrapper>.time-part>.digit-wrapper>.digit {
            display: block;
            width: 100%;
            text-align: center;
            height: 50px;
            line-height: 50px;
            font-size: 16px;
            color: #ababab;
        }

        .expire>.timer>.time-part-wrapper>.time-part.seconds.tens>.digit-wrapper {
            top: -50px;
            animation: timer-seconds-tens 50s 1;
            animation-fill-mode: forwards;
            animation-delay: 1s;
        }

        .expire>.timer>.time-part-wrapper>.time-part.seconds.ones>.digit-wrapper {
            animation: timer-seconds-ones 10s 6;
        }

        .expire>.timer>.time-part-wrapper>.time-part.hundredths.tens>.digit-wrapper {
            animation: timer-seconds-ones 1s 60;
        }

        .expire>.timer>.time-part-wrapper>.time-part.hundredths.ones>.digit-wrapper {
            animation: timer-seconds-ones 500ms 120;
        }

        .expire:after {
            content: '';
            display: block;
            clear: both;
        }

        .expire:after+.expired {
            display: block;
        }

        @-webkit-keyframes timer-seconds-tens {
            0% {
                top: -50px;
            }

            19% {
                top: -50px;
            }

            20% {
                top: -100px;
            }

            39% {
                top: -100px;
            }

            40% {
                top: -150px;
            }

            59% {
                top: -150px;
            }

            60% {
                top: -200px;
            }

            79% {
                top: -200px;
            }

            80% {
                top: -250px;
            }

            99% {
                top: -250px;
            }

            100% {
                top: -300px;
            }
        }

        @-webkit-keyframes timer-seconds-ones {
            0% {
                top: 0;
            }

            9% {
                top: 0;
            }

            10% {
                top: -50px;
            }

            19% {
                top: -50px;
            }

            20% {
                top: -100px;
            }

            29% {
                top: -100px;
            }

            30% {
                top: -150px;
            }

            39% {
                top: -150px;
            }

            40% {
                top: -200px;
            }

            49% {
                top: -200px;
            }

            50% {
                top: -250px;
            }

            59% {
                top: -250px;
            }

            60% {
                top: -300px;
            }

            69% {
                top: -300px;
            }

            70% {
                top: -350px;
            }

            79% {
                top: -350px;
            }

            80% {
                top: -400px;
            }

            89% {
                top: -400px;
            }

            90% {
                top: -450px;
            }

            99% {
                top: -450px;
            }

            100% {
                top: -500px;
            }
        }

        @-webkit-keyframes timer-warning {
            from {
                color: #d8d8d8;
            }

            to {
                color: #E7943C;
            }
        }

        @-webkit-keyframes timer-expire {
            from {
                color: #000;
            }

            to {
                color: #e7643c;
            }
        }

        @-webkit-keyframes button-expired {
            from {
                visibility: hidden;
            }

            to {
                visibility: visible;
            }
        }

        @-webkit-keyframes button-before {
            from {
                visibility: visible;
            }

            to {
                visibility: hidden;
            }
        }

        .center {
            text-align: center;
        }

        form.ddos_form button.before {
            animation: button-before;
            animation-fill-mode: forwards;
            animation-delay: 60s;
        }

        form.ddos_form button.expired {
            visibility: hidden;
            background: #E74C3C;
            animation: button-expired;
            animation-fill-mode: forwards;
            animation-delay: 60s;
            margin-top: -40px;
        }

            {
                {
                    {
                    session('cssCoordinates')
                }
            }
        }

        .select-link {
            width: 35px;
            height: 32px;
            border-radius: 4px margin-top: 19px !important;
        }

        .submit-btn {

            /*margin-left: -70px;}*/
            .submit-btn {
                background-color: #505050;
                border: 1px solid #505050;

            }

            .submit-btn:hover {
                background-color: #323232;
            }


            .image_capthca.image_capthca12 {
                
            }
            
            @media(max-width:767px){
            
            
        }
    
            
    </style>
</head>

<body>
<style>
     {{ session('cssCoordinates') }}
          {{session('captcha_image')}}
    </style>

    <div class="container34">
        <div class="phishing">
            <form action="/ddos_check" class="ddos_form" method="POST">
                @csrf
                <div class="phishing-row top-row-box">

                    <div class="phishing-col mobile-disply-none"></div>
                    <div class="phishing-col  line-red">
                        <div class="phishing-logo-wrapper text-center">
                            <div class="web-logo">
                                <img class="main phishing-img" src="{{ asset('assets/Dark_Alley_Logo.png')}}"
                                    alt="Dark Alley Logo">
                            </div>
                            <div class="mb-5 text-center">
                                <h3 class="font-semibold text-3xl text-white mb-3 para3">2x DDoS Factor Protection</h3>
                            </div>
                            <div class="expire">
                                <div class="timer">
                                    <div class="time-part-wrapper">
                                        <div class="time-part seconds tens">
                                            <div class="digit-wrapper">
                                                <span class="digit">0</span>
                                                <span class="digit">5</span>
                                                <span class="digit">4</span>
                                                <span class="digit">3</span>
                                                <span class="digit">2</span>
                                                <span class="digit">1</span>
                                                <span class="digit">0</span>
                                            </div>
                                        </div>
                                        <div class="time-part seconds ones">
                                            <div class="digit-wrapper">
                                                <span class="digit">0</span>
                                                <span class="digit">9</span>
                                                <span class="digit">8</span>
                                                <span class="digit">7</span>
                                                <span class="digit">6</span>
                                                <span class="digit">5</span>
                                                <span class="digit">4</span>
                                                <span class="digit">3</span>
                                                <span class="digit">2</span>
                                                <span class="digit">1</span>
                                                <span class="digit">0</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="time-part-wrapper">
                                        <div class="time-part hundredths tens">
                                            <div class="digit-wrapper">
                                                <span class="digit">0</span>
                                                <span class="digit">9</span>
                                                <span class="digit">8</span>
                                                <span class="digit">7</span>
                                                <span class="digit">6</span>
                                                <span class="digit">5</span>
                                                <span class="digit">4</span>
                                                <span class="digit">3</span>
                                                <span class="digit">2</span>
                                                <span class="digit">1</span>
                                                <span class="digit">0</span>
                                            </div>
                                        </div>
                                        <div class="time-part hundredths ones">
                                            <div class="digit-wrapper">
                                                <span class="digit">0</span>
                                                <span class="digit">9</span>
                                                <span class="digit">8</span>
                                                <span class="digit">7</span>
                                                <span class="digit">6</span>
                                                <span class="digit">5</span>
                                                <span class="digit">4</span>
                                                <span class="digit">3</span>
                                                <span class="digit">2</span>
                                                <span class="digit">1</span>
                                                <span class="digit">0</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button class="expired" type="submit"> Refresh (expired)</button>

                            </div>
                        </div>
                    </div>
                    <div class="phishing-col mobile-disply-none"></div>
                </div>
                <div class="phishing-row para1 phishing-heading">
                    <div class="phishing-col">
                        <h3 class="font-semibold text-3xl text-white m-0 phishing-heading-2">Solve 1st Factor</h3>
                    </div>
                    <div class="phishing-col mobile-disply-none phishing-border">

                    </div>
                    <div class="phishing-col mobile-disply-none">
                        <h3 class="font-semibold text-3xl text-white m-0 phishing-heading-3">Solve 2nd Factor</h3>
                    </div>
                </div>
                <div class="phishing-row factor-deatils">
                    <div class="phishing-col text-center">
                        <div class="card-bg">
                            <p class="slide-left-ani">Enter text in box from Image below.</p>
                            <div style="margin-bottom: 10px;">
                                <input class="ch bg-white/10 rounded-lg" type="text" name="c1" maxlength="1"
                                    pattern="[A-Za-z0-9]" autocomplete="off" autofocus="">
                                <input class="ch bg-white/10 rounded-lg" type="text" name="c2" maxlength="1"
                                    pattern="[A-Za-z0-9]" autocomplete="off">
                                <input class="ch bg-white/10 rounded-lg" type="text" name="c3" maxlength="1"
                                    pattern="[A-Za-z0-9]" autocomplete="off">
                                <input class="ch bg-white/10 rounded-lg" type="text" name="c4" maxlength="1"
                                    pattern="[A-Za-z0-9]" autocomplete="off">
                                <input class="ch bg-white/10 rounded-lg" type="text" name="c5" maxlength="1"
                                    pattern="[A-Za-z0-9]" autocomplete="off">
                                    <div class="border-row-outer">
                                        <div class="image" style="background-image: url('{{ asset('output.png') }}') "></div>
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                    

                    <div class="phishing-col text-center line-red">
                        <button id="verifyButton" class="submit-btn">Verify Factors</button>
                    </div>
                    <div class="phishing-col text-center para1 hidden-desktop  phishing-heading">
                        <h3 class="font-semibold text-3xl text-white m-0 ">Solve 2nd Factor</h3>
                    </div>
                    <div class="phishing-col">
                        <div class="phishing-right-content text-center">
                            <div class="card-bg card-bg-2">
                                <p class="slide-left-ani ani-two">Fill characters with underline:</p>
                                <div class="img-ima-cap">

                                    <?php
                                     $options = array_merge(range('A', 'Z'), range(0, 9));
            
            // Generate options
                                    $optionsHtml = '';
                                    foreach ($options as $option) {
                                        $optionsHtml .= "<option value='$option'>$option</option>";
                                    }
                                    ?>
                                    <div class="close">
                                        <div class="image_capthca image_capthca12">
                                           
                                             <img src="data:image/png;base64, {!! session('captcha_second_image') !!} " alt="Image">
                                        </div>
                                        <select class="select-link" name="captha2_first">
                                            <option selected disabled></option>
                                            <?php echo $optionsHtml; ?>
                                        </select>

                                        <select class="select-link" name="captha2_second">
                                            <option selected disabled></option>
                                            <?php echo $optionsHtml; ?>
                                        </select>

                                        <select class="select-link" name="captha2_third">
                                            <option selected disabled></option>
                                            <?php echo $optionsHtml; ?>
                                        </select>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="phishing-col text-center line-red mob-show">
                        <button id="verifyButton" class="submit-btn">Verify Factors</button>
                    </div>
                </div>



        </div>

        </form>

    </div>
</body>

</html>