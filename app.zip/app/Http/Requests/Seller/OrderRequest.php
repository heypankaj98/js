<?php
namespace App\Http\Requests\Seller;

use App\Models\Product;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class OrderRequest extends FormRequest {

    protected $stopOnFirstFailure = true;

    //public function authorize() {
    //    return Gate::allows('admin_product_create');
    //}

    public function rules()
    {
        return [
            'type' => ['bail', 'required', 'string'],
            'delivery' => ['bail','date', 'after:2023-01-01']
            ];
    }
}