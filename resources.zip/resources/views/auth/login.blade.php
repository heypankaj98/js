<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dark Allay</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background-color: #000;
            font-family: 'Inter', sans-serif;
            /*overflow-x: hidden;*/
            width: 100%;
            margin: 0px;
        }

        .form-login {
            background-color: rgba(255,255,255,.1);
            border-radius: 8px;
            padding: 30px;
        }

        

        
button.btn.btn-orange {
    background: #ff7d00;
    color: #fff;
}
        

button.btn.btn-orange:hover{background:transparent; border:1px solid #ff7d00}

        .container,
        .fff {
            display: flex;
            width: 100%;
        }

        .border_radiusnone.fw-bold {
            border-radius: 13px;
            margin-top: 0px !important;
            width: 81px !important;
            padding-top: 8px !important;
            width: 90px !important;
        }

        .pass66 {
            color: white;
        }

        img {
            /*margin-left: 25px;*/
            width: 219px;
        }


        .footer_market {
            display: none !important;
        }

        .form-control.border_radiusnone {
            border: 1px solid #ff0000;
            border-radius: 4px;
        }

        .btn {
            height: 42px;
            padding: 8px 16px;
            font-size: 14px;
            text-align: center;
            border: 1px solid #ff7d00;
            font-weight: 600;
            display: inline-block;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all .4s cubic-bezier(0.19, 1, 0.22, 1);
            color: #000;
            display: grid;
            place-items: center;
        }

        .btn.login {
            background-color: #ff7d00;
            border: 1px solid #ff7d00;
        }
        .btn.login:hover{
            background-color: #cc6403;
        }
        .btn.outline {
            background-color: transparent;
            border: 1px solid #ff7d00;
            color: #ff7d00;
        }
        .btn.outline:hover{
            background-color: #ff7d00;
            color: #000;
        }

        .m-auto1 {
            margin: 0px !important;
        }

        .card_main_part .card .card-body {
            box-shadow: 1px -1px 20px 0px #0f0f0f !important;
            background-color: #0f0f0f;
            margin-top: -70px;
        }

        .border_radiusnone.fw-bold {
            color: black !important;

        }

        span.gold_star {
            color: #ff0000;
        }

        form {
            /*margin-top: -299px;*/
        }

        /* Adjustments for inline form */
        .form-group {
            display: flex;
            flex-direction: column;
            align-items: start;
            margin-bottom: 8px;
        }

        .form-group label {
            padding-bottom: 8px;
            font-weight: 600;
            font-size: 14px;
        }

        .form-group .form-control {
            width: 100%;
            height: 42px;
            padding: 12px;
            background: black;
            color: #fff;
        }

        .form-group .form-control:focus-within {
            outline: 1px solid #ff0000;
        }

        .card_main_part .card .card-body form {
            background-color: #0f0f0f;
        }


        hr {
            /*margin-left: -22px;*/
            width: 100%;
            border: none;
            height: 1px;
            background: #ff0000;
            margin-bottom: 30px;
        }

        .fw-bold {
            color: white;
        }


        .fw-bold:nth-child(3) {
            margin-right: 21px !important;
        }

        .form-group1 {
            width: 100% !important;
        }



        img.imgda {
            width: 140px;
            border: 1px solid #ff0000;
            margin-top: -2px;
        }

        .form-control.form-control1.captch_sapce_control.border_radiusnone {
            width: max-content;
            background-color: #0f0f0f;
            border-radius: 4px !important;
            overflow: hidden;
            width: 250px;
            height: 60px;
            padding: 0;
        }

        .form-control.form-control1.captch_sapce_control.border_radiusnone img {
            width: 100%;
            height: 100%;
        }

        .card-body-mg {
            margin-bottom: 150px;
            background-color: #000;
            border: 1px solid #ff0000;
            padding: 15px;
            border-radius: 8px;
        }


        .form-control1 {
            border-radius: 0px !important;
        }

        .col-md-6 {
            display: inline-flex;
            width: 100%;
            text-align: center;
        }

        .col-md-6.m-auto1 {
            margin-left: 120px !important;
        }

        .regi45 {
            margin-right: 86px;
        }

        .flewd {
            margin-top: -20px;
        }

        .fw-beold {
            padding: 3px 15px;
            border-radius: 4px;
            margin-bottom: 0px;
            color: black !important;
            font-size: 18px;
        }

        .reser {
            margin-left: 115px;
        }
        .ffirst, .ssecond {
    position: absolute;
    width: 100%;
}

        .ffirst {
            
            margin-top: 320px;
        }
.row{max-width:400px; width:100%; margin:0 auto; position:relative; z-index:1}
        .ssecond {
           
            margin-top: 350px;
        }

        .imgg-logo32 {
            margin: 0 auto !important;
            width: max-content;
            height: auto;
        }

        .group12 {
            margin-top: 12px;
            margin-bottom: 12px;
        }

        img.img-45 {
            margin-top: 0px;
            padding: 0px 16px;
            width: 150px;
            border-left: 1px solid #ff0000;
            border-right: 1px solid #ff0000;
            padding-bottom: 30px;
            padding-top: 30px;
            display: block;
        }

        .alert.alert-danger {
            display: none;
            color: white;
            margin-left: 100px;
            padding-top: 5px;
        }

        p.alert.alert-info {
            margin-top: -26px;
            color: #ff7d00;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            color: #fff;
            margin: 24px 0 12px;
        }

        .buttons button,
        .buttons a {
            flex: 1;
        }

        .link-underline {
            text-decoration: underline;
            color: #ff7d00;
            display: inline-block;
            margin-top: 12px;
            font-size: 12px;
        }
        .text-center{
            text-align: center;
        }
        @media all and (max-width: 767px){
            .card-bg{margin:0 auto;}
        }
        
        @media all and (max-width:480px){
            .row{max-width:90%; width:100%;}
        }
    </style>
</head>

<body>
    <div class="container fff">
        <!-- Top Separator -->
        <div class="ffirst">
            <hr>
        </div>

        <!-- Main Content -->
        <div class="row">
            <!-- Logo Section -->
            <div class="imgg-logo32 text-center">
                <img class="img-45" src="{{ asset('assets/Dark_Alley_Logo.png') }}" alt="Dark Alley Logo">
            </div>

            <!-- Login Form Card -->
            <div class="card_main_part pt-3 pb-3">
                <div class="card margin_auto border_none">
                    <div class="card-body-mg">
                        <!-- Display Flash Messages -->
                        @if(Session::has('error'))
                            <div class="alert alert-danger text-center">
                                {{ Session::get('error') }}
                            </div>
                        @endif

                        <!-- Login Form -->
                        <form method="POST" action="{{ route('login.perform') }}" class="form-login">
                            @csrf

                            <!-- Username Field -->
                            <div class="form-group">
                                <label for="username" class="fw-bold">{{ trans('auth.username') }} <span class="gold_star">*</span></label>
                                <input id="username" type="text" name="username"
                                    class="form-control border_radiusnone @error('username') is-invalid @enderror"
                                    value="{{ old('username') }}" placeholder="{{ trans('auth.username') }}" required>
                                @error('username')
                                    <div class="alert alert-danger">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <!-- Password Field -->
                            <div class="form-group">
                                <label for="password" class="fw-bold">{{ trans('auth.password') }} <span class="gold_star">*</span></label>
                                <input id="password" name="password" type="password"
                                    class="form-control border_radiusnone @error('password') is-invalid @enderror"
                                    required placeholder="••••••••">
                                @error('password')
                                    <div class="alert alert-danger">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <!-- CAPTCHA Image -->
                            <div class="form-group">
                                <label for="captcha" class="fw-bold">{{ trans('auth.captcha') }} <span class="gold_star">*</span></label>
                                <div class="d-flex align-items-center">
                                    <div class="captcha-box">
                                        {!! captcha_img('inverse') !!}
                                    </div>
                                 
                                </div>
                            </div>

                            <!-- CAPTCHA Input -->
                            <div class="form-group">
                                <label for="captcha_input" class="fw-bold">Captcha (case sensitive) <span class="gold_star">*</span> </label>
                                <input id="captcha" name="captcha" type="text"
                                    class="form-control border_radiusnone @error('captcha') is-invalid @enderror"
                                    required placeholder="{{ trans('auth.captcha') }}  ">
                                @error('captcha')
                                    <div class="alert alert-danger">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <!-- Buttons -->
                            <div class="buttons text-center">
                                <button type="submit" class="btn btn-orange">{{ trans('auth.sign_in') }}</button>
                                <span style="font-size:14px;">OR</span>
                               <a href="{{ route('register.show') }}"
                                    class="btn outline">{{ trans('auth.create_account') }}</a>
                            </div>

                            <!-- Reset Password -->
                            <div class="text-center mt-3">
                                <a href="{{ route('forgot') }}" class="link-underline">Reset Password</a>
                            </div>
                        </form>
                    </div> <!-- Closing card-body-mg -->
                </div> <!-- Closing card -->
            </div> <!-- Closing card_main_part -->
        </div>

        <!-- Bottom Separator -->
        <div class="ssecond">
            <hr>
        </div>
    </div> <!-- Closing container -->
</body>
