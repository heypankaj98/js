<?php

namespace App\Http\Requests\User\Settings;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Crypt;
use App\Tools\PGP;

class ChangePGPKeyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->check();
    }

    /**
     * Get the validation rules that apply to the request
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pgp_key' => 'nullable',
            'verification_code' => 'nullable'
        ];
    }

    /**
     * Create change order
     * 
     * @return Illuminate\Routing\Redirector
     */
public function createRequisition() 
{
    $pgpKey = $this->pgp_key;

    if (is_null($pgpKey)) {
        throw new \Exception('Please enter a valid PGP key for verification!');
    }

    // Check if the user is adding a PGP key for the first time
    if (is_null(auth()->user()->pgp_key)) {
        session()->put('pgp_key', $pgpKey); // Store the PGP key in session
        PGP::verification($pgpKey, 'confirm_new_pgp_key'); // Create verification

        // Redirect to the PGP verification page
        // return redirect()->route('user.profile.verifypgp');
    }

    // If the PGP key was verified for the first time, redirect to security2 view
    if (session()->get('pgp_verified_first_time')) {
        return redirect()->route('user.profile.security2'); // Redirect to security2 Blade
    }

    // If not the first time, keep the existing functionality
    session()->put('pgp_key', $pgpKey);
    PGP::verification($pgpKey, 'confirm_new_pgp_key');

    return redirect()->route('user.profile.security', '#pgpkey');
}

public function becomevendor() 
{
    $pgpKey = $this->pgp_key;

    if (is_null($pgpKey)) {
        throw new \Exception('Please enter a valid PGP key for verification!');
    }

    // Check if the user is adding a PGP key for the first time
    if (is_null(auth()->user()->pgp_key)) {
        session()->put('pgp_key', $pgpKey); // Store the PGP key in session
        PGP::verification($pgpKey, 'confirm_new_pgp_key'); // Create verification

        // Redirect to the PGP verification page
        // return redirect()->route('user.profile.verifypgp');
    }

    // Check if the PGP key is verified
    if (session()->get('pgp_verified_first_time')) {
       
        // Redirect to the security2 view if the PGP key is verified
        return redirect()->route('user.verifybuyer'); // Redirect to security2 Blade
    }

    // If not the first time, keep the existing functionality
    session()->put('pgp_key', $pgpKey);
    PGP::verification($pgpKey, 'confirm_new_pgp_key');

    return redirect()->route('user.verifybuyer', '#pgpkey');
}

    /**
     * Database persist
     * 
     * @return Illuminate\Routing\Redirector
     */
   public function change()
{
    #Get auth user
    $user = auth()->user();

    if (!session()->has('verification_name')) {
        throw new \Exception('Oops... Cancel and try again!');
    }

    #Decrypt session verification code
    $verificationCode = Crypt::decryptString(session()->get('verification_code'));

    if ($this->verification_code !== $verificationCode) {
        throw new \Exception('Invalid verification code!');
    }

    #Set new PGP key
    $user->pgp_key = session()->get('pgp_key');
    $user->save();

    #Destroy verification sessions
    session()->forget(['pgp_key', 'verification_name', 'encrypted_message', 'verification_code']);

    session()->flash('success', 'PGP key changed successfully!');

    # Check if the request is from becomevendor
    if (session()->has('from_becomevendor')) {
        # Remove the session flag after redirection
        session()->forget('from_becomevendor');
        
        # Redirect to security2 page
        return redirect()->route('user.security2');
    }

    # Otherwise, redirect to the default security page
    return redirect()->route('user.security1');
}
}
