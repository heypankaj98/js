<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExceptionModel extends Model {

    use HasFactory;

    protected $table = 'exceptions';

}
