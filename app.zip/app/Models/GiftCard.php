<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GiftCard extends Model {

    use HasFactory;

    protected $fillable = [
        'code',
        'amount',
        'user_id',
        'payable_amount',
            // add any other fields as needed
    ];

    public function payment() {
        return $this->hasOne(Payment::class, 'model_id');
    }

}
 