@extends('layouts.buyer.app')

@section('content')
<div class="col-md-12">
    @if (session('success'))
    <div id="alert_message" class="alert alert-success alert-block">
        <strong>{{ session('success') }}</strong>
    </div>
    @elseif(session('error'))
    <div id="alert_message" class="alert alert-danger alert-block">
        <strong>{{ session('error') }}</strong>
    </div>
    @endif
</div>

<div class="col-lg-12 bid_blade_main ">
    <div class="">
        <div class="custom-title my-4">
            <h5 class="mb-0">{{ trans('common.thanks') }}, {{ Auth::user()->username }} !</h5>
        </div>
        <div class="bg-card-2 mt-3 br1">
            <div class="d-flex justify-content-between align-items-center mb-4 card-header-2 w-100">
                <p class="small text-muted mb-0">{{ trans('common.order') }} {{ trans('common.date') }}: {{ $orders->first()->created_at->format('M ,j Y g:i A') }}</p>
                <p class="small text-muted mb-0">{{ trans('common.order') }} {{ trans('common.number') }}: {{ $id }}</p>
            </div>

            @foreach($orders as $order)
            <div class="bg-card-1">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4 bg-card-2 card-header-2 w-100 mb-4">
                        <div class="">
                            @if($order->product->photo)
                            <img src="{{ $order->product->photo->getUrl('thumb') ?? asset('/assets/img/product-default.jpg') }}"
                                 class="img-fluid br-4" alt="Phone">
                            @else
                            <img src="{{ asset('/assets/img/product-default.jpg') }}" class="img-fluid">
                            @endif
                        </div>
                        <div class="">
                            <p class="text-muted mb-0">{{ $order->product->name }}</p>
                        </div>
                        <div class="">
                            <p class="text-muted mb-0 small">
                                {{ trans('common.type')}}: <span class="text-uppercase">{{ trans('common.' . $order->product->type) }}</span>
                            </p>
                        </div>
                        <div class="">
                            <p class="text-muted mb-0 small"> {{ trans('common.qty')}}: {{ $order->quantity }}</p>
                        </div>
                        <div class="">
                            <p class="text-muted mb-0 small">$ {{ $order->total }}</p>
                        </div>
                    </div>

                    <div class="row d-flex">
                        <div class="col-md-2">
                            <p class="text-muted mb-0 small">
                                {{ trans('common.status')}}: <span class="text-uppercase">{{ trans('common.' . $order->status) }}</span>
                            </p>
                        </div>
                        @php
                        $progressWidth = (array_search($order->status, ['waiting', 'escrow', 'processing', 'shipped', 'delivered', 'completed']) + 1) * 20;
                        @endphp

                        <div class="col-md-10">
                            <div class="progress" aria-label="Default">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: {{ $progressWidth }}%;" aria-valuenow="{{ $progressWidth }}"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                            <div class="d-flex justify-content-between mb-1 escrow_item">
                                @foreach(['waiting', 'escrow', 'processing', 'shipped', 'delivered', 'completed'] as $status)
                                <p class="text-muted mt-1 mb-0 small ms-xl-5{{ $order->status === $status ? ' fw-bold' : '' }}">
                                    {{ trans('common.' . $status) }}
                                </p>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    <hr class="mb-4 hr_line" >
                    <div class="row d-flex align-items-center">
                        <div class="w-max">
                            @if($order->checkDispute())
                                <a href="{{ route('dispute.messages', $order->checkDispute()->id) }}" class="btn btn-main">
                                  {{ trans('common.view')}} {{ trans('common.dispute')}}
                                </a>
                            @else
                                <a href="{{ route('user.orders.dispute', ['order_id' => $order->id, 'product_id' => $order->product->id]) }}" class="btn btn-main">
                                   {{ trans('common.raise')}} {{ trans('common.dispute')}} 
                                </a>
                            @endif
                        </div>
                        @if($order->status == "shipped" || $order->status == "delivered")
                            @if ($order->payment_method =='BitcoinMultiSign')
                                <p>Product Arrival and Transaction release paymet to seller </p>
                                <form id="transactionForm" action="{{  route('user.order.payment.raw', ['order_id' => $id])}}" method="POST">
                                    @csrf
                                    @if($order->buyer->id == auth()->user()->id)
                                    <div class="form-group">
                                        <label for="buyerSignature">Buyer private key Signature:</label>
                                        <input type="text" name='buyer_signature' class="form-control" id="buyerSignature" required>
                                    </div>
                                    @endif
                                    <button type="submit" class="btn btn-primary"> {{ trans('product.sign_transaction')}}</button>
                                </form>
                            @else
                                <div class="col-md-2">
                                    <form action="{{ route('user.order.status',$order->id) }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="type" value="completed" required>
                                       {{ trans('product.expected_delivery_date')}}   {{ $order->delivered_at }}
                                        </div>
                                        <div class="col-md-2">
                                            <button type='submit' class="btn btn-success text-white">
                                              {{ trans('product.mark_as_completed')}}  
                                            </button>
                                    </form>
                                </div>
                                
                            @endif
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
@if($order->status == 'completed')
    <form action="{{ route('review.submit', ['order' => $order->id]) }}" method="POST">
        @csrf
        <div class="bg-card-1 p-24 br1" >
            <div class="btn btn-warning w-100 mb-2">Please Provide Rating</div>
        <label for="review" class="d-flex justify-content-between align-items-center mb-4 card-header-2 w-100">Please rate our product:</label>
        <div>
            <input type="radio" id="star1" name="review" value="1" required>
            <label for="star1">1 Star</label>

            <input type="radio" id="star2" name="review" value="2" required>
            <label for="star2">2 Stars</label>

            <input type="radio" id="star3" name="review" value="3" required>
            <label for="star3">3 Stars</label>

            <input type="radio" id="star4" name="review" value="4" required>
            <label for="star4">4 Stars</label>

            <input type="radio" id="star5" name="review" value="5" required>
            <label for="star5">5 Stars</label>
        </div>

        <label for="feedback" class="d-flex justify-content-between align-items-center mb-4 card-header-2 w-100 mt-2">Your Feedback:</label>
        <textarea name="feedback" id="feedback" rows="5" class="w-100" required></textarea>

        <button type="submit" class="btn btn-main mb-2">Submit Review</button>
        </div>
    </form>
@endif




        <div class="bg-card-1 p-24 br1">
        <div class="d-flex justify-content-between pt-2 mb-3">
            <p class="fw-bold mb-0 fs-5">[{{ trans('common.order') }} {{ trans('common.details')}}]</p>
        </div>
        <div class="d-flex justify-content-between w-100">
    <span class="text-muted">
        <span class="fw-bold me-4">{{ trans('common.order') }} {{ trans('common.number') }}:</span>
        {{ $id }}
    </span>
    <span class="text-muted">
        <span class="fw-bold me-4">{{ trans('common.total') }}:</span>
        {{ $orders->sum('total') }}.00
    </span>
</div>
        <div class="fw-bold me-4">
           

        </div>
        <div class="d-flex justify-content-between py-2 bb-01">
            <p class="text-muted mb-0">
                <span class="fw-bold me-4">{{ trans('common.order') }} {{ trans('common.date') }}:</span>
                {{ $orders->first()->created_at->format('M ,j Y') }}
            </p>
            <p class="text-muted mb-0"><span class="fw-bold me-4">{{ trans('common.discount') }}: </span> $0.00</p>
        </div>
        <div class="d-flex justify-content-between pt-2 py-2 bb-01">
    <p class="text-muted mb-0">
        <span class="fw-bold me-4">Platform Charges:</span>
    </p>
    <p class="text-muted mb-0">
        <span class="fw-bold me-4">{{ trans('common.total') }}:</span>  ${{ number_format($commission, 2) }}
    </p>
</div>

        <div class="d-flex justify-content-between mb-5 py-2">
            <p class="text-muted mb-0"></p>
            <p class="text-muted mb-0">
                <span class="fw-bold me-4">{{ trans('common.delivery') }} {{ trans('common.charge') }}:</span> $0.00
            </p>
        </div>

        </div>
     <div class="card-footer border-0 px-4 py-3 mb-2">
        <h5 class="d-flex align-items-center justify-content-end text-white text-uppercase mb-0">
           <span class="fw-bold me-4">{{ trans('common.total') }}:</span>${{ number_format($orders->sum('total') + $commission, 2) }} USD
        </h5>
    </div>
    <div class="bg-card-1 p-24 br1">
    @if(in_array($orders->first()->status, ['escrow','processing','shipped','delivered','completed']))
            <div class="d-flex justify-content-between pt-2 mb-3">
                <p class="fw-bold mb-0 fs-5">{{ trans('common.escrow')}} {{ trans('common.details')}}:</p>
            </div>
            <div class="d-flex justify-content-between pt-2 py-2 bb-01">
                <p class="text-muted mb-0">
                    {{ trans('common.payment') }} {{ trans('common.coin') }}: {{ $orders->first()->payment_method }}
                </p>
                <p class="text-muted mb-0">
                    <span class="fw-bold me-4">{{ trans('common.total') }} {{ trans('common.order') }} {{ trans('common.amount') }}: </span>
                    {{ $orders->first()->orderPayment()->first()->amount }} {{ $orders->first()->payment_method }}
                </p>
            </div>
            <div class="d-flex justify-content-between py-2 bb-01">
                <p class="text-muted mb-0">
                    {{ trans('common.paid') }}: {{ $orders->first()->orderpayment()->first()->paid_at }}
                </p>
                <p class="text-muted mb-0">
                    <span class="fw-bold me-4">
                        {{ trans('common.discount') }}: 
                    </span>
                    0.00000000 {{ $orders->first()->payment_method }}
                </p>
            </div>
            <div class="d-flex justify-content-between mb-5 py-2">
                <p class="text-muted mb-0 w-65 wordbreak">
                    {{ trans('common.payment') }} {{ trans('common.address') }}: {{ $orders->first()->orderPayment()->first()->payment_address }}
                </p>
                <p class="text-muted mb-0">
                    <span class="fw-bold me-4">{{ trans('common.total') }} {{ trans('common.received') }}: </span>
                    {{ $orders->first()->orderPayment()->first()->total_received }} {{ $orders->first()->payment_method }}
                </p>
            </div>
        @endif
    </div>
      
    </div>

    @if ($orders->first()->status == 'waiting')
        @if (is_null($orders->first()->orderPayment()->first()))
            @if ($orders->first()->payment_method =='BitcoinMultiSign')
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('common.create') }} {{ trans('common.multisig') }}
                        </div>
                        <div class="card-body">
                            
                            @if (!is_null($orders->first()->buyer->meta_multisig_key_pub) && !is_null($orders->first()->seller->meta_multisig_key_pub))
                                <form method="POST" action="{{ route('user.order.payment', ['order_id' => $id]) }}">
                                    @csrf
                                    <div class="form-group">
                                        <label for="userPublicKey">{{ trans('common.user') }} {{ trans('common.public') }} {{ trans('common.key') }}</label>
                                        <input type="text" class="form-control" id="userPublicKey" name="userPublicKey" value='{{ $orders->first()->buyer->meta_multisig_key_pub }}'>
                                    </div>
                                    <div class="form-group">
                                        <label for="sellerPublicKey"> {{ trans('common.seller') }} {{ trans('common.public') }} {{ trans('common.key') }}</label>
                                        <input type="text" class="form-control" id="sellerPublicKey" name="sellerPublicKey" value='{{ $orders->first()->seller->meta_multisig_key_pub }}'>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary mb-3 mt-3">
                                            {{ trans('common.generate') }} {{ trans('common.payment') }}
                                        </button>
                                    </div>
                                  
                                </form>
                            @else
                                <div class="alert alert-danger" role="alert">
                                    {{ trans('common.both_the_buyer')}}
                                </div>
                            @endif
                            
                        </div>
                    </div>
                </div>
            @else
                <form class="row g-3" action="{{ route('user.order.payment', ['order_id' => $id]) }}" method="POST">
                    @csrf
                    <div class="col-auto">
                        <button type="submit" class="btn btn-main mb-3 mt-3">
                            {{ trans('common.generate') }} {{ trans('common.payment') }}
                        </button>
                    </div>
                </form>
            @endif
        @else
            <h2>{{ trans('common.payment') }} {{ trans('common.pending') }}</h2>
            <div class="row my-3 product_row" >
                <div class="col-8 mt-2">
                    <strong>{{ trans('common.to_complete')}}</strong>
                    <textarea class="badge-info col-12 textarea" rows="2" readonly>{{ $orders->first()->orderPayment()->first()->payment_address }}</textarea>
                    <small> {{ trans('common.once_payment')}} </small>
                    <hr>
                    <div class="row">
                        <div class="col-4">
                            <strong>{{ trans('common.total') }} {{ trans('common.amount') }} {{ trans('common.to_pay') }}</strong>
                            <strong class="btn btn-dark col-11 mb-2 copyable">
                                <b>{{ $orders->first()->orderPayment()->first()->amount }} {{ trans('common.' . $orders->first()->payment_method) }}</b>
                            </strong>
                        </div>
                <div class="col-12 col-md-4">
    <strong class="f16">{{ trans('common.total') }} {{ trans('common.received') }} {{ trans('common.coin') }}: </strong>
    @php
        $receivedValue = is_array($received) ? 0.0 : (float) $received;
    @endphp
    <strong class="btn btn-success col-11 mb-2"><b>{{ number_format($receivedValue, 8) }}</b></strong>
</div>
<div class="col-4">
    <strong>{{ trans('common.payment') }} {{ trans('common.status') }}:</strong>
    @if ($receivedValue > 0)
        <strong class="btn btn-success col-11 mb-2"><b>Paid</b></strong>
    @else
        <strong class="btn btn-danger col-11 mb-2"><b>Unpaid</b></strong>
    @endif
</div>


                    </div>
                    <div class="row">
                        <div class="col-3">
                            <br>
                            <a href="{{ route('user.order', $orders->first()->order_id) }}" class="btn btn-primary col-11">
                                {{ trans('common.refresh') }}
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-4 mt-2">
                    <strong class="btn btn-warning col-12">
                        {{ trans('common.' . $orders->first()->payment_method) }} {{ trans('common.qr') }}
                    </strong>
                    <div class="text-center col-12">
                       <img alt="alt" src="https://api.qrserver.com/v1/create-qr-code/?data={{ trans('common.' . $orders->first()->payment_method) }}:{{ $orders->first()->orderPayment()->first()->payment_address }}%3Famount%3D {{ $orders->first()->orderPayment()->first()->amount }} &amp;size=400*400" style="margin-top: 10px;"/>
                    </div>
                </div>
            </div>
        @endif
    @endif
  <!--<div class="form-group">-->
  <!--                                      <button class="btn btn-main">-->
  <!--                                          Pay Through Balance-->
  <!--                                      </button>-->
  <!--                                      </div>-->

</div>
@endsection

<style>
 
.card-footer.border-0.px-4.py-3{
    margin-top: -25px !important;
}
</style>