@extends('layouts.buyer.app')   @section('content')
<div class="bg-card-1 mt-4">
    <div class="col">
        @yield('messenger-content')
    </div>
</div>
@stop