@extends('layouts.auth')    @section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Reset PGP') }}</div>
                <div class="card-body">

                    @if(Session::has('error'))
                    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                    @endif
                    @if(session()->has('verification_name') and session()->get('verification_name') == 'confirm_new_pgp_key')


                    @if(Session::has('error'))
                    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                    @endif
                    <form action="{{ route('forgot.pgp.change') }}" method="post">
                        @csrf
                        <div class="label">
                            <label>encrypted message</label>
                        </div>
                        <textarea class="form-control"  name="pgp_key" " disabled id="" rows="10" >{{ session()->get('encrypted_message') }}</textarea>
                        <div class="footnote">Decrypt the above message with the PGP key entered and copy and paste<br>the verification code into the field below.</div>
                        <div class="label mt-10">
                            <label for="verification_code">verification code   </label>
                        </div>
                        <div class="row g-3">
                            <div class="col-auto">
                                <input type="text" id="verification_code" class="form-control" name="verification_code">
                            </div>
                            <div class="col-auto">
                                <a href="{{ route('cancelpgpkeychange') }}">cancel</a>
                                <button class="btn btn-primary mb-3" type="submit">confirm and change</button>
                            </div>
                        </div>
                    </form>

                    @else
                    <form action="{{route('forgot.pgp.generate')}}" method='post' >
                        @csrf
                        <h5 class="card-title">Change PGP Key</h5>

                        @if(Session::has('error'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        @endif
                        <form class="row g-3">
                            <textarea class="form-control"  name="pgp_key" placeholder="Paste PGP key here" id="" rows="10" >{{old('pgp_key')}}</textarea>
                            <label for="floatingTextarea">PGP Key</label>
                            <div class="info-message">A message will be encrypted with the PGP key entered. You will have to decrypt it and paste the verification code to confirm the PGP key change.</div>

                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary mb-3">Add PGP </button>
                            </div>
                        </form>

                        @endif

                        @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                </div>
            </div>
        </div>
    </div>
</div>



@endsection