@extends('layouts.homeapp')
@section('content')
<head>
    
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<style>.tab-content {
    display: none;
}

#tab21:checked ~ #content21,
#tab22:checked ~ #content22,
#tab23:checked ~ #content23,
#tab24:checked ~ #content24,
#tab25:checked ~ #content25 {
    display: block;
}
</style>
<div class="deshboard_main_part deshboard_main_part_card">
    <div class="super_container">
        <nav class="breadcrumb-nav">
            <ol class="breadcrumb d-flex align-items-center gap-2 mb-0">
                <li class=""><a class="nav-link" href="/"> {{ trans('auth.home_link')}}</a></li> >
                <li class=""><a class="nav-link"
                        href="{{ route('products.by.category', $product->category) }}">Product</a></li>
                >
                <li class=" ries">Accessories</li>
            </ol>
        </nav>
<form action="{{ route('user.add.cart', ['product' => $product]) }}" method="post">
    @csrf
    <div class="section_product">
        <div class="product_main row">
            <div class="col-md-6">
                <div class="details">
                    <h3 class="product-title text-uppercase">{{ ucfirst($product->name) }}</h3>
                    <div class="rating">
                        @php
                        $avgRating = $product->reviews()->avg('rating');
                        $fullStars = floor($avgRating);
                        $halfStar = ($avgRating - $fullStars) >= 0.5;
                        $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                        @endphp
                        <div class="stars">
                            <span class="mx-1 star_main star_main-2">
                                @for($i = 1; $i <= $fullStars; $i++)
                                    <img src="{{ asset('assets/star-full.png') }}" alt="Full Star" />
                                @endfor
                                @if($halfStar)
                                    <img src="{{ asset('assets/star-half.png') }}" alt="Half Star" />
                                @endif
                                @for($i = 1; $i <= $emptyStars; $i++)
                                    <img src="{{ asset('assets/empty-star.png') }}" alt="Empty Star" />
                                @endfor
                            </span>
                            <span class="review-no font-bold mx-1 text-warning text-bold text-white-50">
                                ({{ number_format($avgRating, 1) }})
                            </span>
                        </div>
                   <div class="sellor-info d-flex justify-content-between">
    <h5>
        <span class="text-white-50">Seller: </span>
        <span>
            <a class="badge text-bg-dark text-light"
               href="{{ route('seller.profile', $product->seller->username) }}">
                {{ $product->seller->username }}
            </a>
            <div class="badge text-bg-success text-light" style="background-color:green !important">
                {{ calculateReputationTier($product->seller->id) }}
            </div>
        </span>
    </h5>
    <p><img src="http://192.81.216.50/assets/eye.png" alt="eye"> {{ $product->visit_count }}</p>
</div>


                        <div class="d-flex gap-2 fs-7">
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/btc.png" alt="BTC Logo">
                                <span class="fw-bold">(BTC)</span>
                            </span>
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/xmr.png" alt="XMR Logo">
                                <span class="fw-bold">(XMR)</span>
                            </span>
                        </div>
                    </div>
                    <div class="row mt-3 mb-3 align-items-center">
                        <div class="col">
                            <h5 class="prd-price">
                                <span>Price: </span>
                                <span class="text-accent-1">
                                    {{ convertCurrency($product->price, request()->currency) }} {{ request()->currency }}
                                </span>
                            </h5>
                        </div>
                        <div class="col text-end">
                            <h5>
                                <span>Stock: </span>
                                <span class="text-accent-1">{{ $product->stock ? $product->stock : 0 }}</span>
                            </h5>
                        </div>
                    </div>
                    @if($product->wdiscount)
                        <table class="table tale-prd table-bordered table-hover c-product-table mt-2">
                            <thead class="table-responsive">
                                <tr>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Discount</th>
                                    <th scope="col">Price / Quantity</th>
                                    <th scope="col">Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach(unserialize($product->wdiscount) as $key => $discount)
                                    <tr>
                                        <td scope="row">{{ $key }}</td>
                                        <td>{{ $discount }}</td>
                                        <td>{{ convertCurrency($product->price - $product->price * $discount / 100) }} {{ request()->currency }}</td>
                                        <td>{{ convertCurrency($product->price * $key - $product->price * $key * $discount / 100) }} {{ request()->currency }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                    @if(Session::has('error'))
                        <div class="error">
                            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        </div>
                    @endif
                    <div class="mt-2">
                        <div class="d-flex align-items-center gap-3">
                            @if($product->type == 'physical')
                                <label class="fw-bold w-200" for="country">Ship to Country: </label>
                                <select name="country" id="country" class="form-control py-0 mt-2">
                                    @foreach ($countries = config('countries') as $continent => $countriesByContinent)
                                        <optgroup label="{{ $continent }}">
                                            @foreach ($countriesByContinent as $code => $name)
                                                <option value="{{ $code }}">{{ $name }}</option>
                                            @endforeach
                                        </optgroup>
                                    @endforeach
                                </select>
                                @error('country')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            @endif

                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        </div>
                        <div class="quantity mb-3 mt-2 d-flex align-items-center gap-3">
                            <label for="quantity" class="fw-bold w-200">Quantity: </label>
                            <input id="quantity_input" type="text" name="quantity" pattern="[0-9]*" value="1" class="form-control">
                        </div>
                        <div class="d-flex align-items-center mt-4 product_btn">
                            <button type="submit" class="btn btn-main w-100">Add to Cart</button>
                        </div>
                    </div>
                </div>
            </div>
    <div class="col-md-6 right_side">
    <div class="">
        <input class="radio" id="one" name="group" type="radio" checked>
        <input class="radio" id="two" name="group" type="radio">
        <input class="radio" id="three" name="group" type="radio">
        
        <div class="panels col-sm-12">
            <!-- Panel for the second image -->
            <div class="panel mb-2" id="two-panel">
                <div class="panel-title">
                    <div class="image-container border-img position-relative">
                        <a href="http://68.183.65.127/storage/1/download.jpg" target="_blank">
                            <img class="w-100 object-fit-cover border" src="http://68.183.65.127/storage/1/conversions/644a19c19dfa4_download-preview.jpg">
                            
                            <!-- Zoom icon overlay in the top-right corner -->
                            <div class="position-absolute top-0 end-0 mt-2 me-2 btn btn-dark rounded-circle d-flex align-items-center justify-content-center">
                                <i class="fas fa-search-plus fs-5"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Panel for the first image -->
            <div class="panel mb-2" id="one-panel">
                <div class="panel-title">
                    @if($product->photo)
                        <div class="image-container border-img position-relative">
                            <a href="{{ $product->photo->getUrl() }}" target="_blank">
                                <img class="w-100 object-fit-cover border" src="{{ $product->photo->getUrl() }}" alt="{{ $product->name }}">
                                
                                <!-- Zoom icon overlay in the top-right corner -->
                                <div class="position-absolute top-0 end-0 mt-2 me-2 btn btn-dark rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="fas fa-search-plus fs-5"></i>
                                </div>
                            </a>
                        </div>
                    @else
                        <div class="image-container border-img position-relative">
                            <a href="{{ asset('assets/img/product-default.jpg') }}" target="_blank">
                                <img class="w-100 object-fit-cover border" src="{{ asset('assets/img/product-default.jpg') }}" alt="{{ $product->name }}">
                                
                                <!-- Zoom icon overlay in the top-right corner -->
                                <div class="position-absolute top-0 end-0 mt-2 me-2 btn btn-dark rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="fas fa-search-plus fs-5"></i>
                                </div>
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

        </div>
    </div>
</form>
    <div class="page-content mt-4 br1">
        <div class="tabbed">
            <input type="radio" id="tab21" name="css-tabs2" checked style="display:none;">
            <input type="radio" id="tab22" name="css-tabs2">
            <input type="radio" id="tab23" name="css-tabs2">
            <input type="radio" id="tab24" name="css-tabs2">
            <input type="radio" id="tab25" name="css-tabs2">

            <ul class="tabs tabs_prducts_item tabs d-flex align-items-center p-0">
                <li class="tab"><label for="tab21" class="p-3 text-uppercase fw-bold text-dark">Description</label></li>
                  <li class="tab"><label for="tab22" class="p-3 text-uppercase fw-bold text-dark">Delivery Options</label></li>
                <li class="tab"><label for="tab23" class="p-3 text-uppercase fw-bold text-dark ">Policy</label></li>
                <li class="tab"><label for="tab24" class="p-3 text-uppercase fw-bold text-dark">Reviews</label></li>
                <li class="tab"><label for="tab25" class="p-3 text-uppercase fw-bold text-dark">Questions and
                        Answers</label></li>
                        
              
            </ul>

            <div class="tab-content c-tab-content" id="content21">
                <h5 class="mb-3">Product Description</h5>
                <p>{{$product->description}}</p>
            </div>
            <div class="tab-content" id="content22">
    <div class="card-header-2 w-100 mb-4">
        {{ trans('common.shipping') }} {{ trans('common.methods') }} {{ trans('common.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-prd mt-2 table-striped table-hover datatable datatable-Product text-center">
                <thead>
                    <tr>
                        <th>{{ trans('common.no') }}.</th>
                        <th>{{ trans('common.name') }}</th>
                        <th>{{ trans('common.price') }}</th>
                        <th>{{ trans('common.delivery') }} {{ trans('common.time') }}</th>
                        <th>{{ trans('common.active') }}</th>
                        <th>{{ trans('common.countries') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($shippingMethods as $shippingMethod)
                        <tr>
                            <td>{{ isset($a) ? ++$a : $a=1 }}.</td>
                            <td>{{ $shippingMethod->name }}</td>
                            <td>{{ $shippingMethod->is_free ? trans('common.free') : '$ ' . $shippingMethod->price }}</td>
                            <td>{{ $shippingMethod->delivery_time }} {{ trans('common.days') }}</td>
                            <td>{{ $shippingMethod->availability }}</td>
                            <td class="text-wrap">
                                {{ is_array($shippingMethod->countries) ? implode(', ', $shippingMethod->countries) : $shippingMethod->countries }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

            <div class="tab-content" id="content23">
                <h5 class="mb-3 fw-bold">Product Policy</h5>
                <p> {{$product->policy}}</p>
            </div>

            <div class="tab-content" id="content24">
                <h5 class="mb-3 fw-bold">Reviews</h5>
                <form class="mb-4" action="{{ route('products.reviews.store', $product->id) }}" method="POST">
                    @csrf

                <!--    <div class="form-group">-->
                <!--        <label for="rating" class="my-2">Rating</label>-->
                <!--        <select name="rating" id="rating" class=" ">-->
                <!--            <option value="1">1</option>-->
                <!--            <option value="2">2</option>-->
                <!--            <option value="3">3</option>-->
                <!--            <option value="4">4</option>-->
                <!--            <option value="5">5</option>-->
                <!--        </select>-->
                <!--    </div>-->

                <!--    <div class="form-group">-->
                <!--        <label for="comment" class="mb-2 mt-3">Comment</label>-->
                <!--        <textarea name="comment" id="comment" class="form-control"></textarea>-->
                <!--    </div>-->

                <!--    <button type="submit" class="btn btn-main mt-3">Submit Review</button>-->
                </form>

                <div class=""> @foreach ($reviews as $review)
                    <div class="card mb-3 overflow-hidden">
                        <div class="card-body bg-body-tertiary">
                            <h5 class="card-title">{{ $review->user->name }}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">Rating: {{ $review->rating }}</h6>
                            <p class="card-text">{{ $review->comment }}</p>
                        </div>
                    </div>
                    @endforeach
                    {{ $reviews->appends(['review' => $reviews->currentPage()])->links('partials.pagination') }}

                </div>
            </div>

            <div class="tab-content" id="content25">
                <h5 class="mb-3 fw-bold">Questions and Answers</h5>

                <!-- Create question form -->
                <div class="mb-3">
                    <h3>Ask a Question</h3>
                    <form action="{{ route('product.questions.store', $product->id) }}" method="POST">
                        @csrf
                        <textarea name="question" rows="4" class="form-control-2"
                            placeholder="Enter your question..."></textarea><br>
                        <button type="submit" class="btn btn-main mt-3">Submit</button>
                    </form>
                </div>

                <!-- Display existing questions and answers -->
                @foreach ($product->questions as $question)
                <div class="mb-3">
                    <div class="a-fixed-left-grid a-spacing-small">
                        <div class="a-fixed-left-grid-inner">
                            <div class="row">
                                <div class="col-12 col-md-2">
                                    <span class="fw-bold">Question:</span>
                                </div>
                                <div class="col-12 col-md-10">
                                    <p>{{ $question->question }}</p>
                                    <p>Asked by: {{ $question->user->username }}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if ($question->answer)
                    <div class="a-fixed-left-grid a-spacing-small">
                        <div class="a-fixed-left-grid-inner">
                            <div class="row">
                                <div class="col-12 col-md-2">
                                    <span class="fw-bold">Answer:</span>
                                </div>
                                <div class="col-12 col-md-10">
                                    <p>{{ $question->answer }}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @else
                    <div class="a-fixed-left-grid a-spacing-small">
                        <div class="a-fixed-left-grid-inner">
                            <div class="row">
                                <div class="col-12 col-md-2">
                                    <span class="fw-bold">Answer:</span>
                                </div>
                                <div class="col-12 col-md-10">
                                    <p>No answer yet</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                    <hr>
                </div>
                @endforeach
            </div>
      

   
</div>


        </div>
       
    </div>
    @endsection