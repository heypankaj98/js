@extends('layouts.buyer.app')
@section('content')
<section class="section dashboard">
   
     <div class=" mb-4 col-md-12">
   
    <div class="bg-card-2 h-100 br1">
         <h3 class="card-header-2 text-center">

           Become Seller
        </h3>
          <div class="container">
        <h1>Become a Seller</h1>
        <p>Are you looking to expand your business and reach a wider audience? Join us as a seller and take advantage of our platform to showcase your products and services.</p>
        
        <h2>Why Become a Seller?</h2>
        <p>As a seller, you will gain access to a variety of features that can help you grow your business, including:</p>
        <ul>
            <li>Direct access to a large customer base.</li>
            <li>Tools to manage your inventory and sales.</li>
            <li>Support from our dedicated team.</li>
            <li>Marketing and promotional opportunities.</li>
        </ul>

        <h2>Requirements</h2>
        <p>To become a seller, you must meet the following requirements:</p>
        <ul>
            <li>Must have a registered business.</li>
            <li>Provide valid contact information.</li>
            <li>Agree to our seller policies and terms.</li>
        </ul>

        <h2>Get Started</h2>
        <p>If you are interested in becoming a seller, please contact us for more information and to receive the application form.</p>
    </div>
     <h6 class="my-3"> Wallet Balance</h6>
 
    <div class="d-flex justify-content-between">
        <p class="mb-2">Bitcoin (BTC):{{ $user->btc_balance ?? 0 }}</p>
        <p>Monero (XMR): {{ $user->xmr_balance ?? 0 }}</p>
    </div>
    
@php
    $walletBalance = $user->btc_balance;

    $setting = \App\Models\Settings::where('key', 'become_seller_fee')->first();
@endphp

<h4 class="card-header-2 text-center">Seller Fees: {{ $setting ? $setting->value : 'N/A' }} USD</h4>

<!--<div class="text-center mb-3">-->
<!-- Center the balance message -->
<!--    @if ($walletBalance > ($setting ? $setting->value : 0))-->
<!--        <a class="btn btn-success">Sufficient Balance</a>-->
<!--    @else-->
<!--        <a class="btn btn-danger">Low Balance</a>-->
<!--    @endif-->
<!--</div>-->

<div class="d-flex justify-content-between mt-2"> <!-- Flex container for left and right buttons -->
    <a href="{{ route('buyer.wallet') }}" >
        <span class="btn btn-danger">My Wallet</span>
    </a>

    <!-- Form for "Pay Through Balance" -->
<!--    <form method="POST" action="{{ route('user.become.seller') }}">-->
<!--        @csrf-->
<!--        <button type="submit" class="btn btn-success">Pay Through Balance</button>-->
<!--    </form>-->
<!--</div>-->

<!-- Form for submitting the seller request -->
<form method="POST" action="{{ route('user.become.seller') }}">
    @csrf
    <input type="hidden" name="payment_method" value="BTC"> <!-- Default payment method -->

    <div class="d-flex">
        <button class="btn btn-success" type="submit">Pay Through Balance</button>
    </div>
</form>




        </div>
<!--        <form method="POST" action="{{ route('user.request.become.seller') }}">-->
<!--            @csrf-->
<!--            <h6 class="my-3 info-message">   {{ trans('product.payment_method') }}</h6>-->
<!--            <div class="my-3">-->
<!--                @foreach(config('coins.coin_list') as $index => $coin)-->
<!--                @if($coin !== 'BitcoinMultiSign')-->
<!--                <div class="form-check">-->
<!--                    <input id="payment_method" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>-->
<!--                    <label class="form-check-label" for="payment_method">{{$coin}} [{{$index}}]</label>-->
<!--                </div>-->
<!--                @endif-->
<!--                @endforeach-->
<!--            </div>-->
<!--            <button class="w-100 btn btn-primary btn-lg" type="submit">  {{ trans('product.generate_address') }} </button>-->
<!--        </form>-->
<!--    </div>-->

<!--    <div class="col-md-12">-->
<!--        @if (session('success'))-->
<!--        <div id="alert_message" class="alert alert-success alert-block">-->
<!--            <strong>{{ session('success') }}</strong>-->
<!--        </div>-->
<!--        @elseif(session('error'))-->
<!--        <div id="alert_message" class="alert alert-danger alert-block">-->
<!--            <strong>{{ session('error') }}</strong>-->
<!--        </div>-->
<!--        @endif-->
<!--    </div>-->
        
<!--    </div>-->
<!--      <div class="bg-card-2 h-100 br1">-->
<!--           <div class=" mb-4 col-md-12">-->
   

<!--    <h2>Become Seller Fee: {{$seller_fee}}</h2>-->
<!--    <p class="info-message">*once you submit request wait for few minutes to confirm payment.</p>-->
<!--    <table class="table">-->
<!--        <thead>-->
<!--            <tr>-->
<!--                <th>{{ trans('product.pay-method') }}</th>-->
<!--                <th>{{ trans('product.address') }}</th>-->
<!--                <th> {{ trans('product.to_pay') }}</th>-->
<!--                <th> {{ trans('product.balance') }}</th>-->
<!--                <th>{{ trans('product.action') }}</th>-->
<!--            </tr>-->
<!--        </thead>-->
<!--        <tbody>-->


<!--            @if (!is_null($paymment_coin))-->
      
<!--            @foreach ($paymment_coin as $method => $payment)-->
<!--            <tr>-->
<!--                <td>{{ $method }}</td>-->
<!--                <td>{{ $payment['address'] }}</td>-->
<!--               <td>{{ convert($seller_fee, $method) }}</td>-->
<!--                <td>{{ $payment['balance'] }}</td>-->
<!--                <td>-->
<!--                    @if ($payment['balance'] >= convert($seller_fee, $method))-->
<!--                    You can request to become a seller-->
<!--                    @else-->
<!--                    Balance is less than the seller fee-->
<!--                    {{ trans('product.balance_is_less') }}-->
<!--                    @endif-->
<!--                </td>-->
<!--            </tr>-->
        
<!--            @endforeach-->
<!--            @endif-->
<!--        </tbody>-->

<!--    </table>-->

<!--   <form method="POST" action="{{ route('user.become.seller') }}">-->
<!--    @csrf-->
<!--    <div class="d-flex gap-2">-->
<!--        <button class="btn btn-primary btn-lg flex-grow-1" type="submit">Submit Request</button>-->
<!--        <button class="btn btn-success btn-lg flex-grow-1" type="button" onclick="location.reload();">Refresh</button>-->
<!--    </div>-->
<!--</form>-->

<!--    </div>-->
    </div>
</section>
@endsection
