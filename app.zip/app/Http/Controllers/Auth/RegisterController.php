<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\Auth\RegisterUserRequest;
use Illuminate\Http\Request;

class RegisterController extends Controller {
    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct() {
        $this->middleware('guest');
    }

    public function show() {
        return view('auth.register');
    }

    public function register(RegisterUserRequest $request) {
        try {
            $request->register();
            session()->flash('success', 'You are registered! ');
            return redirect()->route('show.mnemonic');
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    public function showMnemonic() {
        if (!session()->has('mnemonic_key'))
            return redirect()->route('login');
        return view('auth.mnemonic')->with('mnemonic', session()->get('mnemonic_key'));
    }

    public function showMnemonicVefiry() {
        if (!session()->has('mnemonic_key'))
            return redirect()->route('login');
        return view('auth.mnemonic_verify')->with('mnemonic', session()->get('mnemonic_key'));
    }

    public function verifyMnemonic(Request $request) {
        $request->validate([
            'mnemonic' => 'required|string',
        ]);

        $mnemonic = $request->input('mnemonic');
        $hashedMnemonic = session()->get('mnemonic_key');
        
      if ($mnemonic == $hashedMnemonic) {
    session()->flash('mnemonic_key', $mnemonic);
    session()->flash('success', 'You are successfully registered!');
    return redirect()->route('login');
        } else {
            session()->flash('error', 'Mnemonic not verified');
            return redirect()->back();
        }
    }
}