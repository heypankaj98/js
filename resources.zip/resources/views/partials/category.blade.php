<style>

</style>
<nav id="sidebarMenu" class="sidebar-menu side-bar-row-box d-md-block">
    <div class="sidebar-menu-content">
        <h2 class="sidebar-menu-title"> Categories </h2>
        
<div class="menu-wrapper">
    @foreach(app('categories') as $category)
        <div class="menu-item">
            <input type="checkbox" id="submenu-toggle-{{ $category->id }}" class="submenu-toggle visually-hidden">
            <label for="submenu-toggle-{{ $category->id }}" class="menu-item-header">
                <span class="expand-toggle">+</span>
                <a href="{{ route('products.by.category', $category) }}" class="menu-item-link">{{ $category->name }} <span class="back-color-green1">{{ $category->totalAllChildrenProducts() }}</span></a>
            </label>
            <div class="menu-item-dropdown">
                <ul>
                    @foreach($category->subcategory as $subcategory)
                        <li>
                            <input type="checkbox" id="submenu-toggle-{{ $subcategory->id }}" class="submenu-toggle visually-hidden">
                            <label for="submenu-toggle-{{ $subcategory->id }}" class="menu-item-header menu-item-header2">
                                <span class="expand-toggle">+</span>
                                <a href="{{ route('products.by.category', $subcategory) }}" class="menu-item-link menu-item-link2">{{ $subcategory->name }} <span class="back-color-green2">{{ $subcategory->totalProducts() }}</span></a>
                            </label>
                            @if(count($subcategory->subcategory) > 0)
                                <div class="submenu-item-dropdown">
                                    <ul>
                                        @foreach($subcategory->subcategory as $subsubcategory)
                                            <li>
                                                <input type="checkbox" id="submenu-toggle-{{ $subsubcategory->id }}" class="submenu-toggle visually-hidden">
                                                <label for="submenu-toggle-{{ $subsubcategory->id }}" class="menu-item-header menu-item-header3">
                                                    <span class="expand-toggle expand-toggle-white">+</span>
                                                    <a href="{{ route('products.by.category', $subsubcategory) }}" class="menu-item-link menu-item-link3">{{ $subsubcategory->name }} <span class="back-color-green3">{{ $subsubcategory->totalProducts() }}</span></a>
                                                </label>
                                                @if(count($subsubcategory->subcategory) > 0)
                                                    <div class="submenu-item-dropdown">
                                                        <ul>
                                                            @foreach($subsubcategory->subcategory as $subsubsubcategory)
                                                                <li>
                                                                    <a href="{{ route('products.by.category', $subsubsubcategory) }}" class="menu-item-link menu-item-link4">{{ $subsubsubcategory->name }} ({{ $subsubsubcategory->totalProducts() }})</a>
                                                                </li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    @endforeach
</div>

    </div>
</nav>
