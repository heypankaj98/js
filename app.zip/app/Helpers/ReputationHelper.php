<?php

namespace App\Helpers;

 class ReputationHelper
{
    public static function calculateReputationTier(int $productsSold): string
    {
        if ($productsSold >= 300) {
            return 'Demon Seller';
        }

        $reputationTiers = [
            ['tier' => 10, 'min' => 95, 'max' => 299],
            ['tier' => 9, 'min' => 85, 'max' => 94],
            ['tier' => 8, 'min' => 75, 'max' => 84],
            ['tier' => 7, 'min' => 65, 'max' => 74],
            ['tier' => 6, 'min' => 55, 'max' => 64],
            ['tier' => 5, 'min' => 45, 'max' => 54],
            ['tier' => 4, 'min' => 35, 'max' => 44],
            ['tier' => 3, 'min' => 25, 'max' => 34],
            ['tier' => 2, 'min' => 15, 'max' => 24],
            ['tier' => 1, 'min' => 5, 'max' => 14],
            ['tier' => 0, 'min' => 0, 'max' => 4],
        ];

        foreach ($reputationTiers as $tier) {
            if ($productsSold >= $tier['min'] && $productsSold <= $tier['max']) {
                return 'Reputation ' . $tier['tier'];
            }
        }

        return 'No Reputation';
    }

}
