<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration {

    public function up() {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('trx_id');
            $table->string('crypto_name');
            $table->string('crypto_address');
            $table->decimal('crypto_amount', 8, 8);
            $table->tinyInteger('status')->unsigned()->default(0)->limit(1);
            $table->enum('type', ['order', 'dispute', 'ads', 'multisign', 'payouts','become_vendor'])->default('order');
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users');
       
        });
    }

    public function down() {
        Schema::dropIfExists('transactions');
    }

}
