@extends('layouts.seller.app')
@section('content')
@if($page == 'physical')
    @include('seller.include.physical')
@elseif($page == 'digital')
    @include('seller.include.digital')
@else
    @include('seller.include.auction')
@endif
@endsection