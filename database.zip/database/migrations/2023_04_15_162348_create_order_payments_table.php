<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderPaymentsTable extends Migration
{
    public function up()
    {
        Schema::create('order_payments', function (Blueprint $table) {
            $table->id();
            $table->string('order_id');
            $table->string('method');
            $table->text('payment_address');
            $table->string('status')->default('waiting');
            $table->decimal('amount', 8, 8);
            $table->decimal('total_received', 8, 8)->default(0.00000000);
            $table->boolean('deleted')->default(false);
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('order_payments');
    }
}
