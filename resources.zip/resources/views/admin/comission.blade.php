@extends('layouts.admin.master')

@section('content')

<div class="">
    <h1 class="my-4" style="font-size:14px">Commission Settings</h1>
    
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="row">
        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Ads Commission for Impression</h5>
                    <a class="btn btn-primary">{{ $commission['ads_impression'] ?? 0 }}</a>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Ads Commission for Click</h5>
                    <a class="btn btn-primary">{{ $commission['ads_click'] ?? 0 }}</a>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Order Commission</h5>
                    <a class="btn btn-primary">{{ $commission['market_fee'] ?? 0 }}</a>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Featured Product Commission</h5>
                    <a class="btn btn-primary">{{ $commission['featured_product'] ?? 0 }}</a>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Become Seller Fee</h5>
                    <a class="btn btn-primary">{{ $commission['become_seller_fee'] ?? 0 }}</a>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3 mb-4">
            <div class="card h-100 bg-card-second">
                <div class="card-body">
                    <h5 class="card-title">Commission Per Product Sale</h5>
                    <a class="btn btn-primary">{{ $commission['product_sale_commission'] ?? 0 }}</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-8 col-lg-6 ">
            <form action="{{ route('admin.comission.store') }}" method="POST" class="bg-card-second">
                @csrf
                
                <div class="form-group mb-3">
                    <label for="become_seller_fee">Become Seller Fee</label>
                    <input type="number" class="form-control" id="become_seller_fee" name="become_seller_fee" value="{{ $commission['become_seller_fee'] ?? 0 }}">
                </div>
                
                <div class="form-group mb-3">
                    <label for="ads_commission_imp">Ads Commission for Impression</label>
                    <input type="number" class="form-control" id="ads_commission_imp" name="ads_commission_imp" value="{{ $commission['ads_impression'] ?? 0 }}">
                </div>
               
                <div class="form-group mb-3">
                    <label for="ads_commission_click">Ads Commission for Click</label>
                    <input type="number" class="form-control" id="ads_commission_click" name="ads_commission_click" value="{{ $commission['ads_click'] ?? 0 }}">
                </div>
                
                <div class="form-group mb-3">
                    <label for="order_commission">Order Commission</label>
                    <input type="number" class="form-control" id="order_commission" name="order_commission" value="{{ $commission['market_fee'] ?? 0 }}">
                </div>

                <div class="form-group mb-3">
                    <label for="featured_product_commission">Featured Product Commission</label>
                    <input type="number" class="form-control" id="featured_product_commission" name="featured_product_commission" value="{{ $commission['featured_product'] ?? 0 }}">
                </div>

                <div class="form-group mb-3">
                    <label for="product_sale_commission">Commission Per Product Sale</label>
                    <input type="number" class="form-control" id="product_sale_commission" name="product_sale_commission" value="{{ $commission['product_sale_commission'] ?? 0 }}">
                </div>
                
                <button type="submit" class="btn btn-main">Save Commissions </button>
            </form>
        </div>
    </div>
</div>

<style>
    .card {
        border-radius: 0.5rem;
    }

    .btn.btn-primary {
        background-color: #ff7d00;
        border: transparent;
        color: #000;
    }

    @media (max-width: 576px) {
        .container {
            padding: 0 1rem;
        }
    }

    @media (min-width: 577px) {
        .container {
            padding: 0 2rem;
        }
    }
</style>

@endsection
