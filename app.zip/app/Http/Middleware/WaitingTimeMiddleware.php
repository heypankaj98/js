<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;

class WaitingTimeMiddleware
{
    public function handle($request, Closure $next)
    {
        if (!Session::has('waiting')) {
            Session::put('waiting', true);
            Session::put('waiting_start_time', now());
        }

        $elapsedSeconds = now()->diffInSeconds(Session::get('waiting_start_time'));
        $waitingTime = rand(3, 7);

        if ($elapsedSeconds >= $waitingTime) {
            return $next($request);
        }
        
        return response(view('waiting'));
    }
}