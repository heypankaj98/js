<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib;

use Exception;
use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib\jsonRPCClient;

class nodeRPC {

    private $client, $protocol, $host, $port, $url, $user, $password;

    function __construct($host = '127.0.0.1', $port = 18081, $SSL = false, $user = null, $password = null) {
        if (is_array($host)) { // Parameters passed in as object/dictionary
            $params = $host;

            $host = $params['host'] ?? '127.0.0.1';
            $port = $params['port'] ?? 18081;
            $protocol = $params['protocol'] ?? ($SSL ? 'https' : 'http');
            $user = $params['user'] ?? null;
            $password = $params['password'] ?? null;
        } else {
            $protocol = $SSL ? 'https' : 'http';
        }

        $this->host = $host;
        $this->port = $port;
        $this->protocol = $protocol;
        $this->user = $user;
        $this->password = $password;
        $this->check_SSL = $SSL;

        $this->url = $protocol . '://' . $host . ':' . $port . '/';
        $this->client = new jsonRPCClient($this->url, $this->user, $this->password, $this->check_SSL);
    }

    /**
     * Execute command via jsonRPCClient
     *
     * @param  string  $method  RPC method to call
     * @param  array   $params  Parameters to pass  (optional)
     *
     * @return mixed  Call result
     */
    private function _run($method, $params = null, $path = 'json_rpc') {
        try {
            return $this->client->_run($method, $params, $path);
        } catch (Exception $e) {
            throw new Exception('RPC call failed: ' . $e->getMessage());
        }
    }

    /**
     * Get information about the node.
     *
     * @return mixed
     */
    public function get_info() {
        return $this->_run('get_info');
    }
    
      public function get_wallet_info() {
        return $this->_run('get_wallet_info');
    }

    /**
     * Get the current blockchain height.
     *
     * @return mixed
     */
    public function get_height() {
        return $this->_run('get_height');
    }

    /**
     * Get the synchronization status of the node.
     *
     * @return mixed
     */
    public function get_sync_info() {
        return $this->_run('get_sync_info');
    }

    /**
     * Get information about the mining status.
     *
     * @return mixed
     */
    public function get_mining_status() {
        return $this->_run('get_mining_status');
    }

    /**
     * Start or stop mining.
     *
     * @param bool $start Whether to start or stop mining
     * @return mixed
     */
    public function set_mining($start = true) {
        return $this->_run($start ? 'start_mining' : 'stop_mining');
    }

    /**
     * Get information about a specific transaction.
     *
     * @param string $txid Transaction ID
     * @return mixed
     */
    public function get_transaction($txid) {
        return $this->_run('get_transaction', ['txid' => $txid]);
    }

    /**
     * Get a list of all transactions in the blockchain.
     *
     * @return mixed
     */
    public function get_transactions() {
        return $this->_run('get_transactions');
    }

    /**
     * Get the last block hash.
     *
     * @return mixed
     */
    public function get_last_block_hash() {
        return $this->_run('get_last_block_hash');
    }

    /**
     * Get the list of incoming transactions for the node.
     *
     * @return mixed
     */
    public function get_incoming_transfers() {
        return $this->_run('get_incoming_transfers');
    }

    /**
     * Get the list of outgoing transactions for the node.
     *
     * @return mixed
     */
    public function get_outgoing_transfers() {
        return $this->_run('get_outgoing_transfers');
    }

    /**
     * Get the list of unspent outputs for the node.
     *
     * @return mixed
     */
    public function get_unspent_outputs() {
        return $this->_run('get_unspent_outputs');
    }

    /**
     * Get the list of block template.
     *
     * @return mixed
     */
    public function get_block_template($miner_address = '', $reserve_size = 0) {
        return $this->_run('get_block_template', ['miner_address' => $miner_address, 'reserve_size' => $reserve_size]);
    }

    /**
     * Submit a mined block to the network.
     *
     * @param string $block_blob The block blob in hex format
     * @return mixed
     */
    public function submit_block($block_blob) {
        return $this->_run('submit_block', ['block_blob' => $block_blob]);
    }
}
