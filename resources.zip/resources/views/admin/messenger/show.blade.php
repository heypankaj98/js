@extends('admin.messenger.template')
@section('title', $topic->subject)

@section('messenger-content')


<div class="mt-4">
    <div class="row">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="bg-card-2 mb-4 br1 p-16">

                    <div>
                        <h5 class="card-header-2 w-100 mb-4">Channels</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">#general</a></li>
                            <li><a href="#">#announcements</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Users -->

                <div class="bg-card-2 mt-auto br1 h-100 p-16">
                    <h5 class="card-header-2 w-100 mb-4">Chat Users</h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                        <li class="{{ request()->is("messenger/".$singletopic->id) ? "active" : "" }}" >  <a href="{{ route('admin.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                    <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">

                                    <span>{{$singletopic->receiverOrCreator()->username}} ( {{ $singletopic->mesasgeUnreadCount() }} ) </span>
                                    <p class="small">online</p>

                                    @endif
                                </div>
                            </a>
                        </li>
                        @empty
                        No chat User
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">

                    <h5>Chat with {{$topic->receiverOrCreator()->username}}</h5>

                </div>
                <div class="card-body">
                    <div class="chat-messages">

                        @foreach($topic->messages as $message)
                        @if($message->sender_id == Auth::user()->id)
                        <div class="message sent">
                            <div class="message-content mw-100  ">
                                <div class="message-header small">
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text">
                                    {{ $message->content }}
                                </div>
                                @if ($message->hasMedia('photo'))
                                <div class="message-text">
                                    <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                        <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                        @else

                        <div class="message received">

                            <div class="message-content mw-100 ">
                                <div class="message-header small">
                                    <img src="{{$message->sender->avatar}}" class="rounded-circle">
                                    <span class="username">{{$message->sender->username}}</span>
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text mw-100">
                                    {{ $message->content }}
                                </div>
                                @if ($message->hasMedia('photo'))
                                <div class="message-text">
                                    <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                        <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                        @endif
                        @endforeach
                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">

                    <form action="{{ route("admin.messenger.reply", [$topic->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="file" class="form-control-file" name="picture"  accept="image/*">
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                <button type="submit" class="btn btn-main">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="bg-card-2 mb-4 br1 p-16">
                <h5 class="card-header-2 w-100 mb-4">Admin Users</h5>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                    @if (auth()->user()->id != $adminuser->id)
                    @if($adminuser->withChatMessages($adminuser->id) > 0)
                    <a href="{{ route('admin.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$adminuser->username}}</span></a>

                    @else
                    <a href="{{ route('admin.messenger.newMessages', [$adminuser->id]) }}">     <span class="badge text-bg-primary">{{ $adminuser->username}}</span></a>

                    @endif
                    @endif
                    @empty
                    No chat and admin Here
                    @endforelse
                </ul>
            </div>
            <!-- Mod --> 
            <div class="bg-card-2 br1 p-16">
                <h5 class="card-header-2 w-100 mb-4">Mod Users</h5>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                    @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('admin.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    @else
                    <a href="{{ route('admin.messenger.newMessages', [$moduser->id]) }}">     <span class="badge text-bg-primary">{{ $moduser->username}}</span></a>

                    @endif
                    @endif
                    @empty
                    No chat and Mod User
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>




@stop