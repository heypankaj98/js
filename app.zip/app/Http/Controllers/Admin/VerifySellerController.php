<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
class VerifySellerController extends Controller
{
    public function index()
    {
        // Get all sellers (assuming 'isSeller' flag is used to filter sellers)
        $sellers = User::where('isSeller', 1)->get();  // Fetch all users who are sellers

        // Pass the sellers to the view
        return view('admin.sellerlist', compact('sellers'));
    }

 public function toggleVerification(Request $request, $id)
{
    // Find the seller by ID
    $seller = User::where('isSeller', 1)->findOrFail($id);
    
    // Toggle the verification status
    $seller->is_verified = !$seller->is_verified;

    // If the seller is verified, set 'fe_Seller' to 1, otherwise set it to null
    $seller->fe_Seller = $seller->is_verified ? 1 : null;
    
    // Save the changes
    $seller->save();

    // Redirect back with a success message
    return redirect()->route('admin.sellerlist')->with('status', 'Seller verification status updated.');
}

}
