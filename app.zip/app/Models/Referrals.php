<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Referrals extends Model {

    use HasFactory;

    protected $fillable = ['user_id', 'referred_user_id', 'earned'];

    public function user() {
        return $this->belongsTo(User::class);
    }
    public function referredUser()
    {
        return $this->belongsTo(User::class, 'referred_user_id');
    }

}
