@extends('layouts.admin.master')    @section('content')
<div class="mt-4">
<div class="card-header-2 w-100 mb-4">
        {{ trans('global.create') }} {{ trans('cruds.productCategory.title_singular') }}
    </div>
<div class="bg-card-2 br1">
    
    <div class="card-body">
        <form method="POST" action="{{ route("admin.product-categories.store") }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label>Select parent category</label>
                <select type="text" name="parent_id" class="form-control py-0">
                    <option value="">None</option>
                    @if($categories)
                        @foreach($categories as $category)
                            <option value="{{$category->id}}">{{$category->name}}</option>
                        @endforeach
                    @endif
                </select>
            </div>
            <div class="form-group">
                <label class="required label_main" for="name">{{ trans('cruds.productCategory.fields.name') }} <span class="gold_star">{{ trans('auth.user_star') }} </sapn></label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', '') }}" required>
                @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{ $errors->first('name') }}
                </div>
                @endif
                <span class="help-block">{{ trans('cruds.productCategory.fields.name_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="description">{{ trans('cruds.productCategory.fields.description') }}</label>
                <textarea class="form-control form-control-textarea {{ $errors->has('description') ? 'is-invalid' : '' }}" name="description" id="description">{{ old('description') }}</textarea>
                @if($errors->has('description'))
                <div class="invalid-feedback">
                    {{ $errors->first('description') }}
                </div>
                @endif
                <span class="help-block">{{ trans('cruds.productCategory.fields.description_helper') }}</span>
            </div>
            <div class="form-group mb-0">
                <button class="btn btn-main" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>
</div>

@endsection