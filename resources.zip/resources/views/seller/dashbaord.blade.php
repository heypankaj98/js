@extends('layouts.seller.app')      @section('content')
             <div class="banner">
    <div class="home-inn"></div>
    <div class="home-inner"><h4 class="hme">Seller</h4>
    </div>
  <div class="text-co">In this <strong>Seller</strong> section, you can see overall sales, total products, and total earnings.</div>
<div class="text-co">Furthermore, there is a lot of information about sales on this page.</div>

</div>

<h2 class="custom-title my-4">Seller Dashboard</h2>

<div class="bg-card-1">
    <div class="row row-cards-one">
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.sales') }} - {{ trans('common.pending') }} !</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ $user->totalOrders('waiting') }}</span>
                   

                    <a href="{{route('seller.orders')}}" class="btn btn-main text-decoration-none">{{ trans('common.view') }} {{ trans('common.all') }}</a>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.sales') }} - {{ trans('common.processing') }} !</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ $user->totalOrders('ESCROW') }} </span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main text-decoration-none">{{ trans('common.view') }} {{ trans('common.all') }}</a>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.sales') }} - {{ trans('common.completed') }} !</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ $user->totalOrders('completed') }}</span>
                    
                    <a href="{{route('seller.orders')}}" class="btn btn-main text-decoration-none">{{ trans('common.view') }} {{ trans('common.all') }}</a>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.products') }}</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ $user->products()->count() }}</span>
                    <a href="{{ route('seller.products.index') }}" class="btn btn-main text-decoration-none">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.sales') }}</h5>
                    <span class="badge text-bg-dark my-3 fw-bold fs-2 m-auto">{{ $user->sellerOrders()->count() }}</span>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-2">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.earnings') }}</h5>
                    <span class="badge text-bg-dark my-3 fw-bold fs-2 m-auto">${{ array_sum($totalSales) }}</span>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-cards-one mb-4">
        <div class="col-md-6 col-lg-6 col-xl-6">
            <div class="bg-card-2 br1 h-100">
                <h5 class="card-header-2 w-100 mb-4">{{ trans('common.recent') }} {{ trans('common.products') }}</h5>
                <div class="card-body">
                    <div class="table-responsive dashboard-home-table">
                        <div id="pproducts_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="">
                                <div class="table-responsive">
                                    <table id="pproducts" class="table table-hover table-prd table-bordered dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid">
                                        <thead>
                                            <tr role="row">
                                                <th>{{ trans('common.name') }}</th>
                                                <th>{{ trans('common.type') }}</th>
                                                <th>{{ trans('common.price') }}</th>
                                            </tr>
                                        </thead>
                                        @forelse($recent_products as $recent_product)
                                            <tr>
                                                <th>{{ $recent_product->name }}</th>
                                                <th>{{ $recent_product->type }}</th>
                                                <th>$ {{ $recent_product->price }}</th>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="100%">{{ trans('common.no') }} {{ trans('common.products') }}.</td>
                                            </tr>
                                        @endforelse
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6">
            <div class="bg-card-2 br1 h-100">
                <h5 class="card-header-2 w-100 mb-4">{{ trans('common.recent') }} {{ trans('common.sales') }}</h5>
                <div class="card-body">
                    <div class="table-responsive dashboard-home-table">
                        <div id="pproducts_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="">
                                <div class="table-responsive">
                                    <table id="pproducts" class="table table-hover table-prd table-bordered dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid">
                                        <thead>
                                            <tr>
                                                <th>{{ trans('common.order') }}-{{ trans('common.number') }}</th>
                                                <th>{{ trans('common.order') }}-{{ trans('common.date') }}</th>
                                                <th>{{ trans('common.status') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($recent_orders as $recent_order)
                                                <tr>
                                                    <td>{{ $recent_order->order_id }}</td>
                                                    <td>{{ $recent_order->created_at }}</td>
                                                    <td>{{ $recent_order->status }}</td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="100%">{{ trans('common.no') }} {{ trans('common.sales') }}.</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-cards-one mb-4">
        <div class="col-md-6 col-lg-6 col-xl-6">
            <div class="bg-card-2 br1 h-100">
                <h5 class="card-header-2 w-100 mb-4">
                    {{ trans('common.total') }} {{ trans('common.sales') }} {{ trans('common.in') }} 30 {{ trans('common.days') }}
                </h5>
                <div class="card-body">
                    <div class="main-container">
                        <div class="year-stats">
                            <!--@for ($days = 1; $days <= \Carbon\Carbon::now()->month(\Carbon\Carbon::now()->month)->daysInMonth; $days++) @endfor-->
                            @foreach ($totalSales as $date => $total)
                                <div class="month-group">
                                    <div class="bar h-30"></div>
                                    <p class="month">{{ $date }}</p>
                                </div>
                            @endforeach
                        </div>
                        <div class="stats-info">
                            <div class="graph-container">
                                <p>{{ trans('common.total') }}: ${{ array_sum($totalSales) }}</p>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6">
            <div class="bg-card-2 br1 h-100">
                <h5 class="card-header-2 w-100 mb-4">
                    {{ trans('common.total') }} {{ trans('common.sales') }} {{ trans('common.in') }}: {{ \Carbon\Carbon::now()->format('Y') }}
                </h5>
                <div class="card-body">
                    <div class="main-container">
                        <div class="year-stats">
                            <div class="month-group">
                                <div class="bar h-100"></div>
                                <p class="month">{{ trans('common.jan') }}</p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-50"></div>
                                <p class="month">{{ trans('common.fab') }}</p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-75"></div>
                                <p class="month">{{ trans('common.mar') }} </p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-25"></div>
                                <p class="month">{{ trans('common.apr') }}</p>
                            </div>
                            <div class="month-group selected">
                                <div class="bar h-100"></div>
                                <p class="month">{{ trans('common.may') }} </p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-50"></div>
                                <p class="month">{{ trans('common.jun') }} Jun</p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-75"></div>
                                <p class="month">{{ trans('common.jul') }} </p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-25"></div>
                                <p class="month"> {{ trans('common.aug') }}</p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-50"></div>
                                <p class="month">  {{ trans('common.sep') }} </p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-75"></div>
                                <p class="month"> {{ trans('common.oct') }}</p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-25"></div>
                                <p class="month"> {{ trans('common.nov') }} </p>
                            </div>
                            <div class="month-group">
                                <div class="bar h-100"></div>
                                <p class="month"> {{ trans('common.dec') }}</p>
                            </div>
                        </div>

                        <div class="stats-info">
                            <div class="graph-container">
                                <p>{{ trans('common.total') }}: ${{ array_sum($totalSales) }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 