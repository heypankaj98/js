<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{ Auction , ProductCategory, };
use Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\Admin\UpdateAuctionRequest;

class AuctionController extends Controller {
    
    public function index(){
        abort_if(Gate::denies('admin_product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        
        $auction = Auction::paginate(config('setting.pagination'));
        
        return view('admin.auction.index',compact('auction'));
    }
    
    public function edit(Auction $auction) {
        abort_if(Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = ProductCategory::pluck('name', 'id');

        return view('admin.auction.edit', compact('categories', 'auction'));
    }
    
    public function update(UpdateAuctionRequest $request, Auction $auction) {
        abort_if(Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        
        $auction->update($request->all());
        
        if ($request->input('photo', false)) {
            if (!$auction->photo || $request->input('photo') !== $auction->photo->file_name) {
                if ($auction->photo) {
                    $auction->photo->delete();
                }
                $auction->addMedia(storage_path('tmp/uploads/' . basename($request->input('photo'))))->toMediaCollection('photo');
            }
        } elseif ($auction->photo) {
            $auction->photo->delete();
        }

        return redirect()->route('admin.auction.index');
    }
    
    public function destroy(Auction $auction) {
        abort_if(Gate::denies('admin_product_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $auction->delete();

        return back();
    }
}