@extends('layouts.seller.app')     @section('content')

<div class="col-md-12">
    @if (session('success'))
    <div id="alert_message" class="alert alert-success alert-block">
        <strong>{{session('success')}}</strong>
    </div>
    @elseif(session('error'))
    <div id="alert_message" class="alert alert-danger alert-block">
        <strong>{{ session('error') }}</strong>
    </div>
    @endif
</div>

<div class="col-lg-12 col-xl-12  bid_blade_main">
    <div class="bg-card-1 p-24" >
        <div class="card-header bg-success text-white px-4 py-3">
            <h5 class="text-muted mb-0 manage_text">Manage your Order, <span >{{ Auth::user()->username }}</span>!</h5>
        </div>
        <div class="bg-card-2 mt-3">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <p class="lead fw-normal mb-0">Order Status:</p>
                <p class="small text-muted mb-0">Order Number : {{ $id }}</p>
            </div>

            @foreach($orders as $order)
            <div class="bg-card-1 shadow-0 border mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4 bg-card-2">
                        <div class="">
                        @if($order->product->photo)
                            <img class="img-fluid img-100" src="{{ $order->product->photo->getUrl() }}" alt="{{$order->product->name }}">
                            @else
                            <img class="img-fluid img-100" src="{{ asset('assets/img/product-default.jpg')}}" alt="{{$order->product->name }}">
                            @endif                      
                         </div>
                        <div class="">
                        <p class="text-muted mb-0">{{ $order->product->name }}</p>
                        </div>
                        <div class="">
                            <p class="text-muted mb-0 small">
                            <p class="text-muted mb-0 small">Qty: {{ $order->quantity }}</p>
                            </p>
                        </div>
                        <div class="">
                        <p class="text-muted mb-0 small">Qty: {{ $order->quantity }}</p>
                        </div>
                        <div class="">
                        <p class="text-muted mb-0 small">${{ $order->total }}</p>
                        </div>
                    </div>
                    <hr class="mb-4 hr_line" >
                    <div class="row d-flex align-items-center">
                        <div class="col-md-2">
                            <p class="text-muted mb-0 small">Track Order: <span class="text-uppercase">{{ $order->status }}</span></p>
                        </div>
                        @php
                        $progressWidth = (array_search($order->status, ['waiting', 'escrow', 'processing', 'shipped', 'delivered', 'completed']) + 1) * 20;
                        @endphp

                        <div class="col-md-10">
                            <div class="progress" aria-label="Default">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: {{ $progressWidth }}%;" aria-valuenow="{{ $progressWidth }}"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>

                            <div class="d-flex justify-content-around mb-1">
                                @foreach(['waiting', 'escrow', 'processing', 'shipped', 'delivered', 'completed'] as $status)
                                <p class="text-muted mt-1 mb-0 small ms-xl-5{{ $order->status === $status ? ' fw-bold' : '' }}">{{ ucfirst($status) }}</p>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    
                    <hr class="mb-4 hr_line" >
                    <div class="row d-flex align-items-center">
                        <div class="col-md-2">
                            <a href="{{ route('user.orders.dispute', ['order_id' => $order->order_id, 'product_id' => $order->product->id]) }}" class="btn btn-main">
                                Raise Dispute
                            </a>
                        </div>
                        @if($order->status == "escrow")
                        <div class="col-md-2">
                            <form action="{{ route('seller.sale',$order->id) }}" method="POST">
                                @csrf
                                <input type="hidden" name="type" value="processing">
                                <button type='submit' class="btn btn-info text-white">
                                    Mark as Processing
                                </button>
                            </form>
                        </div>
                        @elseif($order->status == "processing")
                        <div class="col-md-2">
                            <form action="{{ route('seller.sale',$order->id) }}" method="POST">
                                @csrf
                                <input type="hidden" name="type" value="shipped" required>
                                Delivery Date : <input class="form-control" type="date" name="delivery" required>
                                </div>
                                <div class="col-md-2">
                                    <button type='submit' class="btn btn-primary text-white">
                                        Mark as Shipped
                                    </button>
                            </form>
                        </div>
                        @elseif($order->status == "shipped")
                        <div class="col-md-2">
                            <form action="{{ route('seller.sale',$order->id) }}" method="POST">
                                @csrf
                                <input type="hidden" name="type" value="delivered" required>
                                Expected Delivery Date : {{ $order->delivered_at }}
                                </div>
                                <div class="col-md-2">
                                    <button type='submit' class="btn btn-success text-white">
                                        Mark as Delivered
                                    </button>
                            </form>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach

                <div class="bg-card-1">
                <div class="d-flex justify-content-between pt-2">
                <p class="fw-bold mb-0">Order Details</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Total</span> {{ $orders->sum('total') }}.00</p>
            </div>

            <div class="d-flex justify-content-between pt-2">
                <p class="text-muted mb-0">Invoice Number : {{ $id }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Discount</span> $0.00</p>
            </div>

            <div class="d-flex justify-content-between">
                <p class="text-muted mb-0">Invoice Date : {{ $orders->first()->created_at->format('j M,o') }}</p>
                <!--p class="text-muted mb-0"><span class="fw-bold me-4">GST 18%</span> 123</p-->
            </div>
            <div class="d-flex justify-content-between">
                <p class="text-muted mb-0">Recepits Voucher : 18KU-62IIK</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Delivery Charges</span> Free</p>
            </div>
                </div>
            

            

            <div class="bg-card-1">
            @if(in_array($orders->first()->status, ['escrow','processing','shipped','delivered','completed']))
            <div class="d-flex justify-content-between pt-2">
                <p class="fw-bold mb-0">Escrow Details</p>
            </div>

            <div class="d-flex justify-content-between pt-2">
                <p class="text-muted mb-0">Payment Coin : {{ $orders->first()->payment_method }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Total Order Amount</span> {{ $orders->first()->orderPayment()->first()->amount }} {{ $orders->first()->payment_method }}</p>
            </div>

            <div class="d-flex justify-content-between">
                <p class="text-muted mb-0">Paid On : {{ $orders->first()->orderpayment()->first()->paid_at }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Total received Coins </span> {{ $orders->first()->orderPayment()->first()->total_received }} {{ $orders->first()->payment_method }}</p>
            </div>
            @endif


            <div class="d-flex justify-content-between pt-2">
                <p class="fw-bold mb-0">Address Details</p>
                <textarea class="form-control form-control-textarea" id="canary" name="canary" rows="10">{{$orders->first()->address}}</textarea>

            </div>
            </div>
        </div>
        <div class="card-footer border-0 px-4 py-3"
             style="background-color: #a8729a; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;">
            <h5 class="d-flex align-items-center justify-content-end text-white text-uppercase mb-0">Total
                : <span class="h2 mb-0 ms-2">$ {{ $orders->sum('total') }}.00 USD</span></h5>

        </div>
    </div>
</div>
@endsection