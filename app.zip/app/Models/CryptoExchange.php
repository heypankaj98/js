<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CryptoExchange extends Model
{
    use HasFactory;
    protected $table = 'coin_exchange_rates';
     
    protected $fillable = [
        'coin_symbol',
        'currency_symbol',
        'rate'
        ];
}
