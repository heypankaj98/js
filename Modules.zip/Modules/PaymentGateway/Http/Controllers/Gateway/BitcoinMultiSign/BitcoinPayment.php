<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\BitcoinMultiSign;

use Modules\PaymentGateway\Http\Controllers\Gateway\Bitcoin\Utility\RPCWrapper;
use Modules\PaymentGateway\Http\Controllers\Gateway\Utility\BitcoinConverter;
use App\Models\ExceptionModel;
use Illuminate\Support\Facades\Cache;

class BitcoinPayment {

    protected $bitcoind;

    public function __construct() {
        $this->bitcoind = new RPCWrapper(config('coins.bitcoin.username'),
                config('coins.bitcoin.password'),
                config('coins.bitcoin.host'),
                config('coins.bitcoin.port'));
    }

    /**
     * Generate new address with optional btc user parameter
     *
     * @param array $params
     * @return string
     * @throws \Exception
     */
    function generateAddress(array $params = []) {
        try {
            if (array_key_exists('btc_user', $params)) {
                $address = $this->bitcoind->getnewaddress($params['btc_user']);
            } else {
                $address = $this->bitcoind->getnewaddress();
            }
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'Invalid Bitcoin Address OR An error occurred. Please create a support ticket with ERROR CODE '; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function getaddressinfo($address) {
        try {
            $info = $this->bitcoind->getaddressinfo($address);
//            $this->bitcoind->setlabel($address, $label);
//            $scriptPubKey = $info['scriptPubKey'];
            if (!$info['ismine']) {
                // Address not found, import it into the wallet
                $this->bitcoind->importaddress($address, '', false);
                $info = $this->bitcoind->getaddressinfo($address);
            }
            
//            dd($this->bitcoind->decodescript($scriptPubKey));
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $info;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'Invalid Bitcoin Address OR An error occurred. Please create a support ticket with ERROR CODE .'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    function getBalance(array $params = []) {
        try {
            if (array_key_exists('address', $params)) {
                // Check if the address exists in the wallet
                $addressInfo = $this->bitcoind->getaddressinfo($params['address']);
                if (!$addressInfo['ismine']) {
                    // Address not found, import it into the wallet
                    $this->bitcoind->importaddress($params['address'], '', false);
                }

                // Get the balance for the imported address
                $accountBalance = $this->bitcoind->getreceivedbyaddress($params['address'], 1);
                if ($this->bitcoind->error)
                    throw new \Exception($this->bitcoind->error);

                return (float) $accountBalance;
            }
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
        return;
    }

    public function GetTransactionFee() {
        $fee = $this->bitcoin->estimatesmartfee(6);
        $fee->result['feerate'] = floatval($fee->result['feerate']) / 5;
        return number_format($fee->result['feerate'], 8);
    }

    /**
     * Convert USD to equivalent BTC amount, rounded on 8 decimals
     *
     * @param $usd
     * @return float
     */
    function usdToCoin($usd): float {
        return round(BitcoinConverter::usdToBtc($usd), 8, PHP_ROUND_HALF_DOWN);
    }

    public function createMultiSigAddress($publicKeys, $requiredSignatures) {
        try {
            $address = $this->bitcoind->addmultisigaddress($requiredSignatures, $publicKeys);
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $address;
        } catch (\Exception $exception) {
            dd($exception);
        }
    }

    public function createRawTransaction(array $params = []) {
        $inputs = $params['inputs'];
        $outputs = $params['outputs'];

        try {
            // Prepare inputs
            $preparedInputs = [];
            foreach ($inputs as $input) {
                $preparedInputs[] = [
                    'txid' => $input['txid'],
                    'vout' => $input['vout'],
                ];
            }

            // Prepare outputs
            $preparedOutputs = [];
            foreach ($outputs as $output) {
                $preparedOutputs[$output['address']] = $output['amount'];
            }

            // Create unsigned raw transaction
            $unsignedTransaction = $this->bitcoind->createrawtransaction($preparedInputs, $preparedOutputs);

            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $unsignedTransaction;
        } catch (\Exception $exception) {
            dd($exception);
        }
    }

    public function listunspent(array $params = []) {
        $multisigAddress = $params['multisignaddress'];
        try {
            $unspent = $this->bitcoind->listunspent(0, 9999999, [$multisigAddress]);

            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $unspent;
        } catch (\Exception $exception) {
            dd($exception);
        }
    }

    public function signMultiSigTransaction($params) {
        $rawTransaction = $params['rawTransaction'];
        $privateKeys = $params['privateKeys'];
        $inputs = $params['inputs'];
        try {
            // Sign the multisig transaction
            $signedTransaction = $this->bitcoind->signrawtransactionwithkey($rawTransaction, $privateKeys, $inputs);

            if ($signedTransaction['complete'] !== true) {
                dd($signedTransaction);
                throw new \Exception('Failed to sign the multisig transaction.');
            }
            // Get the signed transaction hex
            $signedTransactionHex = $signedTransaction['hex'];
            return $signedTransactionHex;
        } catch (\Exception $exception) {
            dd($exception);
        }
    }

    public function sendrawtransaction($params) {
        $signedTransaction = $params['hex'];
        $destinationAddress = $params['destinationAddress'] ?? null;
        $amount = $params['vendor_amount'];
        $fee = $params['fee'] ?? null;
        try {
            // Broadcast the signed transaction to the Bitcoin network
            $txid = $this->bitcoind->sendrawtransaction($signedTransaction);

            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            $primaryWalletAddress = 'tb1quqx6k3dd6w54ax5zy477hnc8za0t90xszgd0cv';
            // Transfer the remaining funds to the destination address (change address)
            $changeAddress = $this->bitcoind->getrawchangeaddress();
            $changeAmount = $this->bitcoind->getreceivedbyaddress($primaryWalletAddress, 1) - $amount - $fee;
            $changeTxid = $this->bitcoind->sendtoaddress($changeAddress, $changeAmount);

            return ['txid' => $txid, 'change_txid' => $changeTxid];
        } catch (\Exception $exception) {
            dd($exception);
            $errorCode = 'btcm-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';

            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();

            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function dumpPrivateKey($params) {
        try {
            // Fetch unspent transaction outputs (UTXOs) for the specified address
            $private_key = $this->bitcoind->dumpprivkey($params['publicKey']); //address btc nt pub key 
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $private_key;
        } catch (\Exception $exception) {
            $errorCode = 'btcm-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function getAddressFromPublicKey($publicKey) {
        try {
            $address = $this->bitcoind->getaddressesbylabel($publicKey['publicKey']);
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $address;
        } catch (\Exception $exception) {
            dd($exception);
            $errorCode = 'btcm-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE: ' . $errorCode;
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function getMultisigTxId($multisigAddress) {
        try {
            $transactions = $this->bitcoind->listtransactions('*', 100); // Adjust the number of transactions as per your needs
            foreach ($transactions as $transaction) {
                if (isset($transaction['address']) && $transaction['address'] === $multisigAddress['address'] && $transaction['category'] === 'receive') {
                    return $transaction;
//                    return $transaction['txid'];
                }
            }


            return null; // No multisig transaction found for the given address
        } catch (\Exception $exception) {
            $errorCode = 'btcm-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

}
