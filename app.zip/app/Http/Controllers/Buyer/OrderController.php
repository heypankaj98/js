<?php

namespace app\Http\Controllers\Buyer;

use Auth,
    Gate;
use Carbon\Carbon;
use App\Traits\OrderTrait;
use App\Http\Requests\Seller\OrderRequest;
use App\Models\{
    Order,
    Product,
    Feedback,
    Dispute,
    DisputeMessage,
    OrderPayment,
    Referrals,
    UserMeta,
    Transaction,
    MultisigTransaction,
    MultisigAddress};
use Illuminate\Support\Facades\Validator;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;

class OrderController {
    use OrderTrait;
    private function checkbuyer($id) {
        if (Order::where('order_id', $id)->first()->buyer_id == Auth::id()) {
            return 1;
        } else {
            session()->flash('error', 'You are not allowed to access this.');

            return redirect()->back();
        }
    }

 public function index()
    {
        $orders = Order::all();
        return view('buyer.orders.index', compact('orders'));
    }

    // Method for handling order status
public function status($orderId)
{
    // Find the order and update the status
    $order = Order::findOrFail($orderId);
    $order->status = 'completed'; // Update status as needed
    $order->save();

    // Redirect back with a success message
    return redirect()->back()->with('success', 'Order status updated!');
}

  public function showall()
{
    $orders = Order::where('buyer_id', Auth::id())->orderBy('order_id')->paginate(20);
    return view('buyer.orders', compact('orders'));
}


    // public function showsingle($id) {
    //     $validator = Validator::make(['id' => $id], [
    //                 'id' => 'required|exists:orders,order_id',
    //     ]);
    //     if ($validator->fails()) {
    //         return redirect()->back()->withErrors($validator);
    //     }
    //     $this->checkbuyer($id);
    //     $orders = Order::where('order_id', $id)->get();
    //     if ($orders->first()->status == 'waiting') {
    //         if (is_null($orders->first()->orderPayment()->first())) {
    //             return view('buyer.order', compact('orders', 'id'));
    //         } else {
    //             $payment_method = $orders->first()->payment_method;
    //             $payment_address = $orders->first()->orderPayment()->first()->payment_address;
    //             $received = PayWay::getBalance($payment_method, ['address' => $payment_address, 'tag' => $orders->first()->buyer->username]);
    //             if (isset($received['error_code'])) {
    //                 $errorCode = $received['error_code'];
    //                 $errorMessage = $received['error_message'];
    //                 session()->flash('error', $errorMessage . "=>" . $errorCode);
    //             } else {
    //                 if ($received >= $orders->first()->orderPayment()->first()->amount) {
    //                     if ($payment_method == 'BitcoinMultiSign') {
    //                         $trx = PayWay::getMultisigTxId($payment_method, ['address' => $payment_address]);

    //                         $multisig_record = MultisigTransaction::where('multisig_address', $payment_address)->first();
    //                         $multisig_record->trx = $trx['txid'] ?? null;
    //                         $multisig_record->vout = $trx['vout'] ?? null;
    //                         $multisig_record->save();
    //                     }
    //                     Order::where('order_id', $id)->update(['status' => 'escrow']);
    //                     OrderPayment::where('order_id', $id)->update(['status' => 'PAID', 'total_received' => $received, 'paid_at' => Carbon::now()]);
    //                     session()->flash('success', 'Payment received successfully. Thank you.');
    //                 }
    //             }
    //             return view('buyer.order', compact('orders', 'id', 'received'));
    //         }
    //     } elseif (in_array($orders->first()->status, ['refund', 'dispute', 'escrow', 'processing', 'shipped', 'delivered', 'completed'])) {
    //         $orderPayment = $orders->first()->orderPayment()->first();
    //         $received = $orderPayment ? $orderPayment->total_received : 0;

    //         return view('buyer.order', compact('orders', 'id', 'received'));
    //     }
    // }
  public function showsingle($id) {
    $validator = Validator::make(['id' => $id], [
        'id' => 'required|exists:orders,order_id',
    ]);
    if ($validator->fails()) {
        return redirect()->back()->withErrors($validator);
    }
    $this->checkbuyer($id);
    $orders = Order::where('order_id', $id)->get();

    // Commission calculation - 2% of the total product amount
    $productAmount = $orders->sum(function ($order) {
        $product = Product::find($order->product_id);
        return $product ? $product->price : 0;
    });

    // Calculate commission (2% of the product amount)
    $commission = $productAmount * 0.02;

    // If order is in 'waiting' status
    if ($orders->first()->status == 'waiting') {
        // Initialize received as 0 if no payment has been made
        $received = 0;

        if (is_null($orders->first()->orderPayment()->first())) {
            return view('buyer.order', compact('orders', 'id', 'commission', 'received'));
        } else {
            $payment_method = $orders->first()->payment_method;
            $payment_address = $orders->first()->orderPayment()->first()->payment_address;
            $received = PayWay::getBalance($payment_method, ['address' => $payment_address, 'tag' => $orders->first()->buyer->username]);

            if (isset($received['error_code'])) {
                $errorCode = $received['error_code'];
                $errorMessage = $received['error_message'];
                session()->flash('error', $errorMessage . "=>" . $errorCode);
            } else {
                if ($received >= $orders->first()->orderPayment()->first()->amount) {
                    if ($payment_method == 'BitcoinMultiSign') {
                        $trx = PayWay::getMultisigTxId($payment_method, ['address' => $payment_address]);

                        $multisig_record = MultisigTransaction::where('multisig_address', $payment_address)->first();
                        $multisig_record->trx = $trx['txid'] ?? null;
                        $multisig_record->vout = $trx['vout'] ?? null;
                        $multisig_record->save();
                    }
                    Order::where('order_id', $id)->update(['status' => 'escrow']);
                    OrderPayment::where('order_id', $id)->update(['status' => 'PAID', 'total_received' => $received, 'paid_at' => Carbon::now()]);
                    session()->flash('success', 'Payment received successfully. Thank you.');
                }
            }
            return view('buyer.order', compact('orders', 'id', 'received', 'commission'));
        }
    } elseif (in_array($orders->first()->status, ['refund', 'dispute', 'escrow', 'processing', 'shipped', 'delivered', 'completed'])) {
        $orderPayment = $orders->first()->orderPayment()->first();
        $received = $orderPayment ? $orderPayment->total_received : 0;

        return view('buyer.order', compact('orders', 'id', 'received', 'commission'));
    }
}


    public function generatePayment($id) {
        
        $total = 0;
        $validator = Validator::make(['id' => $id], [
                    'id' => 'required|exists:orders,order_id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        $this->checkbuyer($id);

        $orders = Order::where('order_id', $id)->get();
        $payment_method = $orders->first()->payment_method;
        if ($payment_method == 'BitcoinMultiSign') {
          
            $own_address = PayWay::generateAddress($payment_method, array('amount' => $orders->first()->total_crypto));
            $fee = PayWay::getTransactionFee($payment_method);
            $address_info = PayWay::getaddressinfo($payment_method, array('address' => $own_address));
            $multisig_record = new MultisigTransaction();
            $multisig_record->multisig_address = "pending";
            $multisig_record->multisig_redeem = "pending";
            $multisig_record->multisig_amount = $orders->first()->total_crypto;
            $multisig_record->listing_id = $orders->first()->order_id;
            $multisig_record->buyer_id = $orders->first()->buyer->id;
            $multisig_record->seller_id = $orders->first()->seller->id;
            $multisig_record->save();

            $address_info['multisig_id'] = $multisig_record->id;

            $addresses_record = new MultisigAddress();
            $addresses_record->multisig_id = $multisig_record->id;
            $addresses_record->address_1 = $orders->first()->seller->meta_multisig_key_pub; // seller Key
            $addresses_record->address_2 = $own_address; // Website address
            $addresses_record->address_3 = $orders->first()->buyer->meta_multisig_key_pub; // buyer Key
            $addresses_record->save();

            $key_1 = $orders->first()->seller->meta_multisig_key_pub;
            $key_2 = $own_address;
            $key_3 = $orders->first()->buyer->meta_multisig_key_pub;

            $publickeys_array = array($key_1, $key_2, $key_3);

            $multisig_address = PayWay::createMultiSigAddress($payment_method, array('pub_keys_array' => $publickeys_array, 'required_signatures' => 2));
            $multisig_record->multisig_address = $multisig_address['address'];
            $multisig_record->multisig_redeem = $multisig_address['redeemScript'];
            $multisig_record->save();
            $payment_address = $multisig_address['address'];
        } else {
            $payment_address = PayWay::generateAddress($payment_method, array('amount' =>0.00015654));
       
        }

        if (isset($payment_address['error_code'])) {
            $errorCode = $payment_address['error_code'];
            $errorMessage = $payment_address['error_message'];
            session()->flash('error', $errorMessage . "=>" . $errorCode);
            return redirect()->back();
        } else {
            if ($payment_address && is_string($payment_address)) {
                // Address was generated successfully
                $payment_address;
            } else {
                session()->flash('error', 'Payment not generated ask Admin to help.');
                return redirect()->back();
            }
        }


        foreach ($orders as $order) {
            $crypto = convert($order->total, $order->payment_method);

            $order->total_crypto = $crypto;
            $order->save();

            $total += $crypto;
        }

        $orderPayment = new OrderPayment();
        $orderPayment->order_id = $id;
        $orderPayment->method = $payment_method;
        $orderPayment->payment_address = $payment_address;
        $orderPayment->amount = $total;
        $orderPayment->save();

        session()->flash('success', 'Payment address generated successfully. Please pay required amount on generated address below.');

        return redirect()->back();
    }

    // public function changeStatus(OrderRequest $request, Order $order) {
    //     $validator = Validator::make(['id' => $order->id, 'order_id' => $order->order_id], [
    //                 'id' => 'required|exists:orders',
    //                 'order_id' => 'required|exists:orders',
    //     ]);

    //     if ($validator->fails()) {
    //         return redirect()->back()->withErrors($validator);
    //     }
    //     if ($order->buyer == auth()->user()) {
    //         if ($request->type == "completed") {
    //             $referral = Referrals::where('referred_user_id', $order->buyer_id)->first();
    //             if ($referral) {
    //                 $referral->earned += 5;
    //                 $referral->save();
    //             }
    //             $vendor_amount = bcmul(number_format($order->total_crypto, 8), 1.00 - $order->commission(), 8);
    //             $seller = $order->seller;

    //             if (!$order->completed) { // Mark the order as completed only once
    //                 if ($order->payment_method == 'Bitcoin') {
    //                     $seller->btc_balance += $vendor_amount;
    //                 }
    //                 if ($order->payment_method == 'Monero') {
    //                     $seller->xmr_balance += $vendor_amount;
    //                 }
    //                 $seller->save();

    //                 $this->markAsCompleted($order->id);
    //             }
    //         }

    //         return redirect()->back();
    //     }
    // }
    public function changeStatus(OrderRequest $request, Order $order) {
    $validator = Validator::make(['id' => $order->id, 'order_id' => $order->order_id], [
        'id' => 'required|exists:orders',
        'order_id' => 'required|exists:orders',
    ]);

    if ($validator->fails()) {
        return redirect()->back()->withErrors($validator);
    }

    if ($order->buyer == auth()->user()) {
        if ($request->type == "completed") {
            $referral = Referrals::where('referred_user_id', $order->buyer_id)->first();
            if ($referral) {
                $referral->earned += 5;
                $referral->save();
            }
            $vendor_amount = bcmul(number_format($order->total_crypto, 8), 1.00 - $order->commission(), 8);
            $seller = $order->seller;

            // Mark the order as completed only once
            if (!$order->completed) {
                if ($order->payment_method == 'Bitcoin') {
                    $seller->btc_balance += $vendor_amount;
                }
                if ($order->payment_method == 'Monero') {
                    $seller->xmr_balance += $vendor_amount;
                }
                $seller->save();

                // Reduce product stock here
                $product = $order->product;
               
                $product->stock -= $order->quantity; // Adjust stock by the quantity in the order
                $product->save();

                $this->markAsCompleted($order->id);
                
            }
        }

        return redirect()->back();
    }
}


    public function postFinalizearly(Order $order) {
        try {
            $this->checkFinalizearly($order);
            $this->finalizearly();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
        }

        return redirect()->route('order', ['order' => $order->id]);
    }

    public function createRawTranstion(Request $request, $order_id) {
        $validator = Validator::make($request->all(), [
                    'buyer_signature' => 'required',
        ]);

        if ($validator->fails()) {
            // Validation failed, return the error response
            return response()->json(['error' => $validator->errors()], 400);
        }
        $order = Order::where('order_id', $order_id)->first();
        if ($order->status == "shipped" || $order->status == "delivered") {
            $payment_address = $order->orderPayment()->first()->payment_address;
            $multisig_trx_record = MultisigTransaction::where('multisig_address', $payment_address)->first();
            $multisig_add_record = MultisigAddress::where('multisig_id', $multisig_trx_record->id)->first();

            $payment_method = $order->payment_method;

// Create a multisig transaction
            $vendor_amount = bcmul(number_format($order->total_crypto, 8), 1.00 - $order->commission(), 8);
            $vandor_address = PayWay::generateAddress($payment_method, ['amount' => $vendor_amount]);
            $listunspent = PayWay::listunspent($payment_method, ['multisignaddress' => $payment_address]);

            $inputs = [];

            foreach ($listunspent as $output) {
                $inputs[] = [
                    'txid' => $output['txid'],
                    'vout' => $output['vout'],
                    'scriptPubKey' => $output['scriptPubKey'],
                    'redeemScript' => $multisig_trx_record->multisig_redeem,
                    'amount' => $output['amount'],
                ];
            }

            $outputs = [
                [
                    'address' => $vandor_address,
                    'amount' => $vendor_amount
                ]
            ];
            $rawTransaction = PayWay::createRawTransaction($payment_method, ['inputs' => $inputs, 'outputs' => $outputs]);
            $priavte_key1 = $request->buyer_signature;
            $priavte_key2 = PayWay::dumpPrivateKey($payment_method, ['publicKey' => $multisig_add_record->address_2]);

            $privateKeys = [
                $priavte_key1,
                $priavte_key2,
            ];

            $signedTransaction = PayWay::signMultiSigTransaction($payment_method, ['rawTransaction' => $rawTransaction, 'privateKeys' => $privateKeys, 'inputs' => $inputs]);

            // Proceed to send the signed transaction
            $transactionId = $this->sendRawTransaction($payment_method, $signedTransaction, $vendor_amount);

            $referral = Referrals::where('referred_user_id', $order->buyer_id)->first();
            if ($referral) {
                $referral->earned += 5;
                $referral->save();
            }
            $vendor_amount = bcmul(number_format($order->total_crypto, 8), 1.00 - $order->commission(), 8);
            $seller = $order->seller;

            if (!$order->completed) { // Mark the order as completed only once
                if ($order->payment_method == 'Bitcoin') {
                    $seller->btc_balance += $vendor_amount;
                }
                if ($order->payment_method == 'Monero') {
                    $seller->xmr_balance += $vendor_amount;
                }
                $seller->save();

                $this->markAsCompleted($order->id);
                
                $transaction = new Transaction;
                $transaction->trx_id = $transactionId['txid'];
                $transaction->to_address = $toAddress;
                $transaction->amount = $amount;
                $transaction->status = 1;
                $transaction->save();
                session()->flash('success', 'Payment successfully released.');

                return redirect()->back();
            }
        }
    }

    public function sendRawTransaction($payment_method, $signedTransaction, $vendor_amount) {
        try {
            $transactionId = PayWay::sendrawtransaction($payment_method, ['hex' => $signedTransaction, 'vendor_amount' => $vendor_amount]);

            if (!$transactionId) {
                throw new \Exception('Failed to send the raw transaction.');
            }

            return $transactionId;
        } catch (\Exception $exception) {
            
            
             $transaction = new Transaction;
                $transaction->trx_id = $transactionId;
                $transaction->to_address = $toAddress;
                $transaction->amount = $vendor_amount;
                $transaction->status = 0;
                $transaction->save();
            // dd($exception);
            // Handle the exception as needed
        }
    }
   public function showOrder($orderId)
{
    $order = Order::with('product')->find($orderId); // Assuming each order has a product relationship
    $product = $order->product; // Retrieve the associated product

    return view('buyer.order', compact('order', 'product'));
}
 public function show($orderId)
    {
        $order = Order::with('product')->findOrFail($orderId);
        return view('buyer.order', compact('order'));
    }

}
