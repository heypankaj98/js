@extends('layouts.homeapp')
@section('content')
<html lang="en">

<head>
    <title>Two-Factor Authentication Setup</title>
    <style>
        .arrow1 {
            margin-top: -2px;
        }

        .anch {
            background-color: #2b3c45;
            padding: 5px 15px;
            border-radius: 5px;
            font-size: 12px;
        }

        h1 {
            background-color: #ff7d00;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            padding:4px 8px;
            border-radius:4px;
            font-weight:600;
        }
        h1.heading{color:#000}
        h3.bg-card-1{font-size:14px;}

        p {
            color: #ddd;
            margin-bottom: 20px;
            line-height: 1.5;
            font-size: 12px;
        }
        li{
            margin-bottom: 8px;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="bg-card-1 p-24">
        <h1 class="px-2 heading">Two-Factor Authentication (2FA) Setup</h1>
        <div class="bg-card-2">


            <h3 class="bg-card-1 mt-4">What is Two-Factor Authentication?</h3>
            <p >Two-Factor Authentication (2FA) adds an extra layer of security to your account. It requires not only a
                password and username but also something that only you have on hand — your PGP key. This helps to ensure
                that even if your password is compromised, unauthorized users cannot access your account without the
                second factor of authentication.</p>

            <h3 class="bg-card-1">Steps to Enable 2FA</h3>
            <ol>
                <li>Generate a PGP key pair if you don't already have one.</li>
                <li>Upload your public PGP key to the Dark Allay Market account settings.</li>
                <li>Confirm the upload by verifying your PGP key through a test message sent to your registered email.
                </li>
                <li>Complete the setup by enabling 2FA in your account settings.</li>
            </ol>
            <br>
            <a class="anch" href="#"><strong>Open:</strong> 2FA Security (User Control Panel)</a>
            <a class="anch" href="{{ route('infocenter') }}"><strong>Open:</strong> Tutorials (Information Center)</a>
            <a class="anch" href="/"><strong>Back to:</strong> {{ trans('auth.home_link')}}</a>
        </div>
    </div>
</body>

</html>
@endsection