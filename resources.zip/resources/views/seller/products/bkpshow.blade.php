@extends('layouts.seller.app')
@section('content')

<div class="col-lg-12 rounded border border-secondary bkpshow_main_part">     
    <div class="row">
        <div class="col-7 text-center bkp_show_item">
            <img class="col-10 mt-4" src="{{ $product->photo->getUrl() }}">
            @if($product->featured)
            <div class="bkp_box" >
                <span class="badge badge-warning hack">{{ trans('global.featured') }} </span>
            </div>
            @endif
        </div>
        <div class="col-5">
            <p class="h1 text-left bkp_show_item_two" >
                <B>{{ $product->name }}</B>
            </p>
            <p class="pb-2 bkp_show_item_two" >
                @if($product->wdiscount != null)
                    @foreach(unserialize($product->wdiscount) as $key => $discount)
                        <span class="discount">  {{$key}} Quantity  -   Discount {{$discount}} % </span><br>
                    @endforeach
                @endif
            </p>
            <p class="mb-1">
                <B>T</B><small><B>{{ trans('global.ype') }}</B></small>
                    {{$product->type}}
            </p>
            <p class="mb-1">
                <B>C</B><small><B> {{ trans('global.ategory') }} </B></small>
                <a href="" class="badge goldbadge">

                </a>
            </p>
            <p class="mb-1">
                <span class="badge badge-info bgo">
                    <b> {{ trans('global.vendor_level') }}  
                        <span class="f14"></span>
                    </b>
                </span>
            </p>
            <p class="mb-1 f16">
                <B>V</B><small><B> {{ trans('global.endor') }}  </B></small>
                <a href="">
                    <span class="badge goldbadge">

                    </span></a>
            </p>
            <p class="mb-2 f18">
                <span class="badge bluebadge">
                 {{ trans('global.escrow') }}    <span> {{ trans('global.&#8651') }}</span>
                </span>
            </p>

            @if($product->featured)
            <p class="mb-2 f18">
                <span class="badge redbadge">
                   {{ trans('global.featured_product') }} 
                </span>
            </p>
            @endif

            <p class="mb-2 f18">
                @if($product->stock == 0) 
                <span class="badge badge-danger">
                     {{ trans('global.out_of_stock') }} 
                  
                </span>
                @else
                <span class="badge badge-success">
                    {{ trans('global.in_stock') }} 
                    
                </span>
                @endif
            </p>
            <p class="mb-1 f16">
                <B> {{ trans('global.s') }} </B><small><B> {{ trans('global.hips_to') }}  </B></small> 
                <span class="badge goldbadge">
                </span>
            </p>
            <p class="mb-1 f16">
                <B>{{ trans('global.s') }} </B><small><B>  {{ trans('global.old') }}</B></small> 
                <span class="badge goldbadge">
                </span>
            </p>
            <form action="" method="post">
                @csrf
                <div class="m-1">
                    <B>{{ trans('global.p') }}</B><small><B> {{ trans('global.ayment') }}   </B></small> 
                    <select name="payment" required>
                        <option disabled selected>{{ trans('global.select_payment_method') }} </option>
                        <option value="302"> {{ trans('global.monero') }} </option>
                    </select><br>
                </div>
                <div>
                    <p class="mb-1 f16">
                        <B>{{ trans('global.q') }} </B><small><B>{{ trans('global.uantity') }}</B></small> 
                        <input class="col-3" id="quantity" name="quantity" type="number" value="0" min="0" max="{{$product->stock}}" @if($product->stock == "0") disabled @endif>
                    </p>
                </div>
                <div>
                    <p class="mb-1 f11">
                        <textarea name="message" cols="37" rows="4"  placeholder="Delivery address & message for vendor :"></textarea><br>
                      (* Secure Auto-PGP Encryption. Enter simple text here and it will be encrypted.  Don't add PGP encrypted message here.)
                    </p>
                </div>
                <div class="card-footer mb-2">
                    @guest
                    <a href="" class="btn btn-dark btn-block">
                        <b> {{ trans('global.buy_now') }} </b>
                    </a>
                    @else
                    <button type="submit" class="btn btn-dark btn-block">
                        <b>{{ trans('global.buy_now') }}</b>
                    </button>
                    @endguest
                </div>
            </form>
        </div>
    </div>
    <hr>
    <p class="card-text">
    <pre>{{ $product->description }}</pre>
</p>
</div>

@endsection