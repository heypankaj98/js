<?php

return [
    'name' => 'Forum'
];
