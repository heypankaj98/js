<div class="sidebar-menu-content">
<h1 class="btn btn-warning w-100 sidebar-title">
    {{ trans('common.seller') }} {{ trans('common.dashboard') }}
</h1>

<div class="sidebar-container">
    <ul class="siddebar-menu">
        <li> 
            <ul class="ds-nav-dropdown-items">
                 <li class="nav-item">
                    <a href="{{ route('seller.profile.index') }}" class="nav-link {{ Route::is('user.profile.index') ? 'text-primary' : '' }}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
                         <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path></svg>    
                    {{ trans('common.profile') }}
                    </a>
                </li>
                <li class="nav-item mb-2">
                    <a href="{{route('seller.dashboard')}}" class="nav-link {{ Route::is('seller.dashboard') ? 'text-primary' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-dashboard">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M12 13m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
                         <path d="M13.45 11.55l2.05 -2.05"></path>
                         <path d="M6.4 20a9 9 0 1 1 11.2 0z"></path></svg>  
                        {{ trans('common.dashboard') }}
                    </a>
                </li>
                 <li class="nav-item mb-2">
                    <a href="{{route('seller.verify')}}"  class="nav-link">
                    <img src="{{ asset('assets/verify.png')}}" >
                        Get Verified
                    </a>
                </li>
                @can('seller_manage_products')
                <li class="nav-item mb-2">
                    <a href="{{route('seller.products.index')}}" class="nav-link {{ Route::is('seller.products.index') ? 'text-primary' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
                        {{ trans('common.products') }}
                    </a>
                </li>
                @endcan
                <li class="nav-item mb-2">
<a href="{{ route('seller.ads.index') }}" class="nav-link {{ Route::is('seller.products.index') ? 'text-primary' : '' }}">
    <img src="{{ asset('assets/verify.png')}}">
    Ads Section
</a>
                </li>
                @can('seller_manage_shipping_method')
                <li class="nav-item mb-2">
                    <a href="{{route('seller.shipping-methods.index')}}" class="nav-link {{ Route::is('seller.shipping-methods.index') ? 'text-primary' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-truck"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
                        {{ trans('common.shipping') }} {{ trans('common.methods') }}
                    </a>
                </li>
                @endcan

               
            </ul>
        </li>

        <ul class="ds-nav-dropdown-items">
            @can('seller_manage_sales')
            <li class="nav-item mb-2">
                <a class="nav-link  {{ Route::is('seller.orders') ? 'text-primary' : '' }}" href="{{route('seller.orders')}}">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M4 19a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                         <path d="M11.5 17h-5.5v-14h-2"></path>
                         <path d="M6 5l14 1l-1 7h-13"></path>
                         <path d="M15 19l2 2l4 -4"></path></svg> 
                          {{ trans('common.sales') }}
                </a>
            </li>
            @endcan
            
            @can('seller_manage_disputes')
            <li class="nav-item mb-2">
                <a class="nav-link {{ Route::is('seller.dispute') ? 'text-primary' : '' }}" href="{{route('seller.dispute')}}">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-friends-off">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M5 5a2 2 0 0 0 2 2m2 -2a2 2 0 0 0 -2 -2"></path>
                         <path d="M5 22v-5l-1 -1v-4a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4l-1 1v5"></path>
                         <path d="M17 5m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
                         <path d="M15 22v-4h-2l1.254 -3.763m1.036 -2.942a1 1 0 0 1 .71 -.295h2a1 1 0 0 1 1 1l1.503 4.508m-1.503 2.492v3"></path>
                         <path d="M3 3l18 18"></path></svg> 
                          {{ trans('common.disputes') }}
                </a>
            </li>
            @endcan
        </ul>
        
        <li>
            <ul class="ds-nav-dropdown-items">
                <li class="nav-item mb-2">
                    <a class="nav-link {{ Route::is('seller.balances') ? 'text-primary' : '' }}" href="{{route('seller.balances')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>   
                     {{ trans('common.balances') }}
                    </a>
                </li>
                
                <li class="nav-item mb-2">
                    <a class="nav-link {{ Route::is('seller.payouts') ? 'text-primary' : '' }}" href="{{route('seller.payouts')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                     {{ trans('common.payouts') }}
                    </a>
                </li>
                
                <li class="nav-item mb-2">
                    <a class="nav-link {{ Route::is('seller.invoices') ? 'text-primary' : '' }}" href="{{route('seller.invoices')}}">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.5 -0.5 16 16" fill="currentColor" id="Invoice--Streamline-Phosphor" height="20" width="20"><desc>Invoice Streamline Icon: https://streamlinehq.com</desc><path d="M0.96666796875 7.772220703125001c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.097259765625 -0.168439453125 0.276990234375 -0.272203125 0.47149218749999994 -0.272203125h1.9055566406250002c0.419109375 -0.000017578125 0.68105859375 -0.45373242187499996 0.47148632812499996 -0.8166855468750001 -0.09725390625 -0.16843359375 -0.27699609375 -0.27219140625000005 -0.47148632812499996 -0.272203125H1.7833359375C0.525990234375 5.593693359375 -0.25903125 4.232109374999999 0.370294921875 3.143595703125c0.291720703125 -0.50457421875 0.8302031249999999 -0.8154667968749999 1.413041015625 -0.8158183593749999 0 -0.419115234375 0.453703125 -0.68105859375 0.816662109375 -0.47150390625000005 0.168451171875 0.097259765625 0.2722265625 0.27699609375 0.2722265625 0.47150390625000005h0.54444140625c0.419115234375 0.000017578125 0.681064453125 0.45373242187499996 0.47149218749999994 0.81669140625 -0.097259765625 0.168439453125 -0.276990234375 0.272197265625 -0.47149218749999994 0.272197265625H1.7833359375c-0.419115234375 0.000017578125 -0.681064453125 0.45373242187499996 -0.47149218749999994 0.81669140625 0.09725390625 0.168427734375 0.27699609375 0.27219140625000005 0.47149218749999994 0.272197265625h1.088888671875c1.25733984375 0.000755859375 2.0423613281249997 1.3623398437499998 1.41303515625 2.45084765625 -0.29171484375 0.50457421875 -0.8302031249999999 0.8154726562500001 -1.41303515625 0.8158183593749999 0 0.419115234375 -0.45370898437499996 0.68105859375 -0.8166679687499999 0.47150390625000005 -0.168451171875 -0.09725390625 -0.272220703125 -0.276990234375 -0.272220703125 -0.47150390625000005ZM14.85 2.872224609375v9.25555078125c0 0.6013593749999999 -0.48752929687499996 1.088865234375 -1.088888671875 1.088888671875H1.7833359375c-0.601400390625 0.000029296875 -1.088888671875 -0.48748828125000004 -1.088888671875 -1.088888671875v-2.72221875c0 -0.419115234375 0.453703125 -0.68105859375 0.816662109375 -0.47150390625000005 0.168451171875 0.09725390625 0.2722265625 0.276990234375 0.2722265625 0.47150390625000005v2.72221875h8.166662109375v-2.17777734375H4.5055546875c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.097259765625 -0.168439453125 0.276990234375 -0.272203125 0.47149218749999994 -0.272203125h5.444443359375v-2.17777734375h-3.811107421875c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.09725390625 -0.16843359375 0.27699609375 -0.27219140625000005 0.47149218749999994 -0.272203125h7.622220703125V3.416666015625H5.594443359375c-0.419115234375 0.000017578125 -0.681052734375 -0.453673828125 -0.471515625 -0.81664453125 0.09725390625 -0.168462890625 0.27699609375 -0.272244140625 0.471515625 -0.272244140625h8.711109375c0.30067968749999996 0.00001171875 0.544447265625 0.24376757812500002 0.544447265625 0.544447265625Zm-3.8111132812500004 5.988884765625h2.722224609375v-2.17777734375H11.03888671875Zm2.722224609375 3.2666660156250003v-2.17777734375H11.03888671875v2.17777734375Z" stroke-width="1"></path></svg>
                     {{ trans('common.invoices') }}
                    </a>
                </li>
            </ul>
        </li>
        
        <!--<li>-->
        <!--    <ul class="ds-nav-dropdown-items">-->
        <!--        <li class="nav-item mb-2">-->
        <!--            <a class="nav-link" href="{{route('seller.dashboard')}}">-->
        <!--                <b>&#9900;</b> {{ trans('common.analytics') }}-->
        <!--            </a>-->
        <!--        </li>-->
        <!--    </ul>-->
        <!--</li>-->

        <li>
            <ul class="ds-nav-dropdown-items">

                @php($unread = \App\Models\QaTopic::unreadCount())
                <li class="nav-item mb-2">
                    <a href="{{ route("seller.messenger.index") }}" class="{{ request()->is("seller/messenger") || request()->is("seller/messenger/*") ? "text-primary" : "" }} nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-messages">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10"></path>
                         <path d="M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2"></path></svg>   
                          {{ trans('common.messages') }}
                        @if($unread > 0)
                            <strong>( {{ $unread }} )</strong>
                        @endif
                    </a>
                </li>
                
                <li class="nav-item mb-2">
                    <a class="nav-link" href="/tickets">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-ticket"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M15 5l0 2"></path><path d="M15 11l0 2"></path><path d="M15 17l0 2"></path><path d="M5 5h14a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-3a2 2 0 0 0 0 -4v-3a2 2 0 0 1 2 -2"></path></svg>    
                    {{ trans('common.tickets') }}
                    </a>
                </li>
                
                <li class="nav-item mb-2">
                    <a class="nav-link" href="{{route('seller.settings')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-settings">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z"></path>
                         <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"></path></svg>  
                          {{ trans('common.settings') }}
                    </a>
                </li>
                
                @can('seller_delegate_access_manage')
                <li class="nav-item">
                    <a class="nav-link" href="{{route('seller.delegate-access')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-unlock"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>
                     {{ trans('common.delegate-access') }}
                    </a>
                </li>
                @endcan
            </ul>
        </li>
    </ul>
</div>
</div>