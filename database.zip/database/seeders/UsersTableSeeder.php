<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class UsersTableSeeder extends Seeder {

    public function run() {
        $users = [
            [
                'id' => 1,
                'username' => 'superadmin',
                'password' => bcrypt('superadmin'),
                'reference_code' => Str::random(15),
                'pin' => bcrypt('123456'),
            ],
        ];

        User::insert($users);
    }

}
