<?php

namespace App\Http\Controllers\Seller;

use App\Models\User;
use App\Helpers\ReputationHelper; 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ReputationController extends Controller
{
    // Method to get the reputation of a seller
    public function showSellerReputation($sellerId)
    {
        $seller = User::findOrFail($sellerId);

        // Calculate reputation based on products sold
        $reputation = ReputationHelper::calculateReputationTier($seller->products_sold);

        // Pass the seller and reputation to the buyer.dashboard view
        return view('buyer.dashboard', compact('seller', 'reputation'));
    }
    
public function updateReputation(Request $request, $id)
{
    // Validate the incoming data
    $validated = $request->validate([
        'manual_reputation' => 'required|string',  // Expecting a string
    ]);

    // Find the user by ID
    $user = User::findOrFail($id);

    // Update the reputation of the user
    $user->manual_reputation = $validated['manual_reputation'];
    $user->save();

    // Redirect back to the previous page with a success message
    return back()->with('message', 'Reputation updated successfully');
}


}
