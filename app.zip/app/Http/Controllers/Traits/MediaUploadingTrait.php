<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;
use Spatie\Image\Image;

trait MediaUploadingTrait {

    public function storeMedia(Request $request) {
        // Validates file size
        if (request()->has('size')) {
            $this->validate(request(), [
                'file' => 'max:' . request()->input('size') * 1024,
            ]);
        }
        // If width or height is preset - we are validating it as an image
        if (request()->has('width') || request()->has('height')) {
            $this->validate(request(), [
                'file' => sprintf(
                        'image|dimensions:max_width=%s,max_height=%s',
                        request()->input('width', 100000),
                        request()->input('height', 100000)
                ),
            ]);
        }




        $path = storage_path('tmp/uploads');

        try {
            if (!file_exists($path)) {
                mkdir($path, 0755, true);
            }
        } catch (\Exception $e) {
            
        }

        $file = $request->file('picture');

        $name = uniqid() . '_' . trim($file->getClientOriginalName());

        $file->move($path, $name);
        if (exif_imagetype($path . '/' . $name) === IMAGETYPE_JPEG || exif_imagetype($path . '/' . $name) === IMAGETYPE_PNG) {
            
            $image = Image::load($path . '/' . $name);
            $image->save($path . '/' . $name . '.webp');
            unlink($path . '/' . $name); // Delete original image
            $name = $name . '.webp'; // Set new file name with .webp extension
        }

        return $name;

//        use Intervention\Image\Facades\Image;
// composer require intervention/image
//// Load image from file
//$image = Image::make('path/to/image.jpg');
//
//// Remove EXIF data
//$image->strip();
//
//// Save the modified image
//$image->save('path/to/new_image.jpg');
    }

}
