<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductQA extends Model {

    protected $table = 'product_qas';
    protected $fillable = [
        'product_id',
        'user_id',
        'seller_id',
        'question',
        'answer',
    ];

    public function user() {
        return $this->belongsTo(User::class);
    }

    // Define the relationships with other models if necessary
}
