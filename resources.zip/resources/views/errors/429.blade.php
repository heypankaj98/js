
<html>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap');

        body {
            background-color: #0f0f0f !important;
            font-family: 'Inter', sans-serif;
        }

        h1 {
            padding-top: 75px;
            color: #ff7d00;
        }

        .container-mh {
            border-top: 2px solid #ff202c;
            border-bottom: 2px solid #ff202c;
            display: flex;
            width: 100%;
            justify-content: space-between;
        }

        img.logout-imgs {
            margin-top: 20px;
            width: 50px;
        }

        img.prot {
            width: 226px;
            border-left: 2px solid #ff202c;
            border-right: 2px solid #ff202c;
        }

        h1.first-h1 {
            padding-right: 50px;
            float: right;
        }

        h1.second-h1 {
            padding-left: 50px;
        }

        .low-text {
            text-align: center;
            color: white;
        }

        h2.low-h2 {
            color: #ff202c;
        }

        h4.advis-0 {
            font-weight: 900;
        }

        .btn-bot {
            text-align: center;
        }

        a.logout-pg {
            text-decoration: none;
            color: #ff7d00;
            font-weight: bold;
        }

        @media (min-width: 768px) and (max-width: 1200px) {
            .main-def {
                width: 39vw;
            }

            .main-def2 {
                width: 20vw;
            }

            .main-def3 {
                width: 42vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 1201px) and (max-width: 1440px) {
            .main-def {
                width: 44vw;
            }

            .main-def2 {
                width: 20vw;
            }

            .main-def3 {
                width: 42vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 1441px) and (max-width: 1700px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 20vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 1701px) and (max-width: 1900px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 15vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 1901px) and (max-width: 2100px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 15vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 2101px) and (max-width: 2500px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 11vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 2501px) and (max-width: 3000px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 8vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 3001px) and (max-width: 3500px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 7vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 3501px) and (max-width: 4000px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 6vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 4001px) and (max-width: 4500px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 6vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 4501px) and (max-width: 5000px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 6vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 5001px) and (max-width: 5500px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 5vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }

        @media (min-width: 5501px) and (max-width: 6000px) {
            .main-def {
                width: 50vw;
            }

            .main-def2 {
                width: 5vw;
            }

            .main-def3 {
                width: 50vw;
            }

            .logout-pgpg {
                text-align: center;
            }
        }
    </style>

    <body>
        <div class="container-mh">
            <div class="main-def">
                <h1 class="first-h1">DARK ALLAY</h1>
            </div>
            <div class="main-def2">
                <img class="prot" src="{{ asset('assets/Protector.png') }}" alt="Protector">
            </div>
            <div class="main-def3">
                <h1 class="second-h1">DEFENDER</h1>
            </div>
        </div>

        <div class="low-text">
            <h2 class="low-h2">SECURITY BREACH DETECTED</h2>
            <h4 class="advis-0">AN ILLEGAL ACTION PERFORMED</h4>
            <p class="low-final">ONLY use the navigation of the Dark Allay Market!</p>
            <p class="final-low">NO direct inputs or anything else!</p>
        </div>

        <div class="btn-bot">
            <img class="logout-imgs" src="{{ asset('assets/Log_out.png') }}" alt="Logout Icon">
        </div>

        <div class="logout-pgpg">
            <a class="logout-pg" href="/login">Back to Dark Allay Market</a>
        </div>
    </body>
</html>
