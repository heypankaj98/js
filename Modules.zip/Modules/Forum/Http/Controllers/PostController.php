<?php

namespace Modules\Forum\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\Forum\Models\Thread;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Post;
use Auth,
    Gate;

class PostController extends Controller {

    public function index() {
        $posts = Post::get();
        return view('forum::forum.post.index', compact('posts'));
        // Code logic for retrieving and returning thread index view
    }

    public function create() {
        // Code logic for displaying thread creation form
    }

    public function store(Request $request)
    {
        $thread = Thread::findOrFail($request->input('thread_id'));
//        $this->authorize('reply', $thread);
        $post = new Post();
        $post->content = $request->input('content');
        $post->author_id = auth()->id();
        $post->thread_id = $thread->id;

        $post->save();

        return redirect()->route('thread.show', $thread);
    }

    public function show(Thread $thread) {
        return view('forum::forum.categories.show', compact('category', 'threads'));
        // Code logic for displaying a specific thread
    }

    public function edit(Thread $thread) {
        // Code logic for displaying thread edit form
    }

    public function update(Request $request, Thread $thread) {
        // Code logic for updating a thread
    }

    public function destroy(Thread $thread) {
        // Code logic for deleting a thread
    }

}
