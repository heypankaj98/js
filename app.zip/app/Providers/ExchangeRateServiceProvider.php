<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\Currency;

class ExchangeRateServiceProvider extends ServiceProvider
{
    public function register()
    {
        //
    }

    public function boot()
    {
        // Fetch current exchange rates for BTC and other currencies
        $rates = Currency::whereIn('currency', ['BTC', 'USD', 'EUR', 'GBP', 'AUD'])
            ->pluck('rate', 'currency');
            
//             $usdInBtc = $rates['btc']; // 1 USD is worth this much BTC
// $btcInUsd = 1 / $usdInBtc; // Calculate the price of 1 BTC in USD

// dd (number_format($btcInUsd, 2)); 

        // Retrieve rates
        $btcRatePerUsd = $rates['BTC'] ?? 0; // BTC per USD
        $usdRate = $rates['USD'] ?? 1; // USD per USD (always 1)
        $eurRate = $rates['EUR'] ?? 1; // EUR per EUR (if you have this rate)
        $gbpRate = $rates['GBP'] ?? 1; // GBP per GBP (if you have this rate)
        $audRate = $rates['AUD'] ?? 1; // AUD per AUD (if you have this rate)

        // Calculate the value of 1 BTC in each currency
        $btcToUsd = ($btcRatePerUsd != 0) ? (1 / $btcRatePerUsd) : 0;
        $btcToEur = ($btcRatePerUsd != 0 && $eurRate != 0) ? ($eurRate/ $btcRatePerUsd ) : 0;
        $btcToGbp = ($btcRatePerUsd != 0 && $gbpRate != 0) ? ($gbpRate / $btcRatePerUsd ) : 0;
        $btcToAud = ($btcRatePerUsd != 0 && $audRate != 0) ? ($audRate/ $btcRatePerUsd ) : 0;

        // Share data with all views
        view()->share('btcToUsd', number_format($btcToUsd, 2));
        view()->share('btcToEur', number_format($btcToEur, 2));
        view()->share('btcToGbp', number_format($btcToGbp, 2));
        view()->share('btcToAud', number_format($btcToAud, 2));
        
        
         $rates = Currency::whereIn('currency', ['XMR', 'USD', 'EUR', 'GBP', 'AUD'])
            ->pluck('rate', 'currency');

        // Retrieve rates
        $xmrRatePerUsd = $rates['XMR'] ?? 0; // XMR per USD
        $usdRate = $rates['USD'] ?? 1; // USD per USD (always 1)
        $eurRate = $rates['EUR'] ?? 1; // EUR per EUR (if you have this rate)
        $gbpRate = $rates['GBP'] ?? 1; // GBP per GBP (if you have this rate)
        $audRate = $rates['AUD'] ?? 1; // AUD per AUD (if you have this rate)

        // Calculate the value of 1 XMR in each currency
        $xmrToUsd = ($xmrRatePerUsd != 0) ? (1 / $xmrRatePerUsd) : 0;
        $xmrToEur = ($xmrRatePerUsd != 0 && $eurRate != 0) ? ($eurRate/ $xmrRatePerUsd) : 0;
        $xmrToGbp = ($xmrRatePerUsd != 0 && $gbpRate != 0) ? ($gbpRate / $xmrRatePerUsd) : 0;
        $xmrToAud = ($xmrRatePerUsd != 0 && $audRate != 0) ? ( $audRate/ $xmrRatePerUsd ) : 0;

        // Share data with all views
        view()->share('xmrToUsd', number_format($xmrToUsd, 2));
        view()->share('xmrToEur', number_format($xmrToEur, 2));
        view()->share('xmrToGbp', number_format($xmrToGbp, 2));
        view()->share('xmrToAud', number_format($xmrToAud, 2));
    }
}
