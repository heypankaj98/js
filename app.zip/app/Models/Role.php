<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Role extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'roles';  // Table name

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'title',  // You can add other fields like 'slug' if needed
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    // Define many-to-many relationship with permissions
    public function permissions()
    {
        return $this->belongsToMany(Permission::class);
    }

    // Define many-to-many relationship with users
    public function users()
    {
        return $this->belongsToMany(User::class);  // Many-to-many relationship with users
    }
}
