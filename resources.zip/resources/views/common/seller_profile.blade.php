@extends('layouts.homeapp')

@section('content')
<style>
    img.card-img-top {
        padding-top: 10px;
        padding-left: 10px;
    }

    .col-md-12 {
        margin-bottom: 20px;
    }

    h4 {
        padding-left: 10px;
        padding-top: 10px;
    }

    .andom32 {
        margin-top: 15px;
    }

    .card-body {
        margin-top: 20px;
    }

    .tab-content {
        display: none;
    }

    input[type="radio"] {
        display: none;
    }

    label {
        cursor: pointer;
        padding: 10px;
        border: 1px solid #ccc;
        display: inline-block;
        margin-right: 5px;
    }

    input[type="radio"]:checked+label {
        background-color: #ff202c;
    }

    #tab1:checked~#content1,
    #tab2:checked~#content2,
    #tab3:checked~#content3,
    #tab4:checked~#content4 {
        display: block;
    }
</style>

<div class="deshboard_main_part">
    <h2 class="title_heading">Seller Profile</h2>
    <div class="super_container">
        <header class="header" style="display: none;">
            <div class="header_main">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
                            <div class="header_search">
                                <div class="header_search_content">
                                    <div class="header_search_form_container">
                                        <form action="#" class="header_search_form clearfix">
                                            <div class="custom_dropdown">
                                                <div class="custom_dropdown_list">
                                                    <span class="custom_dropdown_placeholder clc">All Categories</span>
                                                    <i class="fas fa-chevron-down"></i>
                                                    <ul class="custom_list clc">
                                                        <li><a class="clc" href="#">All Categories</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Static User Info (Avatar, Username) -->
        <div class="col-md-12">
            <div class="card-body text-center">
                <!-- Display User Avatar -->
                <img src="{{ asset('storage/' . $seller->avatar) }}" class="card-img-top" alt="User Avatar" style="width: 50px; height: 50px; border-radius: 50%;">
                <h4>{{ $seller->username }}</h4> <!-- Display username -->
            </div>
        </div>

        <div class="bg-card-1 p-24">
            <div class="col-md-12">
                <h2>About Seller</h2>
            </div>
            <input type="radio" id="tab1" name="tabs" checked>
            <label class="br-4" for="tab1">Profile</label>

            <input type="radio" id="tab2" name="tabs">
            <label class="br-4" for="tab2">Seller PGP</label>

            <input type="radio" id="tab3" name="tabs">
            <label class="br-4" for="tab3">Feedback</label>

            <input type="radio" id="tab4" name="tabs">
            <label class="br-4" for="tab4">Refund Policy</label>

            <!-- Profile Tab Content -->
            <div id="content1" class="tab-content">
                <div class="andom32">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Joined: {{ $seller->created_at->format('M d, Y') }}</li> <!-- Format the date -->
                            <li class="list-group-item">Last Login: Recently</li> <!-- You can replace with actual last login -->
                            <li class="list-group-item">{{ $orders }} Completed Orders</li>
                            <a href="{{ route('messenger.newMessages', $user->id) }}" class="btn btn-primary">
                                <i class="bi bi-chat-dots"></i> Message
                            </a>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Seller PGP Tab Content -->
            <div id="content2" class="tab-content">
                <div class="card-body">
                    <h2 class="card-title mb-2">Seller PGP</h2>
                    <textarea class="form-control-textarea" readonly="readonly" rows="5">{{ $seller->pgp_key ?? 'No PGP key available' }}</textarea>
                </div>
            </div>

            <!-- Feedback Tab Content -->
            <div id="content3" class="tab-content">
                <div class="card-body">
                    @foreach ($reviews as $review)
                    <div class="review">
                        <h6 class="title_heading card-title"><strong>{{ $review->user->name }}</strong> (Rating: {{ $review->rating }} Star)</h6>
                        <h4 class="card-title mb-2 btn-main">{{ $review->comment }}</h4>
                        <p>{{ $review->feedback }}</p>
                    </div>
                    @endforeach

                    <!-- Pagination links -->
                    {{ $reviews->links() }}
                </div>
            </div>

            <!-- Refund Policy Tab Content -->
            <div id="content4" class="tab-content">
                <div class="card-body">
                    <h2 class="card-title mb-2">Refund Policy</h2>
                    <p>Thank you for shopping at Dark Alley Market. If you are not entirely satisfied with your purchase, we're here to help.</p>
                </div>
            </div>
        </div>
        <div class="bg-light p-4 rounded shadow-sm">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2 style="background-color:#ff7d00;" class="p-2 text-center">Vendor's Username on Other Marketplaces</h2>
        </div>
    </div>

    <!-- Success and Error Messages -->
    @if (session('success'))
        <div class="alert alert-success mb-3">{{ session('success') }}</div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger mb-3">{{ session('error') }}</div>
    @endif

    <!-- No Marketplaces Found Message -->
    @if ($marketplaces->isEmpty())
        <div class="alert alert-info">No marketplaces found. Add a new one!</div>
    @else
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-sm">
                <thead class="thead-dark">
                    <tr>
                        <th class="py-3 px-4">ID</th>
                        <th class="py-3 px-4">Marketplace Name</th>
                        <th class="py-3 px-4">Seller Name</th>
                        <th class="py-3 px-4">Sales</th>
                        <th class="py-3 px-4">Rating</th>
                        <th class="py-3 px-4">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($marketplaces as $marketplace)
                        <tr>
                            <td class="py-3 px-4">{{ $marketplace->id }}</td>
                            <td class="py-3 px-4">{{ $marketplace->market_placename }}</td>
                            <td class="py-3 px-4">{{ $marketplace->seller_name }}</td>
                            <td class="py-3 px-4">{{ $marketplace->sales }}</td>
                            <td class="py-3 px-4">{{ $marketplace->rating }}</td>
                            <td class="py-3 px-4">{{ $marketplace->created_at->format('d M Y, h:i A') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Average Rating -->
        <div class="mt-4">
            <h2 style="background-color:#ff7d00;" class="p-2 text-center">Rating Average</h2>
            <p class="h4 font-weight-bold text-center">{{ number_format($scaledAverageRating, 1) }} / 5</p>
        </div>
    @endif
</div>
@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<form action="{{ route('admin.updateReputation', $seller->id) }}" method="POST">
    @csrf

    <div class="form-group">
        <label for="manual_reputation">Set Manual Reputation:</label>
        <input 
            type="text" 
            name="manual_reputation" 
            id="manual_reputation" 
            class="form-control"
            value="{{ $seller->manual_reputation }}"
            placeholder="Enter reputation tier (e.g., 'Reputation 1-10')">
    </div>

    <button type="submit" class="btn btn-primary mt-2">Update Reputation</button>
</form>


<h3>Seller Profile for {{ $seller->name }}</h3>

<p>Current Reputation: {{ $seller->manual_reputation ?? 'No Reputation' }}</p>

<!-- Optionally, display dynamic reputation -->
<p>Dynamic Reputation: {{ getSellerReputationTier($seller->id) }}</p>


            </div>
    </div>
</div>
@endsection
