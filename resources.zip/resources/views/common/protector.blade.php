@extends('layouts.homeapp')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protector of the Dark Alley Marketplace</title>
    <style>
        p {
            color: #fff;
        }
        .section {
            margin-bottom: 20px;
        }
       
        .code {
            background: #000;
            padding: 6px 10px;
            border-radius: 2px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="mt-4">
    <h1 class="custom-title mb-4">Protector of the Dark Alley Marketplace</h1>    
    <div class="bg-card-1 p-24 mt-4 br1">
     

        <div class="section mt-4">
            <h3 class="card-header-2 w-100 mb-4">The Dark Alley Guardian</h3>
            <p>Dark Alley was designed for a permanent existence. That is why we focused on safety and made no compromises.</p>
            <p>The Dark Alley Guardian performs many functions, but we want to briefly explain the two most important ones here, as well as the integrated Strike-System.</p>
            <p>We would like to make one thing clear in advance:</p>
            <p>You can never be striked if you always use the navigation of the Dark Alley Marketplace and do not open multiple instances in several tabs/windows and never manipulate the URL by performing direct URL inputs.</p>
        </div>

        <div class="section">
            <h3 class="card-header-2 w-100 mb-4">Forms</h3>
            <p>Pages containing a form have a special unique token assigned which expires if another page containing a form is opened. For example, if you open multiple pages in several tabs/windows in your browser and all contain forms, a message will be displayed:</p>
            <p class="code">ERROR: TOKEN EXPIRED</p>
            <p>If you try to submit a form from a page which is not the latest that you opened, because all previous ones are expired.</p>
            <p>If you should want to open multiple pages which contain forms anyway, there is no problem:</p>
            <p>Just refresh the page to be submitted with the browser reload button or by using [F5] on your keyboard, before you submit the form, so the token will be updated.</p>
        </div>

        <div class="section">
            <h3 class="card-header-2 w-100 mb-4">Actions and URLs</h3>
            <p>Dark Alley works according to the whitelist principle. That basically means everything is forbidden and only existing actions are allowed and can be executed.</p>
            <p>Before any action on Dark Alley will be executed, the Dark Alley Guardian checks five simple things:</p>
            <ul>
                <li>Does any input contain malicious code?</li>
                <li>Does the requested action really exist?</li>
                <li>Do all given parameters for this action exist?</li>
                <li>Is the user who tries to perform this action authorized for doing so?</li>
                <li>Has the action already been executed previously and now the user tries to perform it again to scam in any way?</li>
            </ul>
            <p>If you try to perform an illegal action, you will be striked.</p>
            <p>The same applies to URLs, so any manual URL alteration is not allowed. If you try to open an URL on Dark Alley that exists or that you are not authorized to open, you will be striked.</p>
            <p>Contrarily, this means quite simply, if you do not try to perform an illegal action, you will never be striked. So don't do it.</p>
        </div>

        <div class="section strike-system">
            <h3 class="card-header-2 w-100 mb-4">The Strike-System</h3>
            <p>The Strike-System works on a very simple principle.</p>
            <p>If you try to perform an illegal action, the Dark Alley Guardian displays the Strike-System notice and the Strike-System is active to count all strikes with every further illegal action.</p>
            <p>You can be striked two times.</p>
            <p>If you have received two strikes and, again, try to perform an illegal action, your account will be temporarily suspended and you will be informed via ticket by the Administration.</p>
            <p>Depending on how many strikes you already have, the Administration decides during the temporary block how this violation is dealt with. Any further violations will be informed via a ticket.</p>
            <p>Be aware: The Dark Alley Guardian notices when you get banned, how and why you were striked and keeps track of it.</p>
            <p>But never forget: Strikes are not a death sentence and only show why a strike(s) was triggered, so avoid every strike and you will never get banned.</p>
        </div>
    </div>
    </div>
  
</body>
</html>
@endsection