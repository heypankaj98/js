<?php
namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Crypt;

class VerifyLoginRequest extends FormRequest {
    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'verification_code' => 'nullable'
        ];
    }

    public function verify() {
        $verificationCode = Crypt::decryptString(session()->get('verification_code'));

        // if ($this->verification_code !== $verificationCode) {
        //     throw new \Exception('Invalid verification code!');
        // }
        #Destroy verification sessions
        session()->forget(['verification_name', 'encrypted_message', 'verification_code']);
        return redirect()->route('user.home');
    }
}