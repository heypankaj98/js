@extends('forum::layouts.master')

@section('content')
<!-- Add this button at the top or bottom of the threads list -->
<a href="{{ route('thread.create.category', ['category' => $category]) }}" class="btn btn-primary">New Thread</a>


 <div class="d-flex flex-row justify-content-between mb-2">
        <h2 style="color: {{ $category->color }};">
            {{ $category->title }} &nbsp;
            @if ($category->description)
                <small>{{ $category->description }}</small>
            @endif
        </h2>
        
        
    </div>
<div class="row">
    @foreach ($threads as $thread)
    <div class="col-md-12">
        <div class="card mb-3 {{ $thread->pinned ? 'border-info' : '' }} {{ $thread->locked ? 'border-warning' : '' }} {{ $thread->trashed() ? 'border-danger' : '' }}">
            <div class="card-body">
                <h5 class="card-title">
                    <a href="{{route('thread.show', $thread) }}" @if (isset($category))style="color: {{ $category->color }};"@endif>{{ $thread->title }}</a>
                </h5>
                <p class="card-text">{{ $thread->authorName }}</p>

                @if (! isset($category))
                <p class="card-text">
                    <a href="{{ route('category.show', $thread->category) }}" style="color: {{ $thread->category->color }};">{{ $thread->category->title }}</a>
                </p>
                @endif

                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        
                        @if ($thread->pinned)
                        <span class="badge bg-info text-light">{{ trans('forum::threads.pinned') }}</span>
                        @endif
                        @if ($thread->locked)
                        <span class="badge bg-warning text-dark">{{ trans('forum::threads.locked') }}</span>
                        @endif
                        @if ($thread->userReadStatus !== null && ! $thread->trashed())
                        <span class="badge bg-success text-light">{{ trans($thread->userReadStatus) }}</span>
                        @endif
                        @if ($thread->trashed())
                        <span class="badge bg-danger text-light">{{ trans('forum::general.deleted') }}</span>
                        @endif
                        <span class="badge bg-primary text-light" @if (isset($category))style="background: {{ $category->color }};"@endif>
                            {{ trans('forum::general.replies') }}:
                            {{ $thread->reply_count }}
                        </span>
                    </div>
                    @if ($thread->lastPost)
                    <div class="text-muted">
                        <a href="{{ route('thread.show', $thread->lastPost) }}">{{ trans('forum::posts.view') }} &raquo;</a>
                        <br>
                        {{ $thread->lastPost->authorName }}
                        <span class="text-muted">@include ('forum::forum.partials.timestamp', ['carbon' => $thread->lastPost->created_at])</span>
                    </div>
                    @endif
                </div>
                @if (auth()->check() && $thread->author_id == auth()->user()->id  )
                <!-- Form for individual thread actions -->
                <form action="{{ route('thread.delete', $thread) }}" method="POST" class="mt-3">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">{{ trans('forum::general.delete') }}</button>
                </form>
                <form action="{{ route('thread.restore', $thread) }}" method="POST" class="mt-2">
                    @csrf
                    @method('PATCH')
                    <button type="submit" class="btn btn-success">{{ trans('forum::general.restore') }}</button>
                </form>
                
                    @endif
            </div>
        </div>
    </div>
    @endforeach

</div>
@endsection
