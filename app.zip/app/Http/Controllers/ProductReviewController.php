<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductReview;
use App\Models\Order;
use Illuminate\Support\Facades\Log;


class ProductReviewController extends Controller {

    public function __construct()
    {
        $this->middleware('auth'); // Ensure only authenticated users can perform actions
    }

    public function storeFeedback(Request $request, $id)
{
    // Validate the feedback data
    $request->validate([
        'rating' => 'required|integer|min:1|max:5',
        'review' => 'required|string',
    ]);

    // Find the product
    $product = Product::findOrFail($id);

    // Store the feedback (assuming the ProductReview model exists)
    $product->reviews()->create([
        'user_id' => auth()->id(),
        'rating' => $request->rating,
        'review' => $request->review,
    ]);

    // Redirect back to the product page or another page
    return redirect()->route('products.show', $id)->with('success', 'Your feedback has been submitted!');
}

    // Method to store the feedback submission
    public function store(Request $request, Product $product)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'feedback' => 'required|string|max:1000',
            'rating' => 'required|numeric|min:1|max:5',
        ]);

        // Assign product and user id to the validated data
        $validatedData['product_id'] = $product->id;
        $validatedData['user_id'] = auth()->user()->id;

        try {
            // Create the product review
            ProductReview::create($validatedData);

            // Redirect back with success message
            return redirect()->route('product.feedback', $product)->with('success', 'Your feedback has been submitted!');
        } catch (\Exception $e) {
            // Handle any errors during the review creation
            return redirect()->back()->with('error', 'There was an error saving your review. Please try again.');
        }
    }

    // Method to delete a review
    public function destroy(ProductReview $review)
    {
        // Ensure the review belongs to the currently authenticated user
        if ($review->user_id !== auth()->user()->id) {
            return redirect()->back()->with('error', 'You are not authorized to delete this review.');
        }

        try {
            $review->delete();
            return redirect()->back()->with('success', 'Review deleted successfully!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'There was an error deleting your review.');
        }
    }
public function submitReview(Request $request, $orderId)
{
    // Debug the incoming request
    Log::info('Review Data:', $request->all());

    // Validate incoming request data
    $request->validate([
        'review' => 'required|integer|min:1|max:5',  // Ensure review is between 1 and 5
        'feedback' => 'required|string|max:255',    // Validate feedback input
    ]);

    // Find the order and check if the user is allowed to review
    $order = Order::findOrFail($orderId);

    // Check if the user has already reviewed this order (ensure only one review per order)
    $existingReview = ProductReview::where('order_id', $orderId)
                                   ->where('user_id', auth()->id())
                                   ->exists();

    if ($existingReview) {
        return back()->with('error', 'You have already submitted a review for this order.');
    }

    // Get the seller_id from the product associated with the order
    $sellerId = $order->product->seller_id;  // Assuming the product has a seller_id field

    // Create a new review record
    $review = new ProductReview();
    $review->order_id = $orderId;
    $review->user_id = auth()->id();  // Assuming the user is authenticated
    $review->product_id = $order->product_id;  // Assuming the order has a product_id
    $review->seller_id = $sellerId;  // Storing the seller ID
    $review->rating = $request->input('review');
    $review->comment = $request->input('feedback');
    $review->save();

    // Fetch all reviews for the seller's products
    $reviews = ProductReview::where('seller_id', $sellerId)
                            ->with('user') // Optional: eager load the related user model
                            ->paginate(10); // Paginate results, adjust as needed

    // Redirect back to the seller's profile page with success message and the reviews
    return view('common.seller_profile', compact('reviews'))
           ->with('success', 'Review submitted successfully!');
}





}
