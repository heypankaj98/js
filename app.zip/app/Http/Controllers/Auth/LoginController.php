<?php
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Http\Requests\Auth\{ LoginRequest , VerifyLoginRequest };
use Auth,Session;

class LoginController extends Controller {
    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct() {
        $this->middleware('guest')->except('logout');
    }

    public function redirectTo() {
        if (auth()->user()->is_admin) {
            return '/admin';
        }
        if (auth()->user()->is_seller) {
            return '/seller/dashboard';
        }
        return '/home';
    }

    public function show() {
        return view('auth.login');
    }

public function login(LoginRequest $request) {
    try {
        return $request->login();
    } catch (\Exception $exception) {
        $attemptCount = session('loginAttempts', 0);
        $attemptCount++;
        session(['loginAttempts' => $attemptCount]);

        // Redirect to the login failed route if attempts exceed 10
        if ($attemptCount >= 10) {
            return redirect()->route('loginfailed');
        }

        // Check for specific exceptions or messages
        $errorMessage = match (true) {
            str_contains($exception->getMessage(), 'username') => 'The username you entered is incorrect.',
            str_contains($exception->getMessage(), 'password') => 'The password you entered is incorrect.',
            str_contains($exception->getMessage(), 'CAPTCHA') => 'CAPTCHA validation failed. Please try again.',
            default => 'An error occurred. Please try again.',
        };

        // Flash the specific error message
        session()->flash('error', $errorMessage);
        return redirect()->back();
    }
}


public function logout() {
    Auth::logout(); // Log the user out
    session()->flush(); // Clear all session data
    session()->invalidate(); // Invalidate the session
    session()->regenerateToken(); // Regenerate the CSRF token

    return redirect()->route('login'); // Redirect to the login page
}

    public function themeSwitch() {
        if (Session::exists('theme')) {
            $theme = Session::get('theme');
            if ($theme == 'dark') {
                Session::put('theme', 'light');
            } else {
                Session::put('theme', 'dark');
            }
        } else {
            Session::put('theme', 'dark');
        }
        return redirect()->back();
    }
    
    
        public function loginfailed() {
            
            
        return view('loginfailed');

            
        }
    
    public function Phishing(){
        
       return view('phishing');
    }
    
}