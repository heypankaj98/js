<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShippingMethod extends Model {

    use HasFactory;

    protected $table = 'shipping_methods';

    public function orders() {
        return $this->hasMany(Order::class, 'shipping_method_id');
    }

    public function products() {
        return $this->hasMany(Product::class);
    }

}
