<?php

namespace App\Http\Controllers\Buyer;

use Auth,
    Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Models\Settings;
use App\Models\Payment;
use App\Models\User;
use App\Models\UserMeta;
use Illuminate\Http\Request;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use PDO;





class HomeController {
    
     public function Widthwral() {
         $id = Auth::id();
      
       $user = User::find($id);
      
          
          return view('buyer.widthwral',compact('user'));
      }
      
     public function Adderss(Request $request) {
   $id = Auth::id();
   $user = User::find($id); 
  
   return view('buyer.addaderss',compact('user'));
     }    
      
public function AddadderssBtc(Request $request) {
        $id = Auth::id();
        $user = User::find($id); 
        
        $coinType=$request->coin;
        $address = $request->addresses;
        
      switch ($coinType) {
        case 'btc_address':
            if (empty($address)) {
                return redirect()->back()->with('error', 'BTC Address Invalid');
            }
            break;
        case 'xmr_address':
            // Validate XMR address if needed
            
             if (empty($address)) {
                return redirect()->back()->with('error', 'XMR Address Invalid');
            }
            
            break;
        case 'ltc_address':
             if (empty($address)) {
                return redirect()->back()->with('error', 'LTC Address Invalid');
            }
            break;
        default:
            return redirect()->back()->with('error', 'Invalid selection');
    }
         switch ($coinType) {
        case 'btc_address':
     if($user->btc_address==NUll){
         $user->btc_address=$request->addresses;
         
     }
         break;
        case 'xmr_address':
    if($user->xmr_address==NUll){
         $user->xmr_address=$request->addresses;
    }
        break;
        case 'ltc_address':
     if($user->ltc_address==NUll){
         $user->ltc_address=$request->addresses;
    }         break;
        default:
            return redirect()->back()->with('error', 'Invalid selection');
    }
        $user->save();   
         
     return redirect()->back()->with('sucsses', 'widthwral sucssesfully');}
 
  public function AddersUpdate(Request $request) {
    $id = Auth::id();
    $user = User::find($id);

    // Retrieve coin type and address from request
    $coinType = $request->coin;
    $address = $request->addresses;

    // Update user's address based on coin type if it's empty
    switch ($coinType) {
        case 'btc_address':
            if (!empty($address)) {
                $user->btc_address = $address;
            }
            break;
        case 'xmr_address':
            if (!empty($address)) {
                $user->xmr_address = $address;
            }
            break;
        case 'ltc_address':
            if (!empty($address)) {
                $user->ltc_address = $address;
            }
            break;
        default:
            // This case should not happen due to earlier validation
            return redirect()->back()->with('error', 'Invalid coin type');
    }
 // Save the updated user object
    $user->save();
 return redirect()->back()->with('success', 'Withdrawal address added');
}

 public function deleteAddress(Request $request)
{ 
    // Retrieve authenticated user ID
    $id = Auth::id();
    // Find the user by ID
    $user = User::find($id);

    // Retrieve coin type from request
    $coinType = $request->coin;

    // Determine which address to delete based on coin type
    switch ($coinType) {
        case 'btc_address':
            if ($user->btc_address !== null) {
                $user->btc_address = null;
                $user->save();
                return redirect()->back()->with('success', 'BTC Address deleted successfully');
            } else {
                return redirect()->back()->with('error', 'BTC Address not found');
            }
            break;
        case 'xmr_address':
            if ($user->xmr_address !== null) {
                $user->xmr_address = null;
                $user->save();
                return redirect()->back()->with('success', 'XMR Address deleted successfully');
            } else {
                return redirect()->back()->with('error', 'XMR Address not found');
            }
            break;
        case 'ltc_address':
            if ($user->ltc_address !== null) {
                $user->ltc_address = null;
                $user->save();
                return redirect()->back()->with('success', 'LTC Address deleted successfully');
            } else {
                return redirect()->back()->with('error', 'LTC Address not found');
            }
            break;
        default:
            return redirect()->back()->with('error', 'Invalid coin type');
    }
}

 
 
 
 
 
 
 
   public function Adderssedit( $id ) {
    $user = User::find($id);
    return view('buyer.addersedit');  
   }
     
     
   public function Widthwralupdate(Request $request) {
     $id = Auth::id();
     $user = User::find($id);
   
     $btc_balance = $user->btc_balance;
     $xmr_balance = $user->xmr_balance;
     $ltc_balance = $user->ltc_balance;
    //  $paymment_address=;
     $amount=$request->amount;
     $coinType=$request->coin;
     switch ($coinType) {
      case 'btc_balance':
            if ($btc_balance < $amount) {
               
                return redirect()->route('user.widthwral')->with('error', 'Insufficient BTC balance');
            }
        
            break;
        case 'xmr_balance':
            if ($xmr_balance < $amount) {
                return redirect()->route('user.widthwral')->with('error', 'Insufficient XMR balance');
            }
            $xmr_balance -= $amount;
            break;
        case 'ltc_balance':
            if ($ltc_balance < $amount) {
                return redirect()->route('user.widthwral')->with('error', 'Insufficient LTC balance');
            }
            break;
        default:
            return redirect()->route('user.widthwral')->with('error', 'Invalid coin type');
    }
    
   $btc_amount =  $btc_balance -= $amount; 
   $ltc_amount = $ltc_balance -= $amount; 
    $xmr_amount =$xmr_balance -= $amount;
   $user->btc_balance=$btc_amount;
   $user->xmr_balance=$ltc_amount;
   $user->ltc_balance=$xmr_amount;
   $user->save();     
     return redirect()->back()->with('sucsses', 'widthwral sucssesfully');
      }
      
      
    public function getBecomeSeller() {


        if (!Auth::user()->pgp_key && Auth::user()->twofa == 0) {
            return redirect()->route('user.profile.security0')->with('error', 'PGP Key is require to be a Vendor 2fa will be auto enable for seller');
        }

        if ($user_meta_become = auth()->user()->meta_become_seller) {
            
        } else {
            $user_meta_become = null;
        }

        $seller_fee = Settings::get('become_seller_fee');

        $paymment_coin = json_decode(auth()->user()->meta_become_seller,
true);
       if (!is_null($paymment_coin)) {
    foreach ($paymment_coin as $method => &$paymment_address) {
        $balance = PayWay::getBalance($method, ['address' => $paymment_address]);
        // Check for error in balance retrieval
        if (isset($balance['error_code'])) {
            $errorCode = $balance['error_code'];
            $errorMessage = $balance['error_message'];
            session()->flash('error', $errorMessage . " => " . $errorCode);
        } else {
            // Format the balance to 8 decimal places
            $formatted_balance = number_format($balance, 8); // Adjust decimal places as needed

            $paymment_address = [
                'address' => $paymment_address,
                'balance' => $formatted_balance
            ];
        }
    }
}


        return view('buyer.become', compact('user_meta_become', 'seller_fee', 'paymment_coin'));
    }
    
     
public function becomeSeller() {
    $user = Auth::user();

    // Check if the user is already a seller or has a pending request
    if ($user->isSeller || $user->has_seller_request) {
        return redirect()->back()->with('error', 'You have already submitted a request to become a seller.');
    }

    // Check for PGP Key and 2FA requirement
    if (!$user->pgp_key && $user->twofa == 0) {
        return redirect()->route('user.profile.security')
                         ->with('error', 'PGP Key is required to be a Vendor. 2FA will be auto-enabled for sellers.');
    }

    $seller_fee = Settings::get('become_seller_fee');
    $btc_sellerfees = convert($seller_fee, 'Bitcoin');
    $xmr_sellerfees = convert($seller_fee, 'Monero');
    $btc_sellerfees = number_format($btc_sellerfees, 8, '.', '');
    $xmr_sellerfees = number_format($xmr_sellerfees, 8, '.', '');

    if ($user->btc_balance >= $btc_sellerfees) {
        // Process BTC payment
        $this->processSellerPayment($user, $seller_fee, $btc_sellerfees, 'btc_wallet');
        return redirect()->back()->with('success', 'Thank you for submitting your request. You are eligible to become a seller. Please wait for admin approval or raise a ticket for further assistance.');
    }

    if ($user->xmr_balance >= $xmr_sellerfees) {
        // Process XMR payment
        $this->processSellerPayment($user, $seller_fee, $xmr_sellerfees, 'xmr_wallet');
        return redirect()->back()->with('success', 'Thank you for submitting your request. You are eligible to become a seller. Please wait for admin approval or raise a ticket for further assistance.');
    }

    // If no valid payment method could be processed, return error
    return redirect()->back()->with('error', 'You need sufficient funds to become a seller.');
}



// Helper function to process payment
private function processSellerPayment($user, $seller_fee, $total_received, $method) {
    // Deduct balance
    if ($method === 'btc_wallet') {
        $user->btc_balance -= $total_received;
    } elseif ($method === 'xmr_wallet') {
        $user->xmr_balance -= $total_received;
    }

    $user->has_seller_request = 1; // Mark request as submitted
    $user->isSeller = 1;
    $user->twofa = 1;  // Enable 2FA for seller
    $user->roles()->sync(3);  // Sync to seller role (role id 3)
    $user->save();

    // Record the payment
    $sellerPayment = new Payment();
    $sellerPayment->user_id = $user->id;
    $sellerPayment->model_type = 'Seller';
    $sellerPayment->method = $method;
    $sellerPayment->payment_address = 'wallet_payment';
    $sellerPayment->status = 'received';
    $sellerPayment->type = 'seller_payment';
    $sellerPayment->amount = $seller_fee;
    $sellerPayment->total_received = $total_received;
    $sellerPayment->save();
}

private function processOrderPayment($user, $order, $order_total, $total_received, $method) {
    // Deduct balance based on the payment method
    if ($method === 'btc_wallet') {
        $user->btc_balance -= $total_received;
    } elseif ($method === 'xmr_wallet') {
        $user->xmr_balance -= $total_received;
    }

    // Record the order payment
    $orderPayment = new Payment();
    $orderPayment->user_id = $user->id;
    $orderPayment->model_type = 'Order';
    $orderPayment->order_id = $order->id;
    $orderPayment->method = $method;
    $orderPayment->payment_address = 'wallet_payment'; // Could be updated with the actual wallet address
    $orderPayment->status = 'received';
    $orderPayment->type = 'order_payment';
    $orderPayment->amount = $order_total;
    $orderPayment->total_received = $total_received;
    $orderPayment->save();

    // Optionally: Update the order status after payment is processed
    $order->status = 'paid';
    $order->payment_method = strtoupper($method);  // Storing the payment method in the order (e.g., BTC, XMR)
    $order->payment_status = 'completed';
    $order->payment_transaction_id = 'TX_ID';  // Replace with actual transaction ID if available
    $order->save();
}

public function payForOrder($orderId) {
    $user = Auth::user();
    $order = Order::find($orderId);

    // Check if the order exists and belongs to the user
    if (!$order || $order->user_id != $user->id) {
        return redirect()->back()->with('error', 'Order not found or you do not have permission to pay for this order.');
    }

    // Check if the order is already paid
    if ($order->status == 'paid') {
        return redirect()->back()->with('error', 'This order has already been paid.');
    }

    $order_total = $order->total_amount;
    $btc_order_total = convert($order_total, 'Bitcoin');
    $xmr_order_total = convert($order_total, 'Monero');
    $btc_order_total = number_format($btc_order_total, 8, '.', '');
    $xmr_order_total = number_format($xmr_order_total, 8, '.', '');

    // Check if the user has sufficient BTC balance
    if ($user->btc_balance >= $btc_order_total) {
        // Process BTC payment
        $this->processOrderPayment($user, $order, $order_total, $btc_order_total, 'btc_wallet');
        
        // Mark the order as paid and update payment details
        $order->status = 'paid';
        $order->payment_method = 'BTC';
        $order->payment_status = 'completed';
        $order->payment_transaction_id = 'BTC_TX_ID';  // Replace with actual transaction ID if available
        $order->save();
        
        return redirect()->back()->with('success', 'Your payment has been processed successfully. Your order has been completed.');
    }

    // Check if the user has sufficient XMR balance
    if ($user->xmr_balance >= $xmr_order_total) {
        // Process XMR payment
        $this->processOrderPayment($user, $order, $order_total, $xmr_order_total, 'xmr_wallet');
        
        // Mark the order as paid and update payment details
        $order->status = 'paid';
        $order->payment_method = 'XMR';
        $order->payment_status = 'completed';
        $order->payment_transaction_id = 'XMR_TX_ID';  // Replace with actual transaction ID if available
        $order->save();
        
        return redirect()->back()->with('success', 'Your payment has been processed successfully. Your order has been completed.');
    }

    // If no valid payment method could be processed, return error
    return redirect()->back()->with('error', 'You need sufficient funds to pay for this order.');
}
 public function setCurrency($currency)
    {
        session(['currency' => $currency]); // Store the selected currency in the session
        return redirect()->back(); // Redirect back to the previous page
    }

public function updateUserReputation($userId)
    {
        // Find the user by ID
        $user = User::findOrFail($userId);

        // Get the user's purchase count (assuming a purchases relationship exists)
        $purchaseCount = $user->purchases()->count();

        // Calculate reputation
        $reputation = $this->getUserReputation($purchaseCount);

        // Update user's reputation in the database
        $user->reputation = $reputation;
        $user->save();

        return response()->json([
            'message' => 'User reputation updated successfully.',
            'reputation' => $reputation,
        ]);
    }

    /**
     * Calculate reputation based on purchase count.
     */
    private function getUserReputation(int $purchaseCount): int
    {
        // Limit purchases considered for reputation calculation to 100
        $purchaseCount = min($purchaseCount, 100);

        // Calculate reputation based on the number of purchases (1-5 -> 0, 6-10 -> 1, etc.)
        return floor(($purchaseCount - 1) / 5);
    }


    }