<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\{
    Model,
    SoftDeletes
};

class Order extends Model {

    use SoftDeletes,
        HasFactory;

    public $table = 'orders';
    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];
    protected $fillable = [
        'order_id',
        'product_id',
        'buyer_id',
        'seller_id',
        'payment_method',
        'address',
        'quantity',
        'status',
        'total',
        'total_crypto',
        'finished',
        'deleted',
        'created_at',
        'updated_at',
        'deleted_at',
    ];
public function orders()
{
    return $this->hasMany(Order::class, 'buyer_id');
}

    public function product() {
        return $this->belongsTo(Product::class, 'product_id');
    }
    public function seller() {
        return $this->belongsTo(User::class, 'seller_id');
    }
    public function buyer() {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function orderPayment() {
        return $this->hasOne(OrderPayment::class, 'order_id', 'order_id');
    }

    public function totalReceived() {
        try {
            return \Monerod::getTotalReceived($this->escrow_monero_wallet);
        } catch (\Exception $exceoption) {
            return 0.00000;
        }
    }

    public function commission() {
        if ($this->total < 100) {
            return config('setting.commission.below100');
        } else {
            return config('setting.commission.above100');
        }
    }

//     public function scopeDisputes($query) {  //$moderatorUsers = User::moderator()->get();
//         
//        return $query->whereHas('disputes', function ($query) {
//                    $query->where('product_id', $product_id);
//                });
//    }

    public function disputes() {
        return $this->belongsTo(Dispute::class,'order_id','order_id');
    }

    public function checkDispute() {
        
         $dispute=$this->disputes()->where('product_id', $this->product_id)->first();
        return $this->disputes()->where('product_id', $this->product_id)->first();
    }

}
