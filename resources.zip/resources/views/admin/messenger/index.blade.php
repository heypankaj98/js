@extends('admin.messenger.template')

@section('title', $title)

@section('messenger-content')


<div class="mt-4">
    <div class="row">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column  h-100 chat-sidebar">
                <div class="bg-card-2 mb-4 br1 p-16">
                    <!-- Channels -->
                    <div>
                        <h5 class="card-header-2 w-100 mb-4">Channels</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">#general</a></li>
                            <li><a href="#">#announcements</a></li>
                        </ul>
                    </div>
                </div>

                <div class="bg-card-2 h-100 br1 p-16">
                    <h5 class="card-header-2 w-100 mb-4">Chat Users</h5>
                    <ul class="list-unstyled">
                    @forelse($topics as $singletopic)
                        <li class="mb-2">
                        <a href="{{ route('admin.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                    <img src="{{$singletopic->receiverOrCreator()->avatar}}" class="rounded-circle">
                                    <div class="d-flex flex-column gap-2">
                                        <span>{{$singletopic->receiverOrCreator()->username}} (
                                            {{ $singletopic->mesasgeUnreadCount() }} )</span>
                                        <p class="small mb-0">online</p>
                                    </div>
                                    @endif
                                </div>
                            </a>

                        </li>
                       
                       
                        @empty
                        No chat User
                        @endforelse
                    </ul>
                    
                </div>

            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">
                    <h5 class="mb-0">Select Chat user to see chat</h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">
                        <p>Select User for chat</p>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="bg-card-2 mb-4 br1 p-16">
                <p class="card-header-2 w-100 mb-4">Admin Users</p>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                    @if (auth()->user()->id != $adminuser->id)
                    @if($adminuser->withChatMessages($adminuser->id) > 0)
                    <a href="{{ route('admin.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                        <span class="badge text-bg-primary">{{$adminuser->username}}</span></a>
                    @else
                    <a href="{{ route('admin.messenger.newMessages', [$adminuser->id]) }}"> <span
                            class="badge text-bg-primary">{{ $adminuser->username}}</span></a>

                    @endif
                    @endif
                    @empty
                    No chat and admin Here
                    @endforelse
                </ul>
            </div>
            <!-- Mod -->
            <div class="bg-card-2 br1 p-16">
                <p class="card-header-2 w-100 mb-4">Mod Users</p>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                    @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('admin.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}"> <span
                            class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    @else
                    <a href="{{ route('admin.messenger.newMessages', [$moduser->id]) }}"> <span
                            class="badge text-bg-primary">{{ $moduser->username}}</span></a>
                    @endif
                    @endif
                    @empty
                    No chat and Mod User
                    @endforelse
                </ul>
            </div>
        </div>
    </div>

</div>




@endsection