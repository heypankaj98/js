@extends('layouts.buyer.app') <!-- Extend your main layout -->

@section('content')
    <div class="container">
        <h1>Leave Feedback for {{ $product->name }}</h1>

        <!-- Display product details -->
        <div>
            <img src="{{ $product->getPhotoAttribute()->url }}" alt="{{ $product->name }}">
            <p>{{ $product->description }}</p>
        </div>

        <!-- Feedback form -->
        <form action="{{ route('products.storeFeedback', $product->id) }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="rating">Rating</label>
                <select name="rating" id="rating" class="form-control">
                    <option value="1">1 Star</option>
                    <option value="2">2 Stars</option>
                    <option value="3">3 Stars</option>
                    <option value="4">4 Stars</option>
                    <option value="5">5 Stars</option>
                </select>
            </div>

            <div class="form-group">
                <label for="review">Review</label>
                <textarea name="review" id="review" class="form-control" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Submit Feedback</button>
        </form>
    </div>
@endsection
