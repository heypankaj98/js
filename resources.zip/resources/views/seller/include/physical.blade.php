<div class="container mt-4 accordion_main_part">
    <form method="POST" action="{{ route("seller.products.store") }}" enctype="multipart/form-data">
        @csrf
        <div class="col-lg-12">
            <div class="p-24 br1 br-4">
            <div class="card-header-2 w-100 mb-4">
                        {{ trans('common.add') }} {{ trans('common.physical') }} {{ trans('common.product') }}
                    </div>
                <div class="card-body">
                    @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <input type="checkbox" checked id="general_info" class="accordion-toggle">
                            <h2 class="accordion-header">
                                <label for="general_info" class="accordion-title accordion-button">
                                    {{ trans('common.general') }} {{ trans('common.details') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-lg-6 col-12">
                                            <label for="product_name" class=" fw-bold label_main">
                                                {{ trans('common.product') }} {{ trans('common.name') }}*:
                                            </label>
                                            <input type="text" class="form-control my-3" id="product_name" placeholder="{{ trans('common.product') }} {{ trans('common.name') }}" name="name" value="">
                                            @error('name')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                            @enderror
                                        </div>
                                        <div class="col-lg-6 col-12">
                                            <label class=" fw-bold label_main">
                                                {{ trans('common.category') }}*:
                                            </label>
                                            <select class="form-select  my-3 py-0" id="Category" aria-label="Default select example" name="category">
                                                @foreach($categories as  $category)
                                                    <?php $dash = ''; ?>
                                                    <option value="{{$category->id}}" @if($category->parent_id  === null) disabled @endif>
                                                        {{ $category->name }}
                                                    </option>
                                                    @if(count($category->subcategory))
                                                        @include('partials.subcategorylist',['subcategories' => $category->subcategory])
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('category')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <div class="mb-3 col-lg-6 col-12">
                                            <label class=" fw-bold label_main">
                                                {{ trans('common.product') }} {{ trans('common.details') }}*:
                                            </label>
                                            <textarea class="form-control-textarea my-3" id="description" rows="5" name="description"></textarea>
                                            @error('description')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <div class="mb-3 col-lg-6 col-12">
                                            <label class=" fw-bold label_main">
                                               {{ trans('common.product') }} {{ trans('common.buy') }}/{{ trans('common.return') }} {{ trans('common.policy') }}*:
                                            </label>
                                            <textarea class="form-control-textarea my-3" id="description" rows="5" name="policy"></textarea>
                                            @error('policy')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <input type="checkbox" id="Pricing-info" class="accordion-toggle">
                            <h2 class="accordion-header">
                                <label for="Pricing-info" class="accordion-title accordion-button">{{ trans('common.price') }}</label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <table class="table table-prd table-bordered">
                                        <thead>
                                            <tr>
                                                <th>{{ trans('common.qty') }}</th>
                                                <th>{{ trans('common.discount') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th>
                                                    <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.qty') }}" min="0" value="" name="wquantity[]">
                                                    @error('wquantity')
                                                        <div class="alert alert-danger" role="alert">
                                                            {{ $message }}
                                                        </div> 
                                                    @enderror
                                                </th>
                                                <td>
                                                    <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.discount') }}" min="0" value="" name="wdiscount[]">
                                                    @error('wquantity')
                                                        <div class="alert alert-danger" role="alert">
                                                            {{ $message }}
                                                        </div> 
                                                    @enderror
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.qty') }}" min="0" name="wquantity[]">
                                                    @error('wquantity')
                                                        <div class="alert alert-danger" role="alert">
                                                            {{ $message }}
                                                        </div>
                                                    @enderror
                                                </th>
                                                <td>
                                                    <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.discount') }}" value="" min="0" name="wdiscount[]" >
                                                    @error('wquantity')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div> 
                                                    @enderror
                                                </td>
                                            </tr>
                                            <tr>
                                                <th scope="row">  <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.qty') }}" min="0" name="wquantity[]" >
                                                    @error('wquantity')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div> 
                                                    @enderror
                                                </th>
                                                <td> <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.discount') }}" min="0" name="wdiscount[]" >
                                                    @error('wquantity')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div> 
                                                    @enderror
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>
                                                    <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.qty') }}" min="0" name="wquantity[]" >
                                                    @error('wquantity')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div> 
                                                    @enderror
                                                </th>
                                                <td> <input type="number" class="form-control my-3" id="wquantity" placeholder="{{ trans('common.add') }} {{ trans('common.discount') }}" min="0" name="wdiscount[]" >
                                                    @error('wquantity')
                                                    <div class="alert alert-danger" role="alert">
                                                        {{ $message }}
                                                    </div> 
                                                    @enderror
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="row">
                                        <div class="col">
                                            <div class="my-3">
                                                <label for="description" class="form-label mb-0">{{ trans('common.price') }}</label>
                                                <input type="text" class="form-control my-3" id="product_name" placeholder="$100" name="price" value="1">
                                                @error('price')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="my-3">
                                                <label for="description" class="form-label mb-0">{{ trans('common.qty') }}</label>
                                                <input type="text" class="form-control my-3" id="product_name" placeholder="Product Unit" name="stock" value="1">
                                                @error('stock')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <input type="checkbox" id="shipping-method" class="accordion-toggle">
                            <h2 class="accordion-header">
                                <label for="shipping-method" class="accordion-title accordion-button">
                                    {{ trans('common.shipping') }} {{ trans('common.method') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="shipping_methods">
                                                    {{ trans('common.shipping') }} {{ trans('common.method') }}
                                                </label>
                                                <select name="shipping_methods[]" id="shipping_methods" class="form-control my-3" multiple required>
                                                    @foreach ($shippingMethods as $method)
                                                        <option value="{{ $method->id }}">{{ $method->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            @if ($shippingMethods->isNotEmpty())
                                                <table class="table table-prd table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>{{ trans('common.name') }}</th>
                                                            <th>{{ trans('common.price') }}</th>
                                                            <th>{{ trans('common.delivery') }} {{ trans('common.time') }}</th>
                                                            <th>{{ trans('common.countries') }}</th>
                                                            <th>{{ trans('common.active') }}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($shippingMethods as $shippingMethod)
                                                            <tr>
                                                                <td>{{ $shippingMethod->name }}</td>
                                                                <td>{{ $shippingMethod->is_free ? 'Free' : '$' . number_format($shippingMethod->price, 2) }}</td>
        
                                                                <td>{{ $shippingMethod->delivery_time }} days</td>
                                                                <td>{{is_array($shippingMethod->countries) ? implode(', ', $shippingMethod->countries) : $shippingMethod->countries }}</td>
                                                                <td>{{ $shippingMethod->availability }}</td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <input type="checkbox" id="Additional-info" class="accordion-toggle">
                            <h2 class="accordion-header">
                                <label for="Additional-info" class="accordion-title accordion-button">{{ trans('common.details') }}</label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col my-3">
                                            <label for="product_measure" class="form-label">
                                                {{ trans('common.product') }} {{ trans('common.measurement') }}*:
                                            </label>
                                            <select class="form-select my-3 py-0" id="product_measure" name="product_measure">
                                                <option value="">{{ trans('common.no') }}</option>
                                                <option value="Gram">{{ trans('common.gram') }}</option>
                                                <option value="Kilogram">{{ trans('common.kilogram') }}</option>
                                                <option value="Litre">{{ trans('common.litre') }}</option>
                                                <option value="Pound">{{ trans('common.pound') }}</option>
                                                <option value="Custom">{{ trans('common.custom') }}</option>
                                            </select>
                                            @error('product_measure')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <div class="col my-3">
                                            <label for="custom-product_measure" class="form-label">
                                                {{ trans('common.custom') }} {{ trans('common.product') }} {{ trans('common.measurement') }}:
                                            </label>
                                            <input type="text" class="form-control my-3" name="custom_product_measure">
                                            @error('custom_product_measure')
                                                <div class="alert alert-danger" role="alert">
                                                    {{ $message }}
                                                </div> 
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <input type="checkbox" id="Product-info" checked class="accordion-toggle">
                            <h2 class="accordion-header">
                                <label for="Product-info" class="accordion-title accordion-button">
                                    {{ trans('common.product') }} {{ trans('common.photo') }}
                                </label>
                            </h2>
                            <div class="accordion-content">
                                <div class="accordion-body">
                                    <div class="col">
                                        <label class="form-label">{{ trans('common.photo') }}</label>
                                        <br>
                                        <input type="file" class="form-control my-3 py-2" id="inputGroupFile02" name="picture">
                                        @error('picture')
                                            <div class="alert alert-danger" role="alert">
                                                {{ $message }}
                                            </div> 
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3 mt-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="isfeature">
                            <label class="form-check-label" for="flexSwitchCheckChecked">
                                {{ trans('common.feature') }} {{ trans('common.product') }}</label>
                        </div>
                    </div>
                    <input type="hidden" name="type" value="physical">
                    <button type="submit" class="btn btn-main mt-3">{{ trans('common.create') }} {{ trans('common.product') }}</button>
                </div>
            </div>
        </div>
    </form>
</div>
