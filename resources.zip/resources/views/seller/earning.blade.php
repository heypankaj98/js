@extends('layouts.seller.app')     @section('content')

<h2>Total Earning</h2>

<div class="row row-cards-one">
    <div class="col-md-6 col-xl-3">
        <div class="card c-info-box-area">
            <div class="c-info-box box1">
                <p>1</p>
            </div>
            <div class="c-info-box-content">
                <h6 class="title"> {{ trans('global.total_earning') }} </h6>
                <p class="text">{{ trans('global.last_30_days') }}</p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card c-info-box-area">
            <div class="c-info-box box2">
                <p>26</p>
            </div>
            <div class="c-info-box-content">
                <h6 class="title">{{ trans('global.total_earning') }}</h6>
                <p class="text"> {{ trans('global.all_time') }} </p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card c-info-box-area">
            <div class="c-info-box box3">
                <p>0</p>
            </div>
            <div class="c-info-box-content">
                <h6 class="title"> {{ trans('global.total_sales') }}</h6>
                <p class="text">{{ trans('global.last_30_days') }}</p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3">
        <div class="card c-info-box-area">
            <div class="c-info-box box4">
                <p>10</p>
            </div>
            <div class="c-info-box-content">
                <h6 class="title">{{ trans('global.total_sales') }}</h6>
                <p class="text">{{ trans('global.all_time') }}</p>
            </div>
        </div>
    </div>
</div>

@endsection 