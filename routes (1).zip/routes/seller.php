<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Seller\ProductController;
use App\Http\Controllers\Seller\ProfileController;
use App\Http\Controllers\Seller\SellerMarketplaceController;
use App\Http\Controllers\Seller\HomeController;
use App\Http\Controllers\Seller\PayoutController;
use App\Http\Controllers\Seller\OrderController;
use App\Http\Controllers\Seller\DisputeController;
use App\Http\Controllers\Seller\MessengerController;
use App\Http\Controllers\Seller\AuctionController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Seller\ReputationController;
use App\Http\Controllers\Seller\AdsController;

Route::group(['prefix' => 'seller', 'as' => 'seller.', 'namespace' => 'Seller', 'middleware' => ['auth', 'seller', 'two_factor_authentication', 'pgp_key', 'currency']], function () {

    Route::post('/products/{id}/clone', [ProductController::class, 'cloneProduct'])->name('products.clone');
    Route::get('/dashboard', [ProfileController::class, 'index'])->name('dashboard');
    Route::get('/get-verified', [SellerMarketplaceController::class, 'getVerified'])->name('verify');
    Route::post('/marketplace/store', [SellerMarketplaceController::class, 'store'])->name('store');
    Route::get('/seller/marketplaces', [SellerMarketplaceController::class, 'showMarketplaces'])->name('seller.marketplaces');
    Route::get('profile', [HomeController::class, 'profileEdit'])->name('profile.index');

    Route::get('/balances', [ProfileController::class, 'balances'])->name('balances');
    Route::get('/payouts', [PayoutController::class, 'index'])->name('payouts');
    Route::post('/payouts/request', [PayoutController::class, 'store'])->name('payout.request');
    Route::get('invoices', [ProfileController::class, 'invoices'])->name('invoices');
    Route::get('/earning', [ProfileController::class, 'totalEarning'])->name('earning');
    Route::view('product-type', 'seller.products.type')->name('product.type');
    Route::resource('products', ProductController::class);
    Route::delete('product/destroy', [ProductController::class, 'massDestroy'])->name('products.massDestroy');
    Route::post('product/media', [ProductController::class, 'storeMedia'])->name('products.storeMedia');
    Route::post('product/ckmedia', [ProductController::class, 'storeCKEditorImages'])->name('products.storeCKEditorImages');
    Route::get('sellers-products', [ProductController::class, 'products'])->name('products');
    Route::get('sale/orders', [OrderController::class, 'showall'])->name('orders');
    Route::get('sale/order/{id}', [OrderController::class, 'showsingle'])->name('order');
    Route::post('sale/{id}', [OrderController::class, 'changeStatus'])->name('sale');

    Route::get('disputes/', [DisputeController::class, 'index'])->name('dispute');
    Route::get('dispute/{dispute}', [DisputeController::class, 'disputeMessage'])->name('dispute.messages');
    Route::post('dispute/reply', [DisputeController::class, 'replyToDispute'])->name('dispute.reply');

    Route::get('messenger', [MessengerController::class, 'index'])->name('messenger.index');
    Route::get('messenger/create', [MessengerController::class, 'createTopic'])->name('messenger.createTopic');
    Route::post('messenger', [MessengerController::class, 'storeTopic'])->name('messenger.storeTopic');
    Route::get('messenger/{topic}', [MessengerController::class, 'showMessages'])->name('messenger.showMessages');
    Route::get('messenger/new/{user}', [MessengerController::class, 'newMessages'])->name('messenger.newMessages');
    Route::delete('messenger/{topic}', [MessengerController::class, 'destroyTopic'])->name('messenger.destroyTopic');
    Route::post('messenger/{topic}/reply', [MessengerController::class, 'replyToTopic'])->name('messenger.reply');
    Route::get('messenger/{topic}/reply', [MessengerController::class, 'showReply'])->name('messenger.showReply');

    Route::resource('auction', AuctionController::class);

    Route::get('auction/create', [AuctionController::class, 'create'])->name('auction.create');
    Route::post('auction/create', [AuctionController::class, 'postcreate'])->name('auction.post.create');

    // Shipping methods routes
    Route::get('/shipping-methods', [ProductController::class, 'indexShippingMethod'])->name('shipping-methods.index');
    Route::get('/shipping-methods/create', [ProductController::class, 'createShippingMethod'])->name('shipping-methods.create');
    Route::post('/shipping-methods', [ProductController::class, 'storeShippingMethod'])->name('shipping-methods.store');
    Route::get('/shipping-methods/{shippingMethod}/edit', [ProductController::class, 'editShippingMethod'])->name('shipping-methods.edit');
    Route::put('/shipping-methods/{shippingMethod}', [ProductController::class, 'updateShippingMethod'])->name('shipping-methods.update');
    Route::delete('/shipping-methods/{shipping_method}', [ProductController::class, 'destroyShippingMethod'])->name('shipping-methods.destroy');

    Route::get('/products/{product}/questions', [ProductController::class, 'questions'])->name('questions');
    Route::post('/questions/{question}/answer', [ProductController::class, 'answerQuestion'])->name('questions.answer');
    Route::delete('/questions/{question}', [ProductController::class, 'deleteQuestion'])->name('questions.delete');

    Route::get('/settings', [ProfileController::class, 'sellerSettings'])->name('settings');
    Route::put('/vacation-mode', [ProfileController::class, 'toggleVacationMode'])->name('vacation-mode');

    Route::get('/delegate-access', [ProfileController::class, 'delegateAccess'])->name('delegate-access');
    Route::post('/delegate-access/add', [ProfileController::class, 'postDelegateAccess'])->name('delegate-access.post');
    Route::post('/sellers/{id}/reputation', [AdminController::class, 'updateReputation'])->name('seller.admin.updateReputation');
Route::get('/ads', [AdsController::class, 'index'])->name('ads.index'); // Seller's main ads page
Route::post('/ads/store', [AdsController::class, 'store'])->name('ads.store'); // Store new ad
Route::get('/ads/activate/{id}', [AdsController::class, 'activate'])->name('ads.activate');
Route::get('/ads/edit', [AdsController::class, 'edit'])->name('ads.edit');
Route::put('seller/ads/{ad_id}/toggle', [AdsController::class, 'toggle'])->name('ads.toggle');
Route::put('/ads/{ad}', [AdsController::class, 'update'])->name('ads.update');
Route::post('/ads/{ad}/storePersonalBanner', [AdsController::class, 'storePersonalBanner'])->name('ads.storePersonalBanner');
Route::post('/ads/create-advertisement', [AdsController::class, 'createAdvertisement'])->name('ads.createAdvertisement'); // Only one definition






});
