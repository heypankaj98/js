@extends('layouts.buyer.app')

@section('content')


<div class="bg-card-1">
    <div class="bg-card-2">
        <div class="bg-card-1">
            Ticket Details
        </div>
        <form action="{{ route('user.tickets.reply', $tickets->id) }}" method="POST">
            @csrf
            <div class="card-body">
                <p class="card-text">Title: <span class="color-accent-2 ">{{ $tickets->title }}</span> </p>
                <p class="card-text">Priority: <span class="color-accent-2 ">{{ $tickets->priority }}</span></p>
                <p class="card-text">Status: <span class="color-accent-2 ">{{ $tickets->status }}</span></p>
                <p class="card-text">Created At: <span class="color-accent-2 ">{{ $tickets->created_at }}</span></p>
                <p class="card-text">Solve/Unsolve: @if ($tickets->is_resolved == 1)
                    <span class="color-accent-2 "> SolveTicket </span>
                    @else
                    <span class="color-accent-2 "> UnsolveTicket </span>
                    @endif
                </p>
                <p class="card-text">Lock/Unlock: @if ($tickets->is_locked == 1)
                    <span class="color-accent-2 "> Lock </span>
                    @else
                    <span class="color-accent-2 "> Unlock </span>
                    @endif
                </p>

                @if ($tickets->media->isNotEmpty())
                <h5 class="mt-3">Media Files</h5>
                <ul>
                    @foreach ($tickets->media as $media)
                    <li>{{ $media->filename }}</li>
                    <!-- Adjust with actual media details you want to display -->
                    @endforeach
                </ul>
                @endif

                <!-- Messages related to the ticket, if any -->
                @if ($tickets->messages->isNotEmpty())
                <h5 class="mt-3">Messages</h5>
                <div class="bg-card-1 msg-tic">
                    @foreach ($tickets->messages->reverse() as $message)
                    @if ($message->user_id == auth()->user()->id)
                    <div class="msg-right1">
                       {{ $message->message }}
                    </div>
                    @else
                    <div class="msg-left1">
                        {{ $message->message }}
                    </div>
                    @endif
                    @endforeach
                </div>
                @endif
                @if ($tickets->is_locked==1)
                @else
                <div class="form-group">
                    <label for="replyMessage">Your Reply:</label>
                    <textarea class="form-control-textarea" id="replyMessage" rows="3" name="reply"
                        placeholder="Type your reply here..." required></textarea>
                </div>
                <button type="submit" class="btn btn-main">Send Reply</button>
                @endif
        </form>
    </div>
</div>
</div>
</div>
@endsection