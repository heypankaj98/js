@extends('layouts.admin.master')    @section('content')

<div class="mt-4">
    <div class="b">
        @can('admin_user_create')
        <div class="row">
            <div class="col-lg-12">
                <a class="btn btn-main w-max-c" href="{{ route('admin.users.create') }}">
                    {{ trans('global.add') }} {{ trans('cruds.user.title_singular') }}
                </a>
            </div>
        </div>
        @endcan
        <div class="card-header-2 w-100 my-4">
                {{ trans('cruds.user.title_singular') }} {{ trans('global.list') }}
            </div>
        <div class="bg-card-2 br1">
           
            <div class="card-body">
                <div class="table-responsive">
                    <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-User">
                        <thead>
                            <tr>
                                <th>User Id</th>
                                <th>Username</th>
                                <th>Roles</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $key => $user)
                            <tr data-entry-id="{{ $user->id }}">
                                <td>
                                    {{ $user->id ?? '' }}
                                </td>
                                <td>
                                    {{ $user->username ?? '' }}
                                </td>
                                <td>
                                    @foreach($user->roles as $key => $item)
                                    <span class="btn btn-dark btn-sm disabled br-4">{{ $item->title }}</span>
                                    @endforeach
                                </td>
                                <td class="text-center">
                                    @can('admin_user_show')
                                    <a class="btn btn-primary btn-sm br-4" href="{{ route('admin.users.show', $user->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                    @endcan

                                  <a class="btn btn-info btn-sm br-4" href="{{ route('admin.users.edit', $user->id) }}">
    {{ trans('global.edit') }}
</a>


                                    @if(!$user->trashed())
                                    @can('admin_user_delete')
                                    <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" class="d-inline-block">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn  btn-danger btn-sm br-4" value="{{ trans('global.delete') }}">
                                    </form>
                                    @endcan

                                    @else
                                    <form action="{{ route('admin.user.recover', ['id' => $user->id]) }}"  method="POST" class="d-inline-block">
                                        @csrf
                                        <button type="submit" class="btn  btn-primary btn-sm br-4">Recover</button>
                                    </form>
                                    @endif

                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection