@extends('layouts.buyer.app')     @section('content')


    <div class="row justify-content-center">
        <div class="col-md-12">
        <h2 class="custom-title my-4">Orders</h2>
            <div class="bg-card-1 br1">
                <div class="card-buyer">
                <div class="card-header-buyer">
                    {{ trans('common.orders') }} {{ trans('common.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered  table-prd table-striped table-hover datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('common.no') }}.
                                    </th>
                                    <th>
                                        {{ trans('common.order') }}-{{ trans('common.id') }}
                                    </th>
                                    <th>
                                        {{ trans('common.type') }}
                                    </th>
                                    <th>
                                        {{ trans('common.payment') }} {{ trans('common.method') }}
                                    </th>
                                    <th>
                                        {{ trans('common.total') }}
                                    </th>
                                    <th>
                                        {{ trans('common.order') }}-{{ trans('common.date') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                @foreach($orders as $key => $mainorder)
                                <tr>
                                    <td>
                                        {{ isset($a) ? ++$a : $a=1 }}.
                                    </td>
                                    <td>
                                       {{$mainorder->id}}
                                    </td>
                                    <td>
                                        @if($mainorder->first()->isauction)
                                            {{ trans('common.auction') }}
                                        @else
                                            {{ trans('common.product') }}
                                        @endif
                                    </td>
                                    <td> 
                                        {{ trans('common.' . $mainorder->payment_method) }}
                                    </td>
                                   <td>
                                        $ {{ $mainorder->total }}
                                    </td>

                                    <td>
                                        {{ $mainorder->created_at->format('M,j Y g:i A') }}
                                    </td>
                                    <td>
                                     
                                            <a class="btn btn-main btn-sm w-max-c m-auto" href="{{ route('user.order', $mainorder->order_id) }}">
                                                {{ trans('common.view') }}
                                            </a>
                                            
                                        </td>
                                </tr>
                                @endforeach
                                
                            </tbody>
                        </table>
                    </div>
                    <div>
                        {{ $orders->onEachSide(1)->links('pagination::bootstrap-5') }}
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

@endsection