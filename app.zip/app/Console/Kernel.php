<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Models\Order;
use App\Models\Product;

class Kernel extends ConsoleKernel {

  
    protected function schedule(Schedule $schedule): void {
        $schedule->command('orders:check-pending')->everyMinute();
        $schedule->command('payments:check-pending')->everyMinute();
        $schedule->command('app:update-exchange-rates')->cron('0 1,13 * * *');
        $schedule->command('payouts:generate')->everyMinute(); 
        $schedule->command('payouts:auto-release')->everyMinute();
        $schedule->command('app:auto-create-transactions')->everyMinute();
        $schedule->command('orders:delete-old-completed')->daily();
        
       
    }


    protected function commands(): void {
        $this->load(__DIR__ . '/Commands');
        require base_path('routes/console.php');
    }
}
