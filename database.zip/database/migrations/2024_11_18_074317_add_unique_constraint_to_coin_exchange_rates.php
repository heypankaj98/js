<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUniqueConstraintToCoinExchangeRates extends Migration
{
    public function up()
    {
        Schema::table('coin_exchange_rates', function (Blueprint $table) {
            $table->unique(['coin_symbol', 'currency_symbol']);
        });
    }

    public function down()
    {
        Schema::table('coin_exchange_rates', function (Blueprint $table) {
            $table->dropUnique(['coin_symbol', 'currency_symbol']);
        });
    }
}
