@extends('layouts.admin.master')        @section('content')

<div class="card mt-4">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.auction.title') }}
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('admin.auctions.update',$auction->id) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            
            <div class="row flex-column flex-sm-row my-2">
                
                <div class="col-sm-4">
                    <label  class="form-label">{{ trans('cruds.auction.name') }} <span class="text-danger">(*)</span></label>
                    <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $auction->name) }}" required>
                    @if($errors->has('name'))
                        <div class="invalid-feedback">
                            {{ $errors->first('name') }}
                        </div>
                    @endif
                    <span class="help-block">{{ trans('cruds.product.fields.name_helper') }}</span>
                </div>
                
                <div class="col-sm-4">
                    <label  class="form-label">{{ trans('cruds.auction.type') }} <span class="text-danger">(*)</span></label>
                    <select class="form-control select2 {{ $errors->has('type') ? 'is-invalid' : '' }}" name="type">
                        <option value="physical" {{ ($auction->type == "physical") ? 'selected' : '' }}>Physical</option>
                        <option value="digital" {{ ($auction->type == "digital") ? 'selected' : '' }}>Digital</option>
                    </select>
                    @if($errors->has('type'))
                        <div class="invalid-feedback">
                            {{ $errors->first('type') }}
                        </div>
                    @endif
                </div>
                
                <div class="col-sm-4">
                    <label class="form-label">{{ trans('cruds.auction.category') }} <span class="text-danger">(*)</span></label>
                    <select class="form-control select2 {{ $errors->has('categories') ? 'is-invalid' : '' }}" name="categories">

                        @foreach($categories as $id => $category)
                            <option value="{{ $id }}" {{ ($auction->category == $id) ? 'selected' : '' }}>{{ $category }}</option>
                        @endforeach
                    </select>
                    @if($errors->has('categories'))
                        <div class="invalid-feedback">
                            {{ $errors->first('categories') }}
                        </div>
                    @endif
                    <span class="help-block">{{ trans('cruds.product.fields.category_helper') }}</span>
                </div>    
            </div>
            
            <div class="row my-2 flex-column flex-sm-row">
                <div class="col-sm-3">
                    <div class="mb-3">
                        <label class="form-label">{{ trans('Reserve Price (USD)') }} <span class="text-danger">(*)</span></label>
                        <input type="text" class="form-control" name="reserve_price" value="{{ old('reserve_price', $auction->reserve_price) }}">
                        @error('reserve_price')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div> 
                        @enderror
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="mb-3">
                        <label class="form-label">{{ trans('Auction Quantity') }} <span class="text-danger">(*)</span></label>
                        <input type="text" class="form-control" name="stock" value="{{ old('stock', $auction->stock) }}">
                        @error('stock')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div> 
                        @enderror
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <label class="form-label">{{ trans('Auction Product Measure Unit') }} <span class="text-danger">(*)</span></label>
                    <select class="form-control" id="product_measure" name="product_measure">
                        <option value="">None</option>
                        <option value="Gram" selected>Gram</option>
                        <option value="Kilogram">Kilogram</option>
                        <option value="Litre">Litre</option>
                        <option value="Pound">Pound</option>
                        <option value="Custom">Custom</option>
                    </select>
                    @error('product_measure')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div> 
                    @enderror
                </div>
                <div class="col-sm-3 mb-3">
                    <label class="form-label">{{ trans('Product Measurement') }}</label>
                    <input type="text" class="form-control" id="custom-product_measure" placeholder="Custom measure unit" name="custom_product_measure" value="">
                    @error('custom_product_measure')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div> 
                    @enderror
                </div>
            </div>
            
            <div class="row my-2 flex-column flex-sm-row">
                <div class="col-sm-3">
                    <label class="form-label">{{ trans('Upload Picture') }} <span class="text-danger">(*)</span></label><br>
                    <input type="file" class="form-control" id="inputGroupFile02" name="picture">
                    @error('picture')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div> 
                    @enderror
                </div>
                <div class="col-sm-3">
                    <label class="form-label">{{ trans('Upload Picture') }} <span class="text-danger">(*)</span></label><br>
                    <input type="file" class="form-control" id="inputGroupFile02" name="picture">
                    @error('picture')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div> 
                    @enderror
                </div>
                <div class="mb-3 col-sm-6">
                    <label class="form-label">{{ trans('Auction Digital Product URL') }}</label>
                    <textarea class="form-control" rows="2" name="content">{{ old('content', $auction->content) }}</textarea>
                    @error('content')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
            
            <div class="row my-2 flex-column flex-sm-row">
                <div class="col-sm-3">
                    <div class="mb-3">
                        <label class="form-label">{{ trans('Auction Start Date') }} <span class="text-danger">(*)</span></label>
                        <input type="datetime-local" class="form-control" name="start_time" value="{{ old('start_time', $auction->start_time) }}">
                        @error('start_time')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="mb-3">
                        <label class="form-label">{{ trans('Auction End Date') }} <span class="text-danger">(*)</span></label>
                        <input type="datetime-local" class="form-control" name="end_time" value="{{ old('end_time', $auction->end_time) }}">
                        @error('end_time')
                            <div class="alert alert-danger" role="alert">
                                {{ $message }}
                            </div> 
                        @enderror
                    </div>
                </div>
            </div>
            
            <div class="row my-2 flex-column flex-sm-row">
                <div class="mb-3 col-sm-6">
                    <label class="form-label">{{ trans('cruds.product.fields.description') }} <span class="text-danger">(*)</span></label>
                    <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" rows="3" name="description">{{ old('description', $auction->description) }}</textarea>
                    @if($errors->has('description'))
                        <div class="invalid-feedback">
                            {{ $errors->first('description') }}
                        </div>
                    @endif
                    <span class="help-block">{{ trans('cruds.product.fields.description_helper') }}</span>
                </div>
                <div class="mb-3 col-sm-6">
                    <label class="form-label">{{ trans('Auction Buy/Return Policy*') }} <span class="text-danger">(*)</span></label>
                    <textarea class="form-control" rows="3" name="policy">{{ old('policy', $auction->policy) }}</textarea>
                    @error('policy')
                        <div class="alert alert-danger" role="alert">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>

            <div class="col-sm-3 my-2">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="isfeature" value="1" @if($auction->isfeature) checked @endif>
                    <label class="form-check-label" for="flexSwitchCheckChecked">Feature This Auction<br><small>* $10 will be charged from price</small></label>
                </div>
            </div>
            
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>
@endsection