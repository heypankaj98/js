@extends('layouts.admin.master')    @section('content')

<div class="mt-4">
    <div class="">
    <div class="card-header-2 w-100 mb-4">
                {{ trans('common.all') }} {{ trans('common.user') }} {{ trans('common.tickets') }}
            </div>
        <div class="bg-card-2 br1">
            <div class="card-body">
                <a class="btn" href="{{ route('user.tickets.create') }}">
                    {{ trans('common.create') }} {{ trans('common.new') }} {{ trans('common.ticket') }}
                </a>
                <!--div class="mb-4 d-flex justify-content-between">
                    <div class="row g-3">
                        <div class="col">
                            <select class="form-select" aria-label="Default select example">
                                <option value="status">-- {{ trans('common.select') }} {{ trans('common.status') }} --</option>
                                <option value="1">{{ trans('common.pending') }}</option>
                                <option value="2">{{ trans('common.completed') }}</option>
                            </select>
                        </div>
                        <div class="col">
                            <select class="form-select" aria-label="Default select example">
                                <option value="status">-- {{ trans('common.select') }} {{ trans('common.priority') }} --</option>
                                <option value="1">{{ trans('common.low') }}</option>
                                <option value="2">{{ trans('common.high') }}</option>
                            </select>
                        </div>
                        <!--div class="col">
                            <select class="form-select" aria-label="Default select example">
                                <option value="status">-- SELECT CATEGORY --</option>
                                <option value="1">Bugs</option>
                                <option value="2">Feature</option>
                                <option value="2">Help</option>
                            </select>
                        </div>
                    </div>
                </div-->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Product">
                            <thead>
                                <tr class="bg-light">
                                    <th>{{ trans('common.title') }}</th>
                                    <th>{{ trans('common.author') }}</th>
                                    <th>{{ trans('common.status') }}</th>
                                    <th>Solve/Unsolve</th>
                                    <th>Lock/Unlock</th>
                                    <th>{{ trans('common.priority') }}</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($tickets as $ticket)
                                    <tr>
                                        <td>
                                            <a href="{{ route('admin.tickets.show', $ticket) }}" class="text-decoration-none">
                                                {{ $ticket->title }}
                                            </a>
                                        </td>
                                        <td>
                                            {{ $ticket->user->username }}
                                        </td>
                                        <td>
                                            {{ $ticket->status }}
                                        </td>
                                            <td>
                                        @if ($ticket->is_resolved == 1)
    SolveTicket
@else
    UnsolveTicket
@endif </td>                                                                            
<td>
@if ($ticket->is_locked == 1)
   Lock
@else
  Unlock
@endif
</td>
                                        <td>
                                            {{ $ticket->priority }}
                                        </td>
                                        <td>
                                            <div class="d-inline-block red">
                                                <a class="btn btn-primary btn-sm br-4" href="{{ route('user.tickets.edit', $ticket) }}">
                                                    {{ trans('common.edit') }}
                                                </a>
                                            </div>
                                                                                        <div class="d-inline-block">
                                                <a class="btn btn-info btn-sm br-4" href="{{ route('admin.tickets.show', $ticket) }}">
                                                  Show
                                                </a>
                                            </div>
                                            <div class="d-inline-block">
                                                <form action="{{ route('user.tickets.destroy', $ticket) }}" method="POST" onsubmit="return confirm('Are you sure?')" style="display: inline-block;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm br-4">{{ trans('common.delete') }}</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="100%">{{ trans('common.no') }} {{ trans('common.tickets') }}.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>






@endsection