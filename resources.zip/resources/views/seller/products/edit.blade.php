@extends('layouts.seller.app')  

@section('content')

    @if($page == 'physical')
        @include('seller.include.physical_edit')
    @elseif($page == 'digital')
        @include('seller.include.digital_edit')
    @else
        @include('seller.include.auction_edit')
    @endif
    
 @endsection