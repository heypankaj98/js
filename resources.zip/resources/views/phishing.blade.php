<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Phishing</title>
    <style>
        body {
            background-color: #000;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            /* Center align text content */
            overflow-x: hidden;
            margin: 0;
        }
    .headi2{margin:0px;}
        .in-linnk {
            margin-top: -125px;
        }

        .enter-alley {
            width: 330px;
            position: relative;
        }

        .phis {
            width: 370px;
            border: 1px solid #ff0000;
            display: block;
            margin: 20px auto;
            /* Center align image */
            position: relative;
        }
        .logo_market img {
    max-width: 120px;
}
.btn-row {
    margin: 5% 0;
}
a.btnn-new {
    text-decoration: none;
    display: inline-block;
    border: 1px solid orange;
    padding: 6px 13px;
    border-radius: 50px;
    line-height: 1;
}
        .phis::before,
        .phis::after {
            content: "";
            position: absolute;
            top: 50%;
            width: 30%;
            /* Adjust length of lines */
            height: 1px;
            background-color: #ff0000;
            /* Color of lines */
        }

        .phis::before {
            left: 0;
            transform: translateX(-100%);
            /* Position left line */
        }

        .phis::after {
            right: 0;
            transform: translateX(100%);
            /* Position right line */
        }

        .mg-9 {
            font-size: 18px;
            border-left: 1px solid #ff0000;
            padding: 10px;
            border-right: 1px solid #ff0000;
            display: inline-block;
            color: #ff7d00;
        }

        .head57 {
            color: #ff7d00;
            margin-top: 320px;
            font-size:14px;

        }

        .up {
            margin-top: -20px;
        }

      

        .always {
            color: white;
        }

        .refer {
            color: #ff0000;
        }

        .always-desc {
            color: white;
            margin-top: -20px;
            /* Adjust space above paragraph */
            font-size:14px;
        }
        

        hr#behind-back1 {
            margin-top: -40px;
        }

        hr#behind-back {
            margin-top: -230px;
        }
    </style>
</head>

<body>
    <div class="containe">
        <h2 class="headi2">
            <div class="mg-9">Don't Get Phished!</div>
        </h2>
        <div class="up">
            <img class="phis" src="{{ asset('assets/Phishing.jpg')}}">
            <div class="in-linnk">
                <a href="/login"><img class="enter-alley" src="{{ asset('assets/enter1.gif')}}"></a></div>
        </div>
        <hr id="behind-back" width="100%" size="1" color="#ff0000">
        <hr id="behind-back1" width="100%" size="1" color="#ff0000">
        <h5 class="head57">
            <span class="always">ALWAYS</span>
            <span class="refer">REFER </span>
            the Dark Alley-Mirrors, PGP-Signed-Message.txt
        </h5>
        <p class="always-desc">(Mirrors) Signed message by using PGP</p>
        
        <div class="btn-row">
    <a href="https://darkalley.market" class="btnn-new" target="_blank">
        <span class="logo-text" style="color: orange; font-weight: bold; font-size:14px">Access</span>
        <span class="highlight" style="color: red; font-weight: bold; font-size:14px">All Dark Alley</span>
        <div>
            <span class="highlight" style="color: white; font-size:12px">Mirrors. PGP Keys. Features.</span>
        </div>
    </a>
</div>
    </div>
    <div class="footer_inner">
        <!-- Logo Section -->
       
        <!-- Access Section -->
      

         <div class="logo_market">
                    <a class="navbar-brand m-0" href="/">
                        <img class="imge" src="{{ asset('assets/toropt.png') }}" alt="Logo" />
        </div>
      
    </div>
</body>

</html>
