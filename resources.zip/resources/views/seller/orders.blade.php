@extends('layouts.seller.app')     @section('content')


    <div class="bg-card-1 p-24 br1 mt-4">
        <div class="col-md-12">
            <div class="">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.sales') }} {{ trans('common.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('common.no') }}.
                                    </th>
                                    <th>
                                        {{ trans('common.sale') }}-{{ trans('common.id') }}
                                    </th>
                                    <th>
                                        {{ trans('common.buyer') }}
                                    </th>
                                    <th>
                                        {{ trans('common.payment') }} {{ trans('common.method') }}
                                    </th>
                                    <th>
                                        {{ trans('common.total') }} {{ trans('common.price') }}
                                    </th>
                                    <th>
                                        {{ trans('common.order') }} {{ trans('common.date') }}
                                    </th>
                                    <th>
                                        {{ trans('common.action') }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                 @php 
                                // Calculate starting point for pagination
                                $a = ($orders->currentPage() - 1) * $orders->perPage() + 1; 
                            @endphp
                                @forelse($orders as $key => $mainorder)
                                    <tr>
                                        <td>{{ $a++ }}.</td>
                                        <td>{{ $mainorder->order_id }}</td>
                                       <td>
    {{ optional($mainorder->buyer)->username ?? 'N/A' }}
</td>

                                        <td> 
                                            {{ $mainorder->payment_method }}
                                        </td>
                                        <td>
                                            $ {{ $mainorder->total }}
                                        </td>
                                        <td>
                                            {{ $mainorder->created_at->format('j-M-Y g:i A') }}
                                        </td>
                                        <td>
                                           
                                            <a class="btn btn-main btn-sm w-max-c m-auto" href="{{ route('seller.order', $mainorder->order_id) }}">
                                                {{ trans('common.view') }}
                                            </a>
                                           
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="100%">{{ trans('common.no') }} {{ trans('common.sales') }}.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                     <div class="d-flex justify-content-end mt-2">
                    {{ $orders->links('pagination::bootstrap-5') }} <!-- Use Bootstrap 5 pagination -->
                </div>
                </div>
            </div>
        </div>
    </div>

@endsection