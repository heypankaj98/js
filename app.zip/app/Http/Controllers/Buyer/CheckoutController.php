<?php

namespace App\Http\Controllers\Buyer;

use Auth;
use Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{
    Order,
    Product,
    User,
    ShippingMethod,
    ExceptionModel
};
use Illuminate\Http\Request;
use DB;
use App\Http\Requests\{
    AddToCartRequest,
    CheckoutPostRequest
};
use Illuminate\Support\Str;
use Session;
use App\Tools\PGP;
use Illuminate\Support\Facades\Crypt;
use App\Notifications\OrderCreateNotification;

class CheckoutController {

    public function checkout() {
        $cartProducts = session()->has('cart') ? session()->get('cart') : [];
        $cartProducts = array_values(array_filter($cartProducts));
        //           $order->applyGiftCardDiscount($giftCard);

        if ($cartProducts) {
            $idproducts = array_column($cartProducts, 'product_id');
            $shipping_id = array_column($cartProducts, 'selected_shipping');
            #Count total products
            $shippings = ShippingMethod::whereIn('id', $shipping_id)->get();
            $products = Product::whereIn('id', $idproducts)->get();
            $totalProducts = count($cartProducts);

            #Set total price
            $totalPrice = 0;
            $totalshippingPrice = 0;

            foreach ($shippings as $single) {
                $totalshippingPrice += $single->price;
            }
            #Sum the total of all products
            foreach ($cartProducts as $product) {
                $totalPrice += $product['total'];
            }

            $totalPrice += $totalshippingPrice;

            return view('buyer.checkout', [
                'products' => $products,
                'cartProduct' => $cartProducts,
                'totalProducts' => $totalProducts,
                'totalshippingPrice' => $totalshippingPrice,
                'totalPrice' => $totalPrice
            ]);
        } else {
            return redirect()->route('user.home');
        }
    }

    public function checkoutpost(CheckoutPostRequest $request) {
        $cartProducts = session()->has('cart') ? session()->get('cart') : [];
        $cartProducts = array_values(array_filter($cartProducts));

        if ($cartProducts) {
            $idproducts = array_column($cartProducts, 'product_id');
            $products = Product::whereIn('id', $idproducts)->get();
            $shipping_id = array_column($cartProducts, 'selected_shipping');
            $shippings = ShippingMethod::whereIn('id', $shipping_id)->get();
            $totalshippingPrice = 0;
            foreach ($shippings as $single) {
                $totalshippingPrice += $single->price;
            }

            $trx = Str::random(10);
            $a = 0;
            $totalProducts = count($cartProducts);
            try {
                DB::beginTransaction();
                // foreach item in cart
                $sellers = [];
                $sellerId = null; // Initialize a variable to store the initial seller ID

                foreach ($products as $product => $item) {
                    $order = new Order;
                    $order->order_id = Auth::id() . $trx;
                    $order->product_id = $item->id;
                    $order->buyer_id = Auth::id();
                    $order->seller_id = $item->seller_id;
                    $order->payment_method = $request->payment_method;
                    $seller_pgp_key = $item->seller->pgp_key;
                    $encryptedAddress = PGP::encryptMessage($seller_pgp_key, $request->address);
                    $order->address = $encryptedAddress;
                    
                    $order->quantity = $cartProducts[$a]['quantity'];
                    $order->total = $cartProducts[$a]['total'];
                    $order->save();
                    $a++;
                    $sellers[] = $item->seller_id;

                    if ($request->payment_method === 'BitcoinMultiSign' && $sellerId !== null && $item->seller_id !== $sellerId) {
                        DB::rollBack();
                        return redirect()->back()->with('error', 'Different sellers detected. Please place separate orders from the same seller for BitcoinMultiSign payment.');
                    }

                    $sellerId = $item->seller_id; // Update the seller ID for the next iteration
                }
                DB::commit();
                $this->clearCart();

                User::whereIn('id', $sellers)->each(fn($user) => $user->notify(new OrderCreateNotification($order)));

                return redirect()->route('user.orders')->with('success', 'Order is created successfully.');
            } catch (RequestException $requestException) {
                DB::rollBack();

                $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
                $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.' . $errorCode; // Set the error message
                $exceptionLog = new ExceptionModel();
                $exceptionLog->error_code = $errorCode;
                $exceptionLog->error_message = $requestException->getMessage();
                $exceptionLog->save();
                return redirect()->back()->with('error', $errorMessage);
            } catch (\Exception $e) {
                DB::rollBack();
                \Illuminate\Support\Facades\Log::error($e->getMessage());

                $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
                $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.' . $errorCode; // Set the error message
                $exceptionLog = new ExceptionModel();
                $exceptionLog->error_code = $errorCode;
                $exceptionLog->error_message = $e->getMessage();
                $exceptionLog->save();
                return redirect()->back()->with('error', $errorMessage);
            }
        } else {
            return redirect()->route('user.home');
        }
    }

    public function cart() {
        $cartProducts = session()->has('cart') ? session()->get('cart') : [];
        $cartProducts = array_values(array_filter($cartProducts));
        $products = null;
        $totalProducts = null;
        $totalPrice = null;
        if ($cartProducts) {
            $idproducts = array_column($cartProducts, 'product_id');
            $products = Product::whereIn('id', $idproducts)->get();
            $totalProducts = count($cartProducts);
            $totalPrice = 0;

            foreach ($cartProducts as $product) {
                $totalPrice += $product['total'];
            }
        }

        return view('buyer.cart', [
            'products' => $products,
            'cartProduct' => $cartProducts,
            'totalProducts' => $totalProducts,
            'totalPrice' => $totalPrice
        ]);
    }

    public function cartPost(Request $request) {
        $cartProducts = session()->has('cart') ? session()->get('cart') : [];
        if (is_array($cartProducts)) {
            foreach ($cartProducts as &$product) {
                $productId = $product['product_id'];
                $shippingKey = "shipping_method-{$productId}";
                if ($request->has($shippingKey)) {
                    $selected_shipment_method = $request->get($shippingKey);
                    $product['selected_shipping'] = $selected_shipment_method;
                }
            }
            session()->put('cart', $cartProducts);
        }
        return redirect()->route('user.checkout');
    }

    public function addCart(AddToCartRequest $request, Product $product) {
        if (auth()->user()->isSeller == 1) {
            return back()->with('error', 'Sellers cannot buy products.');
        }
        try {
            return $request->add($product, $request);
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.' . $errorCode; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return redirect()->back()->with('error', $exception->getMessage());
        }
        return view('buyer.cart');
    }

    public function removeCart(Request $request, Product $product) {
        try {
            if (session()->has('cart')) {
                $cartProducts = session('cart');

                foreach ($cartProducts as $index => $products) {
                    if ($products['product_id'] == $product->id) {
                        session()->forget('cart.' . $index);
                        break;
                    }
                }
            }
            return redirect()->back();
        } catch (\Exception $exception) {

            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.' . $errorCode; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return redirect()->back()->with('error', $errorMessage);
        }
        return view('buyer.cart');
    }

    public function clearCart() {
        session()->forget('cart');
        return redirect()->back();
    }

}
