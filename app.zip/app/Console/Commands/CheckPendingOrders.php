<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order;
use App\Models\OrderPayment;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use Carbon\Carbon;

class CheckPendingOrders extends Command
{
    protected $signature = 'orders:check-pending';
    protected $description = 'Check all pending orders and update their status to escrow if the balance is sufficient';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        // Fetch all pending orders
        $orders = Order::where('status', 'waiting')->with(['buyer' => function ($query) {
            $query->withTrashed(); // Include soft-deleted buyers
        }, 'seller' => function ($query) {
            $query->withTrashed(); // Include soft-deleted sellers
        }])->get();
        
       

        foreach ($orders as $order) {
              \Log::error("Error processing order ID: {$order->id}");
       
            // Check if buyer or seller is soft deleted
            if ($order->buyer && $order->buyer->trashed()) {
              
                $this->error("Buyer for order {$order->order_id} is deleted.");
                continue;
            }

            if ($order->seller && $order->seller->trashed()) {
                $this->error("Seller for order {$order->order_id} is deleted.");
                continue;
            }

            $paymentAddress = $order->orderPayment()->first()->payment_address ?? null;
            $amountDue = $order->orderPayment()->first()->amount ?? 0;

            if ($paymentAddress) {
                // Check the balance
                $paymentMethod = $order->payment_method;
                $received = 0;

                if ($paymentMethod === 'Bitcoin') {
                    $received = PayWay::getBalance($paymentMethod, ['address' => $paymentAddress, 'tag' => $order->buyer->username ?? '']);
                } elseif ($paymentMethod === 'Monero') {
                    $received = PayWay::getAddressBalance($paymentMethod, ['address' => $paymentAddress, 'tag' => $order->buyer->username ]);
                }

                if (isset($received['error_code'])) {
                    $this->error("Error checking balance for order {$order->order_id}: {$received['error_message']}");
                    continue;
                }

                // Check if the received amount is greater than or equal to the amount due
                if ($received >= $amountDue) {
                    // Update the order status to 'escrow'
                    $order->update(['status' => 'escrow']);
                    $order->orderPayment()->update([
                        'status' => 'PAID',
                        'total_received' => $received,
                        'paid_at' => Carbon::now()
                    ]);

                    $this->info("Order {$order->order_id} status updated to escrow.");
                }
            } else {
                $this->error("No payment address found for order {$order->order_id}");
            }
        }
    }
}
