<?php

return [
    'name' => 'Jabber'
];
