@extends('layouts.buyer.app')       @section('content')

<div class="bg-card-1 br1 mt-4">
    <div class="">
        <div class="bg-card-2 mb-3">
            <div class="card-header-2 w-100 mb-4">
               {{ trans('common.multisig') }} {{ trans('common.settings') }}
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('user.profile.settings.generateaddresspubkey') }}">
                    @csrf
                    <div class="form-group">
                        <label for="btc_address" class="mb-2">{{ trans('common.Bitcoin') }} {{ trans('common.address') }}</label>
                        <input type="text" class="form-control" id="btc_address" name="btc_address" value="{{ old('btc_address') }}" required>
                        @error('btc_address')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-main mt-3">{{ trans('common.generate') }} {{ trans('common.address') }}</button>
                </form>
                <hr>
                <form method="POST" action="{{ route('user.profile.settings.update.multisig_key_pub') }}" accept-charset="UTF-8">
                    @csrf
                    <div class="form-group">
                        <label for="buyer_multisig_key_pub" class="mb-2">
                            {{ trans('common.Bitcoin') }} {{ trans('common.multisig') }} {{ trans('common.public') }} {{ trans('common.key') }}
                        </label>
                        <textarea class="form-control-textarea" id="multisig_key_pub" name="multisig_key_pub">{{ auth()->user()->meta_multisig_key_pub }}</textarea>
                    </div>
                    <button type="submit" class="btn btn-main mt-3">{{ trans('common.save')}}</button>
                </form>
            </div>
        </div>
        
        <div class="bg-card-2">
            <div class="card-body">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.delete') }} {{ trans('common.account') }}
                </div>
                <form action="{{ route('user.profiles.destroy', auth()->user()->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <label class="mb-2">{{ trans('common.user') }} {{ trans('auth.password') }} *</label>
                    <input type="text" class="form-control" name="password" placeholder="********" required>
                    <button type="submit" class="btn btn-main mt-3">{{ trans('common.delete') }} {{ trans('common.account') }}</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection 