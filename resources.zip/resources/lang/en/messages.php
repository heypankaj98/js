<?php
return [
    'welcome' => 'Welcome to Dark Allay!',
    'captcha' => 'The captcha is incorrect',
    'incorrect_credentials' => 'Incorrect username or password!',
    'text_placeholder' => 'Type your text here',
    'decrypt_message' => 'A message will be encrypted with the PGP key entered. You will have to decrypt it and paste the verification code to confirm the PGP key change.',
    'withdrawal_msg' => '* Your request will be approve by Admin or Auto Approve in 2 days.',
];