<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\VerifyLoginRequest;
use Illuminate\Support\Facades\Auth;
//use Illuminate\Http\Request;
use Session;
use App\Tools\Captcha;

// use Illuminate\Foundation\Auth\AuthenticatesUsers;

class VerifyController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

    // use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    public function redirectTo() {

        if (auth()->user()->is_admin) {
            return '/admin';
        }
        if (auth()->user()->is_seller) {
            return '/seller/dashboard';
        }

        return '/home';
    }

   
    /**
     * Return verify login view
     * 
     * @return Illuminate\Support\Facades\View
     */
    public function viewVerifyLogin() {
        if (session()->has('verification_name') and session()->get('verification_name') === 'verify_login') {
            return view('auth.verifylogin');
        }

        return abort(404);
    }

    /**
     * Verify login HTTP request
     * @param  VerifyLoginRequest	$request
     * 
     * @return App\Http\Requests\Auth\VerifyLogin
     */
    public function postVerifyLogin(VerifyLoginRequest $request) {
        try {
            return $request->verify();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    public function themeSwitch() {
        if (Session::exists('theme')) {
            $theme = Session::get('theme');
            if ($theme == 'dark') {
                Session::put('theme', 'light');
            } else {
                Session::put('theme', 'dark');
            }
        } else {
            Session::put('theme', 'dark');
        }

        return redirect()->back();
    }

}
