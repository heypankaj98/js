<style>

.grid-container1x {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* Exactly 3 columns */
    gap: 16px; /* Space between items */
    max-height: 420px; /* Optional height limit */
    padding: 24px 0; /* Optional padding */
    overflow: hidden;}
    
a.card_title {
    height: 40px !important;
    display: flex;
    align-items: center;
    justify-content: center;
}
.hm{
    color: #ff0000 !important;
}
.inner-hm{
    font-size: 15px;
}


@media (max-width: 768px) {
    .grid-container1x {
        grid-template-columns: 1fr; /* 1 item per row on small screens */
    }
}

    .custom-select-border {
    border-color: #ff202c !important;
}
.deshboard_main_part .card{
    width: auto !important;
}
    .badge{
        padding: 5px !important;
    }

    .grid-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: space-between;
    }

    .row-cards {
        padding: 0;
    }

    a.btnz-inn {
        width: 154px !important;
        font-size: 14px !important;
        border-radius: 4px !important;
    }

    .tag {
        background-color: green;
        color: white;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        letter-spacing: .3px;
        font-weight: 600;
    }

    .grid-item-bor {
        border-radius: 0px !important;
    }

    .grid-item {
        width: 300px;
        height: 200px;
        perspective: 1000px;
    }

    .card-inner {
        position: relative;
        width: 100%;
        height: 100%;
        transition: transform 0.6s;
        transform-style: preserve-3d;
    }

    .grid-item:hover .card-inner {
        transform: rotateY(180deg);
    }

    .product-type {
        position: absolute;
        top: 4px;
        left: 4px;
        background: #ff2626;
        font-size: 13px;
        padding: 4px 8px;
        border-radius: 2px;
    }

    .card-front,
    .card-back {
        position: absolute;
        width: 100%;
        height: 100%;
        backface-visibility: hidden;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 20px;
        box-sizing: border-box;
    }

    .card-front {
        /*background-color: #fff;*/
        color: #000;
    }

    .card-back {
        color: #fff;
        transform: rotateY(180deg);
        padding: 0;
    }

    .card-back-text {
        display: flex;
        flex-direction: column;
        font-size: 13px;
        gap: 6px;
        opacity: .5;
        margin-top: 18px;

    }

    .card-back-inner {
        width: 100%;
    }

    .img-vendore {
        width: 100px;
        height: 100px;
        /*border-radius: 50%;*/
        margin-bottom: 10px;
    }

    .vendore-name {
        text-decoration: none;
        color: inherit;
        font-weight: bold;
        margin-top: 10px;
    }

    .list-group-item {
        margin: 10px 0;
        list-style: none;
    }
   

    .grid-item.card {
        width: 290px;
        height: 185px;
        flex: 1;
        border: 2px solid #ff7d00 !important;
        border-radius: 4px !important;
    }

    .Vendor-button {
        margin-top: 20px;
    }


    img.img-vendore {
        max-height: 225px ;
        min-height: 225 ;
        min-width: 397px ;
        transition: 0.4s ease-in-out ;
</style>

@extends('layouts.homeapp')
@section('content')

@if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif


<div class="banner">
    <div class="home-inn"></div>
    <div class="home-inner">
        <h4 class="hme">Home</h4>
    </div>
<div class="welcome-text" style="text-align: left;">
   <h4 class="mb-2"> <span class="grey-text text-start ">Security. Anonymity. Integrity = Forever Longevity & Prosperity.</span> </h4>
    <div class="text-start fs-5 lh-1" style="color:#fff !important;"><p>The <span style="color:#ff0000;" class="hm inner-hm fw-bold">HOME</span> page contains featured vendors and listings. Use the <strong class="inner-hm se fw-bold">Search </strong>option or <span class="inner-hm ct fw-bold" style=""><bold>Categories</bold></span> on<br> the left to find anything you want or need.</p>
    </div>
</div>
</div>

<div class="deshboard_main_part">


    <h2 class="title1_heading"> {{ trans('product.featured_vendor')}} </h2>
<div class="grid-container1x mb-4">
    @forelse($featuredSellers as $featuredSeller)
        <div class="grid-item grid-item-bor card">
            <div class="card-inner">
                <div class="card-front">
                    @if($featuredSeller->avatar)
                        <img class="img-vendore" src="{{ asset('storage/' . $featuredSeller->avatar) }}" alt="Avatar">
                    @endif
                    <a class="vendore-name" href="{{ route('seller.profile', $featuredSeller->username) }}">Vendor: {{ $featuredSeller->username }}</a>
                </div>
                
                <div class="card-back">
                    <div class="card-back-inner">
                        <span class="tag">Reputation({{ $featuredSeller->reputation }})</span>
                        @if($featuredSeller->reputation === 'Demon Customer')
                            <span class="tag">Demon Customer</span>
                        @endif

                        <div class="card-back-text">
                            <span>Joined: {{ \Carbon\Carbon::parse($featuredSeller->created_at)->diffForHumans() }}</span>
                            <span>Last Login: {{ \Carbon\Carbon::parse($featuredSeller->last_login)->diffForHumans() }}</span>
                        </div>
                        <div class="Vendor-button">
                            <a class="btn btn-main w-100 mt-4 btnz-inn" href="{{ route('seller.profile', $featuredSeller->username) }}">View/Visit Vendor</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @empty
        <p>No featured vendors available at the moment.</p>
    @endforelse
</div>

    <h2 class="title_heading mb-4">{{ trans('product.featured_products') }}</h2>
  <form action="{{ route('filter') }}" method="GET" class="d-flex align-items-center flex-wrap gap-3 form-filter-main">
            <!-- Price Sorting -->
            <div class="d-flex align-items-center">

<div class="dropdown">
    <div class="d-flex align-items-center">
        <label class="me-2">Price</label>
        
        <!-- Sort by Low to High -->
        <a class="d-flex align-items-center me-2" href="{{ url(request()->path() == 'filter' ? 'filter' : 'filter') . '?' . http_build_query(array_merge(request()->except('page'), ['priceSort' => 'asc'])) }}" title="Sort Low to High">
            <img src="{{ asset('assets/pricelow.png') }}" alt="Low Price Icon" class="img-fluid" style="height: 30px; width: auto;">
        </a>

        <!-- Sort by High to Low -->
        <a class="d-flex align-items-center me-2" href="{{ url(request()->path() == 'filter' ? 'filter' : 'filter') . '?' . http_build_query(array_merge(request()->except('page'), ['priceSort' => 'desc'])) }}" title="Sort High to Low">
            <img src="{{ asset('assets/pricehigh.png') }}" alt="High Price Icon" class="img-fluid" style="height: 30px; width: auto;">
        </a>
    </div>
</div>


</div>


            <!-- Vendor Ships From -->
        <div class="d-flex align-items-center">
  <label for="shipsFrom" class="form-label me-2">Vendor Ships From:</label>
  <select name="shipsFrom" id="shipsFrom" class="form-select-sm w-auto py-2 px-2" style="border-color: #ff0000;">
    <option value="" selected disabled>Select Location</option>
    <option value="Worldwide" {{ request('shipsFrom') == 'Worldwide' ? 'selected' : '' }}>Worldwide</option>
    <option value="USA" {{ request('shipsFrom') == 'USA' ? 'selected' : '' }}>USA</option>
    <option value="Europe" {{ request('shipsFrom') == 'Europe' ? 'selected' : '' }}>Europe</option>
</select>

</div>


            <!-- Vendor Ships To -->
            <div class="d-flex align-items-center">
                <label for="shipsTo" class="form-label me-2 d-flex">Vendor Ships To:</label>
<select name="shipsFrom" id="shipsFrom" class="form-select-sm w-auto  py-2 px-2 custom-select-border">
    <option value="" selected disabled>Select Location</option>
    <option value="Worldwide" {{ request('shipsFrom') == 'Worldwide' ? 'selected' : '' }}>Worldwide</option>
    <option value="USA" {{ request('shipsFrom') == 'USA' ? 'selected' : '' }}>USA</option>
    <option value="Europe" {{ request('shipsFrom') == 'Europe' ? 'selected' : '' }}>Europe</option>
</select>
            </div>

            <!-- Submit Button -->
            <div class="col-auto d-flex align-items-end">
              <button type="submit" class="btn btn-sm">
    <img src="{{ asset('assets/Find_us.png') }}" style="width: 30px; height: 30px;">
</button>

            </div>
        </form>

    <div class="row row-cards">
        @foreach($products as $product)
        <div class="col-md-3 mb-4">
            <div class="card thumbnail-image">
                <div class="card-header-2 w-100 text-center">
                    <h5 class="dress-name">
                        <a class="card_title" href="{{ route('product.details', ['id' => $product->id]) }}">
                            {{ Str::limit($product->name, 40) }}
                        </a>
                    </h5>
                </div>
                <div class="image-container">
                  <a class="card_img" href="{{ route('product.details', ['id' => $product->id]) }}">
    @if($product->photo)
        <img class="img-fluid" src="{{ $product->photo->getUrl() }}" alt="{{ $product->name }}">
    @else
        <img class="img-fluid" src="{{ asset('default-image.png') }}" alt="{{ $product->name }}">
    @endif
</a>

                    <span class="product-type">{{ $product->type }}</span>
                </div>
                <div class="product-detail-container px-3 py-4">
                     <div class="d-flex gap-2 fs-7">
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/btc.png" alt="BTC Logo">
                                <span class="fw-bold">(BTC)</span>
                            </span>
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/xmr.png" alt="XMR Logo">
                                <span class="fw-bold">(XMR)</span>
                            </span>
                        </div>
<div class="user">
    @if ($product->seller->is_verified)
        <span class="crypto-s d-inline-flex align-items-center">
            <img src="http://192.81.216.50/assets/shld.png" alt="Shield" class="img-fluid" style="width: 16px; height: 16px;">
            <small>Verified</small>
        </span>
    @else
        <span class="crypto-s d-inline-flex align-items-center">
            <img src="http://192.81.216.50/assets/cross.png" alt="Shield" class="img-fluid" style="width: 16px; height: 16px; ">
            <small>Not Verified</small>
        </span>
    @endif

    <!--@if ($product->seller->fe_Seller === 1)-->
    <!--    <span class="crypto-s d-inline-flex align-items-center">-->
    <!--        <img src="http://192.81.216.50/assets/flag.png" alt="flag" class="img-fluid" style="width: 16px; height: 16px; margin-right: 5px;">-->
    <!--        <small>FE Active</small>-->
    <!--    </span>-->
    <!--@else-->
    <!--    <span class="crypto-s d-inline-flex align-items-center">-->
    <!--        <img src="http://192.81.216.50/assets/flagred.png" alt="flag" class="img-fluid" style="width: 16px; height: 16px; margin-right: 5px;">-->
    <!--        <small>FE Inactive</small>-->
    <!--    </span>-->
    <!--@endif-->
</div>


                       <div class="sellor-info d-flex justify-content-between">
<h5>
    <span>
        <a class="badge  text-light" style="background:#597B8D"
           href="{{ route('seller.profile', $product->seller->username) }}">
            {{ $product->seller->username }}
        </a>
    </span>
    <span class="badge" style="background-color: #008C00 !important; color: white;">
        {{ getSellerReputationTier($product->seller) }}
    </span>
</h5>


    <p style="font-size:10px"><img src="http://192.81.216.50/assets/eye.png" alt="eye"> {{ $product->visit_count }}</p>
</div>
                    
                    <div class="stars">
                        @php
                        $avgRating = $product->reviews()->avg('rating');
                        @endphp
                        <span class="review-no font-bold mx-1 text-warning">{{ number_format($avgRating, 1) }}</span>
                        <span class="mx-1 star_main">
                            <!-- Display stars based on $avgRating -->
                        </span>
                    </div>
                
<div class="col text-start">
                            <h5>
                                <span>Stock: </span>
                                <span class="text-accent-1">{{ $product->stock ? $product->stock : 0 }}</span>
                            </h5>
                        </div>
                    <div class="price">
                        <span>($)</span>
                        <span class="new-price">{{ convertCurrency($product->price, request()->currency) }} {{ request()->currency }}</span>
                    </div>
<!--                    <div class="text-center">-->
<!--                           <span class="arrow-text id="user-{{ $user->id }}">-->
<!--{{ calculateReputationTier() }}</span>-->
<!--                    </div>-->
                    <div class="c-buy-now-btn">
                        <a class="btn btn-main w-100 mt-4" href="{{ route('product.details', ['id' => $product->id]) }}">
                            View Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
        <div class="col-md-12">
            {{ $products->links('partials.pagination') }}
        </div>
    </div>
</div>
@endsection
