<?php


namespace Modules\Jabber\Http\Controllers\Lib\Exceptions;

use Exception;

class StreamError extends Exception
{
    public function __construct($streamErrorType)
    {
        parent::__construct("Unrecoverable stream error ({$streamErrorType}), trying to reconnect...");
    }
}
