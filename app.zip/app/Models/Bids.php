<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bids extends Model {

    use HasFactory;
    protected $table = 'bids';
    
    protected $fillable = [
        'auction_id',
        'user_id',
        'amount',
        'status',
        'payment_method',
        'payment_address',
        'crypto_total',
        'total_received',
        'paid_at',
        'created_at',
        'updated_at',
    ];
    
    public function auction(){
        return $this->belongsTo(Auction::class);
    }
     public function bidder() {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}