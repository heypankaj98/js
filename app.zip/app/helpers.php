<?php

use Spatie\QueryString\QueryString;
use App\Models\Currency;
use App\Models\Order;
use App\Models\CryptoExchange;
use App\Models\Advertisement;
use Illuminate\Support\Facades\Http;

function toggle(string $name, $toggleValue = null): QueryString {
    $queryString = app(QueryString::class);

    return $queryString
                    ->toggle($name, $toggleValue);
}

function clearQueryString(string $name) {
    $queryString = app(QueryString::class);

    return $queryString->clear($name);
}

function convertCurrency($price, $currency = 'USD', $decimalPlaces = 2) {
    $exchangeRate = Currency::getExchangeRate($currency);
    $convertedPrice = $price * $exchangeRate;

    return number_format($convertedPrice, $decimalPlaces);
}

function exchangeRates() {
   $cryptoExchange = CryptoExchange::all();
   
   if ($cryptoExchange) {
       return $cryptoExchange;
   } else {
       throw new Exception('Error fetching conversion rates.');
   }
}

function convertBtcToUsd($btcAmount = '1') {
    // Fetch the conversion rates for USD, EUR, and GBP
    $response = Http::get('https://api.coingecko.com/api/v3/simple/price', [
        'ids' => 'bitcoin',
        'vs_currencies' => 'usd,eur,gbp'
    ]);

    if ($response->successful()) {
        $rates = $response->json()['bitcoin'];

        // Save the rates in the database
        $cryptoExchange = CryptoExchange::all();  // Assuming you have a single row to update
        $cryptoExchange->btc_usd = $rates['usd'];
        $cryptoExchange->btc_eur = $rates['eur'];
        $cryptoExchange->btc_gbp = $rates['gbp'];
        $cryptoExchange->save();

        // Return the converted amount in USD
        return $btcAmount * $rates['usd'];
    }

    throw new Exception('Unable to fetch conversion rates.');
}

function convert(float $usd, string $coin) {
    if ($coin == "Bitcoin") {
        $get_price = file_get_contents('https://blockchain.info/tobtc?currency=USD&value=' . $usd);
        return number_format(json_decode($get_price, true), 8);
    } elseif ($coin == "Monero") {
        $json = json_decode(file_get_contents("https://min-api.cryptocompare.com/data/price?fsym=USD&tsyms=XMR"));
        return bcmul($json->XMR, $usd, 8);
    } elseif ($coin == "BitcoinMultiSign") {
        $get_price = file_get_contents('https://blockchain.info/tobtc?currency=USD&value=' . $usd);
        return number_format(json_decode($get_price, true), 8);
    } elseif ($coin == "Litecoin") {
        $json = json_decode(file_get_contents("https://min-api.cryptocompare.com/data/price?fsym=USD&tsyms=LTC"));
        return bcmul($json->LTC, $usd, 8);
    }
}

function impressionCount($id) {
    $item = Advertisement::where('id', $id)->first();
    $item->impression += 1;
    $item->save();
}

function advertisements($size) {
    $ad = Advertisement::where('status', 2)->where('size', $size)->inRandomOrder()->first();
  
    if ($ad) {
        impressionCount($ad->id);
        $img = $ad->getMedia('photo')->first()->getUrl($size);
        return '<a target="_blank" href="' . route('admin.add.clicked', encrypt($ad->id)) . '"><img src="' . $img . '" alt="image" class="w-100"></a>';
    } else {
        return null;
    }
}

function calculateReputationTier($sellerId = null) {
    if (!$sellerId) {
        return 'No Reputation';
    }

    // Fetch the total number of completed orders for the specified seller
    $productsSold = Order::where('seller_id', $sellerId)->where('status', 'completed')->count();

    // Define reputation tiers
    $reputationTiers = [
        300 => 'Demon Seller',
        299 => 'Reputation 10',
        94  => 'Reputation 9',
        84  => 'Reputation 8',
        74  => 'Reputation 7',
        64  => 'Reputation 6',
        54  => 'Reputation 5',
        44  => 'Reputation 4',
        34  => 'Reputation 3',
        24  => 'Reputation 2',
        14  => 'Reputation 1',
        4   => 'Reputation 0',
    ];

    // Determine the reputation tier
    foreach ($reputationTiers as $min => $tier) {
        if ($productsSold >= $min) {
            return $tier;
        }
    }

    return 'No Reputation';
}

function getSellerReputationTier() {
    $user = Auth::user();

    // Fetch manual reputation if set
    $manualReputation = $user->manual_reputation;

    // Dynamically calculate reputation
    $productsSold = Order::where('seller_id', $user->id)->where('status', 'completed')->count();

    $reputationTiers = [
        300 => 'Demon Seller',
        299 => 'Reputation 10',
        94  => 'Reputation 9',
        84  => 'Reputation 8',
        74  => 'Reputation 7',
        64  => 'Reputation 6',
        54  => 'Reputation 5',
        44  => 'Reputation 4',
        34  => 'Reputation 3',
        24  => 'Reputation 2',
        14  => 'Reputation 1',
        4   => 'Reputation 0',
    ];

    $dynamicReputation = 'No Reputation';
    foreach ($reputationTiers as $min => $tier) {
        if ($productsSold >= $min) {
            $dynamicReputation = $tier;
            break;
        }
    }

if ($manualReputation) {
    return $manualReputation;
}

return $dynamicReputation;
}

if (!function_exists('getUserReputation')) {
    function getUserReputation($userId)
    {
        $user = \App\Models\User::find($userId);
        $purchaseCount = $user ? $user->completed_purchases ?? 0 : 0;
        
        // Ensure reputation doesn't go negative
        if ($purchaseCount < 1) {
            return 0; // No reputation for users with less than 1 completed purchase
        }
        
        return floor(($purchaseCount - 1) / 5);
    }
}


?>
