@extends('layouts.admin.master')
@section('content')
    <div class="mt-4">
    <div class="card-header-2 w-100 mb-4">Create Gift Card</div>
        <div class="bg-card-2 br1">
          <div class="roq">
          <div class="col-md-12">
                <div class="panel panel-default">
                   
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="{{ route('admin.gift-cards.store') }}">
                            {{ csrf_field() }}

                            <div class="mb-3 form-group{{ $errors->has('code') ? ' has-error' : '' }}">
                                <label for="code" class="col-md-4 control-label">Code</label>

                                <div class="col-md-12 mt-2">
                                    <input id="code" type="text" class="form-control" name="code" value="{{ old('code') }}" required autofocus>

                                    @if ($errors->has('code'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('code') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-3 form-group{{ $errors->has('amount') ? ' has-error' : '' }}">
                                <label for="amount" class="col-md-4 control-label">Amount</label>

                                <div class="col-md-12 mt-2">
                                    <input id="amount" type="text" class="form-control" name="amount" value="{{ old('amount') }}" required>

                                    @if ($errors->has('amount'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('amount') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-3form-group{{ $errors->has('expiration_date') ? ' has-error' : '' }}">
                                <label for="expiration_date" class="col-md-4 control-label">Expiration Date</label>

                                <div class="col-md-12 mt-2">
                                    <input id="expiration_date" type="datetime-local" class="form-control" name="expiration_date" value="{{ old('expiration_date') }}" placeholder="YYYY-MM-DD HH:MM:SS">

                                    @if ($errors->has('expiration_date'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('expiration_date') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group mt-3">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn py-0 btn-main w-100">
                                        Create
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
@endsection
