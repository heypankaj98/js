<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Monero;

use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroPayment;
use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroNode;
use App\Models\Deposit;
use App\Http\Controllers\Controller;

class ProcessController extends Controller {
    protected $wallet;
    protected $node;

    public function __construct() {
        $this->wallet = new MoneroPayment();
        $this->node = new MoneroNode();
    }
    
    /**************************
     * Static methods for Node *
     **************************/

    /**
     * Check if the Monero node is running.
     */
    public static function isNodeRunning() {
        $instance = new self(); // Create an instance
        return $instance->node->isMoneroRunning();
    }

    /**
     * Get blockchain info from Monero node.
     */
    public static function getBlockchainInfo() {
        $instance = new self(); // Create an instance
        return $instance->node->getNodeInfo();
    }

    /******************************
     * Static methods for Wallet  *
     ******************************/

    /**
     * Create a new Monero account.
     */
    public static function createNewAccount($params = []) {
  
        $instance = new self(); // Create an instance
      
        return $instance->wallet->createNewAccount($params);
    }

    /**
     * Generate a new Monero address.
     */
    public static function generateAddress($params = []) {

        
        $instance = new self(); // Create an instance
        return $instance->wallet->createNewAddress($params);
    }

    /**
     * Get balance of a specific Monero account.
     */
    public static function getBalance($params = []) {
       
        $instance = new self(); // Create an instance
        return $instance->wallet->getBalance($params);
    }

  public static function getAddressBalance($params) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getAddressBalance($params);
    }
    /**
     * Get the overall wallet balance.
     */
    public static function getWalletBalance() {
       
        $instance = new self(); // Create an instance
        return $instance->wallet->getWalletBalance();
    }
    
       public static function getWalletData() {
        $instance = new self(); // Create an instance
        return $instance->node->getWalletData();
    }


    /**
     * Get the list of transactions from the wallet.
     */
    public static function getWalletListTransactions($params = []) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getTransactions($params);
    }

    /**
     * Transfer Monero to a specific address.
     */
    public static function sendToAddress($params = []) {
      
        $instance = new self(); // Create an instance
        
        return $instance->wallet->transfer($params);
    }
       public static function primary_transfer($params = []) {
      
        $instance = new self(); // Create an instance
        
        return $instance->wallet->primary_transfer($params);
    }

    /**
     * Send Monero to multiple addresses.
     */
    public static function sendToMany($addressesAmounts = []) {
        $instance = new self(); // Create an instance
        return $instance->wallet->sendToMany($addressesAmounts);
    }

    /**
     * Get the status of a specific address.
     */
    public static function getAddressStatus($address) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getAddressInfo($address);
    }
      /**
     * Get the status of a specific address.
     */
    public static function getAllAccountsInfo($address) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getAllAccountsInfo($address);
    }
     
    public static function getAccountTransactions($index) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getAccountTransactions($index);
    }
     public static function getAccountAddresses($index) {
        $instance = new self(); // Create an instance
        return $instance->wallet->getAccountAddresses($index);
    }
    
    
}
