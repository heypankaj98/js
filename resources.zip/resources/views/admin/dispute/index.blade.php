@extends('admin.dispute.template')

@section('title', "asa")

@section('messenger-content')


<div class="mt-4">
    <div class="">
    <div class="row">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="bg-card-2 mt-auto p-16 br1">
                    <h5 class="card-header-2 w-100 mb-4">Disputes Users</h5>
                    <ul class="list-unstyled">
                        @forelse($disputes as $dispute)
                        <li>  <a href="{{ route('admin.dispute.messages', [$dispute->id]) }}">
                                <div class="user_info position-relative d-flex lign-items-center align-items-center">
                                <img src="{{$dispute->seller->avatar}}"   class="rounded-circle">
                                    <div class="d-flex flex-column">
                                        <span class="d-flex  align-items-center">{{$dispute->seller->username}} 
                                             <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="green" class="bi bi-dot" viewBox="0 0 16 16">
                                                <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/>
                                            </svg> 
                                        </span>
                                        <p class="small mb-0">Status:{{$dispute->status}}</p>
                                    </div>
                                        
                                        <p class="small ab-p">Order:{{$dispute->order_id}}</p>
 
                                </div>
                            </a>
                        </li>
                        @empty
                        No chat User
                        @endforelse
                    </ul>
                </div>

            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">
                    <h5 class="mb-0">Select Chat user to see chat</h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">
                        <p>Select User for chat</p>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">

        </div>
    </div>
    </div>
   





    @endsection