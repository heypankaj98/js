@extends('layouts.admin.master')
@section('content')
<div class="mt-4">
    <div class="row">
        <div class="col-md-12">
        <div class="card-header-2 w-100 mb-4">{{ __('Gift Cards') }}</div>
            <div class="bg-card-2 br1">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <a href="{{ route('admin.gift-cards.create') }}" class="btn btn-main w-max-c">{{ __('Create Gift Card') }}</a>
                        </div>
                        <div class="col-lg-6 text-right">
                            <form method="GET" action="{{ route('admin.gift-cards.index') }}">
                                <div class="input-group mb-3">
                                    <input type="text" name="search" class="form-control" placeholder="{{ __('Search by code') }}" value="{{ request()->input('search') }}" aria-label="{{ __('Search by code') }}" aria-describedby="gift-card-search-button">
                                    <div class="input-group-append">
                                        <button class="btn btn-main" type="submit" id="gift-card-search-button">{{ __('Search') }}</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div> 

                    <div class="table-responsive">
                        <table class="table table-bordered table-prd">
                            <thead>
                                <tr>
                                    <th>{{ __('Code') }}</th>
                                    <th>{{ __('Value') }}</th>
                                    <th>{{ __('Status') }}</th>
                                    <th>{{ __('Actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($giftCards as $giftCard)
                                <tr>
                                    <td>{{ $giftCard->code }}</td>
                                    <td>{{ $giftCard->amount }}</td>
                                    <td>{{ $giftCard->used }}</td>
                                    <td>
                                        <a href="{{ route('admin.gift-cards.show', $giftCard) }}" class="btn btn-primary btn-sm br-4">{{ __('View') }}</a>
                                        <a href="{{ route('admin.gift-cards.edit', $giftCard) }}" class="btn btn-secondary btn-sm br-4" btn-sm br-0>{{ __('Edit') }}</a>
                                        <form method="POST" action="{{ route('admin.gift-cards.destroy', $giftCard) }}" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm br-4" onclick="return confirm('{{ __('Are you sure you want to delete this gift card?') }}')">{{ __('Delete') }}</button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="4" class="text-center">{{ __('No gift cards found.') }}</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            {{ $giftCards->appends(request()->input())->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

