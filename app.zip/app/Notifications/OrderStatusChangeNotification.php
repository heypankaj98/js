<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderStatusChangeNotification extends Notification {

    use Queueable;

    public $order;

    /**
     * Create a new notification instance.
     */
    public function __construct($order) {
        $this->order = $order;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array {
        return ['database'];
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array {
        return [
                //
        ];
    }

    public function toDatabase($notifiable) {
        session(['notification_sound_played' => false]);
        return [
            'message' => 'You have a new message!',
            'link' => route('messenger.showMessages', $this->topic->id),
            'sound' => asset('assets/sound/notification.mp3'),
        ];
    }

}
