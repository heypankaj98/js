<?php

namespace Modules\Forum\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class Post extends BaseModel {

    use SoftDeletes;

    protected $table = 'forum_posts';
    protected $dates = ['deleted_at'];
    protected $fillable = [
        'thread_id',
        'author_id',
        'post_id',
        'sequence',
        'content',
    ];

    public function thread(): BelongsTo {
        return $this->belongsTo(Thread::class)->withTrashed();
    }

    public function parent(): BelongsTo {
        return $this->belongsTo(Post::class, 'post_id');
    }

    public function children(): HasMany {
        return $this->hasMany(Post::class, 'post_id')->withTrashed();
    }

    public function scopeRecent(Builder $query): Builder {
        $age = strtotime(config('forum.general.old_thread_threshold'), 0);
        $cutoff = time() - $age;

        return $query->where('updated_at', '>', date('Y-m-d H:i:s', $cutoff))->orderBy('updated_at', 'desc');
    }

    public function getSequenceNumber(): int {
        foreach ($this->thread->posts as $index => $post) {
            if ($post->id == $this->id) {
                return $index + 1;
            }
        }
    }

    public function author() {
        return $this->belongsTo(User::class);
    }

}
