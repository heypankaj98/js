<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin;

use Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin\Utility\RPCWrapper;
use Modules\PaymentGateway\Http\Controllers\Gateway\Utility\BitcoinConverter;
use App\Models\ExceptionModel;
use Illuminate\Support\Facades\Cache;

class LitecoinPayment {

    protected $litecoind;

    public function __construct() {
        $this->litecoind = new RPCWrapper(config('coins.litecoin.username'),
                config('coins.litecoin.password'),
                config('coins.litecoin.host'),
                config('coins.litecoin.port'));
    }

    public function createNewAccount($tag = null) {
        $username = $tag['username'];
        try {
            if (!empty($username)) {
                $address = $this->litecoind->getnewaddress($username);
            } else {
                $address = $this->litecoind->getnewaddress();
            }
            if ($this->litecoind->error) {
                throw new \Exception($this->litecoind->error);
            }
            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    /**
     * Generate new address with optional btc user parameter
     *
     * @param array $params
     * @return string
     * @throws \Exception
     */
    function generateAddress(array $params = []) {
        try {
            if (array_key_exists('btc_user', $params)) {
                $address = $this->litecoind->getnewaddress($params['btc_user']);
            } else {
                $address = $this->litecoind->getnewaddress();
            }
            if ($this->litecoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    /**
     * Get the balance of a user's Bitcoin account based on the account tag.
     *
     * @param string $tag Account tag
     * @return float|array Account balance or error details
     */
    function getUserBalanceByTag($tag) {
        try {

            $accounts = $this->bitcoind->listaccounts();
            $balance = 0;

            foreach ($accounts as $account => $amount) {
                if ($account === $tag) {
                    $balance = $amount;
                    break;
                }
            }

            return (float) $balance;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE.'; // Set the error message

            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();

            return [
                'error_code' => $errorCode,
                'error_message' => $errorMessage,
            ];
        }
    }

    public function generateAddressAccountTag(array $params = []) {
        try {
            if (array_key_exists('btc_user', $params)) {
                $address = $this->bitcoind->getnewaddress($params['btc_user']);
            } else {
                $address = $this->bitcoind->getnewaddress();
            }

            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }

            if (array_key_exists('btc_tag', $params)) {
                $this->bitcoind->setaccount($address, $params['btc_tag']);
            }

            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    /**
     * Returns the total received balance of the account
     *
     * @param array $params
     * @return float
     * @throws \Exception
     */
    function getBalance(array $params = []) {
        try {
            if (array_key_exists('address', $params)) {
                $accountBalance = $this->bitcoind->getreceivedbyaddress($params['address'], 1);
                if ($this->bitcoind->error)
                    throw new \Exception($this->bitcoind->error);
//                $accountBalance = $this->bitcoind->getreceivedbyaddress($params['address'], 1);
//        else if(array_key_exists('account', $params))
//            // fetch the balance of the account if this parameter is set
//            $accountBalance = $this -> bitcoind -> getbalance($params['account'], (int)config('marketplace.bitcoin.minconfirmations'));
                return (float) $accountBalance;
            }
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
        return;
    }

    function getTransactionDetail(array $params = []) {
        try {
            if (array_key_exists('address', $params)) {
                $transactions = $this->bitcoind->listtransactions($params['address']);
                if (!empty($this->bitcoind->error)) {
                    throw new \Exception($this->bitcoind->error);
                }
                return $transactions;
            }
        } catch (\Exception $exception) {
            dd($exception);
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
        return null;
    }

    public function getWalletBalance() {
        try {
            $balance = $this->bitcoind->getbalance("*", 1);
            if ($this->bitcoind->error)
                throw new \Exception($this->bitcoind->error);
            return (float) $balance;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function getWalletData() {
        try {
            $walletData = [];

            // Get wallet balance
//            $balance = $this->bitcoind->getbalance("*", 1);
//            if ($this->bitcoind->error)
//                throw new \Exception($this->bitcoind->error);
//            $walletData['balance'] = (float) $balance;
//
//            // Get all addresses
//            $addresses = $this->bitcoind->getaddressesbyaccount("*");
//            if ($this->bitcoind->error)
//                throw new \Exception($this->bitcoind->error);
//            $walletData['addresses'] = $addresses;
            // Get all transactions/transfers
            $transactions = $this->bitcoind->listtransactions("*");
            if ($this->bitcoind->error)
                throw new \Exception($this->bitcoind->error);
            $walletData['transactions'] = $transactions;

            return $walletData;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    public function getWalletlisttransactions() {
        return $this->bitcoind->listtransactions('*', 100);
    }

    function sendToAddress($params = []) {
        if (array_key_exists('address', $params)) {
            $toAddress = (string) $params['address'];
            $amount = (float) $params['amount'];
        }
        // Generate a unique identifier for the transfer request
        $transferId = $this->generateUniqueTransferId($toAddress, $amount);
        // Check if the transfer request has already been processed
        if (Cache::has($transferId)) {
            // Transfer request already exists, handle accordingly
            return ['error_code' => 'already_processed', 'error_message' => 'Transfer request already processed'];
        }

        try {
            $txid = $this->bitcoind->sendtoaddress($toAddress, $amount);
            if ($this->bitcoind->error)
                throw new \Exception("Sending to $toAddress amount $amount \n" . $this->bitcoind->error);
            // Store the transfer request identifier in cache with a TTL (time to live)
            $ttl = 60; // Set an appropriate TTL value in seconds
            Cache::put($transferId, true, $ttl);
            return $txid;
//            return $this->transactionDetails($txid);
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    function generateUniqueTransferId($toAddress, $amount) {
        // Create a unique identifier based on the toAddress and amount
        // You can use any method to generate a unique identifier, such as concatenating the values and hashing them
        return sha1($toAddress . $amount);
    }

    /**
     * Send to array of addresses
     *
     * @param string $fromAccount
     * @param array $addressesAmounts
     * @throws \Exception
     */
    function sendToMany(array $addressesAmounts) {

// send to many addresses
//        foreach ($addressesAmounts as $address => $amount){
//            
//            $this -> bitcoind -> sendtoaddress($address, $amount);
//        }

        $this->bitcoind->sendmany("", $addressesAmounts, (int) config('marketplace.bitcoin.minconfirmations'));

        if ($this->bitcoind->error) {
            $errorString = "";
            foreach ($addressesAmounts as $address => $amount) {
                $errorString .= "To $address : $amount \n";
            }
            throw new \Exception($this->bitcoind->error . "\nSending to: $errorString");
        }
    }

    /**
     * Convert USD to equivalent BTC amount, rounded on 8 decimals
     *
     * @param $usd
     * @return float
     */
    function usdToCoin($usd): float {
        return round(BitcoinConverter::usdToBtc($usd), 8, PHP_ROUND_HALF_DOWN);
    }

    /**
     * Returns the string label of the coin
     *
     * @return string
     */
    function coinLabel(): string {
        return 'btc';
    }

    function getaddressinfo($address) {
        return $this->bitcoind->getaddressinfo($address);
    }

    function addmultisigaddress($multi, $addresses_array) {
        return $this->bitcoind->addmultisigaddress(2, $addresses_array);
    }

    public function isBitcoinRunning() {
        try {
            $response = $this->bitcoind->getblockchaininfo(); // Make a JSON-RPC request to get blockchain information
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return true; // Bitcoin is running if the request was successful
        } catch (\Exception $exception) {
// Log the error and return false
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return false;
        }
    }

    public function getBlockchainInfo() {
        try {
            $response = $this->bitcoind->getblockchaininfo();
            if ($this->bitcoind->error) {
                throw new \Exception($this->bitcoind->error);
            }
            return $response;
        } catch (\Exception $exception) {
// Handle the exception or log the error
            return null;
        }
    }

}
 