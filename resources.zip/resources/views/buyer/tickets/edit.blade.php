@extends('layouts.buyer.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Edit Ticket') }}</div>

                <div class="card-body">
                    <form action="{{ route('user.tickets.update', $ticket->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
    @method('PUT')

                        <div class="mb-3">
                            <label for="title" class="form-label">{{ __('Title') }}</label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title', $ticket->title) }}" required>
                            @error('title')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="message" class="form-label">{{ __('Message') }}</label>
                            <textarea class="form-control @error('message') is-invalid @enderror" id="message" name="message" rows="5" required>{{ old('message', $ticket->message) }}</textarea>
                            @error('message')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <fieldset class="mb-3">
                            <legend>{{ __('Labels') }}</legend>
                            @foreach($labels as $id => $name)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="labels[]" id="label-{{ $id }}" value="{{ $id }}" {{ in_array($id, old('labels', $ticket->labels->pluck('id')->toArray())) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="label-{{ $id }}">
                                        {{ $name }}
                                    </label>
                                </div>
                            @endforeach
                        </fieldset>

                        <fieldset class="mb-3">
                            <legend>{{ __('Categories') }}</legend>
                            @foreach($categories as $id => $name)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="categories[]" id="category-{{ $id }}" value="{{ $id }}" {{ in_array($id, old('categories', $ticket->categories->pluck('id')->toArray())) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="category-{{ $id }}">
                                        {{ $name }}
                                    </label>
                                </div>
                            @endforeach
                        </fieldset>

                        <div class="mb-3">
                            <label for="assigned_to" class="form-label">{{ __('Assign To') }}</label>
                            <select name="assigned_to" id="assigned_to" class="form-select">
                                <option value="">{{ __('-- SELECT USER --') }}</option>
                                @foreach($users as $key => $user)
                                    @if ($user->getInRole('Admin'))
                                        <option value="{{ $key }}" {{ old('assigned_to', $ticket->assignedToUser->id ?? '') == $key ? 'selected' : '' }}>Admin => {{ $user->username }}</option>
                                    @elseif ($user->getInRole('Moderator'))
                                        <option value="{{ $key }}" {{ old('assigned_to', $ticket->assignedToUser->id ?? '') == $key ? 'selected' : '' }}>Moderator => {{ $user->username }}</option>
                                    @elseif ($user->getInRole('Seller'))
                                        <option value="{{ $key }}" {{ old('assigned_to', $ticket->assignedToUser->id ?? '') == $key ? 'selected' : '' }}>Seller => {{ $user->username }}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="attachments" class="form-label">{{ __('Attachments') }}</label>
                            <input type="file" class="form-control" id="attachments" name="attachments[]" multiple>
                        </div>

                        <button type="submit" class="btn btn-primary">{{ __('Update Ticket') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
