<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSellerAdvertisementsTable extends Migration
{
    public function up()
    {
        Schema::create('seller_advertisements', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('seller_id'); // Foreign key to users table
            $table->string('title'); // Title of the advertisement
            $table->string('image')->nullable(); // Path to ad image (nullable)
            $table->string('redirect_url')->nullable(); // URL to redirect to (nullable)
            $table->enum('status', ['inactive', 'active'])->default('inactive'); // Enum for status
            $table->timestamps();

            // Foreign key constraint
            $table->foreign('seller_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('seller_advertisements');
    }
}
