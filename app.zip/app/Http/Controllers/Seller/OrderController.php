<?php

namespace app\Http\Controllers\Seller;

use Request,
    Auth,
    Gate;
use App\Http\Requests\Seller\OrderRequest;
use App\Traits\OrderTrait;
use Carbon\Carbon;

use Illuminate\Support\Facades\Validator;
use App\Models\{
    Order,
    Feedback,
    Dispute,
    DisputeMessage,
    OrderPayment
};
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class OrderController {

    use OrderTrait;

    private function checkOrder(Order $order) {
        if (Gate::denies('order', $order)) {
            return abort(404);
        }
    }

    private function checkFeedback(Feedback $feedback) {
        if (Gate::denies('feedback', $feedback)) {
            return abort(404);
        }
    }

public function showall() {
    // Paginate the orders
    $orders = Order::where('seller_id', Auth::id())->orderBy('order_id')->paginate(20);
    return view('seller.orders', compact('orders'));
}


    public function showsingle($id) {
        $validator = Validator::make(['id' => $id], [
                    'id' => 'required|exists:orders,order_id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        $orders = Order::where('order_id', $id)->where('seller_id', Auth::id())->get();

        if ($orders->first()->status == 'waiting') {
            if (is_null($orders->first()->orderPayment()->first())) {
                return view('seller.order', compact('orders', 'id'));
            } else {
                $payment_method = $orders->first()->payment_method;
                $received = PayWay::getBalance($payment_method, ['address' => $orders->first()->orderPayment()->get()->first()->payment_address]);
                if (isset($received['error_code'])) {
                    $errorCode = $received['error_code'];
                    $errorMessage = $received['error_message'];
                    session()->flash('error', $errorMessage . "=>" . $errorCode);
                } else {
                    if ($received >= $orders->first()->orderPayment()->get()->first()->amount) {
                        Order::where('order_id', $id)->update(['status' => 'escrow']);
                        OrderPayment::where('order_id', $id)->update(['status' => 'PAID', 'total_received' => $received, 'paid_at' => Carbon::now()]);

                        session()->flash('success', 'Payment received successfully. You can process order.');
                    }
                }


                return view('seller.order', compact('orders', 'id', 'received'));
            }
        } elseif (in_array($orders->first()->status, ['escrow', 'processing', 'shipped', 'delivered', 'completed'])) {
            $received = $orders->first()->orderPayment()->first()->total_received;

            return view('seller.order', compact('orders', 'id', 'received'));
        }
    }

    public function changeStatus(OrderRequest $request, $id) {
        $validator = Validator::make(['id' => $id], [
                    'id' => 'required|exists:orders,id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        if ($request->type == "processing") {
            $this->markAsProcessing($id);
        } elseif ($request->type == "shipped") {
            $this->markAsShipped($id, $request->delivery);
        } elseif ($request->type == "delivered") {
            $this->markAsDelivered($id);
        }

        return redirect()->back();
    }

    public function postFeedback(Feedback $feedback, Request $request) {
        $this->checkFeedback($feedback);

        $request->validate([
            'rating' => 'required|numeric|min:1|max:5',
            'type' => 'required',
            'feedback' => 'required|max:1000'
        ]);

        try {
            if (!in_array($request->type, config('general.feedback_type'))) {
                throw new \Exception('Invalid or unavailable feedback type!');
            }

            $feedback->rating = $request->rating;
            $feedback->type = $request->type;
            $feedback->message = $request->feedback;
            $feedback->save();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
        }

        session()->flash('success', 'Your feedback has been sent successfully!');
        return redirect()->route('order', ['order' => $feedback->order->id]);
    }

    public function postCreateDisputeMessage(Dispute $dispute, Request $request) {
        $this->checkOrder($dispute->order);

        try {
            $request->validate([
                'message' => 'required|max:1000'
            ]);

            #Get auth user
            $user = auth()->user();

            $message = new DisputeMessage();
            $message->dispute_id = $dispute->id;
            $message->user_id = $user->id;
            $message->message = Crypt::encryptString($request->message);
            $message->save();
        } catch (\Exception $exception) {
            session()->flash('error', 'Oops... An error occurred!');
        }

        return redirect()->route('order', ['order' => $dispute->order_id]);
    }

    public function postFinalizearly(Order $order) {
        try {
            $this->checkFinalizearly($order);
            $this->finalizearly();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
        }

        return redirect()->route('order', ['order' => $order->id]);
    }
    
    public function completeOrder($orderId, $userId)
    {
        // Assume Order and User are models
        $order = Order::find($orderId);

        if ($order && $order->status !== 'completed') {
            // Mark the order as completed
            $order->status = 'completed';
            $order->save();

            // Increment products sold for the user
            $user = User::find($userId);
            $user->products_sold += 1;
            
            // Calculate the new reputation
            $user->reputation = ReputationHelper::calculateReputationTier($user->products_sold);
            
            // Save the updated user information
            $user->save();
        }
    }

}
