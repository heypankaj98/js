<?php
namespace App\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SellerAdvertisement extends Model
{
    use HasFactory;

    protected $table = 'seller_advertisements';  // Explicitly define the table name

    protected $fillable = [
        'user_id',
        'product_id',
        'title',
        'description',
        'price',
        'status',
    ];
//   public function products()
// {
//     return $this->hasMany(Product::class,'id','product_id');
// }
// In SellerAdvertisement model
public function product()
{
    return $this->belongsTo(Product::class, 'product_id');
}

}

