<?php
namespace App\Http\Requests;

use App\Models\Product;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class OrderRequest extends FormRequest {

    protected $stopOnFirstFailure = true;

    //public function authorize() {
    //    return Gate::allows('admin_product_create');
    //}

    public function rules() {
        return [
            'status' => ['bail', 'required', 'string'],
        ];
    }
}