@extends('layouts.nosidebar')       @section('content')

@if(Session::has('error'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
@endif

<div class="container mt-4">
    <div class="row g-5">
        
        <div class="col-md-5 col-lg-4 order-md-last">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-primary">Your cart</span>
                <span class="badge bg-primary rounded-pill"></span>
            </h4>
            <ul class="list-group mb-3">
                <li class="list-group-item d-flex justify-content-between">
                    <span> {{ trans('global.Total') }}  (USD)</span>
                    <strong>${{ $buy_price }}</strong>
                </li>
            </ul>
            <form class="card p-2">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Promo code">
                    <button type="submit" class="btn btn-secondary">{{ trans('global.redeem') }}</button>
                </div>
            </form>
        </div>
        
        <div class="col-md-7 col-lg-8">
            <h4 class="my-4">{{ trans('global.delivery_address') }} </h4>
            <form class="needs-validation" action="{{ route('user.auction.buy.checkout', $auction->id) }}" method="POST" >
                @csrf
                <div class="row my-4">
                    <div class="col">
                        <label for="firstName" class="form-label"> {{ trans('global.Delivery_Address') }}</label>
                        <textarea class="form-control" id="firstName" name="address" rows="5" required></textarea>
                        <small class="text-muted"> {{ trans('global.minimum') }} </small> 
                    </div>
                </div>
                
                @if(Session::has('error'))
                    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                @endif
                
                @error('address')
                    <div class="alert alert-danger" role="alert">
                        {{ $message }}
                    </div>
                @enderror
                
                <h4 class="my-3">{{ trans('global.payment_method') }}</h4>
                <div class="my-3">
                    
                    @foreach(config('coins.coin_list') as $index => $coin)
                        <div class="form-check">
                            <input id="credit" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>
                            <label class="form-check-label" for="credit">{{$coin}} [{{$index}}]</label>
                        </div>
                    @endforeach

                </div>
                <button class="w-100 btn btn-primary btn-lg" type="submit">{{ trans('global.checkout') }}</button>
            </form>
        </div>
    </div>
</div>
@endsection