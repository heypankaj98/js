<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Seller extends Model
{
    use HasFactory;

    // Add your properties here if needed, for example:
    protected $fillable = ['name', 'email', 'is_verified'];

    // Add relationships or methods if necessary
}
