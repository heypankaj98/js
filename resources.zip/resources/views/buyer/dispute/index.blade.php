@extends('buyer.dispute.template')      @section('messenger-content')

<div class="">
    <div class="row h-100">
        
        <div class="col-md-3">
            <div class="bg-card-2 d-flex flex-column h-100 chat-sidebar br1 p-16">
                <div class="">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('common.recent') }} {{ trans('common.disputes') }}</h5>
                    <ul class="list-unstyled mb-0">
                        @forelse($disputes as $dispute)
                            <li>
                                <a class="dispute-link"  href="{{ route('dispute.messages', [$dispute->id]) }}">
                                    <div class="user_info">
                                        <img src="{{ $dispute->seller->avatar }}" class="rounded-circle">
                                        <div class="d-flex flex-column gap-1">
                                        <span>{{ $dispute->seller->username }}</span>
                                        <p class="small mb-0">{{ trans('common.status') }} {{ $dispute->status }}</p>
                                        </div>
                                    </div>
                                    <p class="small ab-p">{{ trans('common.order') }} {{ $dispute->order_id }}</p>
                                </a>
                            </li>
                        @empty
                            {{ trans('common.no') }}  {{ trans('common.disputes') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="bg-card-2 cardds br1 h-100">
                <div class="card-header card-headerrds">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('common.select') }} {{ trans('common.dispute') }}</h5>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection