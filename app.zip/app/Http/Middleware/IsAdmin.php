<?php

namespace App\Http\Middleware;

use Closure;

class IsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        
          if (!auth()->check()) {
            abort(403); // User is not authenticated
        }

        if (!auth()->user()->is_admin && !auth()->user()->inRole('Moderator')) {
            abort(403); // User is not an admin or staff member
        }
        
//        if (! auth()->user()->is_admin ) {
//            abort(403);
//        }

        return $next($request);
    }
}