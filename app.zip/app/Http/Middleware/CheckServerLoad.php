<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckServerLoad {

    public function handle($request, Closure $next) {
        $load = sys_getloadavg();
        // if ($load[0] >= 2) { // Change the threshold value to suit your needs
        //     return response()->view('errors.high-load', [], 503);
        // }

        return $next($request);
    }

}
