@extends('layouts.seller.app')     @section('content')

<div class="mt-4">
    <div class="row row-cards-one">
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 br1 h-100">
                <div class="left d-flex flex-column gap-3 ">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.balance') }} {{ trans('common.Bitcoin') }}!</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ auth()->user()->btc_balance }}</span>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 br1 h-100">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.balance') }} {{ trans('common.Monero') }}!</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ auth()->user()->xmr_balance }}</span>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 br1 h-100">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.balance') }} {{ trans('common.Litecoin') }}!</h5>
                    <span class="number my-3 fw-bold fs-3 text-center">{{ auth()->user()->ltc_balance }}</span>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 br1 h-100">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.escrow') }} {{ trans('common.balance') }}!</h5>
                    <span class="number my-3 fw-bold fs-3 text-center"> </span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main w-100">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4 mb-4">
            <div class="bg-card-2 br1 h-100">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.disputes') }} {{ trans('common.balance') }}!</h5>
                    <span class="number my-3 fw-bold fs-3 text-center"></span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main w-100">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
                <!--div class="right d-flex align-self-center">
                    <div class="icon">
                        5
                    </div>
                </div-->
            </div>
        </div>
    </div>

    <div class="row">
        @if($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="col-12">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.create') }} {{ trans('common.new') }} {{ trans('common.withdrawal') }}:
                </div>
                <div class="card-body">
                    <form class="row g-3" action="{{route('seller.payout.request')}}" method="POST">
                        @csrf
                        <div class="col-3">
                            <h6 class="card-title mb-3">{{ trans('common.select') }} {{ trans('common.coin') }}:</h6>
                            <select class="form-control py-0" name="payment_method">
                                <option value="Bitcoin">{{ trans('common.Bitcoin') }}</option>
                                <option value="Monero">{{ trans('common.Monero') }}</option>
                                <option value="Litecoin">{{ trans('common.Litecoin') }}</option>
                            </select>
                        </div>
                        <div class="col-5">
                            <h6 class="card-title mb-3">{{ trans('common.withdrawal') }} {{ trans('common.address') }}:</h6>
                            <input type="text" name="payment_address" placeholder="{{ trans('common.withdrawal') }} {{ trans('common.address') }}" class="form-control">
                        </div>
                        <div class="col-4">
                            <h6 class="card-title mb-3">{{ trans('common.withdrawal') }} {{ trans('common.amount') }}:</h6>
                            <input type="text" name="amount" placeholder="{{ trans('common.amount') }}" class="form-control">
                        </div>
                        <hr>
                        <div class="col-4">
                            <input type="password" name="password" class="form-control" placeholder="{{ trans('auth.password') }}*">
                        </div>
                        <div class="col-4">
                            <button type="submit" class="btn btn-main">
                                {{ trans('common.create') }} {{ trans('common.withdrawal') }}
                            </button>
                        </div>
                    </form>
                    <p class="card-text mt-3">{{ trans('messages.withdrawal_msg') }}</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-12">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.all') }} {{ trans('common.payouts') }}:
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>{{ trans('common.no') }}.</th>
                                    <th>{{ trans('common.payment') }} {{ trans('common.address') }}</th>
                                    <th>{{ trans('common.payment') }} {{ trans('common.coin') }}</th>
                                    <th>{{ trans('common.amount') }}</th>
                                    <th>{{ trans('common.date') }}</th>
                                    <th>{{ trans('common.status') }}</th>
                                    <th>{{ trans('common.details') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($payouts as $payout)
                                    <tr>
                                        <td>{{ isset($a) ? ++$a : $a =1 }}</td>
                                        <td>{{ $payout->payment_address }}</td>
                                        <td>{{ $payout->payment_method }}</td>
                                        <td>{{ $payout->amount }}</td>
                                        <td>{{ $payout->created_at }}</td>
                                        <td>{{ $payout->status }}</td>
                                        <td>{{ $payout->details }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="100%">{{ trans('common.no') }} {{ trans('common.payouts') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 