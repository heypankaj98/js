<?php
namespace App\Http\Requests\User\Settings;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;

class ChangePasswordRequest extends FormRequest{
    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'current_password' => 'required',
            'password' => 'required|min:8|max:80|confirmed',
        ];
    }
    
    public function messages() {
        return [
            'current_password.required' => trans('validation.required', ['attribute' => trans('validation.attributes.current_password')]),
            'password.required' => trans('validation.required', ['attribute' => trans('validation.attributes.password')]),
            'password.min' => trans('validation.min', ['attribute' => trans('validation.attributes.password'), 'min' => 8]),
            'password.max' => trans('validation.max', ['attribute' => trans('validation.attributes.password'), 'max' => 80]),
            'password.confirmed' => trans('validation.confirmed', ['attribute' => trans('validation.attributes.password')]),
        ];
    }
}