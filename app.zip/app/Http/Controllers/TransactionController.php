<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;

use App\Models\Transaction;
use App\Models\User;
use App\Models\Payment;
use Illuminate\Http\Request;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use Carbon\Carbon;

use Auth;

class TransactionController extends Controller {
    
    public function index() {
        $user = Auth::id();
        $transactions = Transaction::where('user_id',$user)->latest()->paginate(15);
        
        return view('buyer.transaction',compact('transactions'));
    }
public function walletBalance() {
    $id = Auth::id();
    $user = User::findOrFail($id);

    $payments = Payment::where('user_id', $id)
                       ->orderBy('created_at', 'desc')
                       ->where('model_type', 'balance_add')
                       ->where('status', 'waiting')
                       ->paginate(15);

    // Fetch exchange rates
    $btcToUsdRate = $this->getBtcToUsdRate(); // Fetch BTC/USD rate
    $xmrToUsdRate = $this->getXmrToUsdRate(); // Fetch XMR/USD rate

    foreach ($payments as $payment) {
        if ($payment->method == 'Monero') {
            $received = PayWay::getAddressBalance($payment->method, ['address' => $payment->payment_address]);
        } else {
            $received = PayWay::getBalance($payment->method, ['address' => $payment->payment_address]);
        }

        if (isset($received['error_code'])) {
            $errorCode = $received['error_code'];
            $errorMessage = $received['error_message'];
            session()->flash('error', $errorMessage . " => " . $errorCode);
        } else {
            $balance = floatval($received); 
            $formattedBalance = number_format($balance, 8, '.', '');
            $payment->total_received = $balance;

            if ($balance >= $payment->amount) {
                $payment->status = 'received';
                $payment->paid_at = Carbon::now();
                $payment->save();

                if ($payment->method == 'Monero') {
                    $user->xmr_balance += $balance;
                } else {
                    $user->btc_balance += $balance;
                }

                // Convert received balance to USD
                $usdEquivalent = 0;
                if ($payment->method == 'Bitcoin' && $btcToUsdRate) {
                    $usdEquivalent = $balance * $btcToUsdRate;
                } elseif ($payment->method == 'Monero' && $xmrToUsdRate) {
                    $usdEquivalent = $balance * $xmrToUsdRate;
                }

                $user->usd_wallet_balance += $usdEquivalent; // Accumulate the USD balance
                $user->save();
            }

            $payment->save();
        }
    }

    if (!$btcToUsdRate) {
        session()->flash('error', 'Failed to fetch BTC to USD exchange rate.');
    }

    if (!$xmrToUsdRate) {
        session()->flash('error', 'Failed to fetch XMR to USD exchange rate.');
    }

    $pendingBitcoin = Payment::where('user_id', $id)
                             ->where('model_type', 'balance_add')
                             ->where('method', 'Bitcoin')
                             ->where('status', 'waiting')
                             ->sum('amount');

    $pendingMonero = Payment::where('user_id', $id)
                            ->where('model_type', 'balance_add')
                            ->where('method', 'Monero')
                            ->where('status', 'waiting')
                            ->sum('amount');

    $receivedBitcoin = Payment::where('user_id', $id)
                              ->where('model_type', 'balance_add')
                              ->where('method', 'Bitcoin')
                              ->where('status', 'received')
                              ->sum('amount');

    $receivedMonero = Payment::where('user_id', $id)
                             ->where('model_type', 'balance_add')
                             ->where('method', 'Monero')
                             ->where('status', 'received')
                             ->sum('amount');

    $receivedpayments = Payment::where('user_id', $id)
                               ->orderBy('created_at', 'desc')
                               ->where('model_type', 'balance_add')
                               ->paginate(15);

    return view('buyer.wallet', compact('user', 'payments', 'receivedMonero', 'receivedBitcoin', 'pendingMonero', 'pendingBitcoin', 'receivedpayments', 'btcToUsdRate'));
}

private function getBtcToUsdRate() {
    try {
        // Example: Replace this with the actual API call or service
        $response = Http::get('https://api.coindesk.com/v1/bpi/currentprice/BTC.json');
        if ($response->successful()) {
            $rate = $response->json()['bpi']['USD']['rate_float'];
            return $rate;
        }
    } catch (\Exception $e) {
        Log::error('Failed to fetch BTC to USD rate: ' . $e->getMessage());
    }

    return null;
}


public function Addbalance(Request $request) {
    $request->validate([
        'wallet_balance' => 'required|numeric|min:0.01',
        'payment_method' => 'required|string',
    ]);

    $userid = Auth::id();
    $user = User::findOrFail($userid);
    $paymentMethod = $request->payment_method;
    $walletBalance = $request->wallet_balance;

    if ($paymentMethod === 'Bitcoin') {
        // Generate Bitcoin address
        $payment_address = PayWay::generateAddress($paymentMethod, ['amount' => $walletBalance]);

        if (isset($payment_address['error_code'])) {
            $errorCode = $payment_address['error_code'];
            $errorMessage = $payment_address['error_message'];
            session()->flash('error', $errorMessage . " => " . $errorCode);
            return redirect()->back();
        } elseif ($payment_address && is_string($payment_address)) {
            $amount = convert($walletBalance, $paymentMethod);

            // Create payment record
            $payment = new Payment;
            $payment->user_id = $userid;
            $payment->model_type = "balance_add";
            $payment->method = $paymentMethod;
            $payment->payment_address = $payment_address;
            $payment->status = 'waiting';
            $payment->amount = $amount;
            $payment->type = 'balance';
            $payment->deleted = 0;
            $payment->save();

            // Update user's BTC balance
            $user->btc_balance += $walletBalance;  // Add to the existing BTC balance
            $user->save();
        }
    }

    if ($paymentMethod === 'Monero') {
        $username = $user->username;

        // Check if the user has a Monero account created
        if (!$user->is_xmr_created) {
            $account = PayWay::createNewAccount($paymentMethod, ['username' => $username]);
            if ($account) {
                $user->is_xmr_created = 1;
                $user->save();
            }
        }

        // Generate Monero address
        $payment_address = PayWay::generateAddress($paymentMethod, ['amount' => $walletBalance, 'username' => $username, 'tag' => $username]);

        if (isset($payment_address['error_code'])) {
            $errorCode = $payment_address['error_code'];
            $errorMessage = $payment_address['error_message'];
            session()->flash('error', $errorMessage . " => " . $errorCode);
            return redirect()->back();
        } elseif ($payment_address && is_string($payment_address)) {
            $amount = convert($walletBalance, $paymentMethod);

            // Create payment record
            $payment = new Payment;
            $payment->user_id = $userid;
            $payment->model_type = "balance_add";
            $payment->method = $paymentMethod;
            $payment->payment_address = $payment_address;
            $payment->status = 'waiting';
            $payment->amount = $amount;
            $payment->type = 'balance';
            $payment->deleted = 0;
            $payment->save();

            // Update user's XMR received balance
            $user->xmr_received += $walletBalance;  // Add to the existing XMR received balance
            $user->save();
        }
    }

    return redirect()->back()->with('success', 'Address generated successfully.');
}
private function getXmrToUsdRate() {
    try {
        // Example API call for Monero rate (replace with actual API)
        $response = Http::get('https://api.coingecko.com/api/v3/simple/price?ids=monero&vs_currencies=usd');
        if ($response->successful()) {
            $rate = $response->json()['monero']['usd'];
            return $rate;
        }
    } catch (\Exception $e) {
        Log::error('Failed to fetch XMR to USD rate: ' . $e->getMessage());
    }

    return null;
}


      
    
}