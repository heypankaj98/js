<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GiftCard;
use App\Models\Referrals;
use App\Models\Payment;
use Auth;
use Illuminate\Support\Str;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class GiftCardController extends Controller {

    public function index() {
        $giftCards = GiftCard::where('user_id', auth()->user()->id)->latest()->paginate(10);
        $balancecheckgiftcards = GiftCard::where('user_id', auth()->user()->id)->where('status', 'payment_generated')->latest()->paginate(10);
        foreach ($balancecheckgiftcards as $giftCard) {
            $payment_method = $giftCard->payment->method;
            $payment_address = $giftCard->payment->payment_address;
            $received = PayWay::getBalance($payment_method, ['address' => $payment_address]);
            if (isset($received['error_code'])) {
                $errorCode = $received['error_code'];
                $errorMessage = $received['error_message'];
                session()->flash('error', $errorMessage . "=>" . $errorCode);
            } else {
                $giftCard->payment->total_received = $received;

                if ($received >= $giftCard->payment->amount) {
                    $giftCard->payment->status = 'paid';
                    $giftCard->status = 'paid';
                    $giftCard->save();
                }
                $giftCard->payment->save();
            }
        }

        return view('buyer.gift-cards.index', compact('giftCards'));
    }

    public function applyGiftCard(Request $request) {
        $giftCard = GiftCard::where('code', $request->input('gift_card_code'))->first();
        if (!$giftCard) {
            // Invalid gift card code
            return redirect()->back()->withErrors(['gift_card_code' => 'Invalid gift card code']);
        }

        if ($giftCard->expiration_date && $giftCard->expiration_date < now()) {
            // Gift card has expired
            return redirect()->back()->withErrors(['gift_card_code' => 'Gift card has expired']);
        }

        if ($giftCard->used) {
            // Gift card has already been used
            return redirect()->back()->withErrors(['gift_card_code' => 'Gift card has already been used']);
        }
        $giftCard->used = true;
        $giftCard->save();
        // apply the gift card value to the order/cart total
        // you can use the Cart or Order model in your application to implement this logic

        return redirect()->route('checkout')->with('success', 'Gift card applied successfully');
    }

    public function store(Request $request) {
        $request->validate([
            'amount' => 'required|numeric|min:0',
        ]);
        $amount = $request->input('amount');
        $payable_amount = $request->input('amount');

        if ($request->redeem_points) {
            $points = Auth::user()->earnedReferralPoints();
            $pointsusd = $points / 2;
            if ($pointsusd >= $payable_amount) {
                $leftusd = $pointsusd - $payable_amount;
                $leftpoint = $leftusd * 2;
                $payable_amount = 0;
            } else {
                $leftpoint = 0;
                $payable_amount = $amount - $pointsusd;
            }
        }

        if ($payable_amount == 0) {
            $status = 'paid';
        } else {
            $status = 'payment_pending';
        }

        $giftCardCode = Str::random(8);
        $giftCard = new GiftCard([
            'code' => 'C7-' . $giftCardCode,
            'amount' => $amount,
            'payable_amount' => $payable_amount,
            'user_id' => Auth::user()->id,
            'status' => $status,
        ]);
        $giftCard->save();

        if ($request->redeem_points) {
            $referral = Referrals::where('user_id', Auth::user()->id)->first();
            if ($referral) {
                $referral->earned -= $leftpoint;
                $referral->save();
            }
        }

        return redirect()->route('user.gift-cards.index')
                        ->with('success', 'Gift card created successfully.');
    }

    public function generatePayment(Request $request, $id) {
        // Validate the form data
        $request->validate([
            'payment_method' => 'required',
        ]);

        // Retrieve the gift card by its ID
        $giftCard = GiftCard::findOrFail($id);

        // Generate the payment address using the selected payment method
        $paymentMethod = $request->input('payment_method');
        $payment_address = PayWay::generateAddress($paymentMethod);

        if (isset($payment_address['error_code'])) {
            $errorCode = $payment_address['error_code'];
            $errorMessage = $payment_address['error_message'];
            session()->flash('error', $errorMessage . "=>" . $errorCode);
            return redirect()->back();
        } else {
            if ($payment_address && is_string($payment_address)) {
                $giftCard->status = 'payment_generated';
                $giftCard->save();

                $amount = convert($giftCard->payable_amount, $paymentMethod);

                $payment = new Payment;
                $payment->model_id = $giftCard->id;
                $payment->method = $paymentMethod;
                $payment->payment_address = $payment_address;
                $payment->status = 'waiting';
                $payment->amount = $amount;
                $payment->type = 'Gift Card';
                $payment->deleted = 0;
                $payment->save();
            } else {
                session()->flash('error', 'Payment not generated. Please ask the Admin for help.');
                return redirect()->back();
            }
        }
        // Update the gift card status and payment address
        // Redirect the user back to the gift card details page
        return redirect()->route('user.gift-cards.index');
    }

}
