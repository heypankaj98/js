@extends('layouts.admin.master')      @section('content')


    <div class="row justify-content-center">
        <div class="col-md-12 col-12 ">
            <div class="card">
                <div class="card-header">
                    Auction {{ trans('cruds.product.title_singular') }} {{ trans('global.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-striped table-hover datatable datatable-Product">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('cruds.auction.id') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.name') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.auctioner') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.bids') }} [USD]
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.current_price') }} [USD]
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.category') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.type') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($auction as $key => $single)
                                <tr data-entry-id="{{ $single->id }}">
                                    <td>
                                        {{ $single->id ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->seller->username ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->bids->count() ?? 'No Bids' }}
                                    </td>
                                    <td>
                                        $ {{ $single->bids->max('amount') ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->categories->name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->type ?? '' }}
                                    </td>
                                    <td>
                                        @can('admin_product_show')
                                        <a class="btn btn-xs btn-primary" href="{{ route('auction', $single->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_edit')
                                        <a class="btn btn-xs btn-info" href="{{ route('admin.auctions.edit', $single->id) }}">
                                            {{ trans('global.edit') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_delete')
                                        <form action="{{ route('admin.auctions.destroy', $single->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                            <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                        </form>
                                        @endcan
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td class="text-center" colspan="7">No Auction available</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection