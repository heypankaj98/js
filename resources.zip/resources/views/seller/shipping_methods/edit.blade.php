@extends('layouts.seller.app')

@section('content')
<div class="bg-card-1 p-24 br1 mt-4">
<form action="{{ route('seller.shipping-methods.update', $shippingMethod->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" class="form-control mt-2 @error('name') is-invalid @enderror" value="{{ old('name', $shippingMethod->name) }}" required>
        @error('name')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group mt-3">
        <div class="form-check">
            <input type="radio" name="is_free" id="is_free_yes" class="form-check-input" value="1" {{ old('is_free', $shippingMethod->is_free) ? 'checked' : '' }} required>
            <label for="is_free_yes" class="form-check-label">Free</label>
        </div>
        <div class="form-check">
            <input type="radio" name="is_free" id="is_free_no" class="form-check-input" value="0" {{ old('is_free', $shippingMethod->is_free) === '0' ? 'checked' : '' }} required>
            <label for="is_free_no" class="form-check-label">Paid</label>
        </div>
        @error('is_free')
        <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
        <div class="form-group mt-3">
            <label for="price">Price</label>
            <input type="number" name="price" id="price" class="form-control mt-2 @error('price') is-invalid @enderror" value="{{ old('price', $shippingMethod->price) }}" min="0" step="0.01" {{ old('is_free', $shippingMethod->is_free) === '0' ? 'required' : '' }}>
            @error('price')
            <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="form-group mt-3">
        <label for="delivery_time">Delivery Time (in days)</label>
        <input type="number" name="delivery_time" id="delivery_time" class="form-control mt-2 @error('delivery_time') is-invalid @enderror" value="{{ old('delivery_time', $shippingMethod->delivery_time) }}" min="0" required>
        @error('delivery_time')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group mt-3">
        <label for="availability">Availability</label>
        <select name="availability" id="availability" class="form-control py-0 mt-2">
            <option value="worldwide" {{ old('availability', $shippingMethod->availability) === 'worldwide' ? 'selected' : '' }}>Worldwide</option>
            <option value="except" {{ old('availability', $shippingMethod->availability) === 'except' ? 'selected' : '' }}>Except</option>
            <option value="limited" {{ old('availability', $shippingMethod->availability) === 'limited' ? 'selected' : '' }}>Limited</option>
        </select>
    </div>

      @php
    $selectedCountries = collect(); // Initialize as an empty collection
    if ($shippingMethod->countries) {
        $selectedCountries = collect(explode(',', $shippingMethod->countries))->map(function ($code) use ($countries) {
            return collect($countries)->flatten()->firstWhere('code', $code);
        })->filter();
    }
@endphp

    <div class="form-group mt-3">
        <label for="available_countries">Available Countries</label>
        <select name="countries[]" id="countries" class="form-control form-control-textarea  mt-2" multiple>
            @foreach ($countries as $continent => $countriesByContinent)
            <optgroup label="{{ $continent }}">
                 @foreach ($countriesByContinent as $code => $name)
                <option value="{{ $code }}" {{ $selectedCountries->contains('code', $code) ? 'selected' : '' }}>{{ $name }}</option>
                @endforeach
              
            </optgroup>
            @endforeach
        </select>



        @error('countries')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group mt-3">
        <button type="submit" class="btn btn-main">Update Shipping Method</button>
    </div>
</form>

</div>
@endsection