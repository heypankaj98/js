<?php

namespace App\Console\Commands;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\User;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class AutoReleasePayouts extends Command
{
    protected $signature = 'payouts:auto-release';
    protected $description = 'Automatically release payouts for pending orders';

    // Define payout statuses as constants
    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_ERROR = 'error'; // General error status
    const ERROR_SELLER_NOT_FOUND = 'Seller not found';
    const ERROR_ADDRESS_NULL = "Seller's payout address is null";
    
    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        // Fetch all pending payouts
        $payouts = DB::table('payouts')->where('status', self::STATUS_PENDING)->whereDate('created_at', '=', Carbon::now()->subDay()->toDateString())->get();

        foreach ($payouts as $payout) {
            try {
                $this->processPayout($payout);
                $this->info("Payout released for user ID: {$payout->user_id}");
            } catch (\Exception $e) {
                Log::error("Failed to release payout for user ID: {$payout->user_id} - " . $e->getMessage());
                $this->updatePayoutStatusOnError($payout, $e->getMessage());
                $this->error("Failed to release payout for user ID: {$payout->user_id} - " . $e->getMessage());
            }
        }

        return 0;
    }

    private function processPayout($payout)
    {
        // Fetch the order details related to the payout
        $order = DB::table('orders')->where('id', $payout->order_id)->first();
        if (!$order) {
            throw new \Exception("Order not found for payout ID: {$payout->id}");
        }

        // Check for seller
        $seller = DB::table('users')->where('id', $payout->user_id)->first();
        if (!$seller) {
            throw new \Exception(self::ERROR_SELLER_NOT_FOUND);
        }

        // Determine the payout address based on payment method
        $payoutAddress = $this->getPayoutAddress($payout, $seller);
        if (is_null($payoutAddress)) {
            throw new \Exception(self::ERROR_ADDRESS_NULL);
        }

        // Handle the payment method
        try {
            
            $txid = $this->handlePaymentMethod($payout, $seller, $payoutAddress,$order);
             // Check if $txid is a valid response
        if (is_array($txid)) {
            // If it's an array, JSON encode it for storage
            $txidJson = json_encode($txid);
            $this->updatePayoutDetail($payout, $txidJson);
            Log::info("Stored transaction details for user ID: {$payout->user_id} - Details: $txidJson");
        } else {
            // Directly store the txid if it's not an array
            $this->updatePayoutDetail($payout, $txid);
            Log::info("Stored transaction ID for user ID: {$payout->user_id} - ID: $txid");
        }

            // Update payout status and store transaction if successful
            if ($txid) {
                $this->updatePayoutStatus($payout, self::STATUS_APPROVED);
                $this->storeTransaction($payout, $seller, $txid,$order);
            }
        } catch (\Exception $e) {
            throw new \Exception("Payment processing error: " . $e->getMessage());
        }
    }

    private function getPayoutAddress($payout, $seller)
    {
        return $payout->payment_method === 'Bitcoin' ? $seller->btc_address : $seller->xmr_address;
    }

    private function handlePaymentMethod($payout, $seller, $payoutAddress,$order)
    {
        $user = User::find($order->buyer_id);
        
        
      
        $params = [
            'amount' => $payout->amount,
            'address' => $payoutAddress,
            'tag' => $user->username // or any identifier
        ];

        return $payout->payment_method === 'Bitcoin'
            ? PayWay::sendToAddress('Bitcoin', $params)
            : PayWay::sendToAddress('Monero', $params);
    }

    private function updatePayoutStatus($payout, $status)
    {
        DB::table('payouts')->where('id', $payout->id)->update(['status' => $status]);
    }

private function updatePayoutDetail($payout, $details)
{
    DB::table('payouts')->where('id', $payout->id)->update(['details' => $details]);
}

    private function updatePayoutStatusOnError($payout, string $errorMessage)
    {
        $this->updatePayoutStatus($payout, self::STATUS_ERROR); // Handle error statuses appropriately
    }

    private function storeTransaction($payout, $seller, $transferDetails,$order)
    {
       
        if(isset($transferDetails['tx_hash'] )){
            $transferDetailsid=$transferDetails['tx_hash']; 
        }else{
              $transferDetailsid=$transferDetails;
        }
      
        DB::table('transactions')->insert([
            'user_id' => $seller->id,
            'trx_id' => $transferDetailsid ?? '',
            'crypto_name' => $payout->payment_method,
            'crypto_address' => $payout->payment_address,
            'crypto_amount' => $payout->amount,
            'status' => 1,
            'type' => 'payout',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        
          DB::table('order_details')->where('order_id', $order->id)->update(['status' => 'paid']);
        
       
    }
}
