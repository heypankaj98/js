@extends('layouts.admin.master')

@section('content')
<div class="mt-4">
<div class="card-header-2 w-100 mb-4">
            Ticket Details
        </div>
    <div class="bg-card-2 br1">
       
        <div class="card-body">
            <h5 class="card-title">Title: <span class="color-accent-2"> {{ $tickets->title }}</span></h5>
            <p class="card-text">Priority: <span class="color-accent-2">{{ $tickets->priority }}</span></p>
            <p class="card-text">Status: <span class="color-accent-2">{{ $tickets->status }}</span></p>
            <p class="card-text">Created At: <span class="color-accent-2">{{ $tickets->created_at }}</span></p>
            <p class="card-text">Solve/Unsolve: @if ($tickets->is_resolved == 1)
            <span class="color-accent-2"> SolveTicket</span> 
                @else
                <span class="color-accent-2"> UnsolveTicket</span> 
                @endif
            </p>
            <p class="card-text">Lock/Unlock: @if ($tickets->is_locked == 1)
            <span class="color-accent-2"> Lock</span> 
                @else
            <span class="color-accent-2"> Unlock</span> 
                @endif
            </p>

            @if ($tickets->media->isNotEmpty())
            <h5 class="mt-3">Media Files</h5>
            <ul>
                @foreach ($tickets->media as $media)
                <li>{{ $media->filename }}</li>
                <!-- Adjust with actual media details you want to display -->
                @endforeach
            </ul>
            @endif

            @if ($tickets->messages->isNotEmpty())
            <h5 class="mt-3">Messages</h5>
            <ul class="message">
                @foreach ($tickets->messages as $message)
                <li style="clear:both">
                    <div
                        style="float:{{ ($message->user_id == auth()->user()->id) ? 'right' : 'left' }}; background-color: {{ ($message->user_id == auth()->user()->id) ? '#2a4352' : '#254d64' }}; padding: 10px; border-radius: 4px; margin-bottom: 5px; color:#fff">
                     {{ $message->message }}
                    </div>
                </li>
                @endforeach
            </ul>
            @endif

            <form action="{{ route('admin.tickets.reply', $tickets->id) }}" method="POST">
                @csrf

                <h5 class="mt-3">Solved/Unsolved</h5>
                <select class="form-select form-control py-0" aria-label="Default select is_resolved" name="is_resolved">
                    <option value="0" selected>Unsolved</option>
                    <option value="1">Solved</option>
                </select>

                <h5 class="mt-3">Open/Close</h5>
                <select class="form-select form-control py-0" aria-label="Default select is_locked" name="is_locked">
                    <option value="0" selected>Unlocked</option>
                    <option value="1">Locked</option>
                </select>

                <div class="form-group">
                    <label for="replyMessage">Your Reply:</label>
                    <textarea class="form-control form-control-textarea" id="replyMessage" rows="3" name="reply"
                        placeholder="Type your reply here..." required></textarea>
                </div>

                <button type="submit" class="btn btn-main w-max-c">Send Reply</button>
            </form>
        </div>
    </div>
</div>
@endsection