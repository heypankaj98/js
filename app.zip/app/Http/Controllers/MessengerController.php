<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\QaTopicCreateRequest;
use App\Http\Requests\QaTopicReplyRequest;
use App\Models\QaTopic;
use App\Models\User;
use Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Notifications\NewMessageNotification;
use Modules\Jabber\Http\Controllers\JabberController as Jabber;
use App\Http\Controllers\Traits\MediaUploadingTrait;

//use App\Http\Notifications\NewMessageNotification;

class MessengerController extends Controller {

    use MediaUploadingTrait;

    public function index() {


//        Jabber::index();

        $topics = Auth::user()->chatMessages()->get();

//        $topics = QaTopic::where(function ($query) {
//                    $query
//                    ->where('creator_id', Auth::id())
//                    ->orWhere('receiver_id', Auth::id());
//                })
//                ->orderBy('created_at', 'ASC')
//                ->get();
        $title = trans('global.all_messages');
        $unreads = $this->unreadTopics();

        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();

        if ($topics->first()) {
            foreach ($topics->first()->messages as $message) {
                if ($message->sender_id !== Auth::id() && $message->read_at === null) {
                    $message->read_at = Carbon::now();
                    $message->save();
                }
            }
        }


        return view('common.messenger.index', compact('topics', 'title', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }

    public function createTopic() {

        $users = User::all()->except(Auth::id());
        $unreads = $this->unreadTopics();
        return view('common.messenger.create', compact('users', 'unreads'));
    }

    public function storeTopic(QaTopicCreateRequest $request) {
        $subject = Str::limit($request->input('content'), $limit = 10, $end = '...');
        $topic = QaTopic::create([
                    'subject' => $subject,
                    'creator_id' => Auth::id(),
                    'receiver_id' => $request->input('recipient'),
        ]);

//        dd($request->input('recipient'));
        $topic->messages()->create([
            'sender_id' => Auth::id(),
            'content' => $request->input('content'),
        ]);

        $receiver_user = User::findOrFail($request->input('recipient'));
        $receiver_user->notify(new NewMessageNotification($topic));
//        return redirect()->back();
        return redirect()->route('messenger.showMessages', $topic);
    }

    public function showMessages(QaTopic $topic) {
        $topics = Auth::user()->chatMessages()->get();
        $unreads = $this->unreadTopics();
        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();

        if ($topic) {
            foreach ($topic->messages as $message) {
                if ($message->sender_id !== Auth::id() && $message->read_at === null) {
                    $message->read_at = Carbon::now();
                    $message->save();
                }
                foreach (Auth::user()->unreadNotifications as $notification) {
                    if ($notification->type == 'App\Notifications\NewMessageNotification') {
                        $notification->markAsRead();
                    }
                }
            }
        }
        return view('common.messenger.show', compact('topics', 'topic', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }

    public function newMessages(User $user) {
        $topics = Auth::user()->chatMessages()->get();
        foreach ($topics as $topic) {
            if ($topic->receiverOrCreator()->id == $user->id) {
                return redirect()->route('messenger.showMessages', $topic);
            }
        }

        $unreads = $this->unreadTopics();
        $adminUsers = User::admin()->get();
        $sellerUsers = User::seller()->get();
        $moderatorUsers = User::moderator()->get();
        $chatuser = $user;

        return view('common.messenger.create', compact('topics', 'chatuser', 'unreads', 'adminUsers', 'sellerUsers', 'moderatorUsers'));
    }

    public function destroyTopic(QaTopic $topic) {
        $this->checkAccessRights($topic);

        $topic->delete();

        return redirect()->route('messenger.index');
    }

    public function replyToTopic(QaTopicReplyRequest $request, QaTopic $topic) {
//        $this->checkAccessRights($topic);
// dd($request);
        $message = $topic->messages()->create([
            'sender_id' => Auth::id(),
            'content' => $request->input('content'),
        ]);

        if ($topic->receiver_id == Auth::id()) {
            $notification_reciver = $topic->creator_id;
        } else {
            $notification_reciver = $topic->receiver_id;
        }
        if ($request->hasFile('picture')) {
            $input['picture'] = $this->storeMedia($request, 'picture');
            if ($input['picture']) {
                $message->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
            }
        }

        $receiver_user = User::findOrFail($notification_reciver);
        $receiver_user->notify(new NewMessageNotification($topic));

        return redirect()->route('messenger.showMessages', $topic);
//        return redirect()->route('messenger.index');
    }

    public function showReply(QaTopic $topic) {
        $this->checkAccessRights($topic);

        $receiverOrCreator = $topic->receiverOrCreator();

        if ($receiverOrCreator === null || $receiverOrCreator->trashed()) {
            abort(404);
        }

        $unreads = $this->unreadTopics();

        return view('common.messenger.reply', compact('topic', 'unreads'));
    }

    public function unreadTopics(): array {
        $topics = QaTopic::where(function ($query) {
                    $query
                    ->where('creator_id', Auth::id())
                    ->orWhere('receiver_id', Auth::id());
                })
                ->with('messages')
                ->orderBy('created_at', 'DESC')
                ->get();

        $inboxUnreadCount = 0;
        $outboxUnreadCount = 0;

        foreach ($topics as $topic) {
            foreach ($topic->messages as $message) {
                if (
                        $message->sender_id !== Auth::id() && $message->read_at === null
                ) {
                    if ($topic->creator_id !== Auth::id()) {
                        $inboxUnreadCount++;
                    } else {
                        $outboxUnreadCount++;
                    }
                }
            }
        }

        return [
            'inbox' => $inboxUnreadCount,
            'outbox' => $outboxUnreadCount,
        ];
    }

    private function checkAccessRights(QaTopic $topic) {
        $user = Auth::user();

        if ($topic->creator_id !== $user->id && $topic->receiver_id !== $user->id) {
            return abort(401);
        }
    }

}
