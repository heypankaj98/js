<div class="sidebar-menu-content">
  <a href="{{ route('admin.home') }}" class="btn btn-warning w-100 sidebar-title">
                {{ trans('common.admin') }} {{ trans('common.panel') }}
            </a>

<div class="sidebar-container">
    <ul class="siddebar-menu">
<!--       <li>
            <a href="{{ route('admin.home') }}" class="btn btn-light my-3 active">
                {{ trans('common.admin') }} {{ trans('common.panel') }}
            </a>
        </li>-->
        <li>
            <a class="mb-2 d-block">
                <b>&#9900;</b>
                <strong>{{ trans('common.product') }} {{ trans('common.management') }}</strong>
            </a>
            <ul class="ds-nav-dropdown-items">
    @can('admin_product_management_access')
    <li class="nav-item">
        <a href="{{ route('admin.products.index') }}" class="nav-link {{ request()->is('admin/products') || request()->is('admin/products/*') ? 'text-primary' : '' }}">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list">
                <line x1="8" y1="6" x2="21" y2="6"></line>
                <line x1="8" y1="12" x2="21" y2="12"></line>
                <line x1="8" y1="18" x2="21" y2="18"></line>
                <line x1="3" y1="6" x2="3.01" y2="6"></line>
                <line x1="3" y1="12" x2="3.01" y2="12"></line>
                <line x1="3" y1="18" x2="3.01" y2="18"></line>
            </svg> 
            {{ trans('cruds.product.title') }}
        </a>
    </li>
    @endcan

    @can('admin_product_category_access')
    <li class="nav-item">
        <a href="{{ route('admin.product-categories.index') }}" class="nav-link {{ request()->is('admin/product-categories') || request()->is('admin/product-categories/*') ? 'text-primary' : '' }}">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-grid">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
            </svg>  
            {{ trans('cruds.productCategory.title') }}
        </a>
    </li>

    <li class="nav-item">
        <a href="{{ route('admin.comission') }}" class="nav-link {{ request()->is('admin/commission-settings') || request()->is('admin/commission-settings/*') ? 'text-primary' : '' }}">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg> 
            {{ trans('common.commossion_setting') }}
        </a>
    </li>
    @endcan
</ul>

        </li>
    
        
        @can('admin_user_management_access')
        <li>
            <a href="">
                <strong>{{ trans('common.user') }} {{ trans('common.management') }}</strong>
            </a>
            <ul class="ds-nav-dropdown-items">

                @can('admin_user_access')
                <li class="nav-item">
                    <a href="{{ route("admin.users.index") }}" class="nav-link {{ request()->is("admin/users") || request()->is("admin/users/*") ? "text-primary" : "" }}">
                    
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    {{ trans('cruds.user.title') }}
                    </a>
                </li>
                @endcan
 <li class="nav-item">
                    <a href="{{ route('admin.profile.index') }}" class="nav-link {{ Route::is('user.profile.index') ? 'text-primary' : '' }}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
                         <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path></svg>    
                    {{ trans('common.profile') }}
                    </a>
                </li>
                @can('admin_permission_access')
                <li class="nav-item">
                    <a href="{{ route("admin.permissions.index") }}" class="nav-link {{ request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "text-primary" : "" }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-key"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path></svg>
                        {{ trans('cruds.permission.title') }}
                    </a>
                </li>
                @endcan
@can('admin_permission_access')
    <li class="nav-item">
            <a href="{{ route('admin.sellerlist') }}" class="nav-link {{ request()->is('admin/sellerlist') ? 'text-primary' : '' }}">
                <img src="{{ asset('assets/verify.png') }}" style="width:23px;">
                Verify Seller
            </a>

    </li>
@endcan


                  @can('admin_permission_access')
            <li class="nav-item">
    <a href="{{ route('admin.sellerrequest') }}" class="nav-link {{ request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'text-primary' : '' }}">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-paper-plane">
            <path d="M2 2l20 10-20 10 3-10L2 2z"></path>
        </svg>
        Seller Request
    </a>
</li>
 @endcan

                @can('admin_role_access')
                <li class="nav-item">
                    <a href="{{ route("admin.roles.index") }}" class="nav-link {{ request()->is("admin/roles") || request()->is("admin/roles/*") ? "text-primary" : "" }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-check"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>                        {{ trans('common.user') }} {{ trans('cruds.role.title') }}
                    </a>
                </li>
                @endcan

            </ul>
        </li>
        @endcan
        
    
                
        @can('admin_user_communication_access')
        <li>
            <a class="">
                <strong>{{ trans('common.communication') }} {{ trans('common.management') }}</strong>
            </a>
            <ul class="ds-nav-dropdown-items">
                <li class="nav-item">
                    <a href="{{ route("admin.messenger.index") }}" class="{{ request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "text-primary" : "" }} nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-messages">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10"></path>
                         <path d="M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2"></path></svg>  
                    {{ trans('common.messages') }}
                        @php($unread = \App\Models\QaTopic::unreadCount())
                        @if($unread > 0)
                            <strong>( {{ $unread }} )</strong>
                        @endif
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href= "{{ route("admin.tickets.index") }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-ticket"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M15 5l0 2"></path><path d="M15 11l0 2"></path><path d="M15 17l0 2"></path><path d="M5 5h14a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-3a2 2 0 0 0 0 -4v-3a2 2 0 0 1 2 -2"></path></svg>    
                     
                    {{ trans('common.tickets') }}
                    </a>
                </li>
                
                @can('admin_error_access')
                <li class="nav-item">
                    <a class="nav-link" href="{{route('admin.error')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-triangle"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                    {{ trans('common.errors') }}
                    </a>
                </li>
                @endcan
                
                <li class="nav-item">
                    <a href="{{ route('admin.dispute') }}" class="nav-link {{ request()->is("admin/disputes") || request()->is("admin/disputes/*") ? "text-primary" : "" }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-friends-off">
                         <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                         <path d="M5 5a2 2 0 0 0 2 2m2 -2a2 2 0 0 0 -2 -2"></path>
                         <path d="M5 22v-5l-1 -1v-4a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4l-1 1v5"></path>
                         <path d="M17 5m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path>
                         <path d="M15 22v-4h-2l1.254 -3.763m1.036 -2.942a1 1 0 0 1 .71 -.295h2a1 1 0 0 1 1 1l1.503 4.508m-1.503 2.492v3"></path>
                         <path d="M3 3l18 18"></path></svg>   
                    {{ trans('common.disputes') }}
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="{{ route('admin.canery.show') }}" class="nav-link">
                    
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-hash"><line x1="4" y1="9" x2="20" y2="9"></line><line x1="4" y1="15" x2="20" y2="15"></line><line x1="10" y1="3" x2="8" y2="21"></line><line x1="16" y1="3" x2="14" y2="21"></line></svg>   
                    {{ trans('common.canary') }}
                    </a>
                </li>
     
          <li class="nav-item">
                   <a href="#" class="nav-link ">
                        <img src="{{ asset('assets/edit.png')}}">
                        Edit Mirror
                        </a>
                        </li>
           </ul>
        </li>
        @endcan
        
        @can('admin_ads_access')
        <li>
            <a class="">
                <strong>{{ trans('common.ads') }} {{ trans('common.management') }}</strong>
            </a>
            <ul class="ds-nav-dropdown-items">
                <li class="nav-item">
                    <a href="{{ route("admin.ads.index") }}" class="nav-link">
                 <svg id="Gui-Management--Streamline-Carbon" xmlns="http://www.w3.org/2000/svg" viewBox="-0.5 -0.5 16 16" height="20" width="20"><path d="M14.0625 11.25v-0.9375h-0.9848906250000001a2.3286562500000003 2.3286562500000003 0 0 0 -0.343078125 -0.8216718749999999l0.6984375 -0.6984375 -0.6628124999999999 -0.6628124999999999 -0.6984375 0.6984375a2.3286562500000003 2.3286562500000003 0 0 0 -0.8217187499999999 -0.343125V7.5h-0.9375v0.9848906250000001a2.3286562500000003 2.3286562500000003 0 0 0 -0.8216718749999999 0.343078125l-0.6984375 -0.6984375 -0.6628124999999999 0.6628124999999999 0.6984375 0.6984375a2.3286562500000003 2.3286562500000003 0 0 0 -0.343125 0.8217187499999999H7.5v0.9375h0.9848906250000001a2.3286562500000003 2.3286562500000003 0 0 0 0.343078125 0.8216718749999999l-0.6984375 0.6984375 0.6628124999999999 0.6628124999999999 0.6984375 -0.6984375a2.3286562500000003 2.3286562500000003 0 0 0 0.8217187499999999 0.343125V14.0625h0.9375v-0.9848906250000001a2.3286562500000003 2.3286562500000003 0 0 0 0.8216718749999999 -0.343078125l0.6984375 0.6984375 0.6628124999999999 -0.6628124999999999 -0.6984375 -0.6984375a2.3286562500000003 2.3286562500000003 0 0 0 0.343125 -0.8217187499999999Zm-3.28125 0.9375a1.40625 1.40625 0 1 1 1.40625 -1.40625 1.4077968749999998 1.4077968749999998 0 0 1 -1.40625 1.40625Z" stroke-width="1"></path><path d="M13.125 1.875H1.875a0.9384374999999999 0.9384374999999999 0 0 0 -0.9375 0.9375v9.375a0.938578125 0.938578125 0 0 0 0.9375 0.9375h4.6875v-0.9375H1.875V5.625h11.25v1.40625h0.9375V2.8125a0.938578125 0.938578125 0 0 0 -0.9375 -0.9375Zm0 2.8125H1.875V2.8125h11.25Z" stroke-width="1"></path><path d="M8.90625 3.75a0.46875 0.46875 0 1 0 0.9375 0 0.46875 0.46875 0 1 0 -0.9375 0" stroke-width="1"></path><path d="M10.3125 3.75a0.46875 0.46875 0 1 0 0.9375 0 0.46875 0.46875 0 1 0 -0.9375 0" stroke-width="1"></path><path d="M11.71875 3.75a0.46875 0.46875 0 1 0 0.9375 0 0.46875 0.46875 0 1 0 -0.9375 0" stroke-width="1"></path></svg>
                    {{ trans('common.management') }}
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route("admin.gift-cards.index") }}" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-gift"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M3 8m0 1a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1z"></path><path d="M12 8l0 13"></path><path d="M19 12v7a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-7"></path><path d="M7.5 8a2.5 2.5 0 0 1 0 -5a4.8 8 0 0 1 4.5 5a4.8 8 0 0 1 4.5 -5a2.5 2.5 0 0 1 0 5"></path></svg>    
                    {{ trans('common.cards') }}
                    </a>
                </li>
            </ul>
        </li>
        @endcan
                    
        @can('admin_payment_access')
        <li>
            <a href="">
                <strong>{{ trans('common.payment') }} {{ trans('common.management') }}</strong>
            </a>
            <ul class="ds-nav-dropdown-items">
                <li class="nav-item">
                    <a class="nav-link" href="/balances">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>   
                    {{ trans('common.balances') }}
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{route('admin.payouts')}}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-credit-card"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
                    {{ trans('common.payouts') }}
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/invoices">
                                       <svg xmlns="http://www.w3.org/2000/svg" viewBox="-0.5 -0.5 16 16" fill="currentColor" id="Invoice--Streamline-Phosphor" height="20" width="20"><desc>Invoice Streamline Icon: https://streamlinehq.com</desc><path d="M0.96666796875 7.772220703125001c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.097259765625 -0.168439453125 0.276990234375 -0.272203125 0.47149218749999994 -0.272203125h1.9055566406250002c0.419109375 -0.000017578125 0.68105859375 -0.45373242187499996 0.47148632812499996 -0.8166855468750001 -0.09725390625 -0.16843359375 -0.27699609375 -0.27219140625000005 -0.47148632812499996 -0.272203125H1.7833359375C0.525990234375 5.593693359375 -0.25903125 4.232109374999999 0.370294921875 3.143595703125c0.291720703125 -0.50457421875 0.8302031249999999 -0.8154667968749999 1.413041015625 -0.8158183593749999 0 -0.419115234375 0.453703125 -0.68105859375 0.816662109375 -0.47150390625000005 0.168451171875 0.097259765625 0.2722265625 0.27699609375 0.2722265625 0.47150390625000005h0.54444140625c0.419115234375 0.000017578125 0.681064453125 0.45373242187499996 0.47149218749999994 0.81669140625 -0.097259765625 0.168439453125 -0.276990234375 0.272197265625 -0.47149218749999994 0.272197265625H1.7833359375c-0.419115234375 0.000017578125 -0.681064453125 0.45373242187499996 -0.47149218749999994 0.81669140625 0.09725390625 0.168427734375 0.27699609375 0.27219140625000005 0.47149218749999994 0.272197265625h1.088888671875c1.25733984375 0.000755859375 2.0423613281249997 1.3623398437499998 1.41303515625 2.45084765625 -0.29171484375 0.50457421875 -0.8302031249999999 0.8154726562500001 -1.41303515625 0.8158183593749999 0 0.419115234375 -0.45370898437499996 0.68105859375 -0.8166679687499999 0.47150390625000005 -0.168451171875 -0.09725390625 -0.272220703125 -0.276990234375 -0.272220703125 -0.47150390625000005ZM14.85 2.872224609375v9.25555078125c0 0.6013593749999999 -0.48752929687499996 1.088865234375 -1.088888671875 1.088888671875H1.7833359375c-0.601400390625 0.000029296875 -1.088888671875 -0.48748828125000004 -1.088888671875 -1.088888671875v-2.72221875c0 -0.419115234375 0.453703125 -0.68105859375 0.816662109375 -0.47150390625000005 0.168451171875 0.09725390625 0.2722265625 0.276990234375 0.2722265625 0.47150390625000005v2.72221875h8.166662109375v-2.17777734375H4.5055546875c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.097259765625 -0.168439453125 0.276990234375 -0.272203125 0.47149218749999994 -0.272203125h5.444443359375v-2.17777734375h-3.811107421875c-0.419115234375 -0.000017578125 -0.681064453125 -0.45373242187499996 -0.47149218749999994 -0.8166855468750001 0.09725390625 -0.16843359375 0.27699609375 -0.27219140625000005 0.47149218749999994 -0.272203125h7.622220703125V3.416666015625H5.594443359375c-0.419115234375 0.000017578125 -0.681052734375 -0.453673828125 -0.471515625 -0.81664453125 0.09725390625 -0.168462890625 0.27699609375 -0.272244140625 0.471515625 -0.272244140625h8.711109375c0.30067968749999996 0.00001171875 0.544447265625 0.24376757812500002 0.544447265625 0.544447265625Zm-3.8111132812500004 5.988884765625h2.722224609375v-2.17777734375H11.03888671875Zm2.722224609375 3.2666660156250003v-2.17777734375H11.03888671875v2.17777734375Z" stroke-width="1"></path></svg>
                    {{ trans('common.invoices') }}
                    </a>
                </li>
            </ul>
        </li>
    
                <ul class="ds-nav-dropdown-items">
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link" href="/analytics/stats">-->
            <!--        {{ trans('common.analytics') }}-->
            <!--    </a>-->
            <!--</li>-->
                            
            <li class="nav-item">
                <a class="nav-link" href="{{route('admin.node.info')}}">
               
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-hexagon"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path></svg>
                {{ trans('common.node') }}
                </a>
            </li>
        </ul>
        @endcan
    </ul>
</div>
</div>