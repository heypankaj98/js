<?php

use BitcoinPHP\BitcoinECDSA\BitcoinECDSA;

// Generate public and private keys
function generateKeys() {
    $bitcoinECDSA = new BitcoinECDSA();
    $bitcoinECDSA->generateRandomPrivateKey(); // Generate a random private key
    $privateKey = $bitcoinECDSA->getPrivateKey();
    $publicKey = $bitcoinECDSA->getPubKey();
    return ['private_key' => $privateKey, 'public_key' => $publicKey];
}

// Usage example
$keys = generateKeys();
$privateKey = $keys['private_key'];
$publicKey = $keys['public_key'];

echo "Private Key: " . $privateKey . "\n";
echo "Public Key: " . $publicKey . "\n";
