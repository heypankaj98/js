<!DOCTYPE html>
<html lang="en" @if(session()->has('theme'))  data-bs-theme="{{ Session::get('theme') }}" @endif>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/x-icon" href="{{ asset('fev.ico') }}">
        <link href="{{ asset('css/bootstrap-5.3/css/bootstrap.css') }}" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
        <link href="{{ asset('css/kk.css') }}" rel="stylesheet">
        <link href="{{ asset('css/main.css') }}" rel="stylesheet">
        <title>{{ trans('common.user') }} {{ trans('common.panel') }} | {{ trans('global.site_title') }}</title>
    </head>
    <body>
         <div class="">
        <section class="ds-dasboard">
            <div class="header-ds">
                @include('layouts.buyer.topbar')
            </div>
            <div class="container">
               
                    <div class="row">
                        <div class=" col-md-12 col-lg-3">
                            @include('layouts.buyer.sidebar')
                        </div>
                        <div class="col-md-12 col-lg-9 ps-4">
                            @if (session('success'))
                                <div id="alert_message" class="alert alert-success alert-block">
                                    <strong>{{ session('success') }}</strong>
                                </div>
                            @endif
                            @if (session('error'))
                                <div id="alert_message" class="alert alert-danger alert-block">
                                    <strong>{{ session('error') }}</strong>
                                </div>
                            @endif
                            @yield("content")
                        </div>
                    </div>
                </div>
           
        </section>
        @include('layouts.pagefooter')
                    </div>
    </body>
</html>