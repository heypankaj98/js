<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin\src\Exceptions;

use RuntimeException;

class ClientException extends RuntimeException
{
}
