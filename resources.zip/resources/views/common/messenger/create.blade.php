@extends('common.messenger.template')   @section('messenger-content')

<div class="bg-card-1 p-24 mb-0">
    <div class="row h-100">
        <div class="col-md-3">
            <div class="d-flex flex-column h-100 bg-card-2">
                <div class="">
                    <div>
                        
                        <h5 class="mb-2 ">{{ trans('common.channels') }}</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">#{{ trans('common.general') }}</a></li>
                            <li><a href="#">#{{ trans('common.announcements') }}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="mt-auto">
                    <h5 class=" mb-3 mt-4">{{ trans('common.chat') }} {{ trans('common.user') }}</h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                            <li class="mb-2">
                                <a href="{{ route('messenger.showMessages', [$singletopic->id]) }}">
                            <div class="user_info">
                            @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">
                                <div class="d-flex flex-column gap-1">
                                <span>
                                                {{ $singletopic->receiverOrCreator()->username }} ( {{ $singletopic->mesasgeUnreadCount() }} )
                                            </span>
                                    <p class="small mb-0">{{ trans('common.online') }}</p>
                                </div>
                                @endif
                            </div>
                        </a>
                            </li>
                        @empty
                            {{ trans('common.no') }} {{ trans('common.chat') }} {{ trans('common.user') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="bg-card-2">
                <div class="card-header">
                    <h5>{{ trans('common.chat') }}: <span class="btn text-bg-primary">{{ $chatuser->username }}</span></h5>
                </div>
                <div class="card-footer">
                    <form action="{{ route("messenger.storeTopic") }}" method="POST">
                        @csrf
                        <input type='hidden' name="recipient" value='{{$chatuser->id}}'>
                        <textarea type="text" class="form-control-textarea" name="content" placeholder="{{ trans('messages.text_placeholder') }}..."></textarea>
                        <button type="submit" class="btn btn-main">{{ trans('common.send') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12 bg-danger text-white ">
            <div class="bg-card-2 mt-4 admin_user_part">
                <button class="btn btn-main mb-3 raw1">{{ trans('common.admin') }} {{ trans('common.users') }}</button>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                        @if (auth()->user()->id != $adminuser->id)
                            @if($adminuser->withChatMessages($adminuser->id) > 0)
                                <a href="{{ route('messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                                    <span class="badge text-bg-main m-1">{{ $adminuser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('messenger.newMessages', [$adminuser->id]) }}">
                                    <span class="badge text-bg-main m-1">{{ $adminuser->username }}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                        {{ trans('common.no') }} {{ trans('common.admin') }} {{ trans('common.users') }}
                    @endforelse
                </ul>
            </div>
            <div class="bg-card-2 mt-4">
                <button class="btn btn-main mb-3 raw1">{{ trans('common.moderator') }} {{ trans('common.users') }}</button>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                        @if (auth()->user()->id != $moduser->id)
                            @if($moduser->withChatMessages($moduser->id) > 0)
                                <a href="{{ route('messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">
                                    <span class="badge text-bg-main">{{ $moduser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('messenger.newMessages', [$moduser->id]) }}">
                                    <span class="badge text-bg-main">{{ $moduser->username}}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                        {{ trans('common.no') }} {{ trans('common.chat') }} & {{ trans('common.moderator') }} {{ trans('common.users') }}
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>
@stop