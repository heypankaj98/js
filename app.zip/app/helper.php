<?php

use Spatie\QueryString\QueryString;

function toggle(string $name, $toggleValue = null): QueryString {
    $queryString = app(QueryString::class);

    return $queryString
                    ->toggle($name, $toggleValue);
}

function clearQueryString(string $name) {
    $queryString = app(QueryString::class);

    return $queryString->clear($name);
}

function createAvatar() {
// Set the size of the avatar image
    $size = 300;

    die(asset('fev.ico'));
// Load the existing image
    $source_image = imagecreatefromjpeg('path/to/image.jpg');

// Create a blank image
    $image = imagecreatetruecolor($size, $size);

// Generate a random color for the background
    $red = mt_rand(0, 255);
    $green = mt_rand(0, 255);
    $blue = mt_rand(0, 255);
    $background_color = imagecolorallocate($image, $red, $green, $blue);

// Fill the background with the random color
    imagefill($image, 0, 0, $background_color);

// Resize the source image to fit the avatar size
    $source_width = imagesx($source_image);
    $source_height = imagesy($source_image);
    if ($source_width > $source_height) {
        $new_width = $size;
        $new_height = $size * $source_height / $source_width;
    } else {
        $new_height = $size;
        $new_width = $size * $source_width / $source_height;
    }
    $resized_image = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($resized_image, $source_image, 0, 0, 0, 0, $new_width, $new_height, $source_width, $source_height);

// Generate a random shape for the avatar
    $shape = mt_rand(1, 3);
    switch ($shape) {
        case 1:
            // Draw a circle
            $diameter = $size * 0.8;
            $x = ($size - $diameter) / 2;
            $y = ($size - $diameter) / 2;
            $shape_color = imagecolorallocate($image, 255 - $red, 255 - $green, 255 - $blue);
            imagefilledellipse($image, $size / 2, $size / 2, $diameter, $diameter, $shape_color);
            break;
        case 2:
            // Draw a square
            $side = $size * 0.8;
            $x = ($size - $side) / 2;
            $y = ($size - $side) / 2;
            $shape_color = imagecolorallocatealpha($image, $red, $green, $blue, 80);
            imagefilledrectangle($image, $x, $y, $x + $side, $y + $side, $shape_color);
            break;
        case 3:
            // Draw a triangle
            $side = $size * 0.8;
            $x = ($size - $side) / 2;
            $y = ($size - $side) / 2;
            $shape_color = imagecolorallocate($image, 255 - $red, 255 - $green, 255 - $blue);
            $points = array($x + $side / 2, $y, $x + $side, $y + $side, $x, $y + $side);
            imagefilledpolygon($image, $points, 3, $shape_color);
            break;
    }

// Place the resized image onto the avatar
    $x = ($size - $new_width) / 2;
    $y = ($size - $new_height) / 2;
    imagecopy($image, $resized_image, $x, $y, 0, 0, $new_width, $new_height);

// Output the image to the browser
    header('Content-Type: image/png');
    imagepng($image);

// Free up memory
    imagedestroy($image);
}
