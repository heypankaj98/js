<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BuyerController extends Controller
{
    // Show the verification form
    public function verifypgp() {
        return view('buyer.verifybuyer');
    }

    // Handle the PGP key verification
    public function verifyPgpKey(Request $request) {
        // Validate the PGP key from the request
        $request->validate([
            'pgp_key' => 'required|string',
        ]);

        // Check if the PGP key already exists in the users table
        $pgpKeyExists = DB::table('users')->where('pgp_key', $request->pgp_key)->exists();

        if ($pgpKeyExists) {
            return redirect()->back()->withErrors(['pgp_key' => 'This PGP key has already been used with us.']);
        }

        // If the key doesn't exist, you can proceed with your logic (e.g., storing it)
        // Example: DB::table('users')->where('id', $userId)->update(['pgp_key' => $request->pgp_key]);

        return redirect()->back()->with('success', 'PGP key verified successfully.');
    }
}
