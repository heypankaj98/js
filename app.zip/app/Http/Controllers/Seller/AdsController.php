<?php

namespace App\Http\Controllers\Seller;

use App\Models\User;
use App\Models\SellerAdvertisement;
use App\Models\Product;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;

class AdsController extends Controller
{
    // Display the seller's advertisements
public function index()
{
    $seller_id = Auth::id(); // Get the logged-in seller's ID
    $selected_user = User::find(auth()->id());
    $ads = SellerAdvertisement::where('seller_id', $seller_id)->get(); // Get seller's ads
    $vendorAd = SellerAdvertisement::where('seller_id', $seller_id)->first(); // Assuming you want a single vendor ad
    $products = Product::where('seller_id', $seller_id)->get();
     $productAds = SellerAdvertisement::where('seller_id', $seller_id)
        ->where('status', 'active') // Assuming 'active' means an active advertisement
        ->get();

    return view('seller.ads.index', compact('ads', 'products', 'selected_user', 'vendorAd','productAds'));
}

    // Store a new product advertisement
   public function store(Request $request)
{
    $request->validate([
        'product_id' => 'required|exists:products,id', // Ensure the product exists
    ]);

    // Fetch the authenticated seller
    $seller = auth()->user();

    // Check if the seller already has an advertisement for the given product
    $existingAd = SellerAdvertisement::where('seller_id', $seller->id)
        ->where('product_id', $request->product_id)
        ->first();

    if ($existingAd) {
        return redirect()->back()->with('error', 'You have already created an advertisement for this product.');
    }

    // Create the advertisement
    $advertisement = new SellerAdvertisement();
    $advertisement->seller_id = $seller->id;
    $advertisement->product_id = $request->product_id;
    $advertisement->save();

    return redirect()->route('ads.index')->with('success', 'Advertisement created successfully!');
}


    // Update a product advertisement
    public function update(Request $request, $id)
    {
        try {
            $ad = SellerAdvertisement::findOrFail($id);

            $request->validate([
                'ad_title' => 'required|string|max:255',
                'ad_description' => 'nullable|string',
            ]);

            $ad->update([
                'title' => $request->ad_title,
                'description' => $request->ad_description,
            ]);

            return redirect()->route('seller.ads.index')->with('success', 'Advertisement updated successfully!');
        } catch (\Exception $e) {
            return back()->with('error', 'Something went wrong! Please try again.');
        }
    }

    // Toggle advertisement status
    public function toggle($ad_id)
    {
        try {
            $ad = SellerAdvertisement::findOrFail($ad_id);

            $ad->status = $ad->status === 'active' ? 'inactive' : 'active';
            $ad->save();

            return redirect()->route('seller.ads.index')->with('success', 'Advertisement status updated successfully!');
        } catch (\Exception $e) {
            return back()->with('error', 'Something went wrong! Please try again.');
        }
    }

    // Store a personalized vendor banner
    public function storePersonalBanner(Request $request, $ad_id)
    {
        try {
            $request->validate([
                'banner' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

            $seller = Auth::user();

            $advertisement = SellerAdvertisement::firstOrNew(
                ['seller_id' => $seller->id, 'type' => 'vendor'],
                ['status' => 'inactive']
            );

            if ($request->hasFile('banner')) {
                $advertisement->banner = $this->storeMedia($request, 'banner');
            }

            $advertisement->save();

            return redirect()->route('seller.ads.index')->with('success', 'Personalized banner uploaded successfully!');
        } catch (\Exception $e) {
            return back()->with('error', 'Something went wrong! Please try again.');
        }
    }

    // Store media helper function
    protected function storeMedia(Request $request, $field)
    {
        if ($request->hasFile($field)) {
            return $request->file($field)->store('advertisements', 'public');
        }
        return null;
    }
    public function createAdvertisement(Request $request)
{
    // Validate the incoming request
    $request->validate([
        'advertisement_product_id' => 'required|exists:products,id', // Ensure the product exists
    ]);

    // Fetch the authenticated seller
    $seller = auth()->user();

    // Check if the seller already has an advertisement for the given product
    $existingAd = SellerAdvertisement::where('seller_id', $seller->id)
        ->where('product_id', $request->advertisement_product_id)
        ->first();

    if ($existingAd) {
        return redirect()->back()->with('error', 'You have already created an advertisement for this product.');
    }

    // Find the product based on the provided product_id
    $product = Product::findOrFail($request->advertisement_product_id);

    // Create a new advertisement instance
    $advertisement = new SellerAdvertisement();
    $advertisement->seller_id = $seller->id; // Use the seller's ID
    $advertisement->product_id = $product->id; // Use the product being advertised
    $advertisement->title = $product->name; // Use the product's name as the advertisement title
    $advertisement->status = 'inactive'; // Default to inactive status

    // Save the advertisement to the database
    $advertisement->save();

    return redirect()->back()->with('success', 'Advertisement created successfully!');
}

}
