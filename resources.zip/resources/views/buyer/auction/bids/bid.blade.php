@extends('layouts.buyer.app')     @section('content')

<div class="col-md-12 my-4">
    @if (session('success'))
    <div id="alert_message" class="alert alert-success alert-block">
        <strong>{{session('success')}}</strong>
    </div>
    @elseif(session('error'))
    <div id="alert_message" class="alert alert-danger alert-block">
        <strong>{{ session('error') }}</strong>
    </div>
    @endif
</div>

<div class="col-lg-12 col-xl-12   bid_blade_main">
    <div class="card">
   <div class="card-header bg-success text-white px-4 py-5">
            <h5 class=" mb-0"> {{ trans('global.thanks_for_you') }}  <span>{{ Auth::user()->username }}</span>!</h5>
        </div>
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <p class="lead fw-normal mb-0" > {{ trans('global.auction_start_time') }}  {{ Carbon\Carbon::parse($bid->auction->start_time)->format('j-M-Y g:i A') }}</p>
                <p class="lead fw-normal mb-0" > {{ trans('global.auction_close_time') }}  {{ Carbon\Carbon::parse($bid->auction->end_time)->format('j-M-Y g:i A') }}</p>
            </div>
            <div class="card shadow-0 border mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            @if($bid->auction->photo)
                                <img src="{{ $bid->auction->photo->getUrl('thumb') ?? '' }}" class="img-fluid" alt="Phone">
                            @else
                                <img src="{{ asset('/assets/img/product-default.jpg') }}" class="img-fluid">
                            @endif
                        </div>
                        <div class="col-md-3 d-flex justify-content-center align-items-center">
                            <p class="text-muted mb-0">{{ $bid->auction->name }}</p>
                        </div>
                        <div class="col-md-3 text-center d-flex justify-content-center align-items-center">
                            <p class="text-muted mb-0 small">{{ trans('global.type') }} {{ $bid->auction->type }}</p>
                        </div>
                        <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                            <p class="text-muted mb-0 small">{{ trans('global.qty') }}{{ $bid->auction->stock }}</p>
                        </div>
                        <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                            <p class="text-muted mb-0 small">$ {{ $bid->amount }}</p>
                        </div>
                    </div>
                    
                       <hr class="mb-4 hr_line" >
                    <div class="row d-flex align-items-center">
                        <div class="col-md-2">
                            <p class="text-muted mb-0 small">{{ trans('global.status:') }}  <span class="text-uppercase">{{ $bid->status }}</span></p>
                        </div>
                        <div class="col-md-10">
                            <div class="progress" >
                                <div class="progress-bar" role="progressbar"
                                      aria-valuenow="65"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex justify-content-around mb-1">
                                <p class="text-muted mt-1 mb-0 small ms-xl-5">{{ trans('global.payment_waiting') }} </p>
                                <p class="text-muted mt-1 mb-0 small ms-xl-5"> {{ trans('global.escrow') }}</p>
                                <p class="text-muted mt-1 mb-0 small ms-xl-5"> {{ trans('global.completed') }} </p>
                            </div>
                        </div>
                        <hr class="mb-4 hr_line" >
                        <div class="row d-flex align-items-center">
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 border">
                <div class='row'>
                    <div class='col-md-3 my-4'>
                        <h4 class="m-4"> {{ trans('global.your_bid_price') }} </h4>
                        <input class="btn btn-light col-12 f40 ml-4" value="$ {{ $bid->amount }}" disabled>
                    </div>
                    <div class='col-md-8 my-4'>
                        
                        @if($bid->status == 'waiting')
                            @if($bid->payment_method)
                                <div class='row'>
                                    <div class='col-8'>
                                        <strong>{{ trans('global.to_complete_the_order') }}</strong>
                                        <textarea class="badge-info col-12 textarea" rows="2"  readonly>{{ $bid->payment_address }}</textarea>
                                        <small> {{ trans('global.once_payment_is_done') }}</small>
                                        <hr>
                                        <div class="row">
                                            <div class="col-4">
                                                <strong> {{ trans('global.total_amount_to_pay') }}  </strong>
                                                <strong class="btn btn-dark col-11 mb-2"><b>{{ $bid->crypto_total }} {{ $bid->payment_method }}</b></strong>
                                            </div>
                                            <div class="col-4">
                                                <strong> {{ trans('global.payment_status') }}</strong>
                                                <strong class="btn btn-danger col-11 mb-2"><b>{{ trans('global.unpain') }}</b></strong>
                                            </div>
                                            <div class="col-4">
                                                <strong class="f16"> {{ trans('global.total_received_coins') }} </strong>
                                                <strong class="btn btn-success col-11 mb-2"><b>0.000000</b></strong>
                                            </div>
                                        </div>
                                        <div class='row'>
                                            <div class="col-3">
                                                <br>
                                                <a href="{{ route('user.bid.view', $bid->id) }}" class="btn btn-primary col-11">REFRESH&emsp;<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class='col-4 text-center'>
                                        <strong class="btn btn-warning col-12"><b>{{ $bid->payment_method }} {{ trans('global.address_qr') }} </b></strong>
                                        <div class="text-center col-12">
                                            <img alt="alt" src="https://chart.googleapis.com/chart?chs=350x350&cht=qr&chl={{ $bid->payment_address }}"/>
                                        </div>
                                    </div>
                                </div>
                            @else
                                <form class="needs-validation" action="{{ route('user.bid.payment', $bid->id) }}" method="POST">
                                    @csrf
                                    <h4 class="my-3">{{ trans('global.choose_a_payment') }} </h4>
                                    <div class="my-3">
                                        @foreach(config('coins.coin_list') as $index => $coin)
                                        <div class="form-check">
                                            <input id="credit" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>
                                            <label class="form-check-label" for="credit">{{$coin}} [{{$index}}]</label>
                                        </div>
                                        @endforeach
                                    </div>
                                    <small>{{ trans('global.note_bid_will') }} </small>
                                    <hr>
                                    <button class="w-100 btn btn-primary btn-lg" type="submit">{{ trans('global.generate_payment_address') }} </button>
                                </form>
                            @endif
                        @endif
                        
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between pt-2">
                <p class="fw-bold mb-0">{{ trans('global.bid_details') }} </p>
                <!--p class="text-muted mb-0"><span class="fw-bold me-4"></span> </p-->
            </div>

            <div class="d-flex justify-content-between pt-2">
                <p class="text-muted mb-0">{{ trans('global.invoice_number') }}  {{ $bid->id }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">{{ trans('global.bid_price') }}  </span> {{ $bid->amount }}.00</p>
            </div>

            <div class="d-flex justify-content-between">
                <p class="text-muted mb-0">{{ trans('global.invoice_date') }}   {{ $bid->created_at->format('j M,o') }}</p>
                <!--p class="text-muted mb-0"><span class="fw-bold me-4">Discount</span> $ 0.00</p-->
            </div>

            <!--div class="d-flex justify-content-between mb-5">
                <p class="text-muted mb-0">Recepits Voucher : 18KU-62IIK</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">Delivery Charges</span> Free</p>
            </div-->

             <hr class="mb-4 hr_line" >

            @if(in_array($bid->status, ['escrow','processing','shipped','delivered','completed']))
            <div class="d-flex justify-content-between pt-2">
                <p class="fw-bold mb-0"> {{ trans('global.escrow_detailse') }} </p>
            </div>
            

            <div class="d-flex justify-content-between pt-2">
                <p class="text-muted mb-0">{{ trans('global.payment_coin') }} {{ $bid->payment_method }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">{{ trans('global.total_bid_amount') }}  </span> {{ $bid->crypto_total }} {{ $bid->payment_method }}</p>
            </div>

            <div class="d-flex justify-content-between">
                <p class="text-muted mb-0">{{ trans('global.paid_on') }}  {{ $bid->paid_at }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4"> {{ trans('global.discount') }}  </span> 0.00000000 {{ $bid->payment_method }}</p>
            </div>

            <div class="d-flex justify-content-between mb-5">
                <p class="text-muted mb-0">{{ trans('global.payment_address') }} {{ $bid->payment_address }}</p>
                <p class="text-muted mb-0"><span class="fw-bold me-4">{{ trans('global.total_received_on_address') }} </span> {{ $bid->total_received }} {{ $bid->payment_method }}</p>
            </div>
            @endif
        </div>
        <div class="card-footer border-0 px-4 py-5">
            <h5 class="d-flex align-items-center justify-content-end text-white text-uppercase mb-0">
                
               {{ trans('global.total') }}  <span class="h3 mb-0 ms-2">$ {{ $bid->amount }}.00 USD</span>
            </h5>
            <br>
            <h5 class="d-flex align-items-center justify-content-end text-white text-uppercase mb-0">
                [{{-- $bid->crypto_total --}} 
                {{-- $bid->payment_method --}}]
            </h5>
        </div>
    </div>
</div>

@endsection