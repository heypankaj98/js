<?php

namespace Database\Seeders;

use App\Models\Settings;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class SettingsTableSeeder extends Seeder {

    public function run() {
        $settings = [
            [
                'id' => 1,
                'key' => 'become_seller_fee',
                'value' =>400,
            ],
            [
                'id' => 2,
                'key' => 'commission',
                'value' =>1,
            ],
            [
                'id' => 3,
                'key' => 'featured_product',
                'value' =>10,
            ],
        ];

        Settings::insert($settings);
    }

}
