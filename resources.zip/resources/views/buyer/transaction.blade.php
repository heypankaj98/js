@extends('layouts.buyer.app')     @section('content')

<div class="bg-card-1 p-24 br1 mt-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="">
                <div class="card-header-buyer">
                    {{ trans('common.transactions') }} {{ trans('common.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Product mb-4">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('common.id') }}
                                    </th>
                                    <th>
                                        {{ trans('common.crypto') }} {{ trans('common.address') }}
                                    </th>
                                    <th>
                                        {{ trans('common.crypto') }} {{ trans('common.transaction') }} {{ trans('common.id') }}
                                    </th>
                                    <th>
                                       {{ trans('common.type') }}
                                    </th>
                                    <th>
                                        {{ trans('common.crypto') }} {{ trans('common.name') }} 
                                    </th>
                                    <th>
                                        {{ trans('common.amount') }}
                                    </th>
                                    <th>
                                        {{ trans('common.transaction') }} {{ trans('common.date') }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                @forelse($transactions as $transaction)
                                    <tr data-entry-id="{{ $transaction->id }}">
                                        <td>
                                            {{ $transaction->id ?? '' }}
                                        </td>
                                        <td>
                                            {{ $transaction->crypto_address }}
                                        </td>
                                        <td>
                                            {{ $transaction->trx_id  }}
                                        </td>
                                        <td>
                                            {{ $transaction->type }}
                                        </td>
                                        <td>
                                            {{ $transaction->crypto_name ?? '' }}
                                        </td>
                                        <td>
                                            {{ $transaction->crypto_amount }}
                                        </td>
                                        <td>
                                            {{ $transaction->created_at->format('M, j Y g:i A') }}
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-center" colspan="100%">
                                            {{ trans('common.no') }} {{ trans('common.transactions') }}
                                        </td>
                                    </tr>
                                @endforelse
                                
                            </tbody>
                        </table>
                        {{ $transactions->links('partials.pagination') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection