<?php
namespace App\Providers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\{
    Schema,
    Blade,
    View
};
use App\Models\CryptoExchange;
use App\Models\Advertisement; // Import Advertisement model
use App\Helpers\ReputationHelper;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider {
    /**
     * Register any application services.
     */
    public function register(): void {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void {
        // Share authenticated user with all views
        view()->composer('*', function ($view) {
            $user = Auth::user();
            $view->with('user', $user);
        });

        // Share the first CryptoExchange instance with all views
        view()->composer('*', function ($view) {
            $cryptoExchange = CryptoExchange::first();
            $view->with('cryptoExchange', $cryptoExchange);
        });

        // Share seller reputation with the navbar view
        view()->composer('partials.navbar', function ($view) {
            $user = Auth::user();
            $completedPurchases = $user ? $user->completed_purchases ?? 0 : 0;
            $reputation = ReputationHelper::calculateReputationTier($completedPurchases);
            $view->with('reputation', $reputation);
        });

        // Share current UTC time globally
        view()->composer('*', function ($view) {
            $utcTime = Carbon::now('UTC')->format('Y-m-d H:i:s');
            $view->with('utcTime', $utcTime);
        });

        // Share active advertisements with all views (if needed globally)
        view()->composer('*', function ($view) {
            if (Auth::check()) {
                $user = Auth::user();
                if ($user->inRole('Seller')) {
                    // Get seller's active advertisements (optional)
                    $activeAds = Advertisement::where('seller_id', $user->id)
                        ->where('is_active', true)
                        ->get();
                    $view->with('activeAds', $activeAds);
                }
            }
        });

        // Set default string length for Schema
        Schema::defaultStringLength(191);

        // Blade custom directives
        Blade::if('seller', function () {
            return auth()->check() && auth()->user()->inRole('Seller');
        });

        Blade::if('buyer', function () {
            return auth()->check() && auth()->user()->inRole('Buyer');
        });

        Blade::if('staff', function () {
            return auth()->check() && auth()->user()->inRole('Moderator');
        });

        Blade::if('admin', function () {
            return auth()->check() && auth()->user()->inRole('Admin');
        });
    }
}
