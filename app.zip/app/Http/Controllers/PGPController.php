<?php
namespace App\Http\Controllers;

use App\Http\Requests\User\Settings\ChangePGPKeyRequest;

class PGPController {
    
    public function viewSetPGPKey() {
        $user = auth()->user();

        if (is_null($user->pgp_key)) {
            return view('setpgpkey');
        }

        return abort(404);
    }

    public function postSetPGPKey(ChangePGPKeyRequest $request) {
        try {
            return $request->createRequisition();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    public function putChangePGPKey(ChangePGPKeyRequest $request) {
        try {
            return $request->change();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    public function putSetPGPKey(ChangePGPKeyRequest $request) {
        try {
            return $request->change();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    public function cancelSetPGPKey() {
        if (session()->has('verification_name') and session()->get('verification_name') === 'confirm_new_pgp_key') {
            #Destroy verification sessions
            session()->forget(['pgp_key', 'verification_name', 'encrypted_message', 'verification_code']);
        }

        return redirect()->back();
    }

    public function cancelPGPKeyChange() {
        if (session()->has('verification_name') and session()->get('verification_name') === 'confirm_new_pgp_key') {
            #Destroy verification sessions
            session()->forget(['pgp_key', 'verification_name', 'encrypted_message', 'verification_code']);
        }

        return redirect()->route('user.profile.security', '#pgpkey');
    }
          public function security() {
        return view('buyer.security');
    }


  public function cancelPGPKeyChanges() {
        if (session()->has('verification_name') and session()->get('verification_name') === 'confirm_new_pgp_key') {
            #Destroy verification sessions
            session()->forget(['pgp_key', 'verification_name', 'encrypted_message', 'verification_code']);
        }

        return redirect()->route('user.security1', '#pgpkey');
    }

    public function postChangePGPKey(ChangePGPKeyRequest $request) {
        
        try {
            return $request->createRequisition();
        } catch (\Exception $exception) {
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }
    
    
    public function becomevendor(ChangePGPKeyRequest $request) {
      
    try {
        // Set session flag indicating that the request is from becomevendor
        session()->put('from_becomevendor', true); // Use put to make sure it's set
        
        return $request->becomevendor();
    } catch (\Exception $exception) {
        session()->flash('error', $exception->getMessage());
        return redirect()->back();
    
        
    }
}


}