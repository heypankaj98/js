<?php
use Modules\Forum\Http\Controllers\{ CategoryController, ThreadController, PostController, ForumController,PageController };
use App\Http\Middleware\DDoSCheck;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PGPController;
use App\Http\Controllers\AddPgpController;
use App\Http\Controllers\Seller\ReputationController;
use App\Http\Controllers\ProductReviewController;
use App\Http\Controllers\Buyer\OrderController;
use App\Http\Controllers\Admin\AdminController;
// use App\Http\Controllers\CurrencyConverterController;
use App\Http\Controllers\Admin\MirrorlinkController;
use App\Http\Controllers\Seller\SellerMarketplaceController;
use App\Http\Controllers\Admin\VerifySellerController;
use App\Http\Controllers\Seller\ProductController;
use App\Http\Controllers\HomeController;
// use App\Http\Controllers\Seller\ReputationController;
// use App\Http\Controllers\PurchaseController;
 // Adjust the controller path if needed



// Include admin routes
require_once __DIR__ . '/admin.php';

// Include seller routes
require_once __DIR__ . '/seller.php';


Route::group(['middleware' => ['ddos', 'throttlecustom:6,60']], function () { 
    Route::post('/ddos_check', function () {
        // Handle the request after passing through the DDoS check and throttle
    });
});

Route::get('/test-throttle', function () {
    return 'Testing Throttle Middleware';
})->middleware('throttlecustom:5,10');

Route::get('/loginfailed', 'Auth\LoginController@loginfailed')->name('loginfailed');

Route::group(['middleware' => 'ddos','throttlecustom:4,6'], function () {
    
Route::get('/Mirrors', 'PageController@Mirrors')->name('pages.mirrors');


Route::get('/pgp', 'PageController@Pgp')->name('pages.pgp');    
Route::get('/theme-switch', 'HomeController@themeSwitch')->name('themeswitch');
Route::get('/support', 'HomeController@support')->name('support');
Route::get('/message-admin', 'HomeController@startmessage')->name('start_message');
Route::get('/infocenter', 'HomeController@infocenter')->name('infocenter');
Route::get('/aboutus', 'HomeController@aboutus')->name('aboutus');
Route::get('/rules', 'HomeController@darkrules')->name('darkrules');
Route::get('/protector', 'HomeController@protector')->name('protector');
Route::get('/findus', 'HomeController@findus')->name('findus');
Route::get('/faq', 'HomeController@faq')->name('faq');
Route::get('/twofa', 'HomeController@twofa')->name('twofa');
Route::get('/change-currency/{currency}', 'HomeController@changeCurrency')->name('change_currency');
Route::get('/change-language/{language}', 'HomeController@changeLanguage')->name('change_language');
Route::get('/filter', 'HomeController@filter')->name('filter');



Route::get('/captcha', 'CaptchaController@show')->name('captcha.show');
Route::post('/captcha/validate', 'CaptchaController@validateCaptcha')->name('captcha.validate');
Route::match(['get', 'post'], '/logout', 'Auth\LoginController@logout')->name('logout');
Route::get('/phishing', 'Auth\LoginController@Phishing')->name('phishing');
Route::get('/seller/{sellerId}/reputation', [AdminController::class, 'showSellerReputation']);

});

Route::group(['middleware' => 'blockSellerPurchases'], function () {
    Route::get('/product-details/{id}', [ProductController::class, 'show'])->name('product.details');
    // Route::post('/purchase', [PurchaseController::class, 'store'])->name('purchase.store');
});

Route::group(['middleware' => ['auth','ddos']], function () {
    Route::get('/verify-login', 'Auth\VerifyController@viewVerifyLogin')->name('verifylogin');
    Route::get('/verify-login-msg', function () {  $encryptedMessage = session()->get('encrypted_message');  echo "<pre>{$encryptedMessage}</pre>"; })->name('verifylogin.view');
    Route::post('/verify-login', 'Auth\VerifyController@postVerifyLogin')->name('post.verifylogin');
    Route::get('/forgot/pgp/mnemonic', 'Auth\ForgotController@showPGPForgot')->name('forgot.pgp.mnemonic');
    Route::post('/forgot/pgp/mnemonic', 'Auth\ForgotController@postPGPForgot')->name('forgot.pgp.mnemonic.post');
    Route::post('/forgot/pgp/generatepgpmsg', 'Auth\ForgotController@generateVerifyPGP')->name('forgot.pgp.generate');
      Route::get('/forgot/pgp/generatepgpmsg', 'Auth\ForgotController@generateVerifyPGP')->name('forgot.pgp.generate');
    Route::post('/forgot/pgp/change', 'Auth\ForgotController@verifyChangePGP')->name('forgot.pgp.change');
});

Route::group(['middleware' => ['guest','ddos']], function () {
    Route::get('/register', 'Auth\RegisterController@show')->name('register.show');
    Route::post('/register', 'Auth\RegisterController@register')->name('register.perform');
    Route::get('/mnemonic', 'Auth\RegisterController@showMnemonic')->name('show.mnemonic');
    Route::match(['get', 'post'], '/mnemonic/verify', 'Auth\RegisterController@showMnemonicVefiry')->name('show.mnemonic.verify');
    Route::post('/mnemonic/verify/submit', 'Auth\RegisterController@verifyMnemonic')->name('mnemonic.post');
    Route::get('/login', 'Auth\LoginController@show')->name('login');
    Route::get('/forgot', 'Auth\ForgotController@showForgot')->name('forgot');
    Route::get('/forgot/password/mnemonic', 'Auth\ForgotController@showPasswordMnemonic')->name('forgot.password.mnemonic');
    Route::post('/forgot/password/mnemonic/post', 'Auth\ForgotController@postPasswordMnemonic')->name('forgot.password.mnemonic.post');
    Route::get('/forgot/password/pgp', 'Auth\ForgotController@showPasswordPGP')->name('forgot.password.pgp');
    Route::post('/login', 'Auth\LoginController@login')->name('login.perform');
    Route::view('privacy-policy','footer-links.privacy')->name('privacy');
    Route::view('terms-and-conditions', 'footer-links.tnc')->name('tnc');
    Route::view('official-pgp-link', 'footer-links.pgpbeforeauth')->name('official.pgp');
});





Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['auth', 'two_factor_authentication']], function () {
    // Change password

    if (file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {

        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
        Route::post('password', 'ChangePasswordController@update')->name('password.update');
        Route::post('profile', 'ChangePasswordController@updateProfile')->name('password.updateProfile');
        Route::post('profile/destroy', 'ChangePasswordController@destroy')->name('password.destroyProfile');
    }
});



Route::group(['as' => 'user.', 'namespace' => 'Buyer', 'middleware' => ['auth', 'two_factor_authentication', 'currency']], function () {
    // Delete a profile (soft delete)
    
    
    
    
    // page
   
    
    Route::get('/buyer/update-reputation/{userId}', [HomeController::class, 'updateUserReputation']);
    Route::delete('/profiles/{id}', 'ProfileController@destroyAccount')->name('profiles.destroy');
// routes/web.php
  Route::get('/widthwral', 'HomeController@Widthwral')->name('widthwral');
   Route::post('/widthwral/update', 'HomeController@Widthwralupdate')->name('widthwral.update');
  Route::get('/adderss', 'HomeController@Adderss')->name('addaderss');
  Route::get('/user/{id}/edit', 'HomeController@Adderssedit')->name('addersedit');
 Route::post('/adderss/update', 'HomeController@AddersUpdate')->name('adderss.update');
Route::post('/add/adderssBtc', 'HomeController@AddadderssBtc')->name('adderss.add.btc');
Route::delete('/delete-address', 'HomeController@deleteAddress')->name('delete.address');


    Route::get('/profile.dashboard', 'ProfileController@index')->name('dashboard');
    Route::get('/become', 'HomeController@getBecomeSeller')->name('become');
    Route::post('/becomerequest', 'HomeController@requestBecomeSeller')->name('request.become.seller');
    Route::post('/become', 'HomeController@BecomeSeller')->name('become.seller');
    

    Route::get('cart', 'CheckoutController@cart')->name('cart');
    Route::post('cart/post', 'CheckoutController@cartPost')->name('cart.post');
    Route::get('clearCart', 'CheckoutController@clearCart')->name('crearcart');
    Route::get('checkout', 'CheckoutController@checkout')->name('checkout');
    Route::post('/postcheckout', 'CheckoutController@checkoutpost')->name('post.checkout');
    Route::post('/addtocart/{product}', 'CheckoutController@addCart')->name('add.cart');
    Route::get('/removefromcart/{product}', 'CheckoutController@removeCart')->name('remove.cart');

    Route::get('profile', 'ProfileController@profileEdit')->name('profile.index');
    Route::post('profile/picture', 'ProfileController@profileUpdate')->name('profile.update.picture');
    
    Route::get('settings', 'ProfileController@profileSetting')->name('profile.settings');
    Route::post('settings/withdrawal', 'ProfileController@profileSettingWithdrawal')->name('profile.settings.withdrawal');
    Route::post('settings/updatemultisingPub', 'ProfileController@updateMultisigKeyPub')->name('profile.settings.update.multisig_key_pub');
    Route::post('settings/generateaddresspubkey', 'ProfileController@generateaddresspubkey')->name('profile.settings.generateaddresspubkey');
    Route::get('security', 'ProfileController@profileSecurity')->name('profile.security');
    Route::get('VerifySeller', 'ProfileController@profileSecurityzero')->name('profile.securityz0');
    Route::get('security1','ProfileController@profileSecurityone')->name('security1');
    Route::get('security2','ProfileController@profileSecuritytwo')->name('security2');
    Route::get('security3','ProfileController@profileSecuritythree')->name('security3');
    Route::get('verifypgp','ProfileController@verifypgp')->name('securepgp');
    Route::get('verify/becomeseller','ProfileController@verifypgp')->name('verifybuyer');
// Route to handle order payment
Route::post('/order/{orderId}/pay', [\App\Http\Controllers\Buyer\HomeController::class, 'payForOrder'])->name('orders');

    Route::post('profile', 'ProfileController@update')->name('profile.update');
    Route::post('profile/destroy', 'ProfileController@destroy')->name('profile.destroy');
    Route::post('profile/password', 'ProfileController@password')->name('profile.password');
Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('orders', 'OrderController@showall')->name('orders');
    Route::get('order/{id}', 'OrderController@showsingle')->name('order');
    Route::post('order/payment/raw/{order_id}', 'OrderController@createRawTranstion')->name('order.payment.raw');
    Route::post('order/payment/{order_id}', 'OrderController@generatePayment')->name('order.payment');
    Route::post('order/payment/multising/{order_id}', 'OrderController@generatePaymentMultisign')->name('order.payment.multisig');
    Route::post('order/status/{order}', 'OrderController@changeStatus')->name('order.status');
Route::match(['get', 'post'], '/user/order/status/{id}', [OrderController::class, 'status'])->name('user.order.status');

    Route::get('add-dispute/{order_id}/{product_id}', 'DisputeController@create')->name('orders.dispute');
    Route::post('store-dispute', 'DisputeController@store')->name('orders.store_dispute');

    Route::get('/gift-cards/', 'GiftCardController@index')->name('gift-cards.index');
    Route::post('/gift-cards/buy', 'GiftCardController@store')->name('gift-cards.buy');
    Route::post('/gift-cards/payment/{id}', 'GiftCardController@generatePayment')->name('gift-cards.payment');
    Route::get('/gift-cards/apply', 'GiftCardController@applyGiftCard')->name('gift-cards.apply');
    Route::post('gift-cards/{giftCard}/redeem', 'GiftCardController@redeem')->name('gift-cards.redeem');

    Route::get('auction/{id}', 'AuctionController@view')->name('auction');
    Route::post('auction/buy/{id}', 'AuctionController@buyAuction')->name('auction.buy');
    Route::post('auction/buy/checkout/{id}', 'AuctionController@checkoutBuyAuction')->name('auction.buy.checkout');
    Route::post('bid/buy/{id}', 'AuctionController@buyBid')->name('auction.bid.buy');
    Route::post('bid/payment/{id}', 'AuctionController@generatePayment')->name('bid.payment');
    Route::get('bids', 'AuctionController@index')->name('bids.index');
    Route::get('bid/{id}', 'AuctionController@viewSingle')->name('bid.view');

    Route::resource('tickets', 'TicketController');
    Route::get('/tickets/{ticket}', 'TicketController@show')->name('tickets.show');
    Route::post('/tickets/{ticket}', 'TicketController@TicketReply')->name('tickets.reply');
  
    
    Route::get('/seller-access', 'ProfileController@sellerAccess')->name('seller-access');
    Route::post('/seller-access', 'ProfileController@sellerAccessLogin')->name('seller-access.post');
    Route::post('/seller-staff-logout', 'ProfileController@sellerAccessLogout')->name('seller-logout');
});


Route::group(['middleware' => ['auth', 'two_factor_authentication', 'currency']], function () {
 
    Route::post('/settings/change-pgp-key', 'PGPController@postChangePGPKey')->name('post.changepgpkey'); 
     Route::post('/settings/becomevendor-pgp-key', 'PGPController@becomevendor')->name('post.becomevendor');
     #Create verification code
    Route::put('/settings/change-pgp-key', 'PGPController@putChangePGPKey')->name('put.changepgpkey'); #Confirm verification code and change PGP key
    Route::get('/settings/cancel-pgp-key-change', 'PGPController@cancelPGPKeyChange')->name('cancelpgpkeychange');
    Route::get('/settings/cancel-pgp-key-change', 'PGPController@cancelPGPKeyChanges')->name('cancelpgpkey');
    #Cancel pgp key change request
    Route::post('/settings/enable2fa', 'HomeController@verifyEnable2fa')->name('enable2fa');
    Route::put('/settings/change2fa', 'HomeController@putChange2fa')->name('put.changepg2fa'); #Confirm verification code and change PGP key
    Route::get('/', 'HomeController@index')->name('home');
    Route::get('home', 'HomeController@index')->name('user.home');
    Route::get('mywallet', 'TransactionController@walletBalance')->name('buyer.wallet');
    Route::get('product_detail/{id}', 'HomeController@productDetails')->name('product.details');

    Route::post('/products/{product}/questions', 'ProductQAController@store')->name('product.questions.store');

    Route::get('/profile/{username}', 'Seller\ProfileController@publicProfile')->name('seller.profile');

    Route::get('messenger', 'MessengerController@index')->name('messenger.index');
    Route::get('messenger/create', 'MessengerController@createTopic')->name('messenger.createTopic');
    Route::post('messenger', 'MessengerController@storeTopic')->name('messenger.storeTopic');
    Route::get('messenger/{topic}', 'MessengerController@showMessages')->name('messenger.showMessages');
    Route::get('messenger/new/{user}', 'MessengerController@newMessages')->name('messenger.newMessages');
    Route::delete('messenger/{topic}', 'MessengerController@destroyTopic')->name('messenger.destroyTopic');
    Route::post('messenger/{topic}/reply', 'MessengerController@replyToTopic')->name('messenger.reply');
    Route::get('messenger/{topic}/reply', 'MessengerController@showReply')->name('messenger.showReply');

    Route::get('disputes/', 'Buyer\DisputeController@index')->name('dispute');
    Route::get('dispute/{dispute}', 'Buyer\DisputeController@disputeMessage')->name('dispute.messages');
    Route::post('dispute/reply', 'Buyer\DisputeController@replyToDispute')->name('dispute.reply');
    Route::post('/products/{product}/reviews', [ProductReviewController::class, 'store'])->name('products.reviews.store');
Route::delete('/reviews/{review}', [ProductReviewController::class, 'destroy'])->name('reviews.destroy');
    Route::get('/transaction', 'TransactionController@index')->name('transactions');
    Route::post('/balance/Addbalance', 'TransactionController@Addbalance')->name('addbalance');
    Route::view('/changelog', 'common.changelog')->name('changelog');

    Route::middleware('throttle:50,30')->group(function () {
        Route::get('/search', 'SearchController@index')->name('search.index');
        Route::get('/products-by-category/{category}', 'SearchController@showProductsByCategory')->name('products.by.category');
    });
    
    Route::view('vendor-rules', 'footer-links.vendor-rules')->name('page.rules');
    Route::view('official-pgp', 'footer-links.pgp')->name('page.official-pgp');
    Route::view('bug-bounty', 'bug-bounty')->name('page.bounty');
    Route::view('forbidden-goods', 'footer-links.forbidden')->name('page.forbidden');
    Route::view('how-to-use-multi-signature', 'footer-links.multisig')->name('page.multisig');
});

Route::prefix('forum')->middleware(['web', 'auth'])->group(function () {
    Route::get('recent', [ThreadController::class, 'recent'])->name('forum.recent');
    Route::get('unread', [ThreadController::class, 'unread'])->name('forum.unread');

    Route::prefix('categories')->group(function () {
        Route::get('/', [CategoryController::class, 'index'])->name('categories.index');
        Route::get('/create', [CategoryController::class, 'create'])->name('categories.create');
        Route::post('/', [CategoryController::class, 'store'])->name('categories.store');
        Route::get('/{category}', [CategoryController::class, 'show'])->name('categories.show');
        Route::get('/{category}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
        Route::put('/{category}', [CategoryController::class, 'update'])->name('categories.update');
        Route::delete('/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');
    });

    Route::get('/thread', [ThreadController::class, 'index'])->name('thread.index');
    Route::get('/thread/create', [ThreadController::class, 'create'])->name('thread.create');
    Route::post('/thread', [ThreadController::class, 'store'])->name('thread.store');
    Route::get('/thread/{thread}', [ThreadController::class, 'show'])->name('thread.show');
    Route::delete('/threads/{thread}', [ThreadController::class, 'destroy'])->name('thread.delete');
    Route::put('/thread/{thread}/restore', [ThreadController::class, 'restore'])->name('thread.restore');
    Route::get('thread/create/{category}', [ThreadController::class, 'create'])->name('thread.create.category');
    
    Route::prefix('post')->group(function () {
        Route::get('/', [\Modules\Forum\Http\Controllers\PostController::class, 'index'])->name('post.index');
        Route::get('/create', [\Modules\Forum\Http\Controllers\PostController::class, 'create'])->name('post.create');
        Route::post('/', [\Modules\Forum\Http\Controllers\PostController::class, 'store'])->name('post.store');
        Route::get('/{post}', [\Modules\Forum\Http\Controllers\PostController::class, 'show'])->name('post.show');
        Route::get('/{post}/edit', [\Modules\Forum\Http\Controllers\PostController::class, 'edit'])->name('post.edit');
        Route::put('/{post}', [\Modules\Forum\Http\Controllers\PostController::class, 'update'])->name('post.update');
        Route::delete('/{post}', [\Modules\Forum\Http\Controllers\PostController::class, 'destroy'])->name('post.destroy');
    });
    Route::get('/', [ForumController::class, 'index']);
});
// Route::get('/convert', [CurrencyConverterController::class, 'convertCurrency']);

Route::get('/cancel-pgp-key-change', [PGPController::class, 'cancelPGPKeyChange'])->name('cancelpgpkeychange');
Route::get('/user/profile/verifypgp', [PGPController::class, 'verifyPgp'])->name('user.profile.verifypgp');
Route::get('/user/profile/security2', [PGPController::class, 'security2'])->name('user.profile.security2');
Route::get('/user/profile/security', [PGPController::class, 'security'])->name('user.profile.security');
Route::get('/user/profile/security', [PGPController::class, 'security'])->name('user.profile.security');
Route::post('/products/feedback', [ProductReviewController::class, 'store'])->name('products.feedback');
Route::get('/products/{product}/feedback', [ProductReviewController::class, 'feedback'])->name('product.feedback');
Route::get('products/{product}/feedback', [ProductReviewController::class, 'showFeedbackForm'])->name('productreviews.feedback');
Route::get('/products/{product}/feedback', [ProductReviewController::class, 'feedback'])->name('product.feedback');
Route::post('products/{id}/feedback', [ProductReviewController::class, 'storeFeedback'])->name('products.storeFeedback');
Route::post('/sellers/{id}/reputation', [ReputationController::class, 'updateReputation'])->name('admin.updateReputation');
// Route to handle storing the feedback
Route::post('/products/{product}/feedback', [ProductReviewController::class, 'store'])->name('products.feedback.store');
Route::post('/reviews/{order}', [ProductReviewController::class, 'submitReview'])->name('review.submit');
Route::post('/order/status/{order}', [Buyer\OrderController::class, 'changeStatus']);

Route::get('/orders/{order}', [OrderController::class, 'show'])->name('order.show');
Route::namespace('Buyer')->group(function() {
    Route::post('/order/status/{order}', [OrderController::class, 'changeStatus']);
});
Route::get('/user/order/status/{id}', [OrderController::class, 'status'])->name('user.order.status');

// Route to delete a review
Route::delete('/reviews/{review}', [ProductReviewController::class, 'destroy'])->name('products.feedback.destroy');
Route::get('/category/{id}', [CategoryController::class, 'show'])->name('category.show');
// Catch-all route
Route::fallback(function () {
    return response()->view('errors.404', [], 404);
})->name('fallback');

Route::get('download/canary/{filename}', function ($filename) {
    // Build the full file path based on the filename
    $filePath = public_path("assets/canary/{$filename}");

    // Check if the file exists
    if (File::exists($filePath)) {
        // Return the file as a download
        return Response::download($filePath);
    } else {
        // File doesn't exist, return 404
        abort(404, "File not found");
    }
});