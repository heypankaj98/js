<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Ethereum;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Modules\PaymentGateway\Http\Controllers\Gateway\Ethereum\EthereumLib\walletRPC;

class EthereumPayment {

    private $monerod;

    /**
     * __construct
     */
    public function __construct() {
        $this->ethereum = new walletRPC([
            'host' => config('coins.ethereum.host'),
            'port' => config('coins.ethereum.port'),
            'version' => config('coins.ethereum.version'),
        ]);
    }

    /**
     * Validate monero address
     *
     * @return array
     */
    public function validateAddress($address) {
        $result = $this->ethereum->validate_address($address);

        if ($result['valid'] == false) {
            throw new \Exception('The address entered is invalid!');
        }
    }

    /**
     * Create a monero account for the registered user
     * @param  $tag
     *
     * @return array
     */
    public function createNewAccount($tag = null) {

        try {
            $account = $this->ethereum->create_account();

            #Defines the TAG of the created account
            $this->monerod->tag_accounts(array($account['account_index']), $tag);

            return $account['address'];
        } catch (\Exception $exception) {

            return null;
        }
    }

    /**
     * Create new monero address
     * @param  $paymentID
     *
     * @return array
     */
    public function createNewAddress($paymentID = null) {
        try {
            $result = $this->ethereum->make_integrated_address($paymentID);
            return $result['integrated_address'];
        } catch (\Exception $exception) {
            dd($exception);
            return null;
        }
    }

    /**
     * Get balance from a certain account
     * @param  $tag
     *
     * @return float
     */
    public function getBalance($tag = null) {
//         $account = $this->monerod->get_accounts($tag);
//            dd($account);
        try {
//            dd($tag);
            $account = $this->ethereum->get_accounts($tag);
            $balance = $account['total_unlocked_balance'];
            $total_balance = $account['total_balance'];
            return number_format(($total_balance * 0.000000000001), 5);
        } catch (\Exception $exception) {
//            dd($exception);
            return number_format(0, 5);
        }
    }

    public function getBalanceLocked($tag = null) {
        try {
            $account = $this->ethereum->get_accounts($tag);
            $balance = $account['total_unlocked_balance'];
//            dd($balance);
            return number_format(($balance * 0.000000000001), 6);
        } catch (\Exception $exception) {
            return number_format(0, 5);
        }
    }

    /**
     * Get total received by address
     * @param  $address
     *
     * @return float
     */
    public function getTotalReceived($address) {
        try {
            #Get payment ID
            $result = $this->ethereum->split_integrated_address($address);
            $paymentID = $result['payment_id'];

            #Set total received
            $totalReceived = 0.00000;

            #Get all payments
            $payments = $this->ethereum->get_payments($paymentID);

            if (!empty($payments['payments'])) {
                foreach ($payments['payments'] as $payment) {
                    $totalReceived += $payment['amount'];
                }
            }

            return number_format(($totalReceived * 0.000000000001), 5);
        } catch (\Exception $exception) {
            return number_format(0, 5);
        }
    }

    /**
     * Transfer ethereum 
     * @param  $amount
     * @param  $address
     * @param  $accountTag
     *
     * @return array
     */
    public function transfer($amount, $address, $accountTag = null) {
        $subaccountIndexes = '';
        try {
            $result = $this->ethereum->get_accounts($accountTag);
            #Get all accounts belonging to the user
            $accounts = $result['subaddress_accounts'];
            #Collects all indexes of user-owned accounts
            $accountIndexes = [];

            foreach ($accounts as $index => $account) {
                $accountIndexes[$index] = $account['account_index'];
            }
            if (!$accountTag) {
                $subaccountIndexes = $accountIndexes;
            }

            #Transfer the requested amount using only the balance of the accounts belonging to the user
            return $transfer = $this->ethereum->transfer($amount * 1.000000000000, $address, $accountIndexes, $subaccountIndexes);
        } catch (\Exception $exception) {
            return $exception;
            session()->flash('error', 'Unable to transfer, please try again later!');
        }
    }

}
