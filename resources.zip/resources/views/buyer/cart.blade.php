
@extends('layouts.nosidebar')
@section('content') 



<div class="bg-card-1 p-24">
<div class="poduct_cart_mainr">

<h4 class="bg-card-2 p-16 mb-4 card-header-2"> {{ trans('product.cart')}}</h4>
<div class="super_container">

        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-md-9">
                    <div class="bg-card-2">
                    <form action="{{ route('user.cart.post') }}" method='POST'>
                        @csrf
                        <div class="ibox">
                            <div class="ibox-title bg-card-1">
                                <span class="pull-right d-flex justify-content-between align-items-center">
                                    <span> (<strong>{{ $products ? count($products) : 0 }}</strong>) {{ trans('product.items')}} </span>
                                    <a href="{{ route('user.crearcart') }}" class="btn btn-outline-danger btn-sm br-4 bordered-1 d-flex align-items-center w-max-c gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>  
                                    {{ trans('product.clear_cart')}}
                                    </a>
                                </span>
                                <!-- <h5>{{ trans('product.items_in_your')}}</h5> -->
                            </div>
                            <div class="ibox-content">
                                <div class="table-responsive">
                                    <table class="table table-prd mb-4">
                                        <tbody>
                                            @if($products != null)
                                            @foreach($products as $key => $product)
                                            <tr>
                                                <td width="90">
                                                    <div class="cart-product-imitation"></div>
                                                </td>
                                                <td class="desc">
                                                    <h3>
                                                        <a href="#" class="text-navy">
                                                            {{ $product->name }}
                                                        </a>
                                                    </h3>
                                                    @if (!empty($cartProduct[$key]['shipping_methods']) && is_array($cartProduct[$key]['shipping_methods']))
                                                    @foreach($cartProduct[$key]['shipping_methods'] as $shippings)
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" checked name="shipping_method-{{$product->id}}" id="shipping-{{$key}}" value="{{$shippings->id}}">
                                                        <label class="form-check-label" for="shipping-{{$key}}">
                                                            {{$shippings->name}} Shipping ({{ convertCurrency($shippings->price, request()->currency)}})

                                                        </label>
                                                        <p class="small text-muted">
                                                         Product Delivery Date   {{ $shippings->delivery_time }} {{ trans('product.business_days')}} 
                                                        </p>
                                                    </div>
                                                    @endforeach
                                                    @endif



                                                    <div class="m-t-sm">
                                                        <a href="{{ route('user.remove.cart', $product->id) }}" class="btn btn-outline-danger btn-sm br-4 bordered-1 d-flex align-items-center w-max-c gap-2">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>  
                                                            <span>{{ trans('product.remove_item')}}</span>
                                                        </a>
                                                    </div>

                                                </td>
                                                <td>
                                                    <s class="text-muted">
                                                        {{ convertCurrency($product->price * $cartProduct[$key]['quantity'], request()->currency) }} {{ request()->currency }}
                                                    </s>
                                                </td>


                                                <td width="75">
                                                    <input type="text" class="form-control"  readonly="readonly" placeholder="{{ $cartProduct[$key]['quantity'] }}">
                                                </td>
                                                <td class="text-end align-bottom">
                                                    <h4>
                                                        {{ convertCurrency($cartProduct[$key]['price'], request()->currency) }} {{ request()->currency }}
                                                    </h4>
                                                
                                                    <p class="small text-muted">
                                                     {{ trans('product.by_seller')}}  <a class="text-capitalize" href="{{route('seller.profile',$product->seller->username)}}" >{{$product->seller->username}}</a>
                                                    </p>
                                                </td>

                                            </tr>
                                            @endforeach
                                            @else
                                            <tr>
                                                <td colspan="7"> {{ trans('product.cart_is_empty')}}</td>
                                            </tr>
                                            @endif
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between">
                                <a href="{{ url('/') }}" class="text-accent-1 mt-0">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>    
                                    {{ trans('product.continue_shopping')}}
                                 </a>
                                <button class="btn btn-primary float-end br-4 px-4" type="submit" value='checkout'>  {{ trans('product.checkout')}}</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="ibox bg-card-2 h-100 d-flex justify-content-between flex-column">
                        <div class="ibox-title">
                            <h5 class="bg-card-1">{{ trans('product.cart_summary')}}</h5>
                        </div>
                        <div class="ibox-content">
                            <span>Total</span>
                            <h2 class="font-bold">
                                {{ convertCurrency($totalPrice, request()->currency) }} {{ request()->currency }}
                            </h2>
                            <span class="text-muted small">
                                {{ trans('product.your_information')}}
                                
                            </span>
                            <div class="">
                                <div class="">
                                    <a href="{{ route('user.cart.post') }}" class="btn btn-primary w-100 br-4 mt-1">
                                          {{ trans('product.checkout_link')}}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection 