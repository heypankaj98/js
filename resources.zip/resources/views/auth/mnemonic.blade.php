@extends('layouts.auth')    @section('content')

<div class="container">
    <div class="mnemonic_section my-5 my-3 p-4 p-lg-5 radius-5">
        <div class="row  "> 
            <div class="col-md-6 key_main">
                <div class="key_inner text-center ">
                    <h6 class="card-subtitle fw-bold mb-3 mb-lg-4 heading24">{{ trans('auth.Mnemonic') }}</h6>
                    <p class="mb-3 mb-lg-4 text-20">{{ $mnemonic }}</p>
                    <p class="text-14 write_down">{{ trans('auth.seed_phrase') }}</p>
                </div>
            </div>
            <div class="col-md-6 karyx_dnm_left ">
                <div class="key_inner ">
                <h6 class="card-subtitle fw-bold heading24">{{ trans('auth.set_up') }}</h6>
                <div class="col-md-12">
                    @if (session('success'))
                    <div id="alert_message" class="alert alert-success alert-block">
                        <strong>{{ session('success') }}</strong>
                    </div>
                    @endif

                    @if ($errors->any())
                    <div id="alert_message" class="alert alert-danger alert-block">
                        <strong>Validation Error:</strong>
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>
                <div class="mt-3"> 
                    <form action="{{ route('show.mnemonic.verify') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <p class="fw-medium">
                                <span class="word_red">{{ trans('auth.note_word') }}</span>
                                {{ trans('auth.note_text') }}
                            </p>
                        </div>
                        <div class="understand d-flex">
                            <input type="checkbox" id="check3" required>&emsp;&emsp;&emsp;
                            <label class="tab-label fw-medium" for="check3">
                                {{ trans('auth.I_understand') }}
                            </label>
                        </div>
                        <div class="form-group text-center d-flex mt-3 mb-3">
                            <button type="submit" class="btn  col-md-6 m-auto text-decoration-none">
                                {{ trans('auth.verify_securely') }}
                            </button>
                        </div>
                    </form>
                </div>
                </div>
                
                
                
            </div>
        </div>
    </div>
</div>
@endsection