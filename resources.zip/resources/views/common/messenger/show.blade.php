@extends('common.messenger.template')   @section('messenger-content')

<div class="">
    <div class="row h-100 bg-card-1 mt-4">
        <div class="col-md-3">
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="bg-card-2 p-16 mb-4 br1">
                    <div>
                        <h5 class="card-header-2 w-100 mb-4">{{ trans('common.channels') }}</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">#{{ trans('common.general') }}</a></li>
                            <li><a href="#">#{{ trans('common.announcements') }}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="bg-card-2 p-16 h-av br1">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('common.chat') }} {{ trans('common.user') }}</h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                            <li>
                                <a href="{{ route('messenger.showMessages', [$singletopic->id]) }}" class="">
                                    <div class="user_info">
                                        @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                            <img src="{{ asset('storage/' .  $singletopic->receiverOrCreator()->avatar) }}" class="rounded-circle">
                                            <span>
                                                {{ $singletopic->receiverOrCreator()->username }} [{{ $singletopic->mesasgeUnreadCount() }}]
                                            </span>
                                        @endif
                                    </div>
                                </a>
                            </li>
                        @empty
                            {{ trans('common.no') }} {{ trans('common.chat') }} {{ trans('common.user') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    <h5 class="mb-0">{{ trans('common.chat') }}: {{ $topic->receiverOrCreator()->username }}</h5>
                </div>
                <div class="card-body card-body bg-card-1">
                    <div class="chat-messages">
                        @foreach($topic->messages as $message)
                            @if($message->sender_id == Auth::user()->id)
                                <div class="message sent">
                                    <div class="message-content mw-100">
                                        <!--div class="message-header small">
                                            <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                        </div-->
                                        <div class="message-text">
                                            {{ $message->content }}
                                        </div>
                                        @if ($message->hasMedia('photo'))
                                        <div class="message-text">
                                            <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                                <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                            </a>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            @else
                                <div class="message received">
                                    <div class="message-content mw-100">
                                        <div class="message-header small mb-2">
                                            @if (Str::startsWith($message->sender->avatar , 'data:image'))
                                                <img src="{{ $message->sender->avatar }}" alt="Avatar" width="50" height="50" class="rounded-circle">
                                            @else
                                                <img src="{{ asset('storage/' . $message->sender->avatar) }}" alt="Avatar" width="50" height="50" class="rounded-circle">
                                            @endif
                                            <span class="username">{{$message->sender->username}}</span>
                                            <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                        </div>
                                        <div class="message-text mw-100">
                                            {{ $message->content }}
                                        </div>
                                        @if ($message->hasMedia('photo'))
                                            <div class="message-text">
                                                <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                                    <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                                </a>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
                <div class="card-footer">
                    <form action="{{ route("messenger.reply", [$topic->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input type="file" class="form-control-file" name="picture" accept="image/*" >
                        <textarea type="text" class="form-control-textarea" required name="content" placeholder="{{ trans('messages.text_placeholder') }}..."></textarea>
                        <button type="submit" class="btn btn-main ddd">{{ trans('common.send') }}</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="bg-card-2 p-16 mb-4 br1">
                <div class="card-header-2 w-100 mb-4">{{ trans('common.admin') }}</div>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                        @if (auth()->user()->id != $adminuser->id)
                            @if($adminuser->withChatMessages($adminuser->id) > 0)
                                <a href="{{ route('messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                                    <span class="badge badge1 text-bg-primary m-1">{{ $adminuser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('messenger.newMessages', [$adminuser->id]) }}">
                                    <span class="badge text-bg-primary m-1">{{ $adminuser->username }}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                        {{ trans('common.no') }} {{ trans('common.admin') }} {{ trans('common.users') }}
                    @endforelse
                </ul>
            </div>
            <div class="bg-card-2 p-16 br1 h-av">
                <div class="card-header-2 w-100 mb-4">{{ trans('common.moderator') }}</div>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                        @if (auth()->user()->id != $moduser->id)
                            @if($moduser->withChatMessages($moduser->id) > 0)
                                <a href="{{ route('messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">
                                    <span class="badge text-bg-primary">{{ $moduser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('messenger.newMessages', [$moduser->id]) }}">
                                    <span class="badge text-bg-primary">{{ $moduser->username}}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                        {{ trans('common.no') }} {{ trans('common.chat') }} & {{ trans('common.moderator') }} {{ trans('common.users') }}
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>
@stop