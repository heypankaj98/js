<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;
use App\Models\Currency;
use Illuminate\Support\Facades\App;

class SetCurrency {

    public function handle($request, Closure $next) {
//         app()->setLocale('ru');
//        App::setLocale('en');
        $language = Session::get('language', 'en');
        if (isset($language)) {
            
            App::setLocale($language);
        }

        $currency = Session::get('currency', 'USD'); // default to USD

        $exchangeRate = Currency::getExchangeRate($currency);
        $request->merge([
            'currency' => $currency,
            'exchange_rate' => $exchangeRate,
        ]);

        return $next($request);
    }

}
