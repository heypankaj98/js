@extends('layouts.admin')
@section('content')
@can('product_tag_create')
    <div   class="row mb-2">
        <div class="col-lg-12">
            <a class="btn btn-success" href="{{ route('admin.product-tags.create') }}">
                {{ trans('global.add') }} {{ trans('cruds.productTag.title_singular') }}
            </a>
        </div>
    </div>
@endcan
<div class="card">
    <div class="card-header">
        {{ trans('cruds.productTag.title_singular') }} {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-ProductTag">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            {{ trans('cruds.productTag.fields.id') }}
                        </th>
                        <th>
                            {{ trans('cruds.productTag.fields.name') }}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($productTags as $key => $productTag)
                        <tr data-entry-id="{{ $productTag->id }}">
                            <td>

                            </td>
                            <td>
                                {{ $productTag->id ?? '' }}
                            </td>
                            <td>
                                {{ $productTag->name ?? '' }}
                            </td>
                            <td>
                                @can('product_tag_show')
                                    <a class="btn btn-primary btn-sm br-4" href="{{ route('admin.product-tags.show', $productTag->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('product_tag_edit')
                                    <a class="btn btn-info btn-sm br-4" href="{{ route('admin.product-tags.edit', $productTag->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('product_tag_delete')
                                    <form action="{{ route('admin.product-tags.destroy', $productTag->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-danger btn-sm br-4" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>



@endsection