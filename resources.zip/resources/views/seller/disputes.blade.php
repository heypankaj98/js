
@extends('layouts.seller.app')     
@section('content')
<div class="container seller_dispute_section">
    <div class="row justify-content-center">
        <div class="col-md-12">
            @if (session('success'))
            <div id="alert_message" class="alert alert-success alert-block">
                <strong>{{session('success')}}</strong>
            </div>
            @endif
            @if (session('error'))
            <div id="alert_message" class="alert alert-danger alert-block">
                <strong>{{ session('error') }}</strong>
            </div>
            @endif

            <div class="container py-5 px-4">

                <div class="row rounded-lg overflow-hidden shadow">
                    <!-- Users box-->
                    <div class="col-5 px-0">
                        <div class="bg-white">

                            <div class="bg-gray px-4 py-2 bg-light">
                                <p class="h5 mb-0 py-1">Recent Disputes</p>
                            </div>

                            <div class="messages-box">
                                <div class="list-group rounded-0">

                                    @foreach($disputes as $key => $dispute)
                                    <a href="{{route('seller.dispute',$dispute)}}" class="list-group-item list-group-item-action list-group-item-light rounded-0">
                                        <div class="media"><img src="https://bootstrapious.com/i/snippets/sn-chat/avatar.svg" alt="user" width="50" class="rounded-circle">
                                            <div class="media-body ml-4">
                                                <div class="d-flex align-items-center justify-content-between mb-1">
                                                    <h6 class="mb-0">{{$dispute->seller->username}}</h6>
                                                    <small class="small font-weight-bold">{{ $dispute->first()->created_at->format('j-M-Y g:i A') }}</small>
                                                </div>
                                                <p class="font-italic mb-0 text-small">
                                                    @if(!is_null($dispute->messages()->first())) 
                                                    {{$dispute->messages()->first()->message}}
                                                    @endif
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Chat Box-->
                    <div class="col-7 px-0">
                        <div class="px-4 py-5 chat-box bg-white">

                            @if(isset($dispute_message))

                            @foreach($dispute_message as  $message)


                            @if(auth()->user()->id == $message->user_id)
                            <!-- Reciever Message-->
                            <div class="media w-50 ml-auto mb-3">
                                <div class="media-body">
                                    <div class="bg-primary rounded py-2 px-3 mb-2">
                                        <p class="text-small mb-0 text-white">{{$message->message}}</p>
                                    </div>
                                    <p class="small text-muted">{{ date('Y-m-d H:i:s') }}</p>
                                </div>
                            </div>

                            @else
                            <!-- Sender Message-->
                            <div class="media w-50 mb-3"><img src="https://bootstrapious.com/i/snippets/sn-chat/avatar.svg" alt="user" width="50" class="rounded-circle">
                                <div class="media-body ml-3">
                                    <div class="bg-light rounded py-2 px-3 mb-2">
                                        <p class="text-small mb-0 text-muted">{{$message->message}}</p>
                                    </div>
                                    <p class="small text-muted">{{ date('Y-m-d H:i:s') }}</p>
                                </div>
                            </div>
                            @endif
                            @endforeach

                            @endif
                        </div>

                        <!-- Typing area -->
                        <form method="POST" action="{{ route('seller.dispute.reply') }}" class="bg-light">
                            @csrf
                            <div class="input-group">
                                @if(!isset($dispute_id))
                                    @php
                                        $dispute_id = 0;
                                    @endphp
                                @endif
                                <input type="hidden" name="dispute_id" value="{{$dispute_id}}" />
                                <input type="text" name="message" placeholder="Type a message" aria-describedby="button-addon2" class="form-control rounded-0 border-0 py-4 bg-light" />

                                <div class="input-group-append">
                                    <button id="button-addon2" type="submit" class="btn btn-link"> <i class="fa fa-paper-plane"></i>Send</button>
                                </div>
                            </div>
                                @error('message')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                        </form>

                    </div>
                </div>
            </div>









        </div>
        <!--        <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            {{ trans('Disputed') }} {{ trans('global.list') }}
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class=" table table-bordered table-striped table-hover datatable datatable-Product text-center">
                                    <thead>
                                        <tr>
                                            <th>
                                                {{ trans('No.') }}
                                            </th>
                                            <th>
                                                {{ trans('
                                                Order-ID') }}
                                            </th>
                                            <th>
                                                {{ trans('Product') }}
                                            </th>
                                            <th>
                                                {{ trans('Message') }}
                                            </th>
                                            <th>
                                                {{ trans('Dispute-Date') }}
                                            </th>
                                            <th>
                                                &nbsp;
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($disputes as $key => $dispute)
                                        <tr>
                                            <td>
                                                {{ ++$key }}
                                            </td>
                                            <td> 
                                                {{ $dispute->first()->order_id }}
                                            </td>
                                            <td> 
                                                <img class="mt-2" src="{{ $dispute->product->photo->getUrl('thumb') }}">
                                                <br/>
                                                {{ $dispute->product->name }}
                                            </td>
                                            <td> 
                                                @if(!is_null($dispute->messages()->first())) 
                                                {{$dispute->messages()->first()->message}}
                                                @endif
                                            </td>
                                            <td>
                                                {{ $dispute->first()->created_at->format('j-M-Y g:i A') }}
                                            </td>
                                            <td>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>-->
    </div>

</div>

@endsection
