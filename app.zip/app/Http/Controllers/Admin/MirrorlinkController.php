<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\MirrorLink;
use App\Http\Controllers\Controller;

class MirrorlinkController extends Controller
{
    // Show a list of all MirrorLinks
    public function index()
    {
        $mirrorLinks = MirrorLink::all(); // Fetch all mirror links
        return view('admin.mirrorlinks.index', compact('mirrorLinks')); // Return to a view with the data
    }

    // Show the edit page for a specific MirrorLink
    public function edit($id)
    {
        $mirrorLink = MirrorLink::findOrFail($id); // Find the specific link by ID
        return view('admin.mirrorlinks.edit', compact('mirrorLink')); // Return to the edit view with the link data
    }

    // Update a specific MirrorLink
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'required|url',
        ]);

        $mirrorLink = MirrorLink::findOrFail($id);
        $mirrorLink->name = $request->input('name');
        $mirrorLink->url = $request->input('url');
        $mirrorLink->save();

        return redirect()->route('admin.mirrorlinks.index')->with('success', 'MirrorLink updated successfully.');
    }

    // Delete a specific MirrorLink
    public function destroy($id)
    {
        $mirrorLink = MirrorLink::findOrFail($id);
        $mirrorLink->delete();

        return redirect()->route('admin.mirrorlinks.index')->with('success', 'MirrorLink deleted successfully.');
    }
}

