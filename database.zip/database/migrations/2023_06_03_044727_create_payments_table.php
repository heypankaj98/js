<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('model_id')->unsigned();
            $table->string('method', 191);
            $table->text('payment_address');
            $table->string('status', 191)->default('waiting');
            $table->string('type', 20);
            $table->decimal('amount', 8, 8);
            $table->decimal('total_received', 8, 8)->default(0.00000000);
            $table->tinyInteger('deleted')->default(0);
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('payments');
    }
};
