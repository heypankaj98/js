<?php

namespace App\Http\Middleware;

use Closure;

class SetLocale {

    public function handle($request, Closure $next) {
        if (request('change_language')) {
            $language = request('change_language');
        } elseif (session('language')) {
            $language = session('language');
        } elseif (config('panel.primary_language')) {
            $language = config('panel.primary_language');
        }

        if (isset($language)) {
            $languages = config('languages');
            if (array_key_exists($language, $languages)) {
                $languageName = $languages[$language]['name'];
                session()->put('language', $languageName);
            }
            app()->setLocale($language);
        }

        return $next($request);
    }

}
