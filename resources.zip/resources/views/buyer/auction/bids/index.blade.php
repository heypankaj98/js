@extends('layouts.buyer.app')     @section('content')

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    {{ trans('Bids') }} {{ trans('global.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-striped table-hover datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('No.') }}
                                    </th>
                                    <th>
                                        {{ trans('Auction-ID') }}
                                    </th>
                                    <th>
                                        {{ trans('Amount') }}
                                    </th>
                                    <th>
                                        {{ trans('Payment Method') }}
                                    </th>
                                    <th>
                                        {{ trans('Status') }}
                                    </th>
                                    <th>
                                        {{ trans('Bid-Date') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                @foreach($bids as $bid)
                                <tr>
                                    <td>
                                        {{ $a++ }}
                                    </td>
                                    <td>
                                        {{ $bid->auction_id }}
                                    </td>
                                    <td>
                                        {{ $bid->amount }}
                                    </td>
                                    <td> 
                                        {{ $bid->payment_method ?? "N/A" }}
                                    </td>
                                    <td>
                                       {{ $bid->status ?? "N/A" }}
                                    </td>
                                    <td>
                                        {{ $bid->created_at->format('j-M-Y g:i A') }}
                                    </td>
                                    <td>
                                        <a class="btn btn-xs btn-primary" href="{{ route('user.bid.view', $bid->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                                
                            </tbody>
                        </table>
                           
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
