@extends('layouts.homeapp')
@section('content')
<div class="deshboard_main_part  main_filter_cetegory">
    <div class="row py-4">
    <div class="col-md-12 mb-2">  <div class="breadcrumb-nav">
                   <nav aria-label="breadcrumb">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
       @if ($category->parent)
    <li class="breadcrumb-item">
        <a href="{{ route('category.show', $category->parent->id) }}" class="color-accent-2">
            {{ $category->parent->name }}
        </a>
    </li>
@endif
        <li class="breadcrumb-item active" aria-current="page">
            {{ $category->name }}
        </li>
    </ol>
</nav>

</nav>

                </div></p></div>
        @foreach($products as $key => $product)

        <div class="col-md-3 mb-4">

              <div class="card thumbnail-image">
                <div class="card-header-2 w-100 text-center">
                    <h5 class="dress-name">
                        <a class="card_title" href="{{ route('product.details', ['id' => $product->id]) }}">
                            {{ Str::limit($product->name, 10) }}
                        </a>
                    </h5>
                </div>
                <div class="image-container">
                  <a class="card_img" href="{{ route('product.details', ['id' => $product->id]) }}">
    @if($product->photo)
        <img class="img-fluid" src="{{ $product->photo->getUrl() }}" alt="{{ $product->name }}">
    @else
        <img class="img-fluid" src="{{ asset('default-image.png') }}" alt="{{ $product->name }}">
    @endif
</a>

                    <span class="product-type">{{ $product->type }}</span>
                </div>
                <div class="product-detail-container px-3 py-4">
                     <div class="d-flex gap-2 fs-7">
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/btc.png" alt="BTC Logo">
                                <span class="fw-bold">(BTC)</span>
                            </span>
                            <span class="crypto-s">
                                <img src="http://192.81.216.50/assets/xmr.png" alt="XMR Logo">
                                <span class="fw-bold">(XMR)</span>
                            </span>
                        </div>
   <div class="user">
            @if ($product->seller->is_verified)
              <span class="crypto-s d-inline-flex align-items-center">
    <img src="http://192.81.216.50/assets/shld.png" alt="Shield" class="img-fluid" style="width: 16px; height: 16px; margin-right: 5px;">
     <small>Verified</small>
</span>

            @else
                <span class="crypto-s d-inline-flex align-items-center">
                    <img src="http://192.81.216.50/assets/cross.png" alt="Shield" class="img-fluid" style="width: 16px; height: 16px; margin-right: 5px;">
                    <small>Not Verified</small>
                </span>
            @endif
        </div>

                       <div class="sellor-info d-flex justify-content-between">
<h5>
    <span>
        <a class="badge text-bg-dark text-light"
           href="{{ route('seller.profile', $product->seller->username) }}">
            {{ $product->seller->username }}
        </a>
    </span>
    <span class="badge" style="background-color: #28a745 !important; color: white;">
        {{ getSellerReputationTier($product->seller) }}
    </span>
</h5>


    <p style="font-size:10px"><img src="http://192.81.216.50/assets/eye.png" alt="eye"> {{ $product->visit_count }}</p>
</div>
                    
                    <div class="stars">
                        @php
                        $avgRating = $product->reviews()->avg('rating');
                        @endphp
                        <span class="review-no font-bold mx-1 text-warning">{{ number_format($avgRating, 1) }}</span>
                        <span class="mx-1 star_main">
                            <!-- Display stars based on $avgRating -->
                        </span>
                    </div>
                
<div class="col text-start">
                            <h5>
                                <span>Stock: </span>
                                <span class="text-accent-1">{{ $product->stock ? $product->stock : 0 }}</span>
                            </h5>
                        </div>
                    <div class="price">
                        <span>($)</span>
                        <span class="new-price">{{ convertCurrency($product->price, request()->currency) }} {{ request()->currency }}</span>
                    </div>
<!--                    <div class="text-center">-->
<!--                           <span class="arrow-text id="user-{{ $user->id }}">-->
<!--{{ calculateReputationTier() }}</span>-->
<!--                    </div>-->
                    <div class="c-buy-now-btn">
                        <a class="btn btn-main w-100 mt-4" href="{{ route('product.details', ['id' => $product->id]) }}">
                            View Product
                        </a>
                    </div>
                </div>
            </div>
        </div>

        @endforeach
    </div>
</div>


@endsection