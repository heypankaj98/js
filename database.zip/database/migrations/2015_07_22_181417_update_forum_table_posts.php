<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class UpdateForumTablePosts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
public function up()
{
    Schema::table('forum_posts', function (Blueprint $table) {
        // Check if 'post_id' column already exists
        if (!Schema::hasColumn('forum_posts', 'post_id')) {
            // Add 'thread_id' column
            $table->integer('thread_id')->after('content')->unsigned()->nullable();
            // Copy data from 'parent_thread' to 'thread_id'
            // Drop 'parent_thread' column
            $table->dropColumn('parent_thread');
            // Add 'post_id' column
            $table->integer('post_id')->after('content')->unsigned()->nullable();
        }
    });
}

public function down()
{
    Schema::table('forum_posts', function (Blueprint $table) {
        // Add 'parent_thread' column
        $table->integer('parent_thread')->after('content')->unsigned()->nullable();
        // Copy data from 'thread_id' to 'parent_thread'
      
        // Drop 'thread_id' column
        $table->dropColumn('thread_id');
        // Remove 'post_id' column if it was added
        if (Schema::hasColumn('forum_posts', 'post_id')) {
            $table->dropColumn('post_id');
        }
    });
}
}
