<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;

class PermissionRoleTableSeeder extends Seeder
{
   public function run()
    {
        $admin_permissions = Permission::all();
        Role::findOrFail(1)->permissions()->sync($admin_permissions->pluck('id'));

        $seller_permissions = $admin_permissions->filter(function ($permission) {
            return strpos($permission->title, 'seller_') === 0;
        });

        Role::findOrFail(3)->permissions()->sync($seller_permissions);
    }
}