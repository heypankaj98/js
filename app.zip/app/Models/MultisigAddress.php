<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MultisigAddress extends Model
{
    use HasFactory;
    
    protected $table = 'multisig_addresses';

    protected $fillable = [
        'multisig_id',
        'address_1',
        'address_2',
        'address_3',
    ];
}
