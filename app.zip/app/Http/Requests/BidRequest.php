<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BidRequest extends FormRequest {

    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'price' => 'bail|required|gt:0.0',
//            'id' => 'required|exists:auctions,id',
        ];
    }

}
