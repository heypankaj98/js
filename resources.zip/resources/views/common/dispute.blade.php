@extends('layouts.buyer.app')
@section('content')
    <section class="section dashboard">
        <div class="card">
            <div class="card-heading">
               Add Dispute
            </div>
            <form method="POST" action="{{ route('user.orders.store_dispute') }}" >
                @csrf
              <div class="form-group">
                <label for="message">Message:</label>
                <input type="hidden" class="form-control" name="order_id" value="{{$order_id}}">
                <input type="hidden" class="form-control" name="product_id" value="{{$product_id}}">
                <textarea class="form-control" id="message" name="message"></textarea>
                @error('message')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
        </div>
    </section>

@endsection
