@extends('layouts.admin')

@section('content')
    <h1>Mirror Links</h1>
    <a href="{{ route('mirrorlinks.create') }}" class="btn btn-primary">Create New Link</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>Name</th>
                <th>URL</th>
                <th>Link</th>  <!-- Add link column header -->
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($mirrorLinks as $mirrorLink)
                <tr>
                    <td>{{ $mirrorLink->name }}</td>
                    <td>{{ $mirrorLink->url }}</td>
                    <td><a href="{{ $mirrorLink->link }}" target="_blank">{{ $mirrorLink->link }}</a></td>  <!-- Display link -->
                    <td>
                        <a href="{{ route('mirrorlinks.edit', $mirrorLink->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('mirrorlinks.destroy', $mirrorLink->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
