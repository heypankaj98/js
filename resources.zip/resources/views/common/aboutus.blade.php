@extends('layouts.homeapp')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace Rules</title>
    <style>
        .important {
            color: #ff202c;
        }
        .rules, .special-rules {
            margin-top: 20px;
        }
        
        p{
            line-height:1.5
        }
        li{
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="">
    <h1 class="custom-title mb-4 mt-4">Follow these rules.</h1>
    <div class="bg-card-1 p-24 br1 mt-4">
        
        <h3 class="card-header-2 w-100 mb-4">Common Marketplace Rules</h3>
        <p>We don't have many rules here, but those that we have are strictly enforced by the Administration. We treat everyone properly and fair and expect this in return of every member on Dark Alley.</p>

        <p>Take your time to read and understand the Marketplace Rules and the Dark Alley Guardian. Take a look at the FAQ, all important questions are answered there. If something is still unclear, write the Administration via Dark Alley Mail and ask. Later statements like <i>I didn't know that</i> are meaningless. Ignorance does not protect one from punishment.</p>

        <p class="important card-header-2 w-100 mb-4">If members try to scam each other or the marketplace in any way - no consideration will be given. The account will be instantly banned! This also applies if false information will be provided or evidence will be forged in a given case.</p>

        <p>If you receive a strike, The Administration will be informed and will be looking into this. The Administration sees what triggered the strike. If there is no fault of your own, your strike(s) will be reset, otherwise you will be punished. Just don't even try, it's not worth it.</p>

        <p><b>The entire Dark Alley Marketplace is multi-layer encrypted.</b> Always use Dark Alley and you can be sure that you are secure. You can encrypt every sensitive data with PGP through Dark Alley or by yourself with one-click if your PGP Public Key is supplied to the marketplace.</p>

        <p>Download the PGP Public Keys of the Administration and Lucifer, also the signed mirror URL's. Always verify the mirrors' URL's, crypto addresses and user key change. These are always signed by the Administration or by Lucifer (again).</p>

        <p>All options for securing your account are available to every member. Always keep Two-Factor-Authentication (2FA) enabled to prevent any unauthorized access.</p>

        <p>If new information (Attention: BEFORE you ...) please read and understand the following information) is displayed, act according to the displayed information.</p>

        <p>Every user can always report an error or violation of these marketplace rules, same thing for item listings. Write to the Administration. Before you ... please be sure that the report is being displayed for no valid reason. If the report is displayed in error, nothing can happen to you. You can be punished if the report is being abused for no valid reason.</p>

        <p>Any type of communication, agreement or business outside of the marketplace which is related to an order on Dark Alley will be ignored by us and is at your own risk.</p>

        <h3 class="card-header-2 w-100 mb-4">Special Vendor Marketplace Rules</h3>
        <p>Vendors are obligated to fulfill certain requirements for listings.</p>

        <ul>
            <li>Vendors act on their own risk.</li>
            <li>In case of no action in this description, vendors have to do this in their About Vendor section.</li>
            <li>It is not allowed to create item listings with PGP though to checkout without delivering any item.</li>
            <li>It is allowed to deliver samples for your buyers (must be fair, reasonable to price, be a reasonable extent).</li>
            <li>Vendors act on their own risk.</li>
            <li>It is not allowed to create item listings with work, work, jabber and corresponding.</li>
            <li>Vendors are obligated to fulfill certain requirements for listings.</li>
        </ul>
    </div>
    </div>
   
</body>
</html>
@endsection