<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class WaitingController extends Controller
{
    public function index()
    {
        return view('waiting'); // Create this view next
    }
}

