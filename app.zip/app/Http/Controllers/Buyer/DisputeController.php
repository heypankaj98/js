<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{
    Order,
    Dispute,
    DisputeMessage
};
use Illuminate\Support\Str;
use App\Notifications\UserTicketNotification;
use App\Notifications\OrderDisputeNotification;
use App\Traits\OrderTrait;

class DisputeController extends Controller {

    use OrderTrait;

    public function index() {
        $disputes = Dispute::where('buyer_id', \Auth::id())
                ->orderBy('id', 'desc')
                ->get();
        return view('buyer.dispute.index', ['disputes' => $disputes]);
    }

    public function create($orderId, $productId) {
        $disputes = Dispute::where('buyer_id', \Auth::id())
                ->orderBy('id', 'desc')
                ->get();

        $order = Order::where('id', $orderId)
                ->where('product_id', $productId)->where('buyer_id', \Auth::id())
                ->first();

        return view('buyer.dispute.create', [
            'order' => $order,
            'order_id' => $orderId,
            'product_id' => $productId,
            'disputes' => $disputes,
        ]);
    }

    public function store(Request $request) {
        $request->validate([
            'content' => 'required',
            'order_id' => 'required',
            'product_id' => 'required',
        ]);

        $order = Order::where('id', $request->order_id)
                ->where('product_id', $request->product_id)
                ->where('buyer_id', \Auth::id())
                ->first();

        if (!$order) {
            session()->flash('error', 'Invalid order or product');
            return redirect()->back();
        }

        $addDispute = new Dispute();
        $addDispute->order_id = $order->id;
        $addDispute->product_id = $order->product_id;
        $addDispute->buyer_id = $order->buyer_id;
        $addDispute->seller_id = $order->seller_id;
        $addDispute->save();

        if ($addDispute) {
            $addDisputeMsg = new DisputeMessage();
            $addDisputeMsg->user_id = $order->buyer_id;
            $addDisputeMsg->dispute_id = $addDispute->id;
            $addDisputeMsg->message = $request->content;

            if ($addDisputeMsg->save()) {
                $this->markAsDisputed($order->id);
                session()->flash('success', "Dispute added successfully");
            } else {
                session()->flash('error', "Unable to add dispute message");
            }
        } else {
            session()->flash('error', "Unable to add dispute");
        }

        $order->seller->notify(new OrderDisputeNotification($addDispute));

        return redirect()->route('user.order', ['id' => $request->order_id]);
    }

    public function replyToDispute(Request $request) {

        $request->validate([
            'content' => 'required',
            'dispute_id' => 'required',
        ]);

        $addDisputeMsg = new DisputeMessage();
        $addDisputeMsg->user_id = \Auth::id();
        $addDisputeMsg->dispute_id = $request->dispute_id;
        $addDisputeMsg->message = $request->content;
        $addDisputeMsg->save();
        $dispute = Dispute::where('id', $request->dispute_id)->first();
        $dispute->seller->notify(new OrderDisputeNotification($dispute));

        //notification to reciver
        return redirect()->route('dispute.messages', ['dispute' => $request->dispute_id]);
    }

    public function disputeMessage(Dispute $dispute) {
        $disputes = Dispute::where('buyer_id', \Auth::id())
                ->orderBy('created_at', 'asc')
                ->get();
        return view('buyer.dispute.show', ['disputes' => $disputes, 'singledispute' => $dispute]);
    }

}
