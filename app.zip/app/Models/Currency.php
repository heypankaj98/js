<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Currency extends Model {

    use HasFactory;

    public $table = 'exchange_rates';
    public $timestamps = true;
    
    protected $fillable = [
        'currency',
        'rate',
        'updated_at',
    ];

    public static function getExchangeRate($currency) {
        $baseRate = Currency::where('currency', 'USD')->value('rate');
        $rate = Currency::where('currency', $currency)->value('rate');

        return $rate / $baseRate;
    }

}
