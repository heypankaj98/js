@extends('layouts.admin.master')

@section('content')
<div class="mt-4">
    <div class="card-header-2 w-100 mb-4">
        {{ trans('global.edit') }} {{ trans('cruds.user.title_singular') }}
    </div>
    <div class="bg-card-2 br1">
        <div class="card-body">
            <form method="POST" action="{{ route('admin.users.update', [$selected_user->id]) }}" enctype="multipart/form-data">
                @method('PUT')
                @csrf

                <!-- Username Field -->
                <div class="form-group">
                    <label class="required" for="name">Username</label>
                    <input class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}" type="text" name="username" id="name" value="{{ old('username', $selected_user->username) }}" readonly>
                    @if($errors->has('username'))
                        <div class="invalid-feedback">
                            {{ $errors->first('username') }}
                        </div>
                    @endif
                </div>
                
                <!-- Password Field -->
                <div class="form-group">
                    <label class="required" for="password">Password</label>
                    <input class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" type="password" name="password" id="password">
                    @if($errors->has('password'))
                        <div class="invalid-feedback">
                            {{ $errors->first('password') }}
                        </div>
                    @endif
                </div>

                <!-- Roles Field -->
                <div class="form-group">
                    <label class="required" for="roles">{{ trans('cruds.user.fields.roles') }}</label>
                    <div class="pb-1 mb-2">
                        <span class="btn btn-info btn-xs select-all rounded-0">Select All</span>
                        <span class="btn btn-info btn-xs deselect-all rounded-0">Deselect All</span>
                    </div>
                    <select class="form-control select2 form-control-textarea {{ $errors->has('roles') ? 'is-invalid' : '' }}" name="roles[]" id="roles" multiple required>
                        @foreach($roles as $id => $role)
                            <option value="{{ $id }}" {{ (in_array($id, old('roles', [])) || $user->roles->contains($id)) ? 'selected' : '' }}>{{ $role }}</option>
                        @endforeach
                    </select>
                    @if($errors->has('roles'))
                        <div class="invalid-feedback">
                            {{ $errors->first('roles') }}
                        </div>
                    @endif
                </div>

                <!-- Featured Vendor Checkbox -->
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="1" name="featured" value="1" {{ $user->featured ? 'checked' : '' }}>
                    <label class="form-check-label" for="1">Featured Vendors</label>
                </div>

                <!-- Save Button -->
                <div class="form-group mb-0">
                    <button class="btn btn-main w-max-c" type="submit">
                        {{ trans('global.save') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
