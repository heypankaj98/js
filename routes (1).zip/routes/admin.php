<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\VerifySellerController;
use App\Http\Controllers\Admin\HomeController;
use App\Http\Controllers\Admin\PermissionsController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\ProductCategoryController;
use App\Http\Controllers\Admin\ProductTagController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\AuctionController;
use App\Http\Controllers\Admin\UserAlertsController;
use App\Http\Controllers\Admin\MessengerController;
use App\Http\Controllers\Admin\DisputeController;
use App\Http\Controllers\Admin\AdvertisementController;
use App\Http\Controllers\Admin\PayoutController;
use App\Http\Controllers\Admin\GiftCardController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Seller\ReputationController;


Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth', 'admin', 'two_factor_authentication', 'currency']], function () {
    Route::get('/', 'HomeController@index')->name('home');
    Route::resource('mirrorlinks', MirrorlinkController::class);
    Route::get('node', 'HomeController@nodeinfo')->name('node.info');
  Route::get('/sellerlist', [VerifySellerController::class, 'index'])->name('sellerlist');

    Route::post('/verify-seller/{id}', [VerifySellerController::class, 'toggleVerification'])->name('verify.seller');
     Route::get('profile', 'HomeController@profileEdit')->name('profile.index');
    Route::post('node/sendbtc', 'HomeController@btcTransfer')->name('node.btctransfer');
    Route::post('node/dump-private-key', 'HomeController@dumpPrivateKey')->name('node.dumpPrivateKey');
    Route::get('/seller-requests', 'HomeController@sellerrequests')->name('sellerrequest');
    Route::post('/approve-seller/{payment}', 'HomeController@approveSeller')->name('approve.seller');
    Route::get('/charges', 'HomeController@charges')->name('charges');
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');
    
    Route::get('/tickets', 'UsersController@indexticket')->name('tickets.index');
    Route::get('/tickets/{ticket}/show', 'UsersController@ticketshow')->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', 'UsersController@ticketReply')->name('tickets.reply');
    
    // commission
    
      Route::get('comission/setting', 'PermissionsController@comission')->name('comission');
    Route::post('comission/setting', 'PermissionsController@comissionStore')->name('comission.store');
    Route::resource('admin/product-categories', \App\Http\Controllers\Admin\ProductCategoryController::class);
    
    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');
    Route::post('users/{id}/recover', 'UsersController@recoverAccount')->name('user.recover');
    Route::post('admin/login-as/{user}', 'UsersController@loginAsUser')->name('user.loginuser');
    // Product Category
    Route::delete('product-categories/destroy', 'ProductCategoryController@massDestroy')->name('product-categories.massDestroy');
    Route::post('product-categories/media', 'ProductCategoryController@storeMedia')->name('product-categories.storeMedia');
    Route::post('product-categories/ckmedia', 'ProductCategoryController@storeCKEditorImages')->name('product-categories.storeCKEditorImages');
    Route::resource('product-categories', 'ProductCategoryController');
    Route::post('product-categories/{productCategory}', 'ProductCategoryController@update')->name('product-categories.update');
    // Product Tag
    Route::delete('product-tags/destroy', 'ProductTagController@massDestroy')->name('product-tags.massDestroy');
    Route::resource('product-tags', 'ProductTagController');

    // Product 
    Route::delete('products/destroy', 'ProductController@massDestroy')->name('products.massDestroy');
    Route::post('products/media', 'ProductController@storeMedia')->name('products.storeMedia');
    Route::post('products/ckmedia', 'ProductController@storeCKEditorImages')->name('products.storeCKEditorImages');
    Route::resource('products', 'ProductController');

    //Auction
    Route::resource('auctions', 'AuctionController');

    // User Alerts
    Route::delete('user-alerts/destroy', 'UserAlertsController@massDestroy')->name('user-alerts.massDestroy');
    Route::get('user-alerts/read', 'UserAlertsController@read');
    Route::resource('user-alerts', 'UserAlertsController', ['except' => ['edit', 'update']]);

    Route::get('messenger', 'MessengerController@index')->name('messenger.index');
    Route::get('messenger/create', 'MessengerController@createTopic')->name('messenger.createTopic');
    Route::post('messenger', 'MessengerController@storeTopic')->name('messenger.storeTopic');
    Route::get('messenger/inbox', 'MessengerController@showInbox')->name('messenger.showInbox');
    Route::get('messenger/outbox', 'MessengerController@showOutbox')->name('messenger.showOutbox');
    Route::get('messenger/{topic}', 'MessengerController@showMessages')->name('messenger.showMessages');
    Route::delete('messenger/{topic}', 'MessengerController@destroyTopic')->name('messenger.destroyTopic');
    Route::get('messenger/new/{user}', 'MessengerController@newMessages')->name('messenger.newMessages');
    Route::post('messenger/{topic}/reply', 'MessengerController@replyToTopic')->name('messenger.reply');
    Route::get('messenger/{topic}/reply', 'MessengerController@showReply')->name('messenger.showReply');

    Route::get('/canery', 'HomeController@canery')->name('canery.show');
    Route::post('/canery/update', 'HomeController@caneryUpdate')->name('canery.update');

    Route::get('disputes', 'DisputeController@index')->name('dispute');
    Route::get('dispute/{dispute}', 'DisputeController@disputeMessage')->name('dispute.messages');
    Route::post('dispute/reply', 'DisputeController@replyToDispute')->name('dispute.reply');
    Route::post('dispute/setwinner', 'DisputeController@disputeWinner')->name('dispute.winner');

    Route::get('advertisement/list', 'AdvertisementController@index')->name('ads.index');
    Route::get('advertisement/create', 'AdvertisementController@create')->name('ads.create');
    Route::get('advertisement/edit/{id}', 'AdvertisementController@edit')->name('ads.edit');
    Route::post('advertisement/store', 'AdvertisementController@store')->name('ads.store');
  
// Use the match method to accept both POST and PUT methods for the update route
Route::match(['post', 'put'], 'advertisement/update/{id}', 'AdvertisementController@update')->name('ads.update');

 Route::delete('advertisement/delete/{id}', 'AdvertisementController@delete')->name('ads.delete');

    Route::get('/add/{id}', 'AdvertisementController@adclicked')->name('add.clicked');
    Route::get('/error', 'HomeController@error')->name('error');
    Route::get('/payouts', 'PayoutController@index')->name('payouts');
    Route::post('/payouts/approve/{payoutId}', 'PayoutController@approvePayout')->name('payouts.approve');
    Route::post('/payouts/reject/{payoutId}', 'PayoutController@rejectPayout')->name('payouts.reject');

    Route::resource('gift-cards', 'GiftCardController');
Route::post('/reputation/update/{id}', [ReputationController::class, 'updateReputation'])->name('admin.updateReputation');

});
