<!DOCTYPE html>
<html lang="en" @if(session()->has('theme')) data-bs-theme="{{ Session::get('theme') }}" @endif>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="{{ asset('fev.ico') }}">

    <!-- Page Title -->
    <link href="{{ asset('css/bootstrap-5.3/css/bootstrap.css') }}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap"
        rel="stylesheet">
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <title>{{ trans('Admin Dashboard') }}</title>
</head>

<body>
    <div class="">
        <section class="ds-dasboard">
            <div class="header_dasboard">
                @include('layouts.admin.topbar')
            </div>
            <div class="container">
                <div class="custome-row">
                    <div class="side-bar-row-box">
                        @include('layouts.admin.sidebar')
                    </div>
                    <div class="content-bar-row">
                        @yield("content")
                    </div>
                </div>
            </div>
            @include('layouts.pagefooter')
    </div>
    </section>
    </div>

</body>

<style>
    button.add_product:hover+.dropdown-menu {
        display: block;
        margin: 10px;
        /*position: relative;*/
    }

    /*        body{
                    min-height: 100%;
                    background-color: #f5f7f8;
                    font-family: "Inter",sans-serif !important;
                }*/

    .user-menu-icon:hover>.dropdown-menu {
        display: block;
        margin-top: 150px;
        /*position: relative;*/
    }

    .ds-header {
        height: 56px;
        flex: 0 0 56px;
        border-bottom: 0;
        width: 100%;
        z-index: 13;
        position: relative;
        /*background: #fff;*/
        box-shadow: 0 2px 4px -1px rgba(7, 14, 35, .08);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .header-logo-image-big {
        height: 20px;
    }

    .user-menu-icon img {
        width: 2rem;
        height: 2rem;
        border-radius: 100%;
    }

    .user-menu-icon {
        display: flex;
        align-items: center;
    }

    .user-menu-icon span {
        display: flex;
        flex-direction: column;
        padding-left: 5px;
        padding-right: 5px;
        font-weight: 500;
        font-size: 13px;
    }

    .user-menu-subtitle {
        font-size: 12px;
        line-height: 15px;
        /*color: #a2aab4;*/
    }

    .header-intercom {
        border-radius: 0.5rem;
        cursor: pointer;
        padding: 0.5rem 0.75rem;
        background: var(--bs-secondary-bg);
        /*color: #121417;*/
        user-select: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: 1px solid var(--bs-border-color);
        box-shadow: 0 1px 2px rgba(18, 20, 23, .06);
        margin-right: 0.5rem;
        font-family: "Inter";
        font-style: normal;
        font-weight: 500;
        font-size: 13px;
        line-height: 16px;
    }

    .switch {
        position: relative;
        height: 24px;
        padding: 0 0;
        width: 44px;
        margin: 0 0.5rem 0 0.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        /*background-color: #ccc;*/
        -webkit-transition: .4s;
        transition: .4s;
    }

    .switch .slider:before {
        position: absolute;
        content: "";
        height: 20px;
        width: 20px;
        left: 4px;
        bottom: 4px;
        /*background-color: white;*/
        -webkit-transition: .4s;
        transition: .4s;
    }

    .switch input:checked+.slider {
        /*background-color: #f5f7f8;*/
    }

    .switch input:focus+.slider {
        box-shadow: 0 0 1px #2196F3;
    }

    .switch input:checked+.slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
    }

    /* Rounded sliders */
    .switch .slider.round {
        border-radius: 34px;
    }

    .switch .slider.round:before {
        border-radius: 50%;
    }

    .header-searchbar-input {
        /*background-color: white;*/
        height: 100%;
        border: none !important;
        transition: none;
        width: 100%;
        font-family: "Inter";
        font-style: normal;
        font-size: 14px;
        line-height: 17px;
        /*color: #121417;*/
        font-weight: 600;
        display: flex;
        position: relative;
    }

    .header-searchbar-input input {
        /*background-color: white;*/
        height: 100%;
        border: none !important;
        padding-left: 2rem;
        transition: none;
        width: 100%;
        font-family: "Inter";
        font-style: normal;
        font-size: 14px;
        line-height: 17px;
        /*color: #121417;*/
        font-weight: 600;
    }

    .header-searchbar-input svg {
        position: absolute;
    }

    .sidebar-minimized-icon {
        /*border-right: 1px solid var(--bs-border-color);*/

        padding: 0.25rem 1rem;
        cursor: pointer;
    }

    .header-intercom svg {
        margin-right: 12px;
    }

    .siddebar-menu li a {
        font-weight: 500;
        font-size: 15px;
        line-height: 19px;
        /*color: #121417;*/
        text-decoration: none;
        padding: 8px 8px;
        display: block;
    }


    .siddebar-menu li a svg {
        stroke: currentColor !important;
    }

    .siddebar-menu {
        list-style: none;
        padding-left: 0;
    }

    .ds-nav-dropdown-items {
        list-style: none;
    }

    .siddebar-menu>li:nth-child(5),
    .ul.siddebar-menu>li:nth-child(7),
    ul.siddebar-menu>li:nth-child(9) {
        margin-bottom: 1.5rem;
    }

    .dashboard-screen {
        padding: 1.5rem 0;
    }

    .title h1 {
        margin: 0;
        font-size: 1.5rem;
        font-weight: 600;
        /*color: #121417;*/
        margin-bottom: 10px;
    }

    .breadcrumbs a {
        font-size: 13px;
        font-weight: 500;
        /*color: #777f89;*/
        text-decoration: unset;
    }

    .title {
        background-color: #000;
        padding: 20px;
        border-radius: 4px;
        font-size: 14px;
        display: flex;
        align-items: center;
        cursor: pointer;
        position: relative;
    }

    .sellix-date-picker {
        width: 100%;
        display: flex;
        align-items: center;
        flex-direction: column;
        padding: 0 1rem;
        height: 2.25rem;
        font-size: .85rem;
        border-radius: 4px;
        box-shadow: 0 1px 2px rgba(18, 20, 23, .06);
        cursor: pointer;
        border: none;
        padding: 11px;
        height: max-content;
        gap: 15px;
        background: #000;
    }

    .sellix-date-picker svg {
        width: 35px;
        height: 35px;
    }

    .tour-container {
        /*background: #fff;*/
        padding: 20px 20px;
        margin-top: 20px;
        border-radius: 0.5rem;
    }

    .tour-header-line>div {
        width: 200px;
        /*background: #e8edf0;*/
        height: 0.5rem;
        border-radius: 0.5rem;
        margin-left: 1rem;
    }

    .tour-header-line>div>div {
        /*background: #6a3ce2;*/
        height: 0.5rem;
        border-radius: 0.5rem;
    }

    .tour-header-line {
        font-weight: 600;
        font-size: 12px;
        line-height: 15px;
        text-align: right;
        background-color: #6a3ce2;
        display: flex;
        align-items: center;
        transition: width 1s ease-in;
        padding: 5px;
        height: 25px;
    }

    .crossBtn {
        /*color: #555d67;*/
        /*background-color: white;*/
        border: 1px solid var(--bs-border-color);
        box-shadow: 0 1px 2px rgba(18, 20, 23, .06);
        margin-left: 20px;
        background: red;
        border: none;
        width: 25px;
        height: 25px;
    }

    .sidebar-container {
        height: inherit;
        max-height: inherit;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .ds-tab .nav {
        margin-top: 32px;
    }

    .ds-step {
        box-shadow: none;
        border-bottom: 1px solid var(--bs-border-color);
        display: flex;
        align-items: center;
        width: 100%;
        border-top: 0;
        border-radius: 0;
        padding: 20px;
    }

    .ds-step:last-child {
        border-bottom: 0;
    }

    .ds-step-img {
        min-width: 3rem;
        width: 3rem;
        height: 3rem;
        /*background: #eceafd;*/
        margin-right: 1rem;
        border-radius: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .ds-step-title {
        font-weight: 600;
        font-size: 16px;
        line-height: 19px;
        /*color: #121417;*/
    }

    .ds-step-desc {
        font-weight: 400;
        font-size: 13px;
        line-height: 18px;
        /*color: #555d67;*/
    }

    .ds-steps-btn {
        /*color: white;*/
        border: 0;
        height: 2.25rem;
        /*background-color: #121417;*/
        font-weight: 600;
        font-size: 14px;
        border-radius: .5rem !important;
        padding: 0 .25rem 0 1rem;
    }

    .ds-tab-content {
        border: 1px solid #e8edf0;
        border-top: 0;
    }

    .ds-step-img {
        min-width: 3rem;
        width: 3rem;
        height: 3rem;
        /*background: #eceafd;*/
        margin-right: 1rem;
        border-radius: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .ds-step-title {
        font-weight: 600;
        font-size: 16px;
        line-height: 19px;
        /*color: #121417;*/
    }

    .ds-step-desc {
        font-weight: 400;
        font-size: 13px;
        line-height: 18px;
        /*color: #555d67;*/
    }

    .ds-steps-btn {
        /*color: white;*/
        border: 0;
        height: 2.25rem;
        /*background-color: #121417;*/
        font-weight: 600;
        font-size: 14px;
        border-radius: .5rem !important;
        padding: 0 .25rem 0 1rem;
    }

    .ds-tab .nav-tabs .nav-link.active {
        /*background: transparent;*/
        position: relative;
        /*color: #121417;*/
    }

    .ds-tab .nav-tabs .nav-link.active:after {
        content: "";
        left: 0;
        width: 100%;
        height: 2px;
        /*background: #6a3ce2;*/
        display: flex;
        position: absolute;
        top: 100%;
        border-radius: 2px;
    }

    .ds-tab .nav-tabs .nav-link {
        font-weight: 500;
        font-size: 13px;
        line-height: 16px;
        /*color: #777f89;*/
        padding: 10px 10px;
    }

    .ds-reports {
        margin: 20px 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .ds-reports-block {
        padding: 1.25rem;
        /*background: white;*/
        border-radius: 0.5rem;
        box-shadow: 0 2px 4px -1px rgba(7, 14, 35, .08), 0px 2px 8px -2px rgba(7, 14, 35, .05);
        width: calc(20% - 0.75rem);
    }

    .ds-standard-title {
        font-weight: 600;
        font-size: 14px;
        line-height: 17px;
        /*color: #121417;*/
        margin-bottom: 1rem;
        white-space: nowrap;
    }

    .ds-reports-block-count {
        font-weight: 400;
        font-size: 24px;
        line-height: 29px;
        /*color: #121417;*/
        margin-bottom: 0;
    }

    .ds-reports-block-indicator {
        display: flex;
        align-items: center;
        border-radius: 0.5rem;
        padding: 0px 10px;
        width: fit-content;
        /*background: #f9ecdb;*/
        font-size: 13px;
        /*color: #e16727;*/
        margin-top: 20px;
    }

    .ds-indicator-icon svg {
        stroke: #e16727;
    }

    .ds-revenue-graph {
        /*background: #fff;*/
        padding: 20px;
    }

    .ds-revenue-graph-title {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .ds-revenue-graph-title span i {
        width: 10px;
        height: 10px;
        display: flex;
        border-radius: 100%;
        margin-right: 0.5rem;
    }

    .ds-revenue-graph-title span {
        justify-content: center;
        font-weight: 400;
        font-size: 12px;
        line-height: 15px;
        text-align: right;
        /*color: #777f89;*/
        margin-right: 1.25rem;
        display: flex;
        align-items: center;
    }

    .ds-revenue-graph-title span:first-child i {
        /*background: #555d67;*/
    }

    .ds-revenue-graph-title span:last-child i {
        /*background: #6a3ce2;*/
    }

    .ds-revenue-graph-note {
        display: flex;
        justify-content: center;
        white-space: nowrap;
        margin-top: 1.25rem;
        font-family: "Inter";
        font-style: normal;
        font-weight: 400;
        font-size: 12px;
        line-height: 15px;
        /*color: #a2aab4;*/
    }

    .ds-rate {
        padding: 20px 20px;
        border-radius: 4px;
        /*background: #fff;*/
    }
</style>
</body>

</html>