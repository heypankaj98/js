<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDisputesTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void 
     */
    public function up() {
        Schema::create('disputes', function (Blueprint $table) {
         $table->bigIncrements('id');
            $table->char('order_id', 36);
            $table->unsignedBigInteger('product_id');
            $table->unsignedBigInteger('buyer_id');
            $table->unsignedBigInteger('seller_id');
            $table->unsignedBigInteger('winner_id')->nullable();
            $table->string('status', 191)->default('unresolved');
            $table->timestamps();

            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('buyer_id')->references('id')->on('users');
            $table->foreign('seller_id')->references('id')->on('users');
            $table->foreign('winner_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('disputes');
    }

}
