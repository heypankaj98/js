@extends('layouts.admin.master')

@section('content')
<div class="content ">
        <div class="col">
            @yield('messenger-content')
        </div>
    </div>
@stop