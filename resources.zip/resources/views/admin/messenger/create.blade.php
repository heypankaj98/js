@extends('admin.messenger.template')
@section('title', 'chat with '. $chatuser->username)

@section('messenger-content')

<div class="mt-4">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="bg-card-2 mb-4 br1 p-16">
            
                    <div>
                        <h5 class="card-header-2 w-100 mb-4">Channels</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">#general</a></li>
                            <li><a href="#">#announcements</a></li>
                        </ul>
                    </div>
                </div>
                <div class="bg-card-2 h-100 br1 p-16">
                    <h5 class="card-header-2 w-100 mb-4">Chat Users</h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                        <li>  <a href="{{ route('admin.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                      <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">
                                    <span>{{$singletopic->receiverOrCreator()->username}} ( {{ $singletopic->mesasgeUnreadCount() }} )</span>
                                    <p class="small">online</p>
                                    @endif
                                </div>
                            </a>
                        </li>
                        @empty
                        No chat User
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 ">
                <div class="card-header-2 w-100 mb-4">
                    <h5>Chat with {{ $chatuser->username }}</h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">

                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">
                    <form action="{{ route("admin.messenger.storeTopic") }}" method="POST">
                        @csrf
                        <input type='hidden' name="recipient" value='{{$chatuser->id}}'>
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                <button type="submit" class="btn btn-main">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="bg-card-2 mb-4 br1 p-16">
                <h5 class="card-header-2 w-100 mb-4">Admin Users</h5>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                        @if (auth()->user()->id != $adminuser->id)
                            @if($adminuser->withChatMessages($adminuser->id) > 0)
                                <a href="{{ route('admin.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                                    <span class="badge text-bg-primary">{{ $adminuser->username }}</span>
                                </a>
                            @else
                                <a href="{{ route('admin.messenger.newMessages', [$adminuser->id]) }}">\
                                    <span class="badge text-bg-primary">{{ $adminuser->username }}</span>
                                </a>
                            @endif
                        @endif
                    @empty
                        No chat and admin Here
                    @endforelse
                </ul>
            </div>
            <!-- Mod --> 
            <div class="bg-card-2 p-16 br1">
                <h5 class="card-header-2 w-100 mb-4">Mod Users</h5>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                   @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('admin.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    @else
                    <a href="{{ route('admin.messenger.newMessages', [$moduser->id]) }}">     <span class="badge text-bg-primary">{{ $moduser->username}}</span></a>
               
                    @endif
                    @endif
                    @empty
                    No chat and Mod User
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>





@stop