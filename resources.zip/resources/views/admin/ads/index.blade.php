@extends('layouts.admin.master')
@section('content')


<div class="mt-4">
    <div class="">
       
        <div  class="row mb-2">
            <div class="col-lg-12">
                <a class="btn btn-main w-max-c" href="{{ route('admin.ads.create') }}">
                    Create Ads
                </a>
            </div>
        </div>
  

        <div class="card-header-2 w-100 my-4">
               Title
            </div>
        <div class="bg-card-2 br1">
           

            <div class="card-body">
                <div class="table-responsive">
                    <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-User">
                        <thead>
                            <tr>
                               
                                <th>
                                  Id
                                </th>
                                <th>
                                 Name
                                </th>
                                <th>
                                   Image
                                    
                                </th>
                                 <th>
                                   Size
                                </th>
                                <th>
                                   Impressions
                                </th>
                                <th>
                                   Click 
                                </th>
                               
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($ads as $key => $ad)
                            <tr data-entry-id="{{ $ad->id }}">
                                <td>
                                    {{ $ad->id ?? '' }}
                                </td>
                                <td>
                                    {{ $ad->name }}
                                </td>
                               <td>
    @if ($ad->getMedia('photo')->isNotEmpty())
        <a href="{{ $ad->getMedia('photo')->first()->getUrl($ad->size) }}" target="_blank" class="d-inline-block">
            <img src="{{ $ad->getMedia('photo')->first()->getUrl('thumb') }}" alt="Ad Image">
        </a>
    @else
        <span class="text-muted">No Photo</span>
    @endif
</td>

                                <td>

                                   {{ $ad->size }}

                                </td>
                                <td>

                                   {{ $ad->impression }}

                                </td>
                                <td>

                                   {{ $ad->click }}

                                </td>
                                <td>

                                    <a class="btn btn-xs btn-primary" href="{{ route('admin.ads.create', $ad->id) }}">
                                        {{ trans('global.view') }}
                                    </a>


                                    @can('admin_ads_edit')
                                    <a class="btn btn-xs btn-info" href="{{ route('admin.ads.edit', $ad->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                    @endcan

                                    @can('admin_ads_delete')
                                    <form action="{{ route('admin.ads.delete', $ad->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" class="d-inline-block">
        @method('DELETE')
        @csrf
          <input type="hidden" name="id" value="{{ $ad->id }}">
                                        <input type="submit" class="btn btn-danger btn-sm br-4" value="{{ trans('global.delete') }}">
                                    </form>
                                    @endcan

                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
                </div>
            </div>
        </div>
    </div>
</div>


@endsection