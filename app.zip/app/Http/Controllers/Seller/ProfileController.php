<?php

namespace App\Http\Controllers\Seller;

use App\Models\SellerMarketplace;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdatePasswordRequest;
use App\Http\Requests\UpdateProfileRequest;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\ProductCategory;
use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use App\Models\Role;
use App\Models\ProductReview;
use App\Models\UserMeta;
use App\Models\Permission;
use Laravolt\Avatar\Facade as Avatar;
use Carbon\Carbon;


class ProfileController extends Controller {

    public function index() {
        $categories = ProductCategory::with(['media'])->get();
        $orders = Order::all();
        $user = auth()->user();
        $recent_orders = Order::join('products', 'orders.product_id', '=', 'products.id')
                        ->where('products.seller_id', $user->id)
                        ->orderBy('orders.created_at', 'desc')
                        ->select('orders.*')
                        ->latest()->take(10)->get();
        $recent_products = Product::latest()->take(3)->where('seller_id', $user->id)->get();
        // Get the date for 30 days ago
        $startDate = Carbon::now()->subDays(30);

// Get the sales data for the last 30 days
        $sales = Order::whereBetween('created_at', [$startDate, Carbon::now()])
                ->selectRaw('DATE(created_at) as date, SUM(total) as total')
                ->groupBy('date')
                ->get();

// Create an array of total sales data for each day
        $totalSales = [];
        foreach ($sales as $sale) {
            $totalSales[$sale->date] = $sale->total;
        }
        $date = $startDate;
        while ($date <= Carbon::now()) {
            $day = $date->toDateString();
            if (!isset($totalSales[$day])) {
                $totalSales[$day] = 0;
            }
            $date->addDay();
        }
        ksort($totalSales);
        return view('seller.dashbaord', compact('categories', 'orders', 'user', 'totalSales', 'recent_orders', 'recent_products'));
    }


public function publicProfile($username)
{
    // Fetch the seller
    $seller = User::where('username', $username)->first();

    if (!$seller) {
        return redirect()->route('home')->with('error', 'Vendor not found');
    }

    // Fetch marketplace ratings for the seller
    $marketplaceData = SellerMarketplace::where('user_id', $seller->id)->get();

    // Calculate the average rating
    $ratings = $marketplaceData->pluck('rating');
    $averageRating = $ratings->avg();

    // Ensure the result is between 0 and 5
    $scaledAverageRating = min(5, max(0, $averageRating));

    // Fetch related data
    $orders = Order::where('seller_id', $seller->id)->where('status', 'completed')->count();
    $products = Product::where('seller_id', $seller->id)->get();
    $reviews = ProductReview::whereIn('product_id', $products->pluck('id'))
                            ->with('user')
                            ->paginate(10);
    $marketplaces = SellerMarketplace::where('user_id', $seller->id)->get();

    // Pass data to the view
    return view('common.seller_profile', compact('seller', 'orders', 'reviews', 'products', 'marketplaces', 'scaledAverageRating'));
}

    public function update(UpdateProfileRequest $request) {
        $user = auth()->user();

        $user->update($request->validated());

        return redirect()->route('frontend.profile.index')->with('message', __('global.update_profile_success'));
    }

    public function destroy() {
        $user = auth()->user();

        $user->update([
            'email' => time() . '_' . $user->email,
        ]);

        $user->delete();

        return redirect()->route('login')->with('message', __('global.delete_account_success'));
    }

    public function password(UpdatePasswordRequest $request) {
        auth()->user()->update($request->validated());

        return redirect()->route('frontend.profile.index')->with('message', __('global.change_password_success'));
    }

    public function profileSetting() {
        $categories = ProductCategory::with(['media'])->get();

        return view('buyer.profile', compact('categories'));
    }

    public function totalEarning() {

        return view('seller.earning');
    }

    public function balances() {

        return view('seller.balance');
    }

    public function invoices() {

        return view('seller.invoices');
    }
 

    public function sellerSettings() {
        return view('seller.settings');
    }

    public function toggleVacationMode(Request $request) {

        $user = auth()->user();
        $user->vacation_mode = $request->has('vacation_mode');
        $user->save();

        return redirect()->back()->with('status', 'Vacation mode updated successfully');
    }

    public function delegateAccess() {
        abort_if(Gate::denies('seller_delegate_access_manage'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $roleTitles = [12,13,14,15,16];
        $roles = Role::whereIn('id', $roleTitles)->get();

        $seller = auth()->user();
        $seller_staff_ids = json_decode($seller->meta_seller_staff, true) ?? [];
        $seller_staff = User::whereIn('id', $seller_staff_ids)->get();

        return view('seller.delegate-access.delegate-access', compact('roles', 'seller_staff'));
    }

    public function postDelegateAccess(Request $request) {
        abort_if(Gate::denies('seller_delegateaccess_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
         $roleTitles = [12,13,14,15,16];

        $request->validate([
            'username' => 'required|exists:users,username',
            'roles' => [
                'required',
                function ($attribute, $value, $fail) use ($roleTitles) {
                    if (!in_array($value, $roleTitles)) {
                        $fail('Invalid role selected.');
                    }
                },
            ],
        ]);

        $seller = auth()->user();
        $user = User::where('username', $request->input('username'))->first();

        if (!$user) {
            return redirect()->back()->withErrors(['username' => 'Invalid username']);
        }

        // Sync the roles for the user
        $user->roles()->sync($request->input('roles', []));

        $seller_staff_ids = json_decode($seller->meta_seller_staff, true) ?? [];

        if (count($seller_staff_ids) >= 3) {
            return redirect()->back()->withErrors(['staff' => 'Maximum staff members limit reached']);
        }

        $seller_staff_ids[] = $user->id;

        try {
            UserMeta::updateOrCreate(
                    [
                        'user_id' => $seller->id,
                        'key' => 'seller_staff'
                    ],
                    [
                        'value' => json_encode($seller_staff_ids),
                    ]
            );
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['staff' => 'Failed to update seller staff']);
        }

        return redirect()->back();
    }

}
