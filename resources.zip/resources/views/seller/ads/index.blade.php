@extends('layouts.seller.app')

@section('content')
<div class="container">
    <h1>Your Advertisements</h1>

    <!-- Success message -->
    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <!-- Vendor Personalized Banner -->
    <h3>Personalized Banner</h3>
   @if($vendorAd)
    <div class="mb-3">
        <p>Current Banner:</p>
        @if($vendorAd->banner)
            <img src="{{ asset('storage/' . $vendorAd->banner) }}" alt="Vendor Banner" class="img-fluid">
        @else
            <p>No banner uploaded.</p>
        @endif
    </div>
@else
    <p>No personalized banner found. Upload one below:</p>
@endif

    <!-- Upload Banner Form -->
@foreach($ads as $ad)  <!-- Iterating through ads -->
    <form action="{{ route('ads.storePersonalBanner', $ad->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="banner">Upload Personalized Banner</label>
            <input type="file" class="form-control" id="banner" name="banner" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload Banner</button>
    </form>
@endforeach


    <!-- Products for Advertisement -->
    <h3>Products for Advertisement</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{ $product->name }}</td>
                    <td>

                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Active Product Advertisements -->
    <h3>Your Product Advertisements</h3>
    @if($productAds->isEmpty())
        <p>No active product advertisements found.</p>
    @else
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($productAds as $ad)
                    <tr>
                        <td>{{ $ad->title }}</td>
                        <td>{{ $ad->description }}</td>
                        <td>${{ $ad->price }}</td>
                        <td>{{ ucfirst($ad->status) }}</td>
                        <td>
                            <form action="{{ route('ads.toggle', $ad->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <button type="submit" class="btn btn-warning">
                                    {{ $ad->status == 'active' ? 'Deactivate' : 'Activate' }}
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
@endsection
