@extends('layouts.admin.master')
@section('content')
<div class="mt-4">
<div class="card-header-2 w-100 mb-4">
        {{ trans('global.create') }} {{ trans('cruds.ads.create') }}
    </div>
<div class="bg-card-2 br1">
    <div class="card-body">
        
          @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
        <form method="POST" action="{{ route("admin.ads.store") }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="required" for="name">{{ trans('cruds.user.fields.name') }}</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', '') }}" required>
                @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{ $errors->first('name') }}
                </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
            </div>

            <div class="form-group">
                <label class="required" for="url">{{ trans('cruds.url') }}</label>
                <input class="form-control {{ $errors->has('redirect_url') ? 'is-invalid' : '' }}" type="text" name="redirect_url" id="url" value="{{ old('url', '') }}" required>
                @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{ $errors->first('redirect_url') }}
                </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Select Size</label>
                <select class="form-control py-0"  name="adsize" id="exampleFormControlSelect1">
                    <option value="540x984">540x984</option>
                    <option value="779x80">779x80</option>
                    <option value="300x250">300x250</option>
                </select>
                <span class="help-block">{{ trans('cruds.user.fields.roles_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="form-label">{{ trans('Upload Picture') }}</label><br>
                <input type="file" class="form-control" id="inputGroupFile02" name="picture">
                @error('picture')
                <div class="alert alert-danger" role="alert">
                    {{ $message }}
                </div> 
                @enderror
            </div>
            <div class="form-group">
                <button class="btn btn-main w-max-c" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>
</div>




@endsection