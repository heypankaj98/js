<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Cache\RateLimiter;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Modules\Forum\Http\Controllers\CategoryController;


class ThrottleCheckRequests {

    protected $limiter;

    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function __construct(RateLimiter $limiter) {
      
        $this->limiter = $limiter;
    }

public function handle($request, Closure $next, $maxAttempts = 10, $decaySeconds = 60)
{
    // dd($maxAttempts,$decaySeconds);
    // Generate a unique key for this user and request
    $key = $this->resolveRequestSignature($request);

    // Check if the user has exceeded the maximum allowed attempts
    if ($this->limiter->tooManyAttempts($key, $maxAttempts)) {
        // Clear the rate limiter key to reset attempts if desired
        $this->limiter->clear($key);

        // Redirect the user to the loginfailed page
        return redirect()->route('loginfailed');
    }

    // Register a new attempt
    $this->limiter->hit($key, $decaySeconds);

    // Process the request
    $response = $next($request);

    // Add rate-limit-related headers (optional, for debugging or API clients)
    $response->headers->add([
        'X-RateLimit-Limit' => $maxAttempts, // Maximum number of attempts
        'X-RateLimit-Remaining' => $this->limiter->retriesLeft($key, $maxAttempts), // Remaining attempts
        'X-RateLimit-Reset' => $this->limiter->availableIn($key), // Time until reset
    ]);

    return $response;
}

/**
 * Resolve a unique key for rate limiting based on the request.
 * You can customize this method to use user ID, IP address, or other identifiers.
 */
protected function resolveRequestSignature($request)
{
    // Example: Use the user's IP address as the key
    return $request->ip();
}


    protected function buildResponse($key, $maxAttempts, $decaySeconds) {
       
        $retryAfter = $this->limiter->availableIn($key);
        
        return redirect()->route('loginfailed');

        return new Response('Sorry, you have exceeded the maximum number of requests allowed for security reasons. In order to protect our system from potential attacks, please wait for ' . $decaySeconds . ' seconds before trying again. Thank you for your understanding.', 429, [
            'Retry-After' => $retryAfter,
            'X-RateLimit-Limit' => $maxAttempts,
            'X-RateLimit-Remaining' => 0,
            'X-RateLimit-Reset' => $this->limiter->availableIn($key),
        ]);
    }

}
