<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderDisputeNotification extends Notification {

    use Queueable;

    public $dispute;

    /**
     * Create a new notification instance.
     */
    public function __construct($dispute) {
        $this->dispute = $dispute;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array {
        return ['database'];
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array {
        return [
                //
        ];
    }

    public function toDatabase($notifiable) {
        session(['notification_sound_played' => false]);
        if ($this->dispute->relationLoaded('seller')) {
            return [
                'message' => 'You have a new dispute message!',
                'link' => route('seller.dispute.messages', $this->dispute->id),
            ];
        } else {
            return [
                'message' => 'You have a new dispute message!',
                'link' => route('dispute.messages', $this->dispute->id),
                'sound' => asset('assets/sound/notification.mp3'),
            ];
        }
    }

}
