<?php

namespace App\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class TicketLabel extends Model
{
    protected $casts = [
        'is_visible' => 'boolean',
    ];

    public static function boot()
    {
        parent::boot();

        static::saving(function (Label $category) {
            $category->slug = Str::slug($category->name);
        });
    }
     public function tickets(): BelongsToMany {
         
        return $this->belongsToMany(Ticket::class);
    }
}