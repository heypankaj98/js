<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('multisig_transactions', function (Blueprint $table) {
            $table->id();
            $table->text('multisig_address')->nullable;
            $table->text('multisig_redeem')->nullable;
            $table->string('txid')->nullable();
            $table->integer('vout')->nullable();
            $table->decimal('multisig_amount', 10, 8);
            $table->unsignedBigInteger('listing_id')->nullable();
            $table->unsignedBigInteger('buyer_id')->nullable();
            $table->unsignedBigInteger('seller_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('multisig_transactions');
    }
};
