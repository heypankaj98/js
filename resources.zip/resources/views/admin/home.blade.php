@extends('layouts.admin.master')
@section('content')

<div class="">
     <div class="banner">
    <div class="home-inn"></div>
    <div class="home-inner"><h4 class="hme">Admin</h4>
    </div>
    <div class="text-co" style="font-size:12px">In the <strong>Admin</strong> section, you can configure all setting of your account.</div>
    <div class="text-co" style="font-size:12px">Furthermore, the latest more posts displayed.</div>
</div>
    <div class="">
        <div class="row ds-screen-header">
            <div class="col-lg-10 col-md-10 col-sm-10">
                <div class="title p-2 br1 color-accent-2">
                    <h1 class="title mb-0" style="font-size:14px">
                        Good Morning, {{Auth::user()->username}}!  
                        <svg  width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21.44 28.0022H10.56C6.94 28.0022 4 25.0622 4 21.4422V11.9422C4 11.4222 4.42 11.0022 4.94 11.0022H27.06C27.58 11.0022 28 11.4222 28 11.9422V21.4422C28 25.0622 25.06 28.0022 21.44 28.0022Z" fill="url(#paint0_linear_1538_44007)"></path>
                            <path d="M21.44 28.0022H10.56C6.94 28.0022 4 25.0622 4 21.4422V11.9422C4 11.4222 4.42 11.0022 4.94 11.0022H27.06C27.58 11.0022 28 11.4222 28 11.9422V21.4422C28 25.0622 25.06 28.0022 21.44 28.0022Z" fill="url(#paint1_linear_1538_44007)"></path>
                            <path d="M21.44 28.0022H10.56C6.94 28.0022 4 25.0622 4 21.4422V11.9422C4 11.4222 4.42 11.0022 4.94 11.0022H27.06C27.58 11.0022 28 11.4222 28 11.9422V21.4422C28 25.0622 25.06 28.0022 21.44 28.0022Z" fill="url(#paint2_linear_1538_44007)"></path>
                            <path d="M21.44 28.0022H10.56C6.94 28.0022 4 25.0622 4 21.4422V11.9422C4 11.4222 4.42 11.0022 4.94 11.0022H27.06C27.58 11.0022 28 11.4222 28 11.9422V21.4422C28 25.0622 25.06 28.0022 21.44 28.0022Z" fill="url(#paint3_radial_1538_44007)"></path>
                            <path d="M21.44 28.0022H10.56C6.94 28.0022 4 25.0622 4 21.4422V11.9422C4 11.4222 4.42 11.0022 4.94 11.0022H27.06C27.58 11.0022 28 11.4222 28 11.9422V21.4422C28 25.0622 25.06 28.0022 21.44 28.0022Z" fill="url(#paint4_radial_1538_44007)"></path>
                            <path d="M29 28.0022H3C2.45 28.0022 2 28.4522 2 29.0022C2 29.5522 2.45 30.0022 3 30.0022H29C29.55 30.0022 30 29.5522 30 29.0022C30 28.4522 29.55 28.0022 29 28.0022Z" fill="url(#paint5_linear_1538_44007)"></path>
                            <path d="M29 28.0022H3C2.45 28.0022 2 28.4522 2 29.0022C2 29.5522 2.45 30.0022 3 30.0022H29C29.55 30.0022 30 29.5522 30 29.0022C30 28.4522 29.55 28.0022 29 28.0022Z" fill="url(#paint6_linear_1538_44007)"></path>
                            <path d="M29 28.0022H3C2.45 28.0022 2 28.4522 2 29.0022C2 29.5522 2.45 30.0022 3 30.0022H29C29.55 30.0022 30 29.5522 30 29.0022C30 28.4522 29.55 28.0022 29 28.0022Z" fill="url(#paint7_radial_1538_44007)"></path>
                            <path d="M29 28.0022H3C2.45 28.0022 2 28.4522 2 29.0022C2 29.5522 2.45 30.0022 3 30.0022H29C29.55 30.0022 30 29.5522 30 29.0022C30 28.4522 29.55 28.0022 29 28.0022Z" fill="url(#paint8_radial_1538_44007)"></path>
                            <path d="M16.43 9.24217C16.46 9.42217 16.26 9.55217 16.11 9.46217C15.53 9.12217 14.5 8.28217 14.5 6.65217C14.5 5.23217 16.19 4.13217 16.46 2.18217C16.49 1.99217 16.74 1.93217 16.85 2.09217C17.22 2.64217 17.7 3.66217 17.38 4.99217C16.93 6.92217 16.05 6.68217 16.43 9.24217Z" fill="url(#paint9_linear_1538_44007)"></path>
                            <path d="M10.93 9.24217C10.96 9.42217 10.76 9.55217 10.61 9.46217C10.03 9.12217 9 8.28217 9 6.65217C9 5.23217 10.69 4.13217 10.96 2.18217C10.99 1.99217 11.24 1.93217 11.35 2.09217C11.72 2.64217 12.2 3.66217 11.88 4.99217C11.43 6.92217 10.55 6.68217 10.93 9.24217Z" fill="url(#paint10_linear_1538_44007)"></path>
                            <g filter="url(#filter0_f_1538_44007)">
                                <path d="M10.7322 9.13282C10.7467 9.31282 10.6035 9.33217 10.5312 9.24217C10.2519 8.90217 9.39062 8.12995 9.39062 6.49995C9.39062 5.07995 11.0859 4.5975 11.0859 2.40626C11.1004 2.21626 11.2681 2.24181 11.3441 2.40633C11.5784 2.91405 11.7557 3.27154 11.6016 4.60154C11.3848 6.53154 10.2734 6.59373 10.7322 9.13282Z" fill="url(#paint11_linear_1538_44007)"></path>
                            </g>
                            <g filter="url(#filter1_f_1538_44007)">
                                <path d="M10.7889 9.28127C10.8174 9.63568 9.89051 8.25 10.0311 6.98438C10.1718 5.71875 11.0311 5.50002 11.2577 2.21096C11.6718 2.96096 11.8112 3.70248 11.7421 4.63284C11.6729 5.56319 10.2286 6.77345 10.7889 9.28127Z" fill="url(#paint12_radial_1538_44007)"></path>
                                <path d="M10.7889 9.28127C10.8174 9.63568 9.89051 8.25 10.0311 6.98438C10.1718 5.71875 11.0311 5.50002 11.2577 2.21096C11.6718 2.96096 11.8112 3.70248 11.7421 4.63284C11.6729 5.56319 10.2286 6.77345 10.7889 9.28127Z" fill="url(#paint13_radial_1538_44007)"></path>
                            </g>
                            <g filter="url(#filter2_f_1538_44007)">
                                <path d="M16.2566 9.13283C16.2711 9.31283 16.1279 9.33219 16.0557 9.24219C15.7763 8.90219 14.915 8.12997 14.915 6.49997C14.915 5.07997 16.6104 4.59751 16.6104 2.40628C16.6248 2.21628 16.7925 2.24182 16.8685 2.40635C17.1029 2.91406 17.2801 3.27155 17.126 4.60155C16.9093 6.53155 15.7979 6.59375 16.2566 9.13283Z" fill="url(#paint14_linear_1538_44007)"></path>
                            </g>
                            <g filter="url(#filter3_f_1538_44007)">
                                <path d="M16.2138 9.28125C16.2422 9.63566 15.3153 8.24998 15.4559 6.98436C15.5966 5.71873 16.4683 5.46875 16.6825 2.21094C17.0966 2.96094 17.236 3.70246 17.1669 4.63281C17.0977 5.56317 15.6534 6.77342 16.2138 9.28125Z" fill="url(#paint15_radial_1538_44007)"></path>
                                <path d="M16.2138 9.28125C16.2422 9.63566 15.3153 8.24998 15.4559 6.98436C15.5966 5.71873 16.4683 5.46875 16.6825 2.21094C17.0966 2.96094 17.236 3.70246 17.1669 4.63281C17.0977 5.56317 15.6534 6.77342 16.2138 9.28125Z" fill="url(#paint16_radial_1538_44007)"></path>
                            </g>
                            <path d="M21.93 9.24217C21.96 9.42217 21.76 9.55217 21.61 9.46217C21.03 9.12217 20 8.28217 20 6.65217C20 5.23217 21.69 4.13217 21.96 2.18217C21.99 1.99217 22.24 1.93217 22.35 2.09217C22.72 2.64217 23.2 3.66217 22.88 4.99217C22.43 6.92217 21.55 6.68217 21.93 9.24217Z" fill="url(#paint17_linear_1538_44007)"></path>
                            <g filter="url(#filter4_f_1538_44007)">
                                <path d="M21.7498 9.13283C21.7643 9.31283 21.6211 9.33219 21.5488 9.24219C21.2695 8.90219 20.4082 8.12997 20.4082 6.49997C20.4082 5.07997 22.1035 4.59751 22.1035 2.40628C22.118 2.21628 22.2857 2.24182 22.3616 2.40635C22.596 2.91406 22.7732 3.27155 22.6191 4.60155C22.4024 6.53155 21.291 6.59375 21.7498 9.13283Z" fill="url(#paint18_linear_1538_44007)"></path>
                            </g>
                            <g filter="url(#filter5_f_1538_44007)">
                                <path d="M21.7069 9.28125C21.7354 9.63566 20.8085 8.24998 20.9491 6.98436C21.0897 5.71873 21.9065 5.46875 22.1757 2.21094C22.5897 2.96094 22.7292 3.70246 22.66 4.63281C22.5909 5.56317 21.1466 6.77342 21.7069 9.28125Z" fill="url(#paint19_radial_1538_44007)"></path>
                                <path d="M21.7069 9.28125C21.7354 9.63566 20.8085 8.24998 20.9491 6.98436C21.0897 5.71873 21.9065 5.46875 22.1757 2.21094C22.5897 2.96094 22.7292 3.70246 22.66 4.63281C22.5909 5.56317 21.1466 6.77342 21.7069 9.28125Z" fill="url(#paint20_radial_1538_44007)"></path>
                            </g>
                            <defs>
                                <filter id="filter0_f_1538_44007" x="8.89062" y="1.77318" width="3.26855" height="8.02141" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.25" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <filter id="filter1_f_1538_44007" x="9.7666" y="1.96096" width="2.24219" height="7.62659" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.125" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <filter id="filter2_f_1538_44007" x="14.415" y="1.77319" width="3.26855" height="8.02141" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.25" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <filter id="filter3_f_1538_44007" x="15.1914" y="1.96094" width="2.24219" height="7.62659" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.125" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <filter id="filter4_f_1538_44007" x="19.9082" y="1.77319" width="3.26855" height="8.02141" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.25" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <filter id="filter5_f_1538_44007" x="20.6846" y="1.96094" width="2.24219" height="7.62659" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend>
                                    <feGaussianBlur stdDeviation="0.125" result="effect1_foregroundBlur_1538_44007"></feGaussianBlur>
                                </filter>
                                <linearGradient id="paint0_linear_1538_44007" x1="3.5" y1="19.5022" x2="28.3125" y2="19.5022" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#ACA9B3"></stop>
                                    <stop offset="0.18136" stop-color="#ADA0C1"></stop>
                                    <stop offset="0.455919" stop-color="#DBCEED"></stop>
                                    <stop offset="0.687657" stop-color="#F9F2FF"></stop>
                                    <stop offset="0.871536" stop-color="#FAF5FF"></stop>
                                    <stop offset="0.994962" stop-color="#ECEAF4"></stop>
                                </linearGradient>
                                <linearGradient id="paint1_linear_1538_44007" x1="16" y1="21.9375" x2="16" y2="30.5" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.153285" stop-color="#D0BEE6" stop-opacity="0"></stop>
                                    <stop offset="0.627737" stop-color="#7C7982"></stop>
                                    <stop offset="0.70073" stop-color="#3E3D40"></stop>
                                </linearGradient>
                                <linearGradient id="paint2_linear_1538_44007" x1="16" y1="11.0022" x2="16" y2="28.0022" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#C1C2C3"></stop>
                                    <stop offset="0.0136575" stop-color="#C4C4C4" stop-opacity="0"></stop>
                                </linearGradient>
                                <radialGradient id="paint3_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(5.3125 11.0022) rotate(91.9797) scale(0.904592 4.81537)">
                                    <stop stop-color="#A3A3A7"></stop>
                                    <stop offset="1" stop-color="#99989E" stop-opacity="0"></stop>
                                </radialGradient>
                                <radialGradient id="paint4_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(26.375 11.7812) rotate(90) scale(0.484375 13)">
                                    <stop stop-color="white"></stop>
                                    <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                                </radialGradient>
                                <linearGradient id="paint5_linear_1538_44007" x1="2" y1="30.0022" x2="30" y2="30.0022" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#634340"></stop>
                                    <stop offset="0.388393" stop-color="#724842"></stop>
                                    <stop offset="1" stop-color="#825057"></stop>
                                </linearGradient>
                                <linearGradient id="paint6_linear_1538_44007" x1="16" y1="28.0022" x2="16" y2="30.0022" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.436401" stop-color="#7B4359" stop-opacity="0"></stop>
                                    <stop offset="0.873901" stop-color="#7B4568"></stop>
                                </linearGradient>
                                <radialGradient id="paint7_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(24.6875 28.625) rotate(90) scale(0.625 10.25)">
                                    <stop stop-color="#A17C77"></stop>
                                    <stop offset="1" stop-color="#9F7A76" stop-opacity="0"></stop>
                                </radialGradient>
                                <radialGradient id="paint8_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(2.625 29.5) rotate(90) scale(1.1875 8.4906)">
                                    <stop stop-color="#7F5977"></stop>
                                    <stop offset="1" stop-color="#72575A" stop-opacity="0"></stop>
                                </radialGradient>
                                <linearGradient id="paint9_linear_1538_44007" x1="17.3125" y1="6.03125" x2="14.8125" y2="5.74573" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.110003" stop-color="#C5C2C0"></stop>
                                    <stop offset="0.652938" stop-color="#8E8D90"></stop>
                                </linearGradient>
                                <linearGradient id="paint10_linear_1538_44007" x1="11.8125" y1="6.03125" x2="9.3125" y2="5.74573" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.110003" stop-color="#B3B4B7"></stop>
                                    <stop offset="0.524238" stop-color="#8E8D90"></stop>
                                </linearGradient>
                                <linearGradient id="paint11_linear_1538_44007" x1="11.25" y1="6.35936" x2="9.39063" y2="6.03123" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#BBBBC1"></stop>
                                    <stop offset="1" stop-color="#9A98A0"></stop>
                                </linearGradient>
                                <radialGradient id="paint12_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(11.3749 2.59377) rotate(90) scale(3.75 3.08036)">
                                    <stop stop-color="#E5E5E5"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                                <radialGradient id="paint13_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(11.2499 10.2188) rotate(-75.7956) scale(4.58469 3.766)">
                                    <stop stop-color="#E5E5E5"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                                <linearGradient id="paint14_linear_1538_44007" x1="16.7744" y1="6.35937" x2="14.915" y2="6.03125" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#BBBBC1"></stop>
                                    <stop offset="1" stop-color="#9A98A0"></stop>
                                </linearGradient>
                                <radialGradient id="paint15_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.7997 2.59375) rotate(90) scale(3.75 3.08036)">
                                    <stop stop-color="#E5E5E5"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                                <radialGradient id="paint16_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.6747 10.2188) rotate(-75.7956) scale(4.58469 3.766)">
                                    <stop stop-color="#E5E5E5"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                                <linearGradient id="paint17_linear_1538_44007" x1="22.8125" y1="6.03125" x2="20.3125" y2="5.74573" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.110003" stop-color="#C4C4C6"></stop>
                                    <stop offset="1" stop-color="#8E8D90"></stop>
                                </linearGradient>
                                <linearGradient id="paint18_linear_1538_44007" x1="22.2676" y1="6.35937" x2="20.4082" y2="6.03125" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#BFBFC3"></stop>
                                    <stop offset="1" stop-color="#B1B0B8"></stop>
                                </linearGradient>
                                <radialGradient id="paint19_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(22.2929 2.59375) rotate(94.6976) scale(3.1912 2.62134)">
                                    <stop stop-color="#F1F0F6"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                                <radialGradient id="paint20_radial_1538_44007" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(22.1679 10.2188) rotate(-79.3921) scale(4.5218 3.71433)">
                                    <stop stop-color="#DFE0E4"></stop>
                                    <stop offset="1" stop-color="#E5E5E5" stop-opacity="0"></stop>
                                </radialGradient>
                            </defs>
                        </svg>
                    </h1>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2">
                <button type="button" class="sellix-date-picker br1">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.5 3.75H4.5C3.67157 3.75 3 4.42157 3 5.25V14.25C3 15.0784 3.67157 15.75 4.5 15.75H13.5C14.3284 15.75 15 15.0784 15 14.25V5.25C15 4.42157 14.3284 3.75 13.5 3.75Z" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M12 2.25V5.25" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M6 2.25V5.25" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M3 8.25H15" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M8.25 11.25H9" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M9 11.25V13.5" stroke="#ff7d00" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                    <div>Last 24 hours</div>
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
            <div class="breadcrumbs card-header-2 w-100 mt-4">
                    <a class="link" href="/">Here's what's happening with your store today.️</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="bg-card-2 mt-4 br1">
                    <div class="d-flex justify-content-between">
                        <div class="tour-header-title w-50" style="font-size:14px;">Get Started with 
                           <a class="navbar-brand m-0" href="/">
                                @if(session()->has('theme') && Session::get('theme') == "dark")
                                    <img src="{{ asset('assets/Dark_Alley_Logo.png')}}"  alt="alt"/>
                                @else
                                    <img src="{{ asset('assets/Dark_Alley_Logo.png')}}"  alt="alt"/>
                                @endif 
                            </a> 
                        
                        </div>
                        <div class="align-items-center justify-content-end d-flex w-50">
                            <div class="tour-header-line">
                                10% 
                                <div>
                                    <div class="tour-line-two"></div>
            
                                    
                                </div>
                            </div>
                            <button type="button" class="crossBtn">
                                <svg width="14" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 5L5 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M5 5L15 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <div class="ds-tab">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link br-4 active " id="payment-tab" data-bs-toggle="tab" data-bs-target="#payment" type="button" role="tab" aria-controls="payment" aria-selected="true">Payment</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link  br-4" id="branding-tab" data-bs-toggle="tab" data-bs-target="#branding" type="button" role="tab" aria-controls="branding" aria-selected="false">Branding</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link br-4 " id="createProduct-tab" data-bs-toggle="tab" data-bs-target="#createProduct" type="button" role="tab" aria-controls="createProduct" aria-selected="false">Create Product</button>
                            </li>
                        </ul>
                        <div class="ds-tab-content tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="payment" role="tabpanel" aria-labelledby="payment-tab">
                                <div class="ds-step d-flex align-items-center justify-content-between ">
                                    <div class="ds-step-img">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M18 5H6C4.34315 5 3 6.34315 3 8V16C3 17.6569 4.34315 19 6 19H18C19.6569 19 21 17.6569 21 16V8C21 6.34315 19.6569 5 18 5Z" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M3 10H21" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M7 15H7.01" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M11 15H13" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between w-100">
                                        <div>
                                            <div class="ds-step-title">Bitcoin BTC Node Payment</div>
                                            <div class="ds-step-desc">Connect your BTC node  to accept payments on core.</div>
                                        </div>
                                        <div class="pl-5">
                                            <button type="button" class="ds-steps-btn">
                                                @if($isnoderunning)
                                                BTC running  
                                                @else
                                                BTC Stoped  
                                                @endif
                                                <svg width="20" height="20" class="icon" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="margin-left: 0.5rem;">
                                                    <path d="M4.16675 10H15.8334" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M10.8333 15L15.8333 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M10.8333 5L15.8333 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="ds-step d-flex align-items-center justify-content-between ">
                                    <div class="ds-step-img">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M18 5H6C4.34315 5 3 6.34315 3 8V16C3 17.6569 4.34315 19 6 19H18C19.6569 19 21 17.6569 21 16V8C21 6.34315 19.6569 5 18 5Z" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M3 10H21" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M7 15H7.01" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M11 15H13" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between w-100">
                                        <div>
                                            <div class="ds-step-title">Monero XMR node Payment</div>
                                            <div class="ds-step-desc">Connect your Monero node to accept payments.</div>
                                        </div>
                                        <div class="pl-5">
                                            <button type="button" class="ds-steps-btn">
                                                Enable
                                                <svg width="20" height="20" class="icon" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="margin-left: 0.5rem;">
                                                    <path d="M4.16675 10H15.8334" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M10.8333 15L15.8333 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    <path d="M10.8333 5L15.8333 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="branding-tab">...</div>
                            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="createProduct-tab">...</div>
                        </div>
                    </div>
                </div>
                <div class="ds-reports">
                    <div class="ds-reports-block ">
                        <p class="ds-standard-title">Total Revenue</p>
                        <div class="ds-reports-block-count">
                            <span>$0.00</span>
                            <div class="ds-reports-block-indicator">
                                <span class="ds-indicator-icon">
                                    <span class="ds-">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 10H15" stroke="var(--orange6)" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span>0.00%</span>
                            </div>
                        </div>
                    </div>
                    <div class="ds-reports-block ">
                        <p class="ds-standard-title">Total Revenue</p>
                        <div class="ds-reports-block-count">
                            <span>$0.00</span>
                            <div class="ds-reports-block-indicator">
                                <span class="ds-indicator-icon">
                                    <span class="ds-">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 10H15" stroke="var(--orange6)" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span>0.00%</span>
                            </div>
                        </div>
                    </div>
                    <div class="ds-reports-block ">
                        <p class="ds-standard-title">Total Revenue</p>
                        <div class="ds-reports-block-count">
                            <span>$0.00</span>
                            <div class="ds-reports-block-indicator">
                                <span class="ds-indicator-icon">
                                    <span class="ds-">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 10H15" stroke="var(--orange6)" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span>0.00%</span>
                            </div>
                        </div>
                    </div>
                    <div class="ds-reports-block ">
                        <p class="ds-standard-title">Total Revenue</p>
                        <div class="ds-reports-block-count">
                            <span>$0.00</span>
                            <div class="ds-reports-block-indicator">
                                <span class="ds-indicator-icon">
                                    <span class="ds-">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 10H15" stroke="var(--orange6)" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span>0.00%</span>
                            </div>
                        </div>
                    </div>
                    <div class="ds-reports-block ">
                        <p class="ds-standard-title">Total Revenue</p>
                        <div class="ds-reports-block-count">
                            <span>$0.00</span>
                            <div class="ds-reports-block-indicator">
                                <span class="ds-indicator-icon">
                                    <span class="ds-">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 10H15" stroke="var(--orange6)" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span>0.00%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8 col-lg-8 col-md-8">
                <div id="dashboard-graph" class="bg-card-2 h-100 br1">
                    <div class="ds-revenue-graph-title">
                        <div class="ds-standard-title mb-0">Revenues &amp; Orders</div>
                        <span><span><i></i> Revenue </span><span><i></i> Order </span></span>
                    </div>
                    <div class="ds-revenue-graph-note">This graph will always show a 14 days or higher time span</div>
                </div>
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4">
                <div class="ds-rate bg-card-2 h-100 br1">
                    <div class="ds-standard-title">Return Customers Rate</div>
                    <div class="ds-rate-block">
                        graph
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

