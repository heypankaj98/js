<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Advertisement extends Model implements HasMedia {

    use HasFactory,
        InteractsWithMedia;

    public $table = 'advertisement';
    protected $appends = [
        'photo',
    ];
    protected $fillable = [
        'name',
        'type',
        'size',
        'redirect_url',
        'picture',
        'status'
    ];

    public function registerMediaConversions(Media $media = null): void {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50)->format('webp');
        $this->addMediaConversion('540x984')->fit('crop', 540, 984)->format('webp');
        $this->addMediaConversion('779x80')->fit('crop', 779, 80)->format('webp');
        $this->addMediaConversion('300x250')->fit('crop', 300, 250)->format('webp');
    }

    public function getPhotoAttribute() {
        $file = $this->getMedia('photo')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
        }
        return $file;
    }

}
