@extends('layouts.admin.master')        @section('content')

@section('content')
<div class="mt-4">
    <div class="bg-card-2 br1">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="">
                <div class="bg-card-1">
                    <form action="{{ route('admin.error') }}" method="GET">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search error messages" value="{{ $search ?? '' }}">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-main">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-Product mb-3">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Error Code</th>
                                    <th>Error Message</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($errors as $error)
                                <tr>
                                    <td>{{ $error->id }}</td>
                                    <td>{{ $error->error_code }}</td>
                                    <td>{{ $error->error_message }}</td>
                                    <td>{{ $error->created_at }}</td>
                                    <td>{{ $error->updated_at }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                        {{ $errors->links('partials.pagination') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    
</div>
@endsection
