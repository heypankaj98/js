<?php
namespace App\Http\Controllers;

use Auth;
use App\Models\{
    Product,
    ProductCategory,
    User,
    Order,ShippingMethod
};
// use App\Models\SellerAdvertisement;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use App\Tools\PGP;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use App\Models\SellerAdvertisement;

class HomeController {

public function index() {
    $products = Product::inRandomOrder()->paginate(config('settings.paginate'));
    $categories = ProductCategory::whereNull('parent_id')->get();

    
    // Select 3 random featured sellers
    $featuredSellers = User::where('isSeller', 1)
                           ->where('featured', 1)
                           ->inRandomOrder()
                           ->take(6)
                           ->get()
                           ->map(function ($seller) {
                               $orderCount = Order::where('seller_id', $seller->id)
                                                  ->where('status', 'completed')
                                                  ->count();
                               $seller->order_count = $orderCount;
                               $seller->reputation = match (true) {
                                   $orderCount >= 300 => 'Demon Customer',
                                   $orderCount >= 95 => 10,
                                   $orderCount >= 85 => 9,
                                   $orderCount >= 75 => 8,
                                   $orderCount >= 65 => 7,
                                   $orderCount >= 55 => 6,
                                   $orderCount >= 45 => 5,
                                   $orderCount >= 35 => 4,
                                   $orderCount >= 25 => 3,
                                   $orderCount >= 15 => 2,
                                   $orderCount >= 5 => 1,
                                   default => 0,
                               };
                               return $seller;
                           });

    $ads = SellerAdvertisement::where('status', 'active')->get();

    return view('buyer.home', compact('products', 'categories', 'featuredSellers', 'ads'));
}

public function filter(Request $request)
{
    // Get the featured users (if needed in the view)
    $users = User::where('featured', 1)->get();

    // Initialize the query builder for products
    $productsQuery = Product::query();

    // Get the price sorting option from the request
    $priceSort = $request->input('priceSort');

    // Apply sorting logic based on priceSort
    if ($priceSort === 'asc') {
        $productsQuery->orderBy('price', 'asc');
    } elseif ($priceSort === 'desc') {
        $productsQuery->orderBy('price', 'desc');
    } else {
        // Default sorting: order by newest products
        $productsQuery->orderBy('created_at', 'desc');
    }

    // Get the filtered and paginated products
    $products = $productsQuery->paginate(config('settings.paginate'));

    // Get categories for the sidebar
    $categories = ProductCategory::whereNull('parent_id')->get();

    // Generate the base URL for the filter
    $queryString = http_build_query($request->except('page')); // Exclude 'page' as it's handled by pagination

    // Return the view with the filtered results and the query parameters to preserve state
    return view('buyer.home', compact('products', 'categories', 'priceSort', 'users', 'queryString'));
}



    public function changeCurrency($currency) {
        $validator = Validator::make(['currency' => $currency], [
                    'currency' => 'required|in:USD,EUR,GBP,JPY,CHF,RUB,AUD,INR,CAD,CNH',
        ]);

        if ($validator->fails()) {
            return redirect()->back();
        } else {
            session(['currency' => $currency]);
        }

        return redirect()->back();
    }

    public function changeLanguage($language) {
        $validator = Validator::make(['language' => $language], [
                    'language' => 'required|in:en,ru,hi,es,ja,zh,fr',
        ]);

        if ($validator->fails()) {
            return redirect()->back();
        } else {
            session(['language' => $language]);
        }

        return redirect()->back();
    }

    public function verifyEnable2fa(Request $request) {
        $pgpKey = Auth::user()->pgp_key;

        if (is_null($pgpKey)) {
            throw new \Exception('Please enter a valid PGP key for verification!');
        }
        session()->put('pgp_key', $pgpKey);
        PGP::verification($pgpKey, 'confirm_enable2fa_pgp_key');

        return redirect()->route('user.profile.security', '#change2fa');
    }

    public function putChange2fa(Request $request) {
        if (!session()->has('verification_name')) {
            return redirect()->back()->with('error', 'Oops... Cancel and try again!');
        }
        #Decrypt session verification code
        $verificationCode = Crypt::decryptString(session()->get('verification_code'));

//        if ($request->verification_code !== $verificationCode) {
//            return redirect()->back()->with('error', 'Invalid verification code!');
//        }

        $user = Auth::user();
        if ($user->twofa) {
            $user->twofa = 0;
        } else {
            $user->twofa = 1;
        }

        $user->save();
        session()->forget(['pgp_key', 'enable2fa', 'verification_name', 'encrypted_message', 'verification_code']);
        return redirect()->back()->with('success', '2fa Enabled successfull');
    }

public function productDetails($product) {
    // Retrieve the product by its ID
    $product = Product::whereId($product)->first();
  $shipping_method = $product->shipping_method;
$shipping_method = unserialize($shipping_method);
$shippingMethods = ShippingMethod::whereIn('id', $shipping_method)->get();

    // Check if the product exists
    if ($product) {

        // Increment the visit_count
        $product->increment('visit_count');

        // Retrieve associated questions, categories, and reviews
        $questions = $product->questions()->get();
        $categories = ProductCategory::get();
        $reviews = $product->reviews()->paginate(10, ['*'], 'review');
        
      
        // Return the view with the product data
        return view('common.product', compact('product', 'categories', 'reviews','shippingMethods'));
    }

    // Optionally handle the case where the product does not exist
    return redirect()->route('products.index')->with('error', 'Product not found');
}



    public function themeSwitch() {
        if (Session::exists('theme')) {
            $theme = Session::get('theme');
            if ($theme == 'dark') {
                Session::put('theme', 'light');
            } else {
                Session::put('theme', 'dark');
            }
        } else {
            Session::put('theme', 'dark');
        }

        return redirect()->back();
    }

    public function createAvatar() {
        $svg = new \SimpleXMLElement(file_get_contents(asset('light.svg')));

        foreach ($svg->xpath('//svg:rect | //svg:circle | //svg:path') as $element) {
            $color = sprintf('#%06X', mt_rand(0, 0xFFFFFF));

            if (isset($element['fill'])) {
                $element['fill'] = $color;
            }
            if (isset($element['stroke'])) {
                $element['stroke'] = $color;
            }
        }
        $modifiedSvg = $svg->asXML();
    }
public function Support()
{
    $unreadMessagesCount = DB::table('qa_messages')
        ->where('sender_id', 1)  // Assuming the admin has sender_id = 1
        ->where('receiver_id', auth()->id())  // Logged-in user as the recipient
        ->whereNull('read_at')  // Only unread messages
        ->count();

    return view('common.support', compact('unreadMessagesCount'));
}


      public function InfoCenter()
    {
        return view('common.infocenter');
    }
      public function Faq()
    {
        return view('common.faq');
    }
      public function twofa()
    {
        return view('common.twofa');
    }
      public function aboutus()
    {
        return view('common.aboutus');
    }
      public function darkrules()
    {
        return view('common.darkrules');
    }
      public function protector()
    {
        return view('common.protector');
    }
      public function findus()
    {
        return view('common.findus');
    }
public function showPage()
{
    $utcTime = Carbon::now('UTC')->format('Y-m-d H:i:s');
    return view('layouts.pagefooter', compact('utcTime'));
}

public function startmessage()
{
    // Check if the logged-in user is an admin
    if (auth()->user()->is_admin) {
        return redirect()->back()->with('error', 'Admin cannot start a conversation with themselves.');
    }

    // Retrieve the admin user for normal users
    $chatuser = User::find(1);  // Assuming admin has id = 1

    // Check if the admin user exists
    if (!$chatuser) {
        abort(404, 'Admin user not found');
    }

    return view('common.start_message', compact('chatuser'));
}


}
