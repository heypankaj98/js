<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Gate;
use Illuminate\Http\Response;

class UpdateUserRequest extends FormRequest
{
    public function authorize()
    {
       return Gate::allows('admin_user_edit');
    }

    public function rules()
    {
        return [
            'username' => 'required',
            'password' => 'nullable|min:6',
            'roles' => 'required|array',
            'roles.*' => 'exists:roles,id',
            'featured'=>'nullable',
        ];
    }
}
