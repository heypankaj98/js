<?php

namespace App\Policies\Forum;

class ForumPolicy
{
    public function createCategories($user): bool
    {
       return $user->inRole('admin') || $user->inRole('moderator');
    }

    public function manageCategories($user): bool
    {
        return $this->moveCategories($user) ||
               $this->renameCategories($user);
    }

    public function moveCategories($user): bool
    {
        return $user->inRole('admin') || $user->inRole('moderator');
//        return true;
    }

    public function renameCategories($user): bool
    {
        return $user->inRole('admin') || $user->inRole('moderator');
//        return true;
    }

    public function markThreadsAsRead($user): bool
    {
        return true;
    }

    public function viewTrashedThreads($user): bool
    {
        return $user->inRole('admin') || $user->inRole('moderator');
    }

    public function viewTrashedPosts($user): bool
    {
        return $user->inRole('admin') || $user->inRole('moderator');
    }
}
