@extends('buyer.dispute.template')      @section('messenger-content')

<div class="container-fluid h-100 bg-body-tertiary">
    <div class="row h-100 align-items-center">
        
        <div class="col-md-3">
            <div class="d-flex flex-column h-100 chat-sidebar">
                <div class="p-3 mt-auto">
                    <h5 class=" mb-3"> {{ trans('global.disputes_users') }} </h5>
                    <ul class="list-unstyled">
                        @forelse($disputes as $dispute)
                            <li>
                                <a href="{{ route('dispute.messages', [$dispute->id]) }}">
                                    <div class="user_info">
                                        <img src="{{ $dispute->seller->avatar }}" class="rounded-circle">
                                        <span>{{ $dispute->seller->username }}</span>
                                        <p class="small">{{ trans('global.status') }} {{ $dispute->status }}</p>
                                        <p class="small">{{ trans('global.order') }} {{ $dispute->order_id }}</p>
                                    </div>
                                </a>
                            </li>
                        @empty
                            {{ trans('common.no') }} {{ trans('common.dispute') }}  
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card">
                <div class="card-header">
                    <h5>{{ trans('global.dispute_for_order') }}  ( {{$order->order_id}} )</h5>
                </div>
                <div class="card-footer">
                    <form method="POST" action="{{ route('user.orders.store_dispute') }}" >
                        @csrf
                        <input type='hidden' name="order_id" value='{{$order->id}}'>
                        <input type='hidden' name="product_id" value='{{$order->product_id}}'>
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                <button type="submit" class="btn btn-primary">{{ trans('global.send') }} </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="p-3 mt-auto">
                <h5 class="mb-3">{{ trans('global.admin_users') }}</h5>
            </div>
            <div class="p-3 mt-auto">
                <h5 class=" mb-3">{{ trans('global.mod_users') }}</h5>
            </div>
        </div>
    </div>
</div>
@stop