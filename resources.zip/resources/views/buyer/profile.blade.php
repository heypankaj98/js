@extends('layouts.buyer.app')


@section('content')


<div class="dashboard-screen bg-card-1">
    <h2 class="custom-title my-4">{{ trans('common.user') }} {{ trans('common.profile') }}</h2>

    <section>
        <div>
            {{-- Breadcrumb --}}
            <div>
                <div class="breadcrumb-nav">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="#" class="color-accent-2">{{ trans('common.home') }}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="color-accent-2">{{ trans('common.user') }}</a></li>
                            <li class="breadcrumb-item active">{{ trans('common.user') }} {{ trans('common.profile') }}</li>
                        </ol>
                    </nav>
                </div>
            </div>

            {{-- Profile Cards --}}
            <div class="row mb-4">
                {{-- Avatar Update --}}
                <div class="col-md-4 profile-card1 mb-md-3 mb-lg-0">
                    <div class="bg-card-2 h-100 br1">
                        <div class="card-body text-center">
                            @if (Auth::user()->avatar)
                                <img src="{{ Str::startsWith(Auth::user()->avatar, 'data:image') ? Auth::user()->avatar : asset('storage/' . Auth::user()->avatar) }}" alt="Avatar" class="profile_image" width="100" height="100">
                            @endif
                            <h5 class="my-3">{{ Auth::user()->username }}</h5>
                            <p class="text-muted mb-4">******************</p>
                        </div>
                    </div>
                </div>

                {{-- Avatar Form --}}
                <div class="col-md-4 profile-card2 mb-md-3 mb-lg-0">
                    <div class="bg-card-2 h-100 br1">
                        <div class="card-body">
                            <form action="{{ route('user.profile.update.picture') }}" method="POST" enctype="multipart/form-data" class="h100 d-flex flex-column align-items-center justify-content-center"> 
                                @csrf
                                <div class="mb-3 form-label">
                                    <label class="form-label mb-5 card-header-2 w-100">Update {{ trans('common.custom') }} {{ trans('common.avatar') }}</label>
                                    <input type="file" name="avatar" class="form-control card-bodyxz form-control9" id="avatar">
                                </div>
                                <button type="submit" class="btn btn-main card-bodyxzx mt-4">{{ trans('common.update') }} {{ trans('common.avatar') }}</button>
                            </form>
                        </div>
                    </div>
                </div>

                {{-- Two-Factor Authentication --}}
                <div class="col-md-4 profile-card3 mb-md-3 mb-lg-0">
                    <div class="bg-card-2 h-100 br1">
                        <div class="card-header-2">{{ trans('product.two_factor_authentication') }}</div>
                        <div class="card-body">
                            <div class="col-12 mt-4 d-flex align-items-center">
                                <span class="f18 d-block mt-5 mb-5 me-3">{{ trans('common.current') }} {{ trans('common.status') }} :</span>
                                @if(auth()->user()->twofa)
                                    <span class="badge bg-primary badge-primary fs-6 px-3 py-2">Enabled</span>
                                @else
                                    <span class="badge bg-primary badge-primary fs-6 px-3 py-2">Disabled</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Additional User Information --}}
            <div class="row profile-part-main-two mb-3">
                {{-- User Info --}}
                <div class="col-md-6">
                    <div class="card mb-4 br1">
                        <div class="card-body">
                            <div class="card-header-2 w-100 mb-4">User Information</div>
                            @foreach([
                                ['label' => trans('common.user') . ' ' . trans('common.name'), 'value' => Auth::user()->username],
                                ['label' => trans('common.seller'), 'value' => Auth::user()->isSeller ? trans('common.yes') : trans('common.no')],
                                ['label' => trans('common.moderator'), 'value' => Auth::user()->isModerator() ? trans('common.yes') : trans('common.no')],
                                ['label' => trans('common.last') . ' ' . trans('auth.sign_in'), 'value' => \Carbon\Carbon::parse(Auth::user()->updated_at)->diffForHumans()],
                                ['label' => trans('common.join'), 'value' => \Carbon\Carbon::parse(Auth::user()->created_at)->diffForHumans()],
                                ['label' => trans('common.pgp'), 'value' => Auth::user()->pgp_key ? trans('common.yes') : trans('common.no')],
                            ] as $info)
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <p class="mb-0 text-primary">{{ $info['label'] }}:</p>
                                    </div>
                                    <div class="col-6">
                                        <p class="text-muted mb-0">{{ $info['value'] }}</p>
                                    </div>
                                </div>
                                <hr>
                            @endforeach
                        </div>
                    </div>
                </div>

                {{-- Referral Information --}}
                <div class="col-md-6">
                    <div class="card mb-4 mb-md-0 br1">
                        <div class="card-body">
                            <p class="card-header-2 w-100 mb-4">{{ trans('common.referral') }} {{ trans('common.code') }}:</p>
                            <button type="submit" class="btn btn-main mb-2">{{ Auth::user()->reference_code }}</button>
                            <p class="mb-2 text-primary font-italic me-1">{{ trans('common.referral') }} {{ trans('common.link') }}:</p>
                            <div class="bg-card-1">
                                <div class="text-decoration-underline">
                                    {{ route('register.show') }}?referral_code={{ Auth::user()->reference_code }}
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="mb-2 text-primary font-italic me-1">{{ trans('common.referral') }} {{ trans('common.points') }}:</p>
                                <button class="btn btn-main">{{ Auth::user()->earnedReferralPoints() ?? 'None' }}</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@endsection
