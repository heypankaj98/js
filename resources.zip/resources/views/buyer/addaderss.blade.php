@extends('layouts.buyer.app')

@section('content')

<div class="mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">User Balances</div>

                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center bg-card-1">
                            Bitcoin (BTC)
                            <span class="badge badge-primary badge-pill">{{ $user->btc_address }}</span>
                            <form action="{{ route('user.delete.address', ['coin' => 'btc_address']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger br-4  btn-sm">Delete Address</button>
                            </form>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center bg-card-1">
                            Monero (XMR)
                            <span class="badge badge-primary badge-pill">{{ $user->xmr_address }}</span>
                            <form action="{{ route('user.delete.address', ['coin' => 'xmr_address']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger br-4 btn-sm">Delete Address</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
        <div class="bg-card-2 h-100 br1">
                <div class="bg-card-1">
                    <a href="{{ route('user.addersedit', $user->id) }}" class="btn btn-info br-4 w-100">Edit Addresses</a>

                    @if (session('success'))
                        <div class="alert alert-success mt-3" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('user.adderss.add.btc') }}">
                        @csrf

                        <div class="form-group pt-3">
                            <label for="currency my-3 d-block">Select Type</label>
                            <select class="form-control py-0 mt-2" id="currency" name="coin">
                                <option value="btc_address">Bitcoin (BTC)</option>
                                <option value="xmr_address">Monero (XMR)</option>
                                <option value="ltc_address">Litecoin (LTC)</option>
                            </select>
                        </div>
                        <div class="form-group pt-3">
                            <label for="addresses">Add Addresses</label>
                            <input type="text" class="form-control mt-2" id="addresses" name="addresses" placeholder="Enter addresses" required>
                        </div>
                        <button type="submit" class="btn btn-main mt-4 w-100">Save Addresses</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
