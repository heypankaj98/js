<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
public function up()
{
    Schema::table('seller_advertisements', function (Blueprint $table) {
        $table->string('banner')->nullable()->after('image');
    });
}

public function down()
{
    Schema::table('seller_advertisements', function (Blueprint $table) {
        $table->dropColumn('banner');
    });
}

};
