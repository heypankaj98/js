@extends('layouts.seller.app')

@section('content')
<h1>Seller List</h1>

@if(session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
@endif

<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Verified</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($sellers as $seller)
            <tr>
                <td>{{ $seller->id }}</td>
                <td> <a class="vendore-name" href="{{ route('seller.profile', $seller->username) }}">{{ $seller->username }}</a></td>
                <td>{{ $seller->is_verified ? 'Yes' : 'No' }}</td>
                <td>
                    <form action="{{ route('admin.verify.seller', $seller->id) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-{{ $seller->is_verified ? 'danger' : 'success' }}">
                            {{ $seller->is_verified ? 'Unverify' : 'Verify' }}
                        </button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection
