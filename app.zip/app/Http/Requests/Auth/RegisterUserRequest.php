<?php
namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;
use Hash,Auth;
use Illuminate\Support\{
    Str,
    Carbon
};
use App\Models\Referrals;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use Laravolt\Avatar\Facade as Avatar;
use App\Rules\ValidCaptchaRule;
use App\Tools\Mnemonic;
use App\Models\User;

class RegisterUserRequest extends FormRequest {

    public function authorize() {
        return !auth()->check();
    }

    public function rules() {
        return [
            'username' => 'required|unique:users,username|alpha_num|min:4|max:20',
            'password' => 'required|min:8|max:80|confirmed',
            'reference_code' => 'nullable|exists:users,reference_code',
            'withdrawal_pin' =>'required|min:4|max:6|',
            'anti_phishing' =>'required|min:4|',
            'captcha' => 'required|captcha',
        ];
    }

    public function messages() {
        return [
            'username.required' => 'The username field is required.',
            'username.unique' => 'The username has already been taken.',
            'username.alpha_num' => 'The username may only contain letters and numbers.',
            'username.min' => 'The username must be at least 4 characters.',
            'username.max' => 'The username may not be greater than 20 characters.',
            'password.required' => 'The password field is required.',
            'password.min' => 'The password must be at least 8 characters.',
            'password.max' => 'The password may not be greater than 80 characters.',
            'password.confirmed' => 'The password confirmation does not match.',
            'reference_code.exists' => 'The provided reference code does not exist.',
            'captcha.required' => 'Please enter the CAPTCHA code.',
            'captcha.captcha' => 'The CAPTCHA code entered is invalid.',
        ];
    }

    public function register() {
        $mnemonic = (new Mnemonic())->generate(config('marketplace.mnemonic_length'));
        if (session()->has('mnemonic_key')) {
            session()->forget('mnemonic_key');
        }
        session()->put('mnemonic_key', $mnemonic);

        $user = new User();
        $user->username = $this->username;
        $user->password = Hash::make($this->password);
        // $user->pin = $this->pin;
        $user->withdrawal_pin = $this->withdrawal_pin;
        $user->anti_phishing = $this->anti_phishing;
        $user->reference_code = Str::random(15);
        $user->last_login = now();
        $user->avatar = Avatar::create($this->username)->setDimension(100, 100)->toBase64();
        $user->mnemonic = bcrypt(hash('sha256', $mnemonic));
      
        $user->save();

        if (!is_null($this->reference_code)) {
            if ($affiliate = User::where('reference_code', $this->reference_code)->first()) {
                $referral = new Referrals();
                $referral->referred_user_id = $user->id;
                $referral->user_id = $affiliate->id;
                $referral->earned = 10;
                $referral->save();
            }
        }

        // Check if the user has a BTC account
        if (!$user->btc_account) {
            // Create a new BTC account and tag it with the username
            $btcAccount = PayWay::createNewAccount("Bitcoin", ['username' => $user->username]);
            $user->btc_account = $btcAccount;
        }

        // Check if the user has a Monero account
        if (!$user->monero_account) {
            // Create a new Monero account and tag it with the username
            $moneroAccount = PayWay::createNewAccount("Monero", ['username' => $user->username]);
            $user->monero_account = $moneroAccount;
        }

        $user->save();
    }

}
