<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mirrorlink extends Model
{
    use HasFactory;

    // Table name is already set correctly
    protected $table = 'mirrorlink';

    // Fillable fields for mass assignment
    protected $fillable = ['content', 'link'];  // Add 'link' to fillable

    // Optionally, if you're using timestamps, you can specify this explicitly
    public $timestamps = true;
}
