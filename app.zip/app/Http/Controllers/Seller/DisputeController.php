<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{
    Order,
    Dispute,
    DisputeMessage
};
use Auth;
use Illuminate\Support\Str;
use App\Notifications\OrderDisputeNotification;

class DisputeController extends Controller {

    public function index() {
        $disputes = Dispute::where('seller_id',Auth::id())->orderBy('id', 'desc')->get();
        return view('seller.dispute.index', ['disputes' => $disputes]);
    }

    public function create($orderId, $prodcutId) {
        $disputes = Dispute::where('seller_id', Auth::id())
                ->orderBy('id', 'desc')
                ->get();

        $order = Order::where('order_id', $orderId)->where('product_id', $prodcutId)->first();
        return view('seller.dispute.create', ['order' => $order, 'order_id' => $orderId, 'product_id' => $prodcutId, 'disputes' => $disputes]);
    }

    public function replyToDispute(Request $request) {

        $request->validate([
            'content' => 'required',
            'dispute_id' => 'required',
        ]);

        $addDisputeMsg = new DisputeMessage();
        $addDisputeMsg->user_id = \Auth::id();
        $addDisputeMsg->dispute_id = $request->dispute_id;
        $addDisputeMsg->message = $request->content;
        $addDisputeMsg->save();
        $dispute = Dispute::where('id', $request->dispute_id)->first();
        $dispute->buyer->notify(new OrderDisputeNotification($dispute));

        return redirect()->route('seller.dispute.messages', ['dispute' => $request->dispute_id]);
    }

    public function disputeMessage(Dispute $dispute) {
        $disputes = Dispute::where('seller_id', \Auth::id())
                ->orderBy('created_at', 'asc')
                ->get();
        return view('seller.dispute.show', ['disputes' => $disputes, 'singledispute' => $dispute]);
    }

}
