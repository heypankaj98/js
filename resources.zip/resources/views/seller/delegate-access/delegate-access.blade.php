@extends('layouts.seller.app')     
@section('content')

<h2 class="custom-title my-4">Staff Member	Roles</h2>

<div class="">
    <div class="">
        <div class="br1 br-4">
        <div class="staff_member_part_inner">
            @if (session('success'))
            <div id="alert_message" class="alert alert-success alert-block">
                <strong>{{ session('success') }}</strong>
            </div>
            @endif

            @if ($errors->any())
            <div id="alert_message" class="alert alert-danger alert-block">
                <strong>{{ trans('global.validation_error') }} </strong>
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
        </div>

     
            
    <div class="row">
    <div class="col-md-6">
            <form  class="bg-card-2 h-100 br1" method="POST" action="{{ route('seller.delegate-access.post') }}">
            @csrf

            <div class="form-group">
                <label for="username"> {{ trans('global.username') }}</label>
                <input type="text" name="username" id="username" class="form-control mt-2" required>
            </div>

            <div class="form-group mt-3">
                <label for="role">Role:</label>
                <select name="roles" id="role" class="form-control mt-2 py-0" required>
                    <option value="">Select a role</option>
                    @foreach ($roles as $role)
                    <option value="{{ $role->id }}">{{ $role->title }}</option>
                    @endforeach
                </select>
            </div>
            <button type="submit" class="btn btn-main mt-4">{{ trans('global.invite') }}</button>
        </form>
           </div>
           <div class="col-md-6">
            <div class="bg-card-2 br1">
            <table class="table-prd w-100">
            <thead>
                <tr>
                    <th> {{ trans('global.role') }} </th>
                    <th>{{ trans('global.permissions') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($roles as $role)
                <tr>
                    <td>{{ $role->title }}</td>
                    <td>
                        <ul>
                            @foreach ($role->permissions as $permission)
                            <li>{{ $permission->title }}</li>
                            @endforeach
                        </ul>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
            </div>
        
</div>
    </div>
          
       
    </div>
</div>
    
  
</div>


@endsection
