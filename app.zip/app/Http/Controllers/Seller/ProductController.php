<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\{
    MassDestroyProductRequest
};
use App\Http\Requests\Seller\UpdateProductRequest;
use App\Http\Requests\Seller\StoreProductRequest;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{
    Product,
    ProductCategory,
    ProductTag,
    Auction,
    ProductQA
};
use Gate,
    Auth;
use Illuminate\Http\Request;
use App\Models\ShippingMethod;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers;

class ProductController extends Controller {

    use MediaUploadingTrait;

    public function index() {
        abort_if(Gate::denies('seller_manage_products'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();
        $products = Product::where('seller_id', $sellerId)->paginate(config('setting.pagination'));
        return view('seller.products.index', compact('products'));
    }

    public function create(Request $request) {
        abort_if(Gate::denies('seller_manage_products'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = ProductCategory::whereNull('parent_id')->get();
        $page = $request->page;
        $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();

        $shippingMethods = ShippingMethod::where('seller_id', $sellerId)->get();

        if ($page === 'physical') {
            if ($shippingMethods->isEmpty()) {
                return redirect()->route('seller.shipping-methods.index');
            }

            return view('seller.products.create', compact('categories', 'page', 'shippingMethods'));
        } else {
            return view('seller.products.create', compact('categories', 'page'));
        }
    }

    public function store(StoreProductRequest $request) {
        $request->request->add(['isfeature' => $request->input('isfeature') === 'on' ? 1 : 0]);

        if ($request->type == 'physical') {
            $wholesale = serialize(array_filter((array_combine($request->wquantity, $request->wdiscount))));
            $request->request->add(['wdiscount' => $wholesale]);
            if (isset($request->custom_product_measure)) {
                $request->request->add(['product_measure' => $request->custom_product_measure]);
            }
            $request->request->add(['shipping_method' => serialize($request->shipping_methods)]);
        }
        $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();

        $request->request->add(['seller_id' => $sellerId]);
        $product = Product::create($request->all());
        $input['picture'] = $this->storeMedia($request, 'picture');

        if ($input['picture']) {
            $product->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
        }

        return redirect()->route('seller.products.index');
    }

    public function edit(Product $product, Request $request) {
        abort_if(Gate::denies('seller_manage_products'), Response::HTTP_FORBIDDEN, '403 Forbidden');
                $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();

        $shippingMethods = ShippingMethod::where('seller_id',$sellerId)->get();
        $categories = ProductCategory::whereNull('parent_id')->get();
        $page = $request->page;
    
        $product->load('categories');

        return view('seller.products.edit', compact('categories', 'product', 'page','shippingMethods'));
    }

    public function update(UpdateProductRequest $request, Product $product) {
        $requestData = $request->all();
        $requestData['isfeature'] = $request->input('isfeature') === 'on' ? 1 : 0;
    
        if ($product->type == 'physical') {
            $wholesale = serialize(array_filter((array_combine($request->wquantity, $request->wdiscount))));
            $requestData['wdiscount'] = $wholesale;
            if (isset($request->custom_product_measure)) {
                $requestData['product_measure'] = $request->custom_product_measure;
            }
    
            $requestData['shipping_method'] = serialize($request->shipping_methods);
        }
        
        $product->update($requestData);
    
        if ($request->hasFile('picture')) {
            if ($product->photo) {
                $product->photo->delete();
            }
            $product->addMediaFromRequest('picture')->toMediaCollection('photo');
        }
    
        return redirect()->route('seller.products.index');
    }

    public function show(Product $product) {
        abort_if(Gate::denies('seller_manage_products'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $product->load('categories');
        return view('seller.products.show', compact('product'));
    }

    public function products(Product $product) {
        $product->load('categories');
        return view('seller.products.index', compact('product'));
    }

    public function destroy(Product $product) {
        abort_if(Gate::denies('seller_manage_products'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($product->orders()->whereNotIn('status', ['cancelled', 'completed'])->exists()) {
            return back()->with('error', 'The product cannot be deleted because it is associated with an active order.');
        }
        $product->delete();
        return back()->with('success', 'The product is deleted successfull.');
    }

    public function massDestroy(MassDestroyProductRequest $request) {
        $products = Product::find(request('ids'));
        foreach ($products as $product) {
            $product->delete();
        }
        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request) {
        abort_if(Gate::denies('seller_manage_products') && Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $model = new Product();
        $model->id = $request->input('crud_id', 0);
        $model->exists = true;
        $media = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');
        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }

    public function indexShippingMethod() {
        $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();
        $shippingMethods = ShippingMethod::where('seller_id',$sellerId)->paginate(config('setting.pagination'));
        return view('seller.shipping_methods.index', compact('shippingMethods'));
    }

    public function createShippingMethod() {
        $countries = config('countries');
        return view('seller.shipping_methods.create', compact('countries'));
    }

    public function storeShippingMethod(Request $request) {
        $request->validate([
            'name' => 'required|string|max:255',
            'is_free' => 'required|boolean',
            'price' => 'required_if:is_free,false|numeric|min:0',
            'delivery_time' => 'required|integer|min:0',
            'availability' => 'required|string|in:worldwide,except,limited',
            'countries' => 'required_if:availability,limited|array',
            'countries.*' => 'required_if:availability,limited|string|size:2',
        ]);

        $shippingMethod = new ShippingMethod();
        $shippingMethod->name = $request->name;
        $shippingMethod->is_free = $request->is_free ?? 0;
        $shippingMethod->price = $request->price ?? 0;
        $shippingMethod->delivery_time = $request->delivery_time;
        $shippingMethod->availability = $request->availability;

        if ($request->availability === 'limited' || $request->availability === 'except') {
            $shippingMethod->countries = json_encode($request->countries);
        }
        $sellerId = Session::has('accessed_seller') ? Session::get('accessed_seller')->id : Auth::id();
        $shippingMethod->seller_id = $sellerId;
        $shippingMethod->save();

        return redirect()->route('seller.shipping-methods.index')->with('success', 'Shipping method created successfully.');
    }

    public function editShippingMethod($id) {
        $shippingMethod = ShippingMethod::findOrFail($id);
        $countries = config('countries');
        return view('seller.shipping_methods.edit', compact('shippingMethod', 'countries'));
    }

    public function destroyShippingMethod($id) {
        $shippingMethod = ShippingMethod::findOrFail($id);
        $shippingMethod->delete();
        return back();
    }

    public function updateShippingMethod(Request $request, $id) {
        $request->validate([
            'name' => 'required|string|max:255',
            'is_free' => 'required|boolean',
            'price' => 'required_if:is_free,false|numeric|min:0',
            'delivery_time' => 'required|integer|min:0',
            'availability' => 'required|string|in:worldwide,except,limited',
            'countries' => 'required_if:availability,limited|array',
            'countries.*' => 'required_if:availability,limited|string|size:2',
        ]);

        $shippingMethod = ShippingMethod::findOrFail($id);

        $shippingMethod->name = $request->name;
        $shippingMethod->is_free = $request->is_free ?? 0;
        $shippingMethod->price = $request->price ?? 0;
        $shippingMethod->delivery_time = $request->delivery_time;
        $shippingMethod->availability = $request->availability;

        if ($request->availability === 'limited' || $request->availability === 'except') {
            $shippingMethod->countries = $request->countries;
        }
        $shippingMethod->save();

        return redirect()->route('seller.shipping-methods.index')->with('success', 'Shipping method updated successfully.');
    }

    public function questions($productId) {
        $product = Product::findOrFail($productId);
        return view('seller.products.product_questions', compact('product'));
    }

    public function answerQuestion(Request $request, $questionId) {
        $request->validate([
            'answer' => 'required',
        ]);
        $question = ProductQA::findOrFail($questionId);
        $question->answer = $request->input('answer');
        $question->save();
        return redirect()->back()->with('success', 'Answer submitted successfully.');
    }

    public function deleteQuestion($questionId) {
        $question = ProductQA::findOrFail($questionId);
        $question->delete();
        return redirect()->back()->with('success', 'Question deleted successfully.');
    }
     public function cloneProduct($id)
{
    // Find the original product by ID
    $originalProduct = Product::findOrFail($id);

    // Clone the original product by creating a new instance
    $clonedProduct = $originalProduct->replicate();

    // Ensure the new product has a unique name
    $clonedProduct->name = $clonedProduct->name . ' (Copy)';

    // Set the status of the cloned product to 'inactive'
    $clonedProduct->status = 'inactive';  // Assuming 'status' is the column name
   $clonedProduct->view = 0; //clone product view 0,
    // Save the cloned product
    $clonedProduct->save();

    return redirect()->route('seller.products.index')->with('success', 'Product cloned successfully.');
}
}