<?php

namespace App\Models;

use Illuminate\Support\Facades\Config;
use Illuminate\Database\Eloquent\Model;

class Language extends Model {

    public static function all($columns = ['*']) {
        return Config::get('languages');
    }

    public static function getFlagPath($code) {
        $language = Config::get("languages.$code");
        if ($language) {
            return asset('flags/' . $language['flag']);
        }
        return null;
    }

}
