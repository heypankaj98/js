@extends('layouts.admin.master')    @section('content')
<div class="mt-4">
@can('admin_role_create')
    <div class="row">
        <div class="col-lg-12">
            <a class="btn btn-main w-max-c" href="{{ route('admin.roles.create') }}">
                {{ trans('global.add') }} {{ trans('cruds.role.title_singular') }}
            </a>
        </div>
    </div>
@endcan
    
<div class="card-header-2 w-100 my-4">
        User {{ trans('cruds.role.title_singular') }} {{ trans('global.list') }}
    </div>
<div class="bg-card-2 br1">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Role">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Permissions</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($roles as $key => $role)
                        <tr data-entry-id="{{ $role->id }}">
                            <td style="vertical-align: sub;">{{ $role->id ?? '' }}</td>
                            <td style="vertical-align: sub;">{{ $role->title ?? '' }}</td>
                            <td >
                                <div class="d-flex flex-wrap gap-2">
                                @foreach($role->permissions as $key => $item)
                                    <span class="btn btn-success br-4 ">{{ $item->title }}</span>
                                @endforeach
                                </div>
                            </td>
                            <td class="text-center" style="vertical-align: sub;">
                                <div class="d-flex flex-wrap gap-2">
                                @can('admin_role_show')
                                    <a class="btn  btn-primary btn-sm br-4" href="{{ route('admin.roles.show', $role->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('admin_role_edit')
                                    <a class="btn  btn-info btn-sm br-4" href="{{ route('admin.roles.edit', $role->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('admin_role_delete')
                                    <form action="{{ route('admin.roles.destroy', $role->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn  btn-danger btn-sm br-4" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan
                                </div>
                                
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

@endsection