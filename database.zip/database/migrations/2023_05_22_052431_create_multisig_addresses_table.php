<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('multisig_addresses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('multisig_id');
            $table->string('address_1')->nullable(); // seller Key
            $table->string('address_2'); // Website address
            $table->string('address_3')->nullable(); // buyer Key
            $table->timestamps();

            $table->foreign('multisig_id')->references('id')->on('multisig_transactions')->onDelete('cascade');
     
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('multisig_addresses');
    }
};
