<?php
namespace Modules\PaymentGateway\Http\Controllers\Gateway\BlockIO;

use App\Http\Controllers\Controller;

class ProcessController extends Controller {
    
    function generateAddress(array $para = []){   //   Generate new address of given label of witness_v0 type
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->get_new_address(array('labels' => $para['label'],'address_type' => $para['type']));
    }
    
    function isValidAddress(array $para = []){      //  Check that address is Valid of not
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->is_valid_address(array('address' => $para['address']));
    }

    function getBalance(){  //  Get Balance of whole wallet
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->get_balance();
    }

    function getWalletBalance($para) {     //  GET BALANCE OF ANY LABEL
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->get_address_balance(array('labels' => $para['label'] ));
    }
    
    function getAddressByLabel($para) {     //   GET ADDRESS OF ANY LABEL
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->get_address_by_label(array('label' => $para['label']));
    }
    
    function getEstimate($para){    //   GET ESTIMATE FEE
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->get_network_fee_estimate(array('to_address' => $para['to'], 'amount' => $para['amount']));
    }
    
    function sendToLabel($para){    //   SEND AMOUNT TO ANY LABEL
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        $prepare_transaction = $data->prepare_transaction(array('amounts' => $para['amount'] , 'priority' => 'custom' , 'custom_network_fee' => $para['fee'] , 'from_labels' => $para['from'] , 'to_labels' => $para['to']));
        $summarize_prepared_transaction = $data->summarize_prepared_transaction($prepare_transaction);
        $create_and_sign_transaction = $data->create_and_sign_transaction($prepare_transaction);
        return $data->submit_transaction(array('transaction_data' => $create_and_sign_transaction));
    }
    
    function archieveAddress($para) {     //   ARCHIEVE ANY LABEL
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        return $data->archive_addresses(array('labels' => $para['label']));
    }
    
    function sendToAddress($para) {      // SEND AMOUNT TO ANY ADDRESS
        $data = new \BlockIo\Client(config('coins.IObtc.API_KEY') , config('coins.IObtc.PIN'), config('coins.IObtc.V'));
        $prepare_transaction = $data->prepare_transaction(array('amounts' => $para['amount'] , 'priority' => 'custom' , 'custom_network_fee' => $para['fee'] , 'from_labels' => $para['from'] , 'to_labels' => $para['toAddress']));
        $summarize_prepared_transaction = $data->summarize_prepared_transaction($prepare_transaction);
        $create_and_sign_transaction = $data->create_and_sign_transaction($prepare_transaction);
        return $data->submit_transaction(array('transaction_data' => $create_and_sign_transaction));
    }
}