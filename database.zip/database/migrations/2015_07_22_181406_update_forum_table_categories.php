<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateForumTableCategories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('forum_categories', function (Blueprint $table) {
            // Check if columns exist before modifying them
            if (!Schema::hasColumn('forum_categories', 'category_id')) {
                $table->integer('category_id')->default(0);
            } else {
                $table->integer('category_id')->default(0)->change();
            }

            if (!Schema::hasColumn('forum_categories', 'description')) {
                $table->string('description')->nullable();
            } else {
                $table->string('description')->nullable()->change();
            }

            if (!Schema::hasColumn('forum_categories', 'weight')) {
                $table->integer('weight')->default(0);
            } else {
                $table->integer('weight')->default(0)->change();
            }

            // Add new columns
            $table->boolean('enable_threads')->default(0);
            $table->boolean('private')->default(0);
            
            // Add timestamps if they don't exist
            if (!Schema::hasColumn('forum_categories', 'created_at')) {
                $table->timestamps();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('forum_categories', function (Blueprint $table) {
            // Drop newly added columns
            $table->dropColumn(['enable_threads', 'private']);

            // Drop timestamps if needed
            if (Schema::hasColumn('forum_categories', 'created_at')) {
                $table->dropTimestamps();
            }
        });
    }
}
