@extends('layouts.homeapp')
@section('content')
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Darknet & Clearnet</title>
    <style>
        .section {
            margin-bottom: 20px;
            padding: 16px;
            border-radius: 4px;

            background: #000;
            border: 1px solid #ff202c;
        }

        .section a {
            color: #ff9900;
            text-decoration: none;
        }

        p {
            line-height: 1.5;
        }

        .section a:hover {
            text-decoration: underline;
        }

        .section ul {
            list-style: none;
            padding: 0;
        }

        .section li {
            margin: 5px 0;
        }

        .highlight {
            color: #ff0;
        }
    </style>
</head>

<body>
    <div class="">
    <h1 class="custom-title my-4">Darknet & Clearnet</h1>
        <div >
            <p class="card-header-2 w-100 mb-4">We have registered on the following websites.<br>
                Any other websites where you can get information about us are not verified by us and maybe a scam, don't
                trust.</p>

            <a class="bg-card-1 d-flex gap-2 align-items-center p-2 mt-4" download
                style="background-color: #000 !important;" href="/file_pgp/Kerberos-Mirrors_PGP-SIGNED-MESSAGE.txt"
                target="_blank">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="feather feather-download">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                <span>Kerberos-Find-Us-Here_PGP-SIGNED-MESSAGE.txt</span>
            </a>

            <div class="section">
                <h2>Darktrain Express</h2>
                <ul>
                    <li><a href="http://darktrainwkr2inbw2uvfavdkgcjruenkjsqcs4pqfwkjvgomcshad.onion"
                            target="_blank">Tor: darktrainwkr2inbw2uvfavdkgcjruenkjsqcs4pqfwkjvgomcshad.onion</a></li>
                    <li><a href="http://darktrain.express" target="_blank">Secured Clearnet: darktrain.express</a></li>
                    <li><a href="i2p://dwxopkvlwg5fnpir2drbpkrizjywapao2o6vrze3qkkqr7pcilta.b32.i2p"
                            target="_blank">I2P: dwxopkvlwg5fnpir2drbpkrizjywapao2o6vrze3qkkqr7pcilta.b32.i2p</a></li>
                </ul>
            </div>

            <div class="section">
                <h2>Dark Eye</h2>
                <ul>
                    <li><a href="http://darkeypewv7cuzu2cppnjgqav64jzqy143clnd4yfj7lly5xcxid.onion" target="_blank">Dark
                            Eye: darkeypewv7cuzu2cppnjgqav64jzqy143clnd4yfj7lly5xcxid.onion</a></li>
                    <li><a href="http://darkeypewv7cuzu2cppnjgqav64jzqy143clnd4yfj7lly5xcxid.onion/hs/kerberos-market.html"
                            target="_blank">Kerberos Market:
                            darkeypewv7cuzu2cppnjgqav64jzqy143clnd4yfj7lly5xcxid.onion/hs/kerberos-market.html</a></li>
                </ul>
            </div>

            <div class="section">
                <h2>DarkNet Trust</h2>
                <ul>
                    <li><a href="http://dntrustmuq5ccf3lygnhrsprdlilakq7t2jspsczmdssj5fw4taeid.onion"
                            target="_blank">DarkNet Trust:
                            dntrustmuq5ccf3lygnhrsprdlilakq7t2jspsczmdssj5fw4taeid.onion</a></li>
                </ul>
            </div>

            <div class="section">
                <h2>DarkDotNet</h2>
                <ul>
                    <li><a href="http://darkdotnet.com" target="_blank">DarkDotNet: darkdotnet.com</a></li>
                    <li><a href="http://darkdotnet.com/kerberos-market" target="_blank">Kerberos Market:
                            darkdotnet.com/kerberos-market</a></li>
                    <li><a href="http://darkdotnet.com/category/darknet-markets" target="_blank">Darknet Markets:
                            darkdotnet.com/category/darknet-markets</a></li>
                </ul>
            </div>

            <div class="section">
                <h2>Tor.Fish</h2>
                <ul>
                    <li><a href="http://torfish7hbkl4vgostgkzddddj4npq4xcxsi2opfdzyfzrlzs3x3fj7byd.onion"
                            target="_blank">Tor.Fish:
                            torfish7hbkl4vgostgkzddddj4npq4xcxsi2opfdzyfzrlzs3x3fj7byd.onion</a></li>
                    <li><a href="http://tor.fish" target="_blank">Tor.Fish (clearnet): tor.fish</a></li>
                </ul>
            </div>
        </div>
    </div>

</body>

</html>
@endsection