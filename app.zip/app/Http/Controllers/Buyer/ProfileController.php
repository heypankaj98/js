<?php
namespace app\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateProfileRequest;
use App\Http\Requests\User\Settings\ChangePasswordRequest;
use App\Models\{
    ProductCategory,
    Order,
    UserMeta,
    User
};
use Gate,Hash,Session,Auth;
use Symfony\Component\HttpFoundation\Response;
use App\Traits\OrderTrait;
use Illuminate\Http\Request;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class ProfileController extends Controller {
    use OrderTrait;

    public function index() {
        $orders = Order::where('buyer_id', Auth::id())->get()->groupBy('order_id');
        $total = Order::where('buyer_id', Auth::id())->sum('total');
        return view('buyer.dashbaord', compact('orders', 'total'));
    }

    public function update(UpdateProfileRequest $request) {
        $user = auth()->user();
        $user->update($request->validated());
        return redirect()->route('frontend.profile.index')->with('message', __('global.update_profile_success'));
    }
    
    public function password(ChangePasswordRequest $request) {
        $user = auth()->user();

        if (!Hash::check($request->current_password, $user->password)) {
            return redirect()->route('user.profile.security')->with('error', trans('validation.password_invalid'));
        }

        $user->password = Hash::make($request->password);
        $user->save();

        return redirect()->route('user.profile.security')->with('success', trans('validation.password_changed'));
    }

    public function profileSetting() {
        return view('buyer.settings');
    }

    public function profileSettingWithdrawal(Request $request) {
        $request->validate([
            'payment_method' => 'required',
            'address' => 'required',
        ]);
        $payment = [];
        $user = Auth::user();

        $user_meta = $user->getMeta('withdrawal');
        if ($user_meta) {
            foreach ($user_meta as $payment_key => $single) {
                if ($payment_key == $request->payment_method) {
                    return redirect()->back()->with('error', 'You can not add more then one address for single coin');
                }
            }
        }
        $payment[$request->payment_method] = $request->address;
        $user->setMeta('withdrawal', $payment);
        return redirect()->route('user.profile.settings');
    }

    public function profileSecurity() {
        $categories = ProductCategory::with(['media'])->get();
        return view('buyer.security', compact('categories'));
    }
public function profileSecurityzero() {
    // Assuming you have access to the authenticated user
    $user = auth()->user();

    // Check if the user has any orders (this will block the seller registration)
    $hasOrders = Order::where('buyer_id', $user->id)->exists();

    if ($hasOrders) {
        // If the user has an order, prevent them from becoming a seller and redirect with error message
        return redirect()->route('user.profile.securityz0')->with('error', 'You have an order and need to register as a different user to become a seller.');
    }

    // If no orders, proceed to show the security0 view for registration
    return view('buyer.security0');
}


       public function profileSecurityone() {
        return view('buyer.security1');
    }
     public function profileSecuritytwo() {
         
        return view('buyer.security2');
    }
      public function profileSecuritythree() {
        return view('buyer.security3');
    }
        public function verifypgp() {
            
        return view('buyer.verifybuyer');
    }

  public function profileEdit() {
        $categories = ProductCategory::with(['media'])->get();
        return view('buyer.profile', compact('categories'));
    }


    public function updateMultisigKeyPub(Request $request) {
        $request->validate([
            'multisig_key_pub' => 'required',
        ]);

        $seller = auth()->user();
        UserMeta::updateOrCreate([
            'user_id' => $seller->id,
            'key' => 'multisig_key_pub'
                ], [
            'value' => $request->input('multisig_key_pub')
        ]);
        return redirect()->back()->with('success', 'Multisig key pub updated successfully.');
    }

    public function generateaddresspubkey(Request $request) {
        $request->validate([
            'btc_address' => 'required',
        ]);
        $payment_method = "BitcoinMultiSign";
        $address_info = PayWay::getaddressinfo($payment_method, array('address' => $request->btc_address));
        return redirect()->back()->with('success', 'here is information:' . json_encode($address_info));
    }

    public function destroyAccount(Request $request,$id) {
        $user = User::findOrFail($id);
        $request->validate([
            'password' => 'required|string',
        ]);
        
        if (Hash::check($request->input('password'), $user->password)) {
            $user->delete();
            return redirect()->route('login');
        } else {
            return redirect()->back()->with('error',trans('validation.password_invalid'));
        }
    }

    public function sellerAccess() {
        $tempUser = User::dedicatedAccessUsers()->first();
        if (!$tempUser){
            return redirect()->back()->with('error',trans('validation.no_seller_access'));
        }
        return view('buyer.seller_access', compact('tempUser'));
    }

    public function sellerAccessLogin(Request $request) {
        $tempUser = User::dedicatedAccessUsers()->first();

        $validatedData = $request->validate([
            'seller_id' => 'required|integer'
        ]);

        if ($validatedData['seller_id'] == $tempUser->id) {
            Session::put('accessed_seller', $tempUser);
            return redirect()->back()->with('success', 'You are logged in as seller staff');
        } else {
            return redirect()->back()->with('error', 'Invalid seller ID');
        }
    }

    public function sellerAccessLogout() {
        Session::forget('accessed_seller');
        return redirect()->back()->with('success', 'You are logged out as seller staff');
    }
    
    public function profileUpdate(Request $request){
        $user = auth()->user();
        $validatedData = $request->validate([
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
 
        $avatarPath = $validatedData['avatar']->store('avatars', 'public');
        $user->avatar = $avatarPath;
        $user->save();
    
         return redirect()->back()->with('success', 'You have updated profile picture');
    }
}