<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin;

use Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin\Src\Client as LitecoinClient;
use Modules\PaymentGateway\Http\Controllers\Gateway\Utility\BitcoinConverter;
use App\Models\ExceptionModel;
use Illuminate\Support\Facades\Cache;

class LitecoinPayment {

    protected $litecoind;

    public function __construct() {

        $this->litecoind = new LitecoinClient([
            'scheme' => 'http', // optional, default http
            'host' => config('coins.litecoin.host'), // optional, default localhost
            'port' => config('coins.litecoin.port'), // optional, default 9332
            'user' => config('coins.litecoin.username'), // required
            'pass' => config('coins.litecoin.password'), // required
//            'ca' => '/etc/ssl/ca-cert.pem'  // optional, for use with https scheme
        ]);
    }

    /**
     * Generate new address with optional LTC user parameter
     *
     * @param array $params
     * @return string
     * @throws \Exception
     */
    function generateAddress(array $params = []) {

        try {
            if (array_key_exists('user', $params)) {
                $responce = $this->litecoind->getnewaddress($params['user']);
            } else {
//                dd($this->litecoind->listSinceBlock());
                $responce = $this->litecoind->getnewaddress();
            }
            if ($responce->hasResult()) {
                $address = $responce->result();
            }
            return $address;
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999); // Generate a random error code
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .'; // Set the error message
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
    }

    function getBalance(array $params = []) {
        try {
            if (array_key_exists('address', $params)) {
                $responce = $this->litecoind->getreceivedbyaddress($params['address'], 1);
                if ($responce->hasResult()) {
                    $accountBalance = $responce->result();
                }
                return (float) $accountBalance;
            }
        } catch (\Exception $exception) {
            $errorCode = 'btc-' . mt_rand(1000, 9999);
            $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE .';
            $exceptionLog = new ExceptionModel();
            $exceptionLog->error_code = $errorCode;
            $exceptionLog->error_message = $exception->getMessage();
            $exceptionLog->save();
            return ['error_code' => $errorCode, 'error_message' => $errorMessage];
        }
        return;
    }

}
