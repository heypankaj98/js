@extends('layouts.admin.master')

@section('content')
<div class="mt-4">
<div class="card-header-2 w-100 mb-4">
        {{ trans('global.edit') }} {{ trans('cruds.ads.edit') }}
    </div>
<div class="bg-card-2 br1">
    <div class="card-body">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route("admin.ads.update", $ad->id) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT') {{-- Use the PUT method to update the existing ad --}}
            
            <div class="form-group">
                <label class="required" for="name">{{ trans('cruds.user.fields.name') }}</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $ad->name) }}" required>
                @if($errors->has('name'))
                    <div class="invalid-feedback">
                        {{ $errors->first('name') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
            </div>

            <div class="form-group">
                <label class="required" for="redirect_url">{{ trans('cruds.url') }}</label>
                <input class="form-control {{ $errors->has('redirect_url') ? 'is-invalid' : '' }}" type="text" name="redirect_url" id="redirect_url" value="{{ old('redirect_url', $ad->redirect_url) }}" required>
                @if($errors->has('redirect_url'))
                    <div class="invalid-feedback">
                        {{ $errors->first('redirect_url') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Select Size</label>
                <select class="form-control py-0" name="adsize" id="exampleFormControlSelect1">
                    <option value="540x984" {{ $ad->adsize === '540x984' ? 'selected' : '' }}>540x984</option>
                    <option value="779x80" {{ $ad->adsize === '779x80' ? 'selected' : '' }}>779x80</option>
                    <option value="300x250" {{ $ad->adsize === '300x250' ? 'selected' : '' }}>300x250</option>
                </select>
                <span class="help-block">{{ trans('cruds.user.fields.roles_helper') }}</span>
            </div>
            
         
            <a href="{{ $ad->getMedia('photo')->first()->getUrl($ad->size) }}" target="_blank" class="d-inline-block" >
        <img src="{{ $ad->getMedia('photo')->first()->getUrl('thumb') }}">
    </a>


            <div class="form-group">
                <label class="form-label">{{ trans('Upload Picture') }}</label><br>
                <input type="file" class="form-control" id="inputGroupFile02" name="picture">
                @error('picture')
                    <div class="alert alert-danger" role="alert">
                        {{ $message }}
                    </div> 
                @enderror
            </div>

            <div class="form-group">
                <button class="btn btn-main w-max-c" type="submit">
                    {{ trans('global.update') }}
                </button>
            </div>
        </form>
    </div>
</div>
</div>


@endsection
