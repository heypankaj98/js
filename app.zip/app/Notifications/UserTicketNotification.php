<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;

class UserTicketNotification extends Notification {

    use Queueable;

    public $ticket;

    /**
     * Create a new notification instance.
     */
    public function __construct($ticket) {
        $this->ticket = $ticket;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array {
        return ['database'];
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array {
        session(['notification_sound_played' => false]);
        return [
            'message' => 'You have a new Ticket!',
            'title' => 'new ticket' . auth()->user()->username . $this->ticket->title,
            'link' => route('user.tickets.show', $this->ticket->id),
            'sound' => asset('assets/sound/notification.mp3'),
        ];
    }

}
