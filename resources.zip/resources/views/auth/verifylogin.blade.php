@extends('layouts.auth')
@section('content')

<div class="container verification_container ">
    <div class="verification_section verification_section_clone my-5 my-3 p-4 p-lg-4 radius-5">
        <div class="row">
            <div class="col">
                <h5 class="card-title fw-bold  pb-3 mb-4">
                    {{ trans('auth.verify_2fa') }}
                </h5>
            </div>
        </div>
        <div class="row">
            <div class="verification-market-right col-md-7 pe-3 pe-md-5">
                <div class=" margin_auto border_none">
                    <div class=" p-0">
                        @if(Session::has('error'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        @endif
                        <form method="POST" action="{{ route('post.verifylogin') }}">
                            @csrf
                            <div class="form-group mb-2 mt-4">
  <pre class="p-2 p-lg-3 w-100 user-select-all" style="white-space: pre-wrap; overflow-y: auto; max-height: 300px; margin: 0; padding: 0; line-height: 1.2;">
    {{ session()->get('encrypted_message') }}
</pre>

                            </div>
                            <a href="{{route('verifylogin.view')}}" target=”_blank” class=" fw-bold text-decoration-none" >{{ trans('auth.full_screen') }}</a>
                        </form>
                    </div>
                </div>
            </div>
             <div class="verification col-md-5">
                <div class="border_none ps-3 ps-md-3">
                    <div class="p-0">
                        <h6 class="card-subtitle mb-2  pb-2 pb-lg-2 fw-bold text-18">Please Decrypt Message</h6>
                        @if(Session::has('error'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        @endif
                        <form method="POST" action="{{ route('post.verifylogin') }}">
                            @csrf
                            <div class="form-group mb-2">
                                <label for="verification_code" class="pb-2 fw-bold">Enter Verification Code</label>
                                <input id="verification_code" type="text" class="form-control border_radiusnone @error('verification_code') is-invalid @enderror" name="verification_code" value="{{ old('verification_code') }}" required autocomplete="verification_code">
                            </div>
                            <div class="form-group mb-2">
                                <button type="submit" class="btn btn-main w-100">    {{ trans('global.submit') }}</button>
                            </div>

                        </form>





                        <div class="form-group text-center">
                            <ul class="need_help need_help_two text-start mt-2" style="list-style: none;">

                                <li class="nav-item dropdown text-start">
                                    <input type="checkbox" id="chck1">

                                        <label class="tab-label fw-bold" for="chck1"
                                               <a class="nav-link dropdown-toggle dropdown fw-bold me-3" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                            {{ trans('auth.Lost-your-PG')}}?  <span class="sign_link">Reset Password</span>
                                        </label>

                                        </a>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="6" class="me-2 help_arrow " height="10" viewBox="0 0 6 10" fill="none">
                                            <path d="M0.5 10L5.5 5L0.5 0L0.5 10Z" fill=""/>
                                        </svg>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <li> <a class="dropdown-item" href="{{route('forgot.pgp.mnemonic')}}">Reset PGP</a></li>
                                        </ul>
                                </li>
                            </ul>
                        </div>

                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <div class=" text-start mt-3 mt-lg-3">
                                <button class=" btn btn-main text-uppercase "  type="submit">{{ trans('auth.Logout') }}</button>
                            </div>
                        </form>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
<style>
    .footer_market {
    display: none;
}
    
</style>
@endsection

