@extends('buyer.dispute.template') @section('messenger-content')

<div class="">
    <div class="row">

        <div class="col-md-3">
            <div class="bg-card-2 mt-auto chat-sidebar  chat-sidebar_two h-100 p-16 br1">
                <h5 class="card-header-2 w-100 mb-4">{{ trans('global.disputes_users') }}</h5>
                <ul class="list-unstyled">
                    @forelse($disputes as $dispute)
                    <li>
                        <a class="dispute-link" href="{{ route('dispute.messages', [$dispute->id]) }}">
                            <div class="user_info">
                                <img src="{{ $dispute->seller->avatar }}" class="rounded-circle">
                                <div class="d-flex flex-column gap-1">
                                    <span>{{ $dispute->seller->username }}</span>
                                    <p class="small mb-0">{{ trans('common.status') }} {{ $dispute->status }}</p>
                                </div>
                            </div>
                            <p class="small ab-p">{{ trans('common.order') }} {{ $dispute->order_id }}</p>
                        </a>
                    </li>
                    @empty
                    {{ trans('common.no') }} {{ trans('common.disputes') }}
                    @endforelse
                </ul>
            </div>
        </div>
        <div class="col-md-9">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    <h5>{{ trans('global.chat_with') }} {{$singledispute->seller->username}} for order
                        {{$singledispute->order_id }} status:{{$singledispute->status }}</h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">
                        @foreach($singledispute->messages() as $message)
                        @if($message->user_id == Auth::user()->id)
                        <div class="message sent">
                            <div class="message-content mw-100  ">
                                <div class="message-header small">
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @else
                        <div class="message received">
                            <div class="message-content mw-100 ">
                                <div class="message-header small">
                                    <img src="{{$message->sender->avatar}}" class="rounded-circle">
                                    <span class="username">{{$message->sender->username}}</span>
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text mw-100">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @endif
                        @endforeach
                    </div>
                </div>
                <div class="card-footer">
                    <form action="{{ route("dispute.reply", [$singledispute->id]) }}" method="POST">
                        @csrf
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="hidden" name="dispute_id" value="{{$singledispute->id}}" />
                                <input type="text" class="form-control" name="content"
                                    placeholder="Type your message...">
                                <button type="submit" class="btn btn-main">{{ trans('global.send') }} </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12 mt-4">
            <div class="bg-card-2 br1">
                <div class="">
                    <div class="">
                        <p class="card-header-2 w-100 mb-4">{{ trans('global.send') }} {{ trans('global.product_details') }} </p>
                        @if ($singledispute->product->photo)
                        <img src="{{ $singledispute->product->photo->getUrl() }}" class="card-img-top"
                            style="max-width:100px" alt="User Avatar">
                        @endif
                        <div class="card-body mt-2">
                            <h5 class="card-title fs-4">{{$singledispute->product->name}}</h5>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"> {{ trans('global.Price:') }} {{$singledispute->product->price}}
                            </li>
                            <li class="list-group-item">{{ trans('global.type') }} {{$singledispute->product->type}}
                            </li>
                            <li class="list-group-item">{{ trans('global.Seller:') }} Seller:
                                {{$singledispute->product->seller->username}}</li>
                            <a href="{{route('messenger.newMessages',$singledispute->seller->id)}}"
                                class="btn mt-2 btn-main d-flex-center">
                                <i class="bi bi-chat-dots"></i> Message
                            </a>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
@stop