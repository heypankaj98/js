<?php

namespace Modules\Jabber\Http\Controllers\Lib\AuthTypes;

use 
Modules\Jabber\Http\Controllers\Lib\Options;
use 
Modules\Jabber\Http\Controllers\Lib\Xml\Xml;

abstract class Authentication implements Authenticable
{
    use Xml;

    protected $name;
    protected $options;

    public function __construct(Options $options)
    {
        $this->options = $options;
    }

    public function getName(): string
    {
        return $this->name;
    }
}
