<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title')</title>

    <style>
        body {
            font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: #f7fafc;
        }

        .code {
            font-size: 4rem;
            font-weight: 600;
            color: #4a5568;
            margin-right: 1rem;
            border-right: 1px solid #cbd5e0;
            padding-right: 1rem;
        }

        .message {
            font-size: 2rem;
            font-weight: 600;
            color: #4a5568;
            text-transform: uppercase;
            margin-left: 1rem;
        }

        .back-link {
            margin-top: 2rem;
            text-decoration: underline;
            color: #718096;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <div class="flex items-center">
            <div class="code">@yield('code')</div>
            <div class="message">@yield('message')</div>
        </div>
        <a href="/" class="back-link">Back to Home</a>
    </div>
</body>
</html>


