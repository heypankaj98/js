<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RolesTableSeeder extends Seeder
{
    public function run()
    {
        $roles = [
            [
                'id' => 1,
                'title' => 'Admin',
            ],
            [
                'id' => 2,
                'title' => 'Buyer',
            ],
            [
                'id' => 3,
                'title' => 'Seller',
            ],
            [
                'id' => 4,
                'title' => 'Admin - Moderator',
            ],
            [
                'id' => 5,
                'title' => 'Admin - Administrator',
            ],
            [
                'id' => 6,
                'title' => 'Admin - Analytics Manager',
            ],
            [
                'id' => 7,
                'title' => 'Admin - Customer Support Manager',
            ],
            [
                'id' => 8,
                'title' => 'Admin - Payment Manager',
            ],
            [
                'id' => 9,
                'title' => 'Admin - Inventory Manager',
            ],
            [
                'id' => 10,
                'title' => 'Admin - Marketing Manager',
            ],
            [
                'id' => 11,
                'title' => 'Admin - Site Designer',
            ],
            [
                'id' => 12,
                'title' => 'Seller - Product Manager',
            ],
            [
                'id' => 13,
                'title' => 'Seller - Order Manager',
            ],
            [
                'id' => 14,
                'title' => 'Seller - Analytics Viewer',
            ],
            [
                'id' => 15,
                'title' => 'Seller - Customer Support Representative',
            ],
            [
                'id' => 16,
                'title' => 'Seller - Marketing Contributor',
            ],
        ];

        Role::insert($roles);
    }
}
