@extends('layouts.homeappinfo')
@section('content')
<html lang="en">
<head>
    <title>Support - E-Commerce Website</title>
<style>
   .arrow1 {
    margin-top: -2px;}
           .info-header {
            background-color: #ff7d00;
            color: white;
            padding: 10px;
            font-weight: bold;
        }
        .info-body {
            color: white;
            padding: 20px;
        }
    </style>
</style>
</head>
<body>
    <div class="bg-card-1 p-24 br1 mt-4">
        <div class="card-header-2 w-100 mb-4">
            Information Center: Welcome
        </div>
        <div class="info-body">
            <p>Welcome to the <strong>Information Center</strong>.</p>
            <p>Here you can find information about the Dark Alley Market and helpful tutorials.</p>
            <p><strong>Please select the action you want to perform, in the menu on the left side.</strong></p>
        </div>
    </div>

</body>
</html>
@endsection
