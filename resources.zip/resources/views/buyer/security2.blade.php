@extends('layouts.buyer.app')       @section('content')
    <div class="container my-5">
        <h1 class="text-center">User Control Panel: Become a Vendor</h1>

        <div class="mt-4">
            <p>We are very pleased that you want to become a vendor on Dark Allay and join our informal family.</p>
            <p>We offer vendors as well as customers a long-term and stable platform for decent business relationships...</p>
        </div>

        <div class="info-box">
            <h5 class="text-warning">Please read and understand the following information</h5>
            <p>In addition to the regular marketplace vendor URLs, a vendor also receives a special shop-specific and secret URL.</p>
            <ul>
                <li>Vendor account type Level 1 will be instantly converted to a vendor account.</li>
                <li>Vendor account type Level 2 will be manually verified and converted after verification.</li>
                <li>Vendor account type Level 3 has passed all tests and is seen as the vendor security.</li>
                <li>Your vendor account will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items, we recommend that you create a new account before becoming a vendor.</li>
            </ul>
        </div>

        <div class="warning-box">
            <p>There are rules on this marketplace to ensure that everything runs smoothly and securely.</p>
            <p><strong>Any attempt at fraud, fake feedbacks, etc. will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you...</p>
        </div>
        <div class="container my-5" style="background-color: #2b3035;">
        <div class="p-3 bg-warning text-center">
            <h4>Please read and understand the following information</h4>
        </div>

        <div class="p-4 bg-light">
            <p>In addition to the regular marketplace mirror URLs, a vendor gets access to special preferred and secured mirror URLs, protected by Onion Authentication, to ensure that vendors always have access to their shop.</p>
            <ul>
                <li>Vendor account type <strong class="text-danger">Level 1</strong> will be instantly converted to a vendor account.</li>
                <li>Vendor account type <strong  class="text-danger">Level 2 and 3</strong> will be converted to a vendor account after the verification process is completed.</li>
                <li>A vendor account can only sell, not purchase items - this serves the vendors security.</li>
                <li>Your customer wallet will be converted to a vendor wallet. This means, all ledger history (if exists) will be deleted.</li>
                <li>Your wallet starts new with your current balance less the paid vendor bond.</li>
                <li>The vendor bond will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items with this account, we recommend that you create a new account for becoming a vendor. The reason for that is, that other vendors can know an address or something else about you from a previous purchase.</li>
            </ul>
        </div>

        <div class="p-4 mt-4 bg-light border border-danger">
            <h5 class="text-center text-danger">There are rules on this marketplace to ensure that everything runs smoothly and secure.</h5>
            <p>Read the Marketplace Rules (<a href="#" class="text-warning">Marketplace Rules</a>) and the Dark Allay Guardian (<a href="#" class="text-warning">Dark Allay Guardian</a>).</p>
            <p><strong class="text-danger">Any attempt at fraud/scam against customers, vendor account or the marketplace, such as attempts to fake feedbacks etc, will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you and you have nothing to fear. But if you try to scam in any way - no consideration will be given! We treat everyone properly and fair and expect this in return.</p>
            <p><strong>Be faithful to us and we will never be unfaithful to you. Hell yes.</strong></p>
        </div>
    </div>


        <div class="mt-5">
            <h2 class="mb-4">Vendor Account Types</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-center">
                        <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 1</h3>
                            <h4>PGP Key</h4>
                          
                            @if (!auth()->user()->pgp_key)
                              <p>(Unverified)</p>
                              <a href="{{ route('user.security1') }}" class="btn btn-warning" style="background-color:#ff202c;">View Conditions</a>
                              @else
                                <p>(Verified)</p>
                            @endif
                          
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                         <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 2</h3>
                          
                            @if (!auth()->user()->twofa)
                              <p>(Unverified)</p>
                              <a href="{{ route('user.security2') }}" class="btn btn-warning" style="background-color:#ff202c;">View Conditions</a>
                              @else
                                <p>(Verified)</p>
                            @endif
                          
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                        <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 3</h3>
                            <p>(Verified, Trusted)</p>
                            <a href="{{ route('user.security3') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       <div class="container my-5">
           <h2>
               Conditions and requirements for vendor account type: Level 2
           </h2>
            <div class="p-3 bg-dark text-white">
            <p class="font-weight-bold">Attention: BEFORE you open a vendor account, please read and understand the following information:</p>
    <ol>
        <li>The necessary conditions will be checked by The Administration.</li>
        <li>Your PGP Public Key must be supplied on the Dark Allay Marketplace.</li>
        <li>You are required to have at least 50 sales from a maximum of three other marketplaces combined.</li>
        <li>You have to provide the marketplaces where you are currently active as the vendor with the profile URLs or</li>
        <li>You need a Premium Account on DarkNet Trust (DarkNet Trust ?!) with your assigned PGP Public Key and with the assigned markets to your DNT Premium Account that we can see your stats.</li>
    </ol>

    <p>Notice: If the provable data belongs to another (old) PGP Public Key as the PGP Public Key that you have supplied on Dark Allay, please also send that PGP Public Key and a Signed PGP Message (belonging to this PGP Public Key) with your request.</p>
    <p>The regular temporary vendor bond is (USD) $144.00.</p>

    <p>Temporary means, that you will get your paid vendor bond back when we see that you are a decent vendor. This is for the safety of our customers and to make it more difficult for fraudsters, at least as far as possible.</p>
    <p>For the safety of all vendors, all bonds are linked to the canary. If the canary would ever expire, all vendor bonds will be automatically refunded to their wallet.</p>

    <h3>Why is there no one-time payment for vendor registration on Dark Allay?</h3>
    <ol>
        <li>If you pay a one-time payment for vendor registration, this money is gone for good in any case but the bond will be refunded. We think that's more fair.</li>
        <li>We don't keep them for a very long time, this is only to prevent fraudsters and trolls from flooding the market which is in everyone's best interest.</li>
        <li>If you are a decent vendor and want to do business, we see this very quickly and your vendor bond will be refunded.</li>
        <li>As a rule, the vendor bond will be refunded after about 2-3 months or even faster, according to your sales.</li>
    </ul>

    <h3>Other Information:</h3>
    <ol>
        <li>The vendor marketplace commission for every sale is between 5% to 4%, depending on the classified reputation of that vendor and decreases to 2% with increasing reputation.</li>
        <li>The vendor account is not trusted, but will be faster trusted than Level 1 vendor account and gets a higher reputation after verification.</li>
        <li>After a certain amount of successful sales and positive feedback, The Administration checks intensively the feedback.</li>
        <li>If your account gets negative and fake/bot flagged feedback, you will be banned and the vendor bond will not be refunded.</li>
        <li>After a certain amount of successful sales and positive feedback, the adminstration intensively checks and finalizes the trust level.</li>
        <li>Finalize Early (FE) is not available at the beginning for this account type.</li>
        <li>A trusted account will be manually by The Administration after the account becomes trusted through positive sales and feedback.</li>
        <li>There are no listing limits.</li>
        <li>The vendor’s account PGP Public Key is integrated with DarkNet Trust.</li>
    </ol>

          
            </div>
            <h5 class="card-header-2 w-100 mb-4">PGP Supplied: 
    <i class="fas fa-circle" 
       style="color: {{ $user->pgp_key ? 'green' : 'red' }};"></i>
    {{ $user->pgp_key ? 'Verified' : 'Not Verified' }}
</h5>


            <div class="d-flex justify-content-between">
                <a href="{{ route('user.become') }}" class="btn btn-light">Pay Fees</a>
            </div>
        </div>
    </div>
    </div>
@endsection
<style>
    h2{
        background-color: #ff202c;
        text-align: center;
    }
   h1 {
    color: var(--bs-light-text-emphasis) !important;
}

</style>