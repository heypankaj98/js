@extends('layouts.buyer.app')       @section('content')
<div class="content-area seller_dashboard_main">
      <h3 class="mb-4">Wallet</h3>
  
    
    <div class="row g-2">
        <div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Total Add Amount') }} Monero</h5>
        <span class="number">{{ $receivedMonero ?? 0 }}</span>
    </div>
</div>
<div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Total Add Amount') }} Bitcoin</h5>
        <span class="number">{{ $receivedBitcoin ?? 0 }}</span>
    </div>
</div>
<div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Pending Amount') }} Bitcoin</h5>
        <span class="number">{{ $pendingBitcoin ?? 0 }}</span>
    </div>
</div>
<div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Pending Amount') }} Monero</h5>
        <span class="number">{{ $pendingMonero ?? 0 }}</span>
    </div>
</div>
<div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Total Balance') }} USD (Monero)</h5>
        <span class="number">{{ $receivedBitcoin ?? 0 }}</span>
    </div>
</div>
<div class="col-md-12 col-lg-4 col-xl-4">
    <div class="bg-ter-2 h-custom-seller">
        <h5 class="title">{{ __('common.Total Balance') }} USD(BTC) </h5>
        <span class="number">{{ $user->btc_balance ?? 0 }}</span>
    </div>
</div>
    </div>

  <div class="row mt-4">
    <div class="col-12">
        <div class="bg-card-2 h-100 br1 w-100">
            <div class="card-header-2 w-100 mb-4"><h4>{{ __('common.Add Wallet Balance') }}</h4></div>

            <div class="card-body">
                @if(session('notify'))
                    <div class="alert alert-{{ session('notify')[0] }}">
                        {{ session('notify')[1] }}
                    </div>
                @endif

                <form method="POST" action="{{ route('addbalance') }}">
                    @csrf
                    <h4 class="my-3">{{ __('common.Payment Method') }}</h4>
                   <div class="my-3">
    @foreach(config('coins.coin_list') as $index => $coin)
        <div class="form-check">
            <input id="payment_method_{{ $index }}" name="payment_method" type="radio" class="form-check-input"
                value="{{ $coin }}" required 
                {{ $coin === 'Bitcoin' ? 'checked' : '' }}>
            <label class="form-check-label" for="payment_method_{{ $index }}">{{ $coin }} [{{ $index }}]</label>
        </div>
    @endforeach
</div>

                    <div class="form-group">
                        <label for="wallet_balance">{{ __('common.Amount:') }} in USD </label>
                        <input type="number" class="form-control nav-search-input my-3" id="wallet_balance" name="wallet_balance" required>
                    </div>

                    <button type="submit" class="btn btn-primary">{{ __('common.Generate Address') }}</button>
                </form>
            </div>
        </div>
    </div>
</div>


    <div class="mt-5">
        <h1 class="mb-4">{{ __('common.Payments') }}</h1>

        <div class="table-responsive cardheader">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>{{ __('common.ID') }}</th>
                        <th>{{ __('common.Method') }}</th>
                        <th>{{ __('common.Payment Address') }}</th>
                        <th>{{ __('common.Status') }}</th>
                        <th>{{ __('common.Amount') }}</th>
                        <th>{{ __('common.Total Received') }}</th>
                        <th>{{ __('common.Paid At') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($receivedpayments as $payment)
                        <tr>
                            <td>{{ $payment->id }}</td>
                            <td>{{ $payment->method }}</td>
                            <td>{{ $payment->payment_address }}</td>
                            <td>{{ $payment->status }}</td>
                            <td>{{ $payment->amount }}</td>
                            <td>{{ $payment->total_received }}</td>
                          <td>{{ $payment->paid_at ? \Carbon\Carbon::parse($payment->paid_at)->format('Y-m-d H:i:s') : __('common.N/A') }}</td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        <!-- Pagination Links -->
        {{ $payments->links() }}
    </div>
</div>
@endsection