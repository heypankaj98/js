@extends('layouts.admin.master')    @section('content')
<div class="mt-4">
@can('admin_product_category_create')
    <div class="row">
        <div class="col-lg-12">
            <a class="btn btn-main w-max-c" href="{{ route('admin.product-categories.create') }}">
                {{ trans('global.add') }} {{ trans('cruds.productCategory.title_singular') }}
            </a>
        </div>
    </div>
@endcan
<div class="card-header-2 w-100 my-4">
        {{ trans('cruds.productCategory.title_singular') }} {{ trans('global.list') }}
    </div>
<div class="bg-card-2 br1">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-prd table-striped table-hover datatable datatable-ProductCategory">
                <thead>
                    <tr>
                        <th>
                            {{ trans('cruds.productCategory.fields.id') }}
                        </th>
                        <th>
                            Category {{ trans('cruds.productCategory.fields.name') }}
                        </th>
                        <th>
                            Sub-Category {{ trans('cruds.productCategory.fields.name') }}
                        </th>
                        <th>
                            {{ trans('cruds.productCategory.fields.description') }}
                        </th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($productCategories as $key => $productCategory)
                        <tr data-entry-id="{{ $productCategory->id }}">
                            <td>
                                {{ $productCategory->id ?? '' }}
                            </td>
                            <td>
                             {{ $productCategory->parent_id ? $productCategory->parent->name : $productCategory->name }}

                            </td>
                            <td>
                                {{ $productCategory->parent_id ? $productCategory->name : '' }}
                            </td>
                            <td>
                                {{ $productCategory->description ?? '' }}
                            </td>
                            <td class="text-center">
                                @can('admin_product_category_show')
                                    <a class="btn  btn-primary btn-sm br-4" href="{{ route('admin.product-categories.show', $productCategory->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                @endcan

                                @can('admin_product_category_edit')
                                    <a class="btn  btn-info btn-sm br-4" href="{{ route('admin.product-categories.edit', $productCategory->id) }}">
                                        {{ trans('global.edit') }}
                                    </a>
                                @endcan

                                @can('admin_product_category_delete')
                                    <form action="{{ route('admin.product-categories.destroy', $productCategory->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn  btn-danger btn-sm br-4" value="{{ trans('global.delete') }}">
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>

@endsection