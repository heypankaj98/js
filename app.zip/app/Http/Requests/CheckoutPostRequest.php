<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CheckoutPostRequest extends FormRequest {

    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'address' => 'bail|required|string|min:20|max:5000',
            'payment_method' => 'required|in:BitcoinMultiSign,Bitcoin,Monero,Litecoin,Dashcoin'
        ];
    }
}   