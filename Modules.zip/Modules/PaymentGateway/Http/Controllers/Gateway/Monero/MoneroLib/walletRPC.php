<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib;

use Exception;
use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib\jsonRPCClient;

class WalletRPC {

    private $client, $protocol, $host, $port, $url, $user, $password;

    function __construct($host = '127.0.0.1', $port = 18085, $SSL = false, $user = null, $password = null) {
        if (is_array($host)) {
            $params = $host;

            $host = $params['host'] ?? '127.0.0.1';
            $port = $params['port'] ?? 18085;
            $protocol = $params['protocol'] ?? ($SSL ? 'https' : 'http');
            $user = $params['user'] ?? null;
            $password = $params['password'] ?? null;
        } else {
            $protocol = $SSL ? 'https' : 'http';
        }

        $this->host = $host;
        $this->port = $port;
        $this->protocol = $protocol;
        $this->user = $user;
        $this->password = $password;
        $this->check_SSL = $SSL;

        $this->url = $protocol . '://' . $host . ':' . $port . '/';
       $this->client = new jsonRPCClient($this->url, $this->user, $this->password, $this->check_SSL);
    }

   private function _run($method, $params = null, $path = 'json_rpc') {
    try {
        return $this->client->_run($method, $params, $path);
    } catch (Exception $e) {
        // Log the error or handle it
        throw new Exception("RPC call failed: " . $e->getMessage());
    }
}


    public function _print($json) {
        echo json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    // public function _transform($amount = 0,$address) {
    //     return intval(bcmul($amount, 1000000000000));
    // }
     public function _transform($amount = 0)
  {
    return intval(bcmul($amount, 1000000000000));
  }

    public function get_balance($account_index = 0) {
        return $this->_run('get_balance', ['account_index' => $account_index]);
    }
    
  public function getbalance($account_index = 0)
  {
    return $this->get_balance($account_index);
  }

    public function get_transactions($account_index = 0) {
        return $this->_run('get_transfers', ['in' => true,'out'=>true,'pending'=>true,'failed'=>true,'all_accounts'=>true]);
    }

    public function get_address($account_index = 0, $address_index = 0) {
        return $this->_run('get_address', ['account_index' => $account_index, 'address_index' => $address_index]);
    }

    public function get_address_index($address) {
        return $this->_run('get_address_index', ['address' => $address]);
    }

    public function create_address($account_index = 0, $label = '') {
     
        $result = $this->_run('create_address', ['account_index' => $account_index, 'label' => $label]);
        $this->store(); // Save wallet state after subaddress creation
        return $result;
    }

    public function label_address($index, $label) {
        return $this->_run('label_address', ['index' => $index, 'label' => $label]);
    }

    public function get_accounts($tag = null) {
       
        return $this->_run('get_accounts', $tag ? ['tag' => $tag,'account_index'=>10,'limit'=>10 ] : null);
    }
        public function getAccountTransactions( $accountIndex)
    {
   
        return $this->_run('get_transfers', [
            'account_index' => (int)  $accountIndex,
            'in' => true,  // Fetch incoming transactions
            'out' => true  // Fetch outgoing transactions
        ]);
    }
    
    public function getAccountAddresses($accountIndex)
    {
        return $this->_run('get_address', [
            'account_index' =>(int)  $accountIndex
        ]);
    }

    public function create_account($label = '') {
       
       
        $result = $this->_run('create_account', ['label' => $label]);
 
        $this->store(); // Save wallet state after account creation
        return $result;
    }

    // public function label_account($para) {
    //   $account_index = $para['account_index'];
    //   $label= $para['label'];
    
    //     $result = $this->_run('label_account', ['account_index' => $account_index, 'label' => $label]);
    //     $this->store(); // Save wallet state after account label
    //     return $result;
    // }
    
    
      public function label_account($account_index, $label)
  {
    $params = array('account_index' => $account_index, 'label' => $label);
    $label_account_method = $this->_run('label_account', $params);

    $save = $this->store(); // Save wallet state after account label

    return $label_account_method;
  }

    public function get_account_tags() {
        return $this->_run('get_account_tags');
    }
    

    // public function tag_accounts($para) {
    //  $accounts = $para['accounts'];
    //   $tag= $para['tag'];
     
    //     $result = $this->_run('tag_accounts', ['accounts' => $accounts, 'tag' => $tag]);
    
    //     $this->store(); // Save wallet state after account tagging
    //     return $result;
    // }

  public function tag_accounts($accounts, $tag)
  {
   $params = [
        'tag' => $tag,
        'accounts' => $accounts,
       
    ];

    $tag_accounts_method = $this->_run('tag_accounts', $params);

    $save = $this->store(); // Save wallet state after account tagging

    return $tag_accounts_method;
  }
  
    public function untag_accounts($accounts) {
        $result = $this->_run('untag_accounts', ['accounts' => $accounts]);
        $this->store(); // Save wallet state after untagging accounts
        return $result;
    }

    public function set_account_tag_description($tag, $description) {
        $result = $this->_run('set_account_tag_description', ['tag' => $tag, 'description' => $description]);
        $this->store(); // Save wallet state after describing tag
        return $result;
    }

    public function get_height() {
        return $this->_run('get_height');
    }

 public function get_wallet_info() {
     
        return $this->_run('get_wallet_info');
    }
    
  public function primary_transfer($amount, $address, $account_index = 0, $subaddr_indices = [0], $priority = 0, $ring_size = 7)
{
   
    $mixin = 10;
    $do_not_relay = false;
    
    // Convert the amount to atomic units (1 XMR = 1e12 atomic units)
    $amt = (int)($amount * 1000000000000);
    
    // Prepare the destinations array with amount and address
    $destinations = [
        [
            'amount' => $amt, // Amount in atomic units
            'address' => $address
        ]
    ];
   

    // Define the parameters array
    $params = [
        'destinations' => $destinations,
        'mixin' => $mixin,
        'get_tx_key' => true,
        'account_index' => (int)$account_index, // Ensure this is an integer
        'subaddr_indices' => $subaddr_indices,
        'priority' => $priority,
        'do_not_relay' => $do_not_relay,
        'ring_size' => $ring_size // Correct parameter name
    ];

    // Execute the transfer method
    $result = $this->_run('transfer', $params);

    // Save the wallet state after the transfer
    $this->store();
    // dd($result);
    return $result;
}

    
public function transfer($amount, $address = '', $account_index = 0, $subaddr_indices = '', $payment_id = '', $mixin = 10, $priority = 2, $unlock_time = 0, $do_not_relay = false, $ringsize = 11) {

        if (is_array($amount)) {
            $params = $amount;

            if (isset($params['destinations'])) {
                $destinations = $params['destinations'];

                if (!is_array($destinations)) {
                    throw new Exception('Error: destinations must be an array');
                }

                foreach ($destinations as $destination) {
                    if (!isset($destination['amount']) || !isset($destination['address'])) {
                        throw new Exception('Error: Amount and Address required');
                    }
                    $destination['amount'] = $this->_transform($destination['amount']);
                }
            } else {
                if (!isset($params['amount']) || !isset($params['address'])) {
                    throw new Exception('Error: Amount and Address required');
                }
                $destinations = [['amount' => $this->_transform($params['amount']), 'address' => $params['address']]];
            }

            $mixin = $params['mixin'] ?? $mixin;
            $account_index = $params['account_index'] ?? $account_index;
            $subaddr_indices = $params['subaddr_indices'] ?? $subaddr_indices;
            $priority = $params['priority'] ?? $priority;
            $unlock_time = $params['unlock_time'] ?? $unlock_time;
            $do_not_relay = $params['do_not_relay'] ?? $do_not_relay;
        } else {
           
            $destinations = [['amount' => $this->_transform($amount), 'address' => $address]];
        }

        $params = [
            'destinations' => $destinations,
            'mixin' => $mixin,
            'get_tx_key' => true,
            'account_index' => $account_index,
            'subaddr_indices' => $subaddr_indices,
            'priority' => $priority,
            'do_not_relay' => $do_not_relay,
            'ringsize' => $ringsize
        ];
        $result = $this->_run('transfer', $params);
        
        $this->store(); // Save wallet state after transfer
        return $result;
    }

    public function transfer_split($amount, $address = '', $payment_id = '', $mixin = 10, $account_index = 0, $subaddr_indices = '', $priority = 2, $unlock_time = 0, $do_not_relay = false) {
        if (is_array($amount)) {
            $params = $amount;

            if (isset($params['destinations'])) {
                $destinations = $params['destinations'];

                if (!is_array($destinations)) {
                    throw new Exception('Error: destinations must be an array');
                }

                foreach ($destinations as $destination) {
                    if (!isset($destination['amount']) || !isset($destination['address'])) {
                        throw new Exception('Error: Amount and Address required');
                    }
                    $destination['amount'] = $this->_transform($destination['amount']);
                }
            } else {
                if (!isset($params['amount']) || !isset($params['address'])) {
                    throw new Exception('Error: Amount and Address required');
                }
                $destinations = [['amount' => $this->_transform($params['amount']), 'address' => $params['address']]];
            }

            $payment_id = $params['payment_id'] ?? $payment_id;
            $mixin = $params['mixin'] ?? $mixin;
            $account_index = $params['account_index'] ?? $account_index;
            $subaddr_indices = $params['subaddr_indices'] ?? $subaddr_indices;
            $priority = $params['priority'] ?? $priority;
            $unlock_time = $params['unlock_time'] ?? $unlock_time;
            $do_not_relay = $params['do_not_relay'] ?? $do_not_relay;
        } else {
            $destinations = [['amount' => $this->_transform($amount), 'address' => $address]];
        }

        $params = [
            'destinations' => $destinations,
            'payment_id' => $payment_id,
            'mixin' => $mixin,
            'account_index' => $account_index,
            'subaddr_indices' => $subaddr_indices,
            'priority' => $priority,
            'unlock_time' => $unlock_time,
            'do_not_relay' => $do_not_relay
        ];
        $result = $this->_run('transfer_split', $params);
        $this->store(); // Save wallet state after transfer_split
        return $result;
    }

    public function sweep_all($account_index = 0, $address = '', $priority = 2, $mixin = 10, $unlock_time = 0, $do_not_relay = false) {
        return $this->_run('sweep_all', [
            'account_index' => $account_index,
            'address' => $address,
            'priority' => $priority,
            'mixin' => $mixin,
            'unlock_time' => $unlock_time,
            'do_not_relay' => $do_not_relay
        ]);
    }

    public function sweep_dust($address, $priority = 2, $mixin = 10, $unlock_time = 0, $do_not_relay = false) {
        return $this->_run('sweep_dust', [
            'address' => $address,
            'priority' => $priority,
            'mixin' => $mixin,
            'unlock_time' => $unlock_time,
            'do_not_relay' => $do_not_relay
        ]);
    }

    public function store() {
        // Implement wallet storage logic if needed
    }
     public function make_integrated_address($payment_id = null)
  {
    $params = array('payment_id' => $payment_id);
    return $this->_run('make_integrated_address', $params);
  }
  
   public function split_integrated_address($integrated_address)
  {
    $params = array('integrated_address' => $integrated_address);
    return $this->_run('split_integrated_address', $params);
  }
  
  
//   admin


public function getAllAccountsInfo() {
        $accounts = $this->get_accounts();
        $accountsDetails = [];
      
        foreach ($accounts['subaddress_accounts'] as $account) {
            $accountInfo = [];
            $accountInfo['account_index'] = $account['account_index'];
            $accountInfo['balance'] = $account['balance'] / 1000000000000;  // Convert to XMR
            $accountInfo['address'] = $this->get_address($account['account_index'])['address'];
            $accountInfo['label'] = $account['label'] ?? 'No Label';
            
            $accountsDetails[] = $accountInfo;
        }

        return $accountsDetails;
    }
     /**
     * Fetches the transaction history of all accounts.
     * 
     * @return array
     */
    public function getAllTransactions() {
        return $this->get_transactions();
    }

  
}
