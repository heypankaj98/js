@extends('layouts.buyer.app')   @section('content')

<div class="">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="">
                <div class="custom-title my-4 mt-4">
                    {{ trans('common.cards') }} <small>[{{ trans('common.referral') }} {{ trans('common.points') }} = {{ Auth::user()->earnedReferralPoints() }} ~ $ {{ Auth::user()->earnedReferralPoints()/2 }}]</small>
                </div>
                <div class="col-md-12">
                    <div class="br1 br-4">
                        <form action="{{route('user.gift-cards.buy')}}" method='POST'>
                            @csrf
                            <div class="col-md-12 col-lg-6 mt-3 mb-3">
                                <div class="bg-card-2 p-24">
                                    <div class="card-statistic-3 ">
                                        <div class="mb-4">
                                            <h5 class="card-header-buyer">{{ trans('common.cards') }}</h5>
                                        </div>
                                        <div class="row align-items-center mb-2 d-flex">
                                            <div class="col-12">
                                                <h2 class="d-flex align-items-center mb-0">
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" name="amount" placeholder="{{ trans('common.amount') }}" step="0.01" required>
                                                    </div>
                                                </h2>
                                            </div>
                                            <br>
                                            <div class="col-12 mb-3">
                                                <div class="form-check mt-2">
                                                    <input class="form-check-input" type="checkbox" name="redeem_points" id="redeem_points">
                                                    <label class="form-check-label" for="redeem_points">
                                                        {{ trans('common.redeem') }} {{ trans('common.points') }}   
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-main">{{ trans('common.buy') }} {{ trans('common.card') }}</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-12">
                    @foreach($giftCards as $giftCard)
                    <div class="bg-card-2 br1 mt-4">
                        <div class="card-header-2 w-100 mb-4">
                             {{ trans('common.card') }} {{ trans('common.details') }}
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>{{ trans('common.card') }} {{ trans('common.code') }}:</h5>
                                    <p class="text-accent-1">{{ $giftCard['code'] }}</p>
                                </div>
                                <div class="col-md-6">
                                    <h5>{{ trans('common.amount') }}:</h5>
                                    <p class="text-accent-1">$ {{ $giftCard['amount'] }}</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>{{ trans('common.status') }}:</h5>
                                    <p class="text-accent-1">
                                        @if($giftCard['status'] == 'payment_pending')
                                            {{ trans('common.payment') }} {{ trans('common.pending') }}
                                        @elseif($giftCard['status'] == 'payment_generated')
                                            {{ trans('common.payment') }} {{ trans('common.address') }} {{ trans('common.generated') }}
                                        @elseif($giftCard['status'] == 'paid')
                                            {{ trans('common.paid') }}
                                        @endif
                                    </p>
                                    
                                    @if ($giftCard['status'] == 'payment_pending')
                                        <form class="row g-3" action="{{ route('user.gift-cards.payment', ['id' => $giftCard['id']]) }}" method="POST">
                                            @csrf
                                            @foreach(config('coins.coin_list') as $index => $coin)
                                            <div class="form-check">
                                                <input id="payment_method" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>
                                                <label class="form-check-label" for="payment_method">{{$coin}} [{{$index}}]</label>
                                            </div>                                        @endforeach
                                            <div class="col-auto">
                                                <button type="submit" class="btn btn-main mb-3">{{ trans('global.generate_payment_address') }} </button>
                                            </div>
                                            
                                        </form>
                                    @elseif($giftCard['status'] == 'payment_generated')
                                        <div class="card">
                                            <p>
                                                <strong>{{ trans('common.amount') }}:</strong>
                                                <span class="badge text-bg-primary">
                                                    {{ trans('common.' . $giftCard->payment->method) }} {{ $giftCard->payment->amount }}
                                                </span>
                                            </p>
                                            <p>
                                                <strong>{{ trans('common.address') }}:</strong><br>
                                                <textarea class="btn text-bg-primary w-100" rows="4">{{ $giftCard->payment->payment_address }}</textarea>
                                            </p>
                                        </div>
                                    @elseif($giftCard['status'] == 'paid')
                                          <p>{{ trans('global.payment_received_you') }} </p>
                                    @endif
                                </div> 
                                <div class="col-md-6">
                                    <h5>{{ trans('common.date') }}:</h5>
                                    <p class="text-accent-1">{{ $giftCard['created_at']->format('M, j Y g:i A') }}</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>{{ trans('common.expiration') }} {{ trans('common.date') }}</h5>
                                    <p class="text-accent-1">{{ $giftCard['expiration_date'] ?: trans('common.no') }}</p>
                                </div>
                                <div class="col-md-6">
                                    <h5>Used:</h5>
                                    <p class="text-accent-1">{{ $giftCard['used'] ? trans('common.yes') : trans('common.no') }}</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    @endforeach
                    <div class="col-md-12">
                        {{ $giftCards->appends(request()->input())->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection