@extends('layouts.buyer.app')       @section('content')

<div class="container">
    <div class="row justify-content-center disputes_blade_part">
        <div class="col-md-12">
            @if (session('success'))
                <div id="alert_message" class="alert alert-success alert-block">
                    <strong>{{session('success')}}</strong>
                </div>
            @endif
            @if (session('error'))
                <div id="alert_message" class="alert alert-danger alert-block">
                    <strong>{{ session('error') }}</strong>
                </div>
            @endif

            <div class="container">
                <div class="row rounded-lg overflow-hidden shadow">
                    <div class="col-5 px-0">
                        <div class="bg-white">
                            <div class="bg-gray px-4 py-2 bg-light">
                                <p class="h5 mb-0 py-1">{{ trans('common.recent') }} {{ trans('common.disputes') }}</p>
                            </div>
                            <div class="messages-box">
                                <div class="list-group rounded-0">
                                    @foreach($disputes as $key => $dispute)
                                        <a href="{{route('dispute',$dispute)}}" class="list-group-item list-group-item-action list-group-item-light rounded-0">
                                            <div class="media">
                                                <img src="https://bootstrapious.com/i/snippets/sn-chat/avatar.svg" alt="user" width="50" class="rounded-circle">
                                                <div class="media-body ml-4">
                                                    <div class="d-flex align-items-center justify-content-between mb-1">
                                                        <h6 class="mb-0">{{ $dispute->seller->username }}</h6>
                                                        <small class="small font-weight-bold">
                                                            {{ $dispute->first()->created_at->format('j-M-Y g:i A') }}
                                                        </small>
                                                    </div>
                                                    <p class="font-italic mb-0 text-small">
                                                        @if(!is_null($dispute->messages()->first())) 
                                                            {{ $dispute->messages()->first()->message }}
                                                        @endif
                                                    </p>
                                                </div>
                                            </div>
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-7 px-0">
                        <div class="px-4 py-5 chat-box bg-white">

                            @if(isset($dispute_message))

                            @foreach($dispute_message as  $message)


                            @if(auth()->user()->id == $message->user_id)
                            <!-- Reciever Message-->
                            <div class="media w-50 ml-auto mb-3" style="margin-left: 222px;">
                                <div class="media-body">
                                    <div class="bg-primary rounded py-2 px-3 mb-2">
                                        <p class="text-small mb-0 text-white">{{$message->message}}</p>
                                    </div>
                                    <p class="small text-muted">{{ date('Y-m-d H:i:s') }}</p>
                                </div>
                            </div>

                            @else
                            <!-- Sender Message-->
                            <div class="media w-50 mb-3"><img src="https://bootstrapious.com/i/snippets/sn-chat/avatar.svg" alt="user" width="50" class="rounded-circle">
                                <div class="media-body ml-3">
                                    <div class="bg-light rounded py-2 px-3 mb-2">
                                        <p class="text-small mb-0 text-muted">{{$message->message}}</p>
                                    </div>
                                    <p class="small text-muted">{{ date('Y-m-d H:i:s') }}</p>
                                </div>
                            </div>
                            @endif



                            @endforeach

                            @endif
                        </div>

                        <!-- Typing area -->
                        <form method="POST" action="{{ route('dispute.reply') }}" class="bg-light">
                            @csrf
                            <div class="input-group">
                                @if(!isset($dispute_id))
                                    @php
                                        $dispute_id = 0;
                                    @endphp
                                @endif
                                <input type="hidden" name="dispute_id" value="{{$dispute_id}}" />
                                <input type="text" name="message" placeholder="Type a message" aria-describedby="button-addon2" class="form-control rounded-0 border-0 py-4 bg-light" />
                                @error('message')
                                    <div class="text-danger">{{ $message }}</div>
                                @enderror
                                <div class="input-group-append">
                                    <button id="button-addon2" type="submit" class="btn btn-link">
                                        {{ trans('product.send_btn') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection