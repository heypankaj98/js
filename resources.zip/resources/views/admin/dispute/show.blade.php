@extends('admin.dispute.template')
@section('title', $singledispute->order_id)

@section('messenger-content')


<div class="mt-4">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar">
        
                <!-- Users -->
                <div class="bg-card-2 h-100 p-16 br1 ">
                    <h5 class="card-header-2 w-100 mb-4">Disputes</h5>
                    <ul class="list-unstyled">
                        @forelse($disputes as $dispute)
                        <li>  <a href="{{ route('admin.dispute.messages', [$dispute->id]) }}">
                        <div class="user_info position-relative d-flex lign-items-center align-items-center">
                                <img src="{{$dispute->seller->avatar}}"   class="rounded-circle">
                                    <div class="d-flex flex-column">
                                        <span class="d-flex  align-items-center">{{$dispute->seller->username}} 
                                             <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="green" class="bi bi-dot" viewBox="0 0 16 16">
                                                <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/>
                                            </svg> 
                                        </span>
                                        <p class="small mb-0">Status:{{$dispute->status}}</p>
                                    </div>
                                        
                                        <p class="small ab-p">Order:{{$dispute->order_id}}</p>
 
                                </div>
                            </a>
                        </li>
                        @empty
                        No chat User
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">

                    <h5>Chat with {{$singledispute->seller->username}} for order {{$singledispute->order_id }} status:{{$singledispute->status }}</h5>

                </div>
                <div class="card-body">
                    <div class="chat-messages">
                        @foreach($singledispute->messages() as $message)
                        @if($message->user_id == Auth::user()->id)
                        <div class="message sent">
                            <div class="message-content mw-100  ">
                                <div class="message-header small">
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @else
                        <div class="message received">

                            <div class="message-content mw-100 ">
                                <div class="message-header small">
                                    <img src="{{$message->sender->avatar}}" class="rounded-circle">
                                        <span class="username">{{$message->sender->username}}</span>
                                        <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text mw-100">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @endif
                        @endforeach
                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">

                    <form action="{{ route("admin.dispute.reply", [$singledispute->id]) }}" method="POST">
                        @csrf

                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="hidden" name="dispute_id" value="{{$singledispute->id}}" />
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                    <button type="submit" class="btn btn-main">Send</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="">
                <div class="">
                    <div class="">
                        <div class="bg-card-2 p-16 br1">
                            <p class="card-header-2 w-100 mb-4">Product Details</p>
                            @if ($singledispute->product->photo)
                            <img src="{{ $singledispute->product->photo->getUrl() }}" class="img-fluid br1 br-4" alt="User Avatar">
                                @endif 
                                <div class="card-body">
                                    <h5 class="card-title mt-2">{{$singledispute->product->name}}</h5>
                                </div>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">Price: {{$singledispute->product->price}}</li>
                                    <li class="list-group-item">Type: {{$singledispute->product->type}}</li>
                                    <li class="list-group-item">Seller: {{$singledispute->product->seller->username}}</li>
                                    <a href="{{route('messenger.newMessages',$singledispute->seller->id)}}" class="btn btn-main">
                                        <i class="bi bi-chat-dots"></i> Message
                                    </a>
                                </ul>


                        </div>
                    </div>
                </div>
                <br>
    
                    <form action="{{ route("admin.dispute.winner", [$singledispute->id]) }}" method="POST">
                        @csrf
                        <select class="form-select py-0" name="winner" aria-label="Default select example">
                            <option selected>Select Winner</option>
                            <option value="{{$singledispute->buyer->id}}">Buyer {{$singledispute->buyer->username}}</option>
                            <option value="{{$singledispute->seller->id}}">Seller {{$singledispute->seller->username}}</option>
                        </select>
                        
                            <div class="form-group mt-2">
                                <div class="">
                                    <input type="hidden" name="dispute_id" value="{{$singledispute->id}}" />
                                    <button type="submit" class="btn btn-main w-100">Select Winner</button>
                                </div>
                            </div>
                    </form>
            </div>
        </div>
    </div>
</div>





@stop