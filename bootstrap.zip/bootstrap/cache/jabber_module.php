<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Jabber\\Providers\\JabberServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Jabber\\Providers\\JabberServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);