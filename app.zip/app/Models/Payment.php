<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model {

    use HasFactory;

    protected $fillable = [
        'method',
        'payment_address',
        'status',
        'amount',
        'type',
        'total_received',
        'deleted',
        'paid_at',
    ];
      public function user() {
        return $this->belongsTo(User::class);
    }

}
