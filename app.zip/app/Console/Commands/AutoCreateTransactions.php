<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\OrderPayment;
use App\Models\Transaction;
use App\Models\UserMeta;
use Carbon\Carbon;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class AutoCreateTransactions extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:auto-create-transactions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle(): void {
        $oneHourAgo = Carbon::now()->subHour();

        $orderPayments = OrderPayment::where('status', 'PAID')
                ->where('created_at', '>=', $oneHourAgo)
                ->get();

        foreach ($orderPayments as $orderPayment) {
            $payment_method = $orderPayment->method;
            $address = $orderPayment->payment_address;
            $transaction_data = PayWay::getWalletlisttransactions($payment_method, [
                        'address' => $address
            ]);
            foreach ($transaction_data as $single_transaction) {

                $transaction = Transaction::firstOrNew(['crypto_address' => $address]);

                if ($single_transaction['address'] == $address) {
                    $transaction->user_id = $orderPayment->order()->first()->buyer->id;
                    $transaction->trx_id = $single_transaction['txid'];
                    $transaction->crypto_name = $payment_method;
                    $transaction->crypto_address = $address;
                    $transaction->crypto_amount = $single_transaction['amount'];
                    $transaction->created_at = now()->setTimestamp($single_transaction['time']);
                    $transaction->type = 'order'; // enum: Order, dispute, ads, multisign, payouts
                    $transaction->updated_at = now();
                    $transaction->save();
                }
            }
        }


        $userMetaCollection = UserMeta::where('key', 'become_seller')
                ->where('created_at', '>=', $oneHourAgo)
                ->get();

        foreach ($userMetaCollection as $userMeta) {
            $paymentCoins = json_decode($userMeta->value, true);
            foreach ($paymentCoins as $payment_method => $address) {

                $transaction_data = PayWay::getWalletlisttransactions($payment_method, [
                            'address' => $address
                ]);
                foreach ($transaction_data as $single_transaction) {
                    $transaction = Transaction::firstOrNew(['crypto_address' => $address]);
                    if ($single_transaction['address'] == $address) {
                        $transaction->user_id = $userMeta->user_id;
                        $transaction->trx_id = $single_transaction['txid'];
                        $transaction->crypto_name = $payment_method;
                        $transaction->crypto_address = $address;
                        $transaction->crypto_amount = $single_transaction['amount'];
                        $transaction->created_at = now()->setTimestamp($single_transaction['time']);
                        $transaction->type = 'become_vendor'; // enum: Order, dispute, ads, multisign, payouts
                        $transaction->updated_at = now();
                        $transaction->save();
                    }
                }
            }
        }
        $this->info('Auto-Transaction create completed.');
    }

}
