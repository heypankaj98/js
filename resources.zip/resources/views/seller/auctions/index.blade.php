@extends('layouts.seller.app')      @section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
            @can('admin_product_create')
                <div  class="row mb-2">
                    <div class="dropdown">
                        <a class="btn btn-dark" href="{{ route("seller.auction.create") }}"> {{ trans('global.create_an ') }}</a>
                    </div>
                </div>
            @endcan
            
              <div class="card">
                <div class="card-header">
                    Auction {{ trans('cruds.product.title_singular') }} {{ trans('global.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-striped table-hover datatable datatable-Product">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('cruds.auction.id') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.name') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.auctioner') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.bids') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.current_price') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.category') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.auction.type') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($auction as $key => $single)
                                <tr data-entry-id="{{ $single->id }}">
                                    <td>
                                        {{ $single->id ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->seller->username ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->bids->count() ?? 'No Bids' }}
                                    </td>
                                    <td>
                                        $ {{ $single->bids->max('amount') ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->categories->name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $single->type ?? '' }}
                                    </td>
                                    <td>
                                        @can('admin_product_show')
                                        <a class="btn btn-primary btn-sm" href="{{ route('auction', $single->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_edit')
                                        <a class="btn btn-info btn-sm" href="{{ route('seller.auction.edit', $single->id) }}">
                                            {{ trans('global.edit') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_delete')
                                        <form action="{{ route('seller.auction.destroy', $single->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" class=" d-inline-block">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                            <input type="submit" class="btn btn-danger btn-sm" value="{{ trans('global.delete') }}">
                                        </form>
                                        @endcan
                                    </td>
                                </tr>
                                @empty
                                    <tr>
                                        <td colspan="8">{{ trans('global.no_auction_available') }} </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                        
                    </div>
                </div>
              </div>
        </div>
    </div>
</div>

@endsection