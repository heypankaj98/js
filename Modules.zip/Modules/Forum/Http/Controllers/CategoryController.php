<?php

namespace Modules\Forum\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Forum\Models\Category;
use Modules\Forum\Models\Thread;
use Auth,
    Gate;
use Symfony\Component\HttpFoundation\Response;

class CategoryController extends Controller {

    /** 
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index() {
        $categories = Category::get();
        return view('forum::index', compact('categories'));
//        return view('forum::index');
    }

    public function create() {
        abort_if(Gate::denies('forum_create_categories'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('forum::forum.categories.create');
    }

    public function store(Request $request) {
        abort_if(Gate::denies('forum_create_categories'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $category = Category::create($request->all());
        return redirect()->route('categories.index');
    }

    public function show($category) {
        $category = Category::findOrFail($category);
        $threads = $category->threads()->get();

        return view('forum::forum.categories.show', compact('category', 'threads'));
    }

    public function edit(Category $category) {
        return view('forum.categories.edit', compact('category'));
    }

    public function update(Request $request, Category $category) {
        $category->update($request->all());

        // Redirect to the category index page or show a success message
    }

    public function destroy(Category $category) {
        $category->delete();

        // Redirect to the category index page or show a success message
    }

}
