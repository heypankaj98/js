@extends('layouts.app')

@section('content')
<div class="container">
    <h2>PGP Key Management</h2>

    @if (Auth::user()->pgp_key)
        <p>Your PGP key is set and verified.</p>
        <form action="{{ route('pgp.updatePgpKey') }}" method="POST">
            @csrf
            @method('POST')
            <div class="form-group">
                <label for="pgp_key">Update Your PGP Key:</label>
                <textarea id="pgp_key" name="pgp_key" class="form-control" rows="8" required>{{ Auth::user()->pgp_key }}</textarea>
            </div>
            <button type="submit" class="btn btn-warning">Update PGP Key</button>
        </form>

        <form action="{{ route('pgp.toggleTwoFactorAuth') }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-secondary">
                {{ Auth::user()->twofa ? 'Disable' : 'Enable' }} Two-Factor Authentication
            </button>
        </form>
    @else
        <p>You haven't set a PGP key yet. <a href="{{ route('pgp.viewSetPGPKey') }}">Set it now</a>.</p>
    @endif
</div>
@endsection
