<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order;
use App\Models\Settings;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class GeneratePayouts extends Command
{
    protected $signature = 'payouts:generate';
    protected $description = 'Generate payouts for completed orders without executing payments';

    const PROCESSED = 1;
    const ERROR_OCCURED = 2;
    const ERROR_SELLER_NOT_FOUND = 3;
    const ERROR_ADDRESS_NULL = 4;

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $fourDaysAgo = Carbon::now()->subDays(4);

        $orders = Order::where(function ($query) {
            $query->where('status', 'completed')
                  ->orWhere('status', 'finalize');
        })
         ->where('payout_created', 0)
        ->where('created_at', '>=', $fourDaysAgo)
        // ->where('buyer_id', 349)
        // ->where('seller_id', 3)
        ->get();

        foreach ($orders as $order) {
            try {
                $this->createPayout($order);
                $this->info("Payout created for order ID: {$order->id}");
            } catch (\Exception $e) {
                Log::error("Failed to create payout for order ID: {$order->id} - " . $e->getMessage());
                $this->updateOrderStatusOnError($order, $e->getMessage());
                $this->error("Failed to create payout for order ID: {$order->id} - " . $e->getMessage());
            }
        }

        return 0;
    }

    private function createPayout(Order $order)
    {
        $commission = Settings::get('market_fee');
        $orderPrice = $order->total_crypto;

        // Calculate commission and payout amount
        $orderCommission = $orderPrice * $commission / 100;
        $payoutAmount = $orderPrice - $orderCommission;

        // Adjust for featured product commission
        if ($order->product->isfeature) {
            $featureCommission = Settings::get('featured_product');
            $payoutAmount -= convert($featureCommission, $order->payment_method);
        }

        // Check for seller
        $seller = $order->seller;
        if (!$seller) {
            throw new \Exception("Seller not found");
        }

        // Get payout address based on payment method
        $payoutAddress = null;
        if ($order->payment_method == 'Bitcoin') {
            $payoutAddress = $seller->btc_address ?? null;
        } elseif ($order->payment_method == 'Monero') {
            $payoutAddress = $seller->xmr_address ?? null;
        }

        // Ensure the payout address is valid
        if (is_null($payoutAddress)) {
            throw new \Exception("Payout address is null for seller ID: {$seller->id}");
        }

        // Store payout details without executing payment
        $this->storePayout($order, $seller->id, $payoutAddress, $order->payment_method, $payoutAmount, $orderPrice, $orderCommission, $commission);

        // Update order status
        $order->update(['payment_release' => self::PROCESSED]);
    }

    private function storePayout(Order $order, int $sellerId, string $cryptoAddress, string $paymentMethod, float $amount, float $orderPrice, float $orderCommission, float $commission)
    {
     $payoutId = DB::table('payouts')->insertGetId([
        'user_id' => $sellerId,
         'order_id' => $order->id,
        'payment_address' => $cryptoAddress,
        'payment_method' => $paymentMethod,
        'amount' => $amount,
        'status' => 'pending', // Or any relevant status
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    // Store order details with a reference to the payout
    DB::table('order_details')->insert([
        'order_id' => $order->id,
        'seller_id' => $sellerId,
        'payout_id' => $payoutId, // Assuming you have a `payout_id` column in `order_details`
        'order_amount' => $orderPrice,
        'payment_method' => $paymentMethod,
        'commission_earned' => $orderCommission,
        'commission_percentage' => $commission,
        'seller_transfer' => $amount,
        'status' => 'pending',
        'created_at' => now(),
        'updated_at' => now(),
    ]);
    
     $order->update(['payout_created' => 1]);
    }

    private function updateOrderStatusOnError(Order $order, string $errorMessage)
    {
        if (strpos($errorMessage, "Seller not found") !== false) {
            $order->update(['payment_release' => self::ERROR_SELLER_NOT_FOUND]);
        } else {
            $order->update(['payment_release' => self::ERROR_OCCURED]);
        }
    }
}
