<?php
namespace App\Http\Requests\Admin;

use App\Models\Auction;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateAuctionRequest extends FormRequest {

    protected $stopOnFirstFailure = true;

    //public function authorize() {
    //    return Gate::allows('admin_product_edit');
    //}

    public function rules() {
        return [
            'type' => ['bail', 'required', 'string', 'in:digital,physical'],
            'name' => ['bail', 'required', 'string', 'min:5', 'max:150'],
            'description' => ['bail', 'required', 'string', 'min:50', 'max:7000'],
            'policy' => ['bail', 'required', 'string', 'min:50', 'max:7000'],
            'picture' => ['bail','image', 'mimes:jpeg,jpg,png,webp'],
            'category' => ['bail', 'required', 'integer', 'exists:product_categories,id'],
            'start_time' => ['required','after_or_equal:' . now()->format('Y-m-d H:i:s'),'before:end_time'],
            'end_time' => ['required','after:start_time'],
            'isfeature' => ['bail','integer'],
            'stock' => ['bail', 'required', 'integer','gt:0'],
            'product_measure' => ['bail', 'required','string','max:20'],
            'custom_product_measure' => ['bail'],
            'reserve_price' => ['bail', 'required','integer','gt:0'],
            'content' => ['bail','string']
            ];
    }
    
    public function messages()
    {
        return [
            'start_time.required' => 'The auction start time is required.',
            'start_time.date_format' => 'The auction start time must be in the format of YYYY-MM-DD HH:mm:ss.',
            'start_time.before' => 'The auction start time must be before the end time.',
            'end_time.required' => 'The auction end time is required.',
            'end_time.date_format' => 'The auction end time must be in the format of YYYY-MM-DD HH:mm:ss.',
            'end_time.after' => 'The auction end time must be after the start time.'
        ];
    }
}