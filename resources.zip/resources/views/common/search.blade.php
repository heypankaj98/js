@extends('layouts.homeapp')
@section('content')
<div class="bg-card-1 p-24">
    <div class="title-box mb-3"><h1>Search results for "{{ $query }}"</h1></div>
    <div class="filter_heading">
        <p>Filtered by: {{ $filter }}</p>
    </div>
    <div class="row">
        @foreach($results as $key => $product)

        <div class="col-md-3 mb-4">

            <div class="card thumbnail-image">
                <div class="image-container">
                    <div class="first">
                        <div class="d-flex justify-content-between align-items-center">
                            @if($product->wdiscount != null)
                            @foreach(unserialize($product->wdiscount) as $key => $discount)
                            <span class="discount"> {{$key}} - {{$discount}}% </span>
                            @endforeach
                            @endif
                        </div>
                    </div>


                    <a href="" class="card_img">

                        @if($product->photo)
                        <img src="{{ $product->photo->getUrl() }}" class="img-fluid rounded thumbnail-image">
                        @endif

                    </a>
                    <span class="product-type">{{$product->type}} </span>
                </div>
                <div class="product-detail-container p-2">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="dress-name"> {{ $product->name ?? '' }}</h5>
                    </div>
                    <span class="pull-right">By <span class="badge">{{$product->seller->username}}</span> </span>
                    <div class="d-flex align-items-center gap-1 mt-2">
                    <span class="rating-number">4.8</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-star" viewBox="0 0 16 16">
                            <path fill="#FCCC0E"
                                d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-star" viewBox="0 0 16 16">
                            <path fill="#FCCC0E"
                                d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-star" viewBox="0 0 16 16">
                            <path fill="#FCCC0E"
                                d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-star" viewBox="0 0 16 16">
                            <path fill="#FCCC0E"
                                d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-star" viewBox="0 0 16 16">
                            <path fill="#FCCC0E"
                                d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z" />
                        </svg>
                        
                    </div>
                    <div class="d-flex flex-column mb-2 mt-2">

                        <span class="new-price">{{ convertCurrency($product->price, request()->currency) }}
                            {{ request()->currency }} </span>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-2 ">
                        <a class="btn-orange br-4 w-100" href="{{ route('product.details', ['id' => $product->id] ) }}">
                            {{ trans('global.buy-now') }}</a>
                    </div>
                </div>

            </div>

        </div>
        @endforeach

        {{ $results->links('partials.pagination') }}
    </div>
</div>

@endsection