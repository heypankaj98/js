@extends('layouts.seller.app')     @section('content')


<div class="mt-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('Invoices') }} {{ trans('global.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('No.') }}
                                    </th>
                                    <th>
                                        {{ trans('Invoice-ID') }}
                                    </th>
                                    <th>
                                        {{ trans('Payment Method') }}
                                    </th>
                                    <th>
                                        {{ trans('Total Price') }}
                                    </th>
                                    <th>
                                        {{ trans('Payment-Date') }}
                                    </th>
                                    <th>
                                        {{ trans('Payment-Status') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection 