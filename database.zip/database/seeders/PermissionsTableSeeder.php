<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder {

    public function run() {
        $permissions = [
            [
                'id' => 1,
                'title' => 'admin_user_management_access',
            ],
            [
                'id' => 2,
                'title' => 'admin_permission_create',
            ],
            [
                'id' => 3,
                'title' => 'admin_permission_edit',
            ],
            [
                'id' => 4,
                'title' => 'admin_permission_show',
            ],
            [
                'id' => 5,
                'title' => 'admin_permission_delete',
            ],
            [
                'id' => 6,
                'title' => 'admin_permission_access',
            ],
            [
                'id' => 7,
                'title' => 'admin_role_create',
            ],
            [
                'id' => 8,
                'title' => 'admin_role_edit',
            ],
            [
                'id' => 9,
                'title' => 'admin_role_show',
            ],
            [
                'id' => 10,
                'title' => 'admin_role_delete',
            ],
            [
                'id' => 11,
                'title' => 'admin_role_access',
            ],
            [
                'id' => 12,
                'title' => 'admin_user_create',
            ],
            [
                'id' => 13,
                'title' => 'admin_user_edit',
            ],
            [
                'id' => 14,
                'title' => 'admin_user_show',
            ],
            [
                'id' => 15,
                'title' => 'admin_user_delete',
            ],
            [
                'id' => 16,
                'title' => 'admin_user_access',
            ],
            [
                'id' => 17,
                'title' => 'admin_product_management_access',
            ],
            [
                'id' => 18,
                'title' => 'admin_product_category_create',
            ],
            [
                'id' => 19,
                'title' => 'admin_product_category_edit',
            ],
            [
                'id' => 20,
                'title' => 'admin_product_category_show',
            ],
            [
                'id' => 21,
                'title' => 'admin_product_category_delete',
            ],
            [
                'id' => 22,
                'title' => 'admin_product_category_access',
            ],
            
            [
                'id' => 23,
                'title' => 'admin_dispute_access',
            ],
            
            [
                'id' => 24,
                'title' => 'admin_dispute_show',
            ],
            
            [
                'id' => 25,
                'title' => 'admin_dispute_edit',
            ],
            [
                'id' => 26,
                'title' => 'admin_dispute_delete',
            ],
            [
                'id' => 27,
                'title' => 'admin_dispute_change',
            ],
            
            [
                'id' => 28,
                'title' => 'admin_product_create',
            ],
            [
                'id' => 29,
                'title' => 'admin_product_edit',
            ],
            [
                'id' => 30,
                'title' => 'admin_product_show',
            ],
            [
                'id' => 31,
                'title' => 'admin_product_delete',
            ],
            [
                'id' => 32,
                'title' => 'admin_product_access',
            ],
            [
                'id' => 33,
                'title' => 'admin_profile_password_edit',
            ],
            [
                'id' => 34,
                'title' => 'admin_user_communication_access',
            ],
            [
                'id' => 35,
                'title' => 'admin_ads_access',
            ],
            [
                'id' => 36,
                'title' => 'admin_payment_access',
            ],
            [
                'id' => 37,
                'title' => 'admin_error_access',
            ],
            [
                'id' => 38,
                'title' => 'seller_delegate_access_manage',
            ],
            [
                'id' => 39,
                'title' => 'seller_delegateaccess_create',
            ],
            [
                'id' => 40,
                'title' => 'seller_manage_disputes',
            ],
            [
                'id' => 41,
                'title' => 'seller_manage_sales',
            ],
            [
                'id' => 42,
                'title' => 'seller_manage_aution',
            ],
            [
                'id' => 43,
                'title' => 'seller_manage_shipping_method',
            ],
            [
                'id' => 44,
                'title' => 'seller_manage_products',
            ],
            [
                'id' => 45,
                'title' => 'seller_staff_access',
            ],
        ];

        Permission::insert($permissions);
    }

}
