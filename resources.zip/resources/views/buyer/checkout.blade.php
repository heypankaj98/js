@extends('layouts.nosidebar')       @section('content')

<div class="container">
    <div class="row g-5">
        <div class="col-md-5 col-lg-4 order-md-last">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-primary">{{ trans('product.your_cart')}}</span>
                <span class="badge bg-primary rounded-pill">{{ $totalProducts }}</span>
            </h4>
            <ul class="">
                @forelse($products as $key =>  $product  )
                <li class="list-group-item d-flex justify-content-between lh-sm">
                    <div>
                        <h6 class="my-0">{{$product->name}}</h6>
                        <small class="text-muted">{{ trans('product.brief_description')}}</small> 
                    </div>
                    <span class="text-muted">{{ convertCurrency($cartProduct[$key]['price'], request()->currency)  }} </span>
                </li>
                @empty
                <td colspan="7"> {{ trans('product.your_shopping_cart')}} </td>
                @endforelse
                <hr>

                <li class="list-group-item d-flex justify-content-between">
                    <span>Shipping Price ({{request()->currency}})</span>
                    <strong>{{ convertCurrency($totalshippingPrice, request()->currency)  }}</strong>
                </li>
                <hr>
                <li class="list-group-item d-flex justify-content-between">
                    <span>Total ({{request()->currency}})</span>
                    <strong>{{convertCurrency($totalPrice, request()->currency) }}</strong>
                </li>
            </ul>
            <form class="card p-2" action="{{ route('user.gift-cards.apply') }}" method="POST">
                <!--<div class="input-group">-->


                <!--    @csrf-->
                    <!--<label class="form-control" for="gift_card_code">Gift Card Code:</label>-->
                    <!--<input type="text" id="gift_card_code" name="gift_card_code">-->
                    <!--<button class="btn btn-secondary mt-3" type="submit"> {{ trans('product.apply_gift_card')}} </button>-->

                    
                <!--</div>-->
            </form>
        </div>
        <div class="col-md-7 col-lg-8">
            <h4 class="mb-3"> {{ trans('product.delivery_addreess')}}</h4>
            <form class="needs-validation" action="{{ route('user.post.checkout') }}" method="POST" >
                @csrf
                <div class="row my-4">
                    <div class="col">
                        <label for="firstName" class="form-label"> {{ trans('product.belivery_address')}}</label>
                        <textarea class="form-control" id="firstName" name="address" required></textarea>
                        <small class="text-muted"> {{ trans('product.minimum')}} </small> 
                    </div>
                </div>
                
                
                @if(Session::has('error'))
                <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                @endif
                @error('address')
                <div class="alert alert-danger" role="alert">
                    {{ $message }}
                </div>
                @enderror
                <!--div class="form-check my-4">
                    <input type="checkbox" class="form-check-input" id="save-info" name="defa">
                    <label class="form-check-label" for="save-info">Make this address default</label>
                </div-->
                <h4 class="my-3">Payment Method</h4>
                <div class="my-3">
                    @foreach(config('coins.coin_list') as $index => $coin)

                    <div class="form-check">
                        <input id="payment_method" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>
                        <label class="form-check-label" for="payment_method">{{$coin}} [{{$index}}]</label>
                    </div>
                    @endforeach

                </div>
                <button class="w-100 btn btn-primary btn-lg" type="submit"> {{ trans('product.checkout_btn')}}</button>
            </form>


        </div>
    </div>

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@endif

@if($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
</div>
@endsection