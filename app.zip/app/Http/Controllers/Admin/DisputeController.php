<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{
    Order,
    Dispute,
    DisputeMessage
};
use Illuminate\Support\Str;
use App\Notifications\OrderDisputeNotification;
use App\Traits\OrderTrait;

class DisputeController extends Controller {

    use OrderTrait;

    public function getDisputes() {
        if (\Auth::user()->isAdmin) {
            return Dispute::orderBy('id', 'desc')->get();
        } else {
            if (\Auth::user()->isSeller) {
                return Dispute::where('disputes.seller_id', \Auth::id())
                                ->orderBy('id', 'desc')
                                ->get();
            } elseif (\Auth::user()->isMod) {
                return Dispute::get()->orderBy('id', 'desc');
            } else {
                return Dispute::orderBy('id', 'desc')
                                ->get();
            }
        }
    }

    public function index() {

        $disputes = Dispute::orderBy('id', 'desc')->get();
        return view('admin.dispute.index', ['disputes' => $disputes]);
    }

    public function disputeMessage(Dispute $dispute) {
        $disputes = Dispute::orderBy('id', 'desc')->get();

        return view('admin.dispute.show', ['disputes' => $disputes, 'singledispute' => $dispute]);
    }

    public function disputeWinner(Request $request) {
        $request->validate([
            'dispute_id' => 'required',
            'winner' => 'required',
        ]);

        $dispute = Dispute::findOrFail($request->dispute_id);

        // Prevent duplicate entries
        if ($dispute->status === 'solved') {
            return redirect()->back()->with('error', 'This dispute has already been marked as solved.');
        }

        $winnerId = (int) $request->winner;
        $buyerId = (int) $dispute->buyer_id;
        $sellerId = (int) $dispute->seller_id;

        if ($winnerId === $buyerId) {
            $winner = $dispute->buyer;
            $this->markAsRefund($dispute->order->id);
        } elseif ($winnerId === $sellerId) {
            $winner = $dispute->seller;
            $this->markAsCompleted($dispute->order->id);
        } else {
            return redirect()->back()->with('error', 'Invalid winner selection.');
        }

        if ($dispute->order->payment_method == 'Bitcoin') {
            $winner->btc_balance += $dispute->order->total_crypto;
        }
        if ($dispute->order->payment_method == 'Monero') {
            $winner->xmr_balance += $dispute->order->total_crypto;
        }

        $dispute->winner_id = $winnerId;
        $dispute->status = 'solved';
        $dispute->save();

        $addDisputeMsg = new DisputeMessage();
        $addDisputeMsg->user_id = \Auth::id();
        $addDisputeMsg->dispute_id = $request->dispute_id;
        $addDisputeMsg->message = "Dispute marked as solved and the winner is " . $winner->username;
        $addDisputeMsg->save();

//        return redirect('admin/dispute/' . $request->dispute_id);
        return redirect()->route('admin.dispute.messages', $request->dispute_id);
    }

    public function replyToDispute(Request $request) {
        $request->validate([
            'content' => 'required',
            'dispute_id' => 'required',
        ]);
        $addDisputeMsg = new DisputeMessage();
        $addDisputeMsg->user_id = \Auth::id();
        $addDisputeMsg->dispute_id = $request->dispute_id;
        $addDisputeMsg->message = $request->content;
        $addDisputeMsg->save();
        $dispute = Dispute::where('id', $request->dispute_id)->first();
        $dispute->seller->notify(new OrderDisputeNotification($dispute));
        $dispute->buyer->notify(new OrderDisputeNotification($dispute));

        return redirect()->route('admin.dispute.messages', ['dispute' => $request->dispute_id]);
    }

}
