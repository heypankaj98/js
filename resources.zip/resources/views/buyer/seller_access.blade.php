@extends('layouts.buyer.app')

@section('content')
<h2>Seller Access</h2>

@if (Session::has('accessed_seller'))


<a class="nav-link" href="{{route('seller.dashboard')}}">
    <div class="header-intercom">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15.75 10.5L13.5 8.25H8.25C8.05109 8.25 7.86032 8.17098 7.71967 8.03033C7.57902 7.88968 7.5 7.69891 7.5 7.5V3C7.5 2.80109 7.57902 2.61032 7.71967 2.46967C7.86032 2.32902 8.05109 2.25 8.25 2.25H15C15.1989 2.25 15.3897 2.32902 15.5303 2.46967C15.671 2.61032 15.75 2.80109 15.75 3V10.5Z" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            <path d="M10.5 11.25V12.75C10.5 12.9489 10.421 13.1397 10.2803 13.2803C10.1397 13.421 9.94891 13.5 9.75 13.5H4.5L2.25 15.75V8.25C2.25 8.05109 2.32902 7.86032 2.46967 7.71967C2.61032 7.57902 2.80109 7.5 3 7.5H4.5" stroke="#6A3CE2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        <div class="header-intercom-text"> {{ trans('product.seller_bashboard')}} </div>
    </div>
</a>



<form action="{{ route('user.seller-logout') }}" method="POST">
    @csrf
    <button type="submit" class="btn btn-danger mt-3">{{ trans('product.logout')}}</button>
</form>
@else
<form action="{{ route('user.seller-access.post') }}" method="POST">
    @csrf
    <div class="form-group">
        <label for="role">Seller User:</label>
        <select class="form-control" id="role" name="seller_id">
            <option value="{{ $tempUser->id }}">{{ $tempUser->username }}</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary"> {{ trans('product.login _as_seller')}</button>
</form>
@endif

@endsection
