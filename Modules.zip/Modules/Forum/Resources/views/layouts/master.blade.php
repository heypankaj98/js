
<!doctype html>
<html lang="en" @if(session()->has('theme'))  data-bs-theme="{{ Session::get('theme') }}" @endif>
    <head> 
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <link rel="icon" type="image/x-icon" href="{{ asset('fev.ico') }}">
        <title>{{ trans('panel.site_title') }}</title>
        <link href="{{ asset('css/bootstrap-5.3/css/bootstrap.css') }}" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
        <link href="{{ asset('css/kk.css') }}" rel="stylesheet">
        <link href="{{ asset('css/main.css') }}" rel="stylesheet">
        

    </head>
    <body>

        <header>
            @include('partials.forumheader')
            
        </header>

        <div class="container-fluid">
            <div class="row">
                <main class="col-md-12 p-5 col-lg-12 px-md-4 category_main_part">
                    @yield("content")
                </main>
            </div>
        </div>
          @include('layouts.pagefooter')
    </body>
</html>
