<?php

namespace App\Logging;

use Illuminate\Contracts\Logging\Log;

use Illuminate\Support\Facades\DB;

class DatabaseLogger implements Log
{
    /**
     * Write a message to the log.
     *
     * @param  string  $level
     * @param  string  $message
     * @param  array  $context
     * @return void
     */
    public function log($level, $message, array $context = [])
    {
        DB::table('logs')->insert([
            'level' => $level,
            'message' => $message,
            'context' => json_encode($context),
            'created_at' => now(),
        ]);
    }

    /**
     * Log an emergency message to the logs.
     *
     * @param  string  $message
     * @param  array  $context
     * @return void
     */
    public function emergency($message, array $context = [])
    {
        $this->log('stack', $message, $context);
    }

    // ... implement the other Log methods as needed
}
