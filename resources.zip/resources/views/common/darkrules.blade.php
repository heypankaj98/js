@extends('layouts.homeapp')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace Rules</title>
    <style>
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background: #1a1a1a;
    margin: 10px 0;
    padding: 10px;
    border-radius: 4px;
        }
        h1 {
            background-color: #ff7d00;
            text-align: center;
            font-size: 28px;
            padding:12px 8px;
            border-radius:4px;
            font-weight:600;
        }
    </style>
</head>
<body>
    <div class="mt-4">
    <h1 class="custom-title my-4">Marketplace Rules</h1>
    <div class="bg-card-1 p-24 mt-4 br1">
        
        <ul>
            <li>No spam or self-promotion in the marketplace.</li>
            <li>All items must be listed with accurate descriptions.</li>
            <li>Sellers must ship items within 3 days of receiving payment.</li>
            <li>Buyers must pay for items within 48 hours of purchase.</li>
            <li>No counterfeit or illegal items allowed.</li>
            <li>All communication should remain within the marketplace messaging system.</li>
            <li>Respect other members and their listings.</li>
            <li>No duplicate listings of the same item.</li>
            <li>All transactions should be conducted through the marketplace platform.</li>
            <li>Report any suspicious activity to the marketplace support team.</li>
        </ul>
    </div>
    </div>
    
</body>
</html>
@endsection
