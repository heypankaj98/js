<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Dark Allay</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
        rel="stylesheet">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background-color: #000;
            display: flex;
            overflow-x: hidden;
            font-family: 'Inter', sans-serif;
            margin: 0px;
        }

        .buttons {
            margin-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            gap: 0px;
            font-size: 16px;
        }
        p.karyx_word.fw-semibold.text-center{font-size:14px;}
        .btn {
            height: 42px;
            padding: 8px 16px;
            font-size: 16px;
            text-align: center;
            border: 1px solid #ff7d00;
            font-weight: 600;
            display: inline-block;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all .4s cubic-bezier(0.19, 1, 0.22, 1);
            color: #000;
            display: grid;
            place-items: center;
        }

        .btn.register {
            background-color: #ff7d00;
            border: 1px solid #ff7d00;
        }
        .btn.register:hover{
            background-color: #cc6403;
        }
        .btn.outline {
            background-color: transparent;
            border: 1px solid #ff7d00;
            color: #ff7d00;
            padding: 0;
            font-size: 14px;
        }
        .btn.outline:hover{
            background-color: #ff7d00;
            color: #000;
        }

        .form-card {
            background-color: rgba(255,255,255,.1);
            border-radius: 8px;
            padding: 20px;
        }

        .timer-button {
            /* Initial "disabled" appearance */
            pointer-events: none;
            opacity: 0.5;
            cursor: not-allowed;
            transition: opacity 0.5s, cursor 0.5s;
            animation: enableButton 210s forwards;
        }

        @keyframes enableButton {
            100% {
                opacity: 1;
                cursor: pointer;
                pointer-events: auto;
            }
        }

        .card-body-mgg {
            border: 1px solid #ff0000;
            padding: 15px;
            margin-top: -4px;
            border-radius: 8px;
        }

        .alert.alert-danger {
            color: white;
        }

        button.registratin-bt {
            font-size: 16px;
            background-color: #FF7D00;
            BORDER: 1px solid #ff7d00;
            color: white;
            font-weight: 600;
        }
                  
        .expire {

            border: 1px solid #ff0000;
            position: relative;
            animation: timer-warning 1s 1;
            animation-fill-mode: forwards;
            animation-delay: 50s;
            border-radius: 4px;
        }

        button.expired {
            display: none;
        }

        .expire>.timer {
            position: relative;
            overflow: hidden;
            height: 42px;
            display: flex;
            align-items: center;
            line-height: 42px;
            padding: 4px 12px;
            border-radius: 4px;
        }

        .expire>.timer>.time-part-wrapper {
            display: inline-block;
            height: 42px;
            color: #d8d8d8;
        }

        .expire>.timer>.time-part-wrapper:first-child:after {
            content: ':';
            display: inline-block;
            width: 15px;
            height: 42px;
            text-align: center;
            font-size: 22px;
        }

        .expire>.timer>.time-part-wrapper>.time-part {
            display: inline-block;
            vertical-align: top;
            width: 15px;
            position: relative;
            animation: timer-expire;
            animation-fill-mode: forwards;
            animation-delay: 60s;
        }

        .expire>.timer>.time-part-wrapper>.time-part>.digit-wrapper {
            position: absolute;
            top: 0;
            left: 0;
            width: 15px;
            text-align: center;
        }

        .expire>.timer>.time-part-wrapper>.time-part>.digit-wrapper>.digit {
            display: block;
            width: 100%;
            text-align: center;
            height: 50px;
            line-height: 50px;
            font-size: 18px;
            color: #f9ff00;
        }

        .expire>.timer>.time-part-wrapper>.time-part.seconds.tens>.digit-wrapper {
            top: -50px;
            animation: timer-seconds-tens 50s 1;
            animation-fill-mode: forwards;
            animation-delay: 1s;
        }

        .expire>.timer>.time-part-wrapper>.time-part.seconds.ones>.digit-wrapper {
            animation: timer-seconds-ones 10s 6;
        }

        .expire>.timer>.time-part-wrapper>.time-part.hundredths.tens>.digit-wrapper {
            animation: timer-seconds-ones 1s 60;
        }

        .expire>.timer>.time-part-wrapper>.time-part.hundredths.ones>.digit-wrapper {
            animation: timer-seconds-ones 500ms 120;
        }

        .expire:after {
            content: '';
            display: block;
            clear: both;
        }

        .expire:after+.expired {
            display: block;
        }

        @-webkit-keyframes timer-seconds-tens {
            0% {
                top: -50px;
            }

            19% {
                top: -50px;
            }

            20% {
                top: -100px;
            }

            39% {
                top: -100px;
            }

            40% {
                top: -150px;
            }

            59% {
                top: -150px;
            }

            60% {
                top: -200px;
            }

            79% {
                top: -200px;
            }

            80% {
                top: -250px;
            }

            99% {
                top: -250px;
            }

            100% {
                top: -300px;
            }
        }

        @-webkit-keyframes timer-seconds-ones {
            0% {
                top: 0;
            }

            9% {
                top: 0;
            }

            10% {
                top: -50px;
            }

            19% {
                top: -50px;
            }

            20% {
                top: -100px;
            }

            29% {
                top: -100px;
            }

            30% {
                top: -150px;
            }

            39% {
                top: -150px;
            }

            40% {
                top: -200px;
            }

            49% {
                top: -200px;
            }

            50% {
                top: -250px;
            }

            59% {
                top: -250px;
            }

            60% {
                top: -300px;
            }

            69% {
                top: -300px;
            }

            70% {
                top: -350px;
            }

            79% {
                top: -350px;
            }

            80% {
                top: -400px;
            }

            89% {
                top: -400px;
            }

            90% {
                top: -450px;
            }

            99% {
                top: -450px;
            }

            100% {
                top: -500px;
            }
        }

        @-webkit-keyframes timer-warning {
            from {
                color: #d8d8d8;
            }

            to {
                color: #E7943C;
            }
        }

        @-webkit-keyframes timer-expire {
            from {
                color: #000;
            }

            to {
                color: #e7643c;
            }
        }

        @-webkit-keyframes button-expired {
            from {
                visibility: hidden;
            }

            to {
                visibility: visible;
            }
        }

        @-webkit-keyframes button-before {
            from {
                visibility: visible;
            }

            to {
                visibility: hidden;
            }
        }

        .center {
            text-align: center;
        }

        form.ddos_form button.before {
            animation: button-before;
            animation-fill-mode: forwards;
            animation-delay: 60s;
        }

        form.ddos_form button.expired {
            visibility: hidden;
            background: #E74C3C;
            animation: button-expired;
            animation-fill-mode: forwards;
            animation-delay: 60s;
            margin-top: -40px;
        }

        a.registratin-bt1 {
            text-decoration: none;
            color: white;
            font-size: 17px;
            font-weight: 600;
        }

        .low-down-timer {
            width: 100%;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 0px;
            flex-direction: column;
        }

        .lower_btn {
            font-size: 16px;
            background-color: #FF7D00;
            BORDER: 1px solid #ff7d00;
            border-radius: 7PX;
            color: white;
            font-weight: bolder;
            width: 212px;
            text-align: center;
            margin-left: 173px;
            padding: 12px 0px;

        }

        h5.protect32 {
            text-align: center;
            color: #ff0000;
            font-size: 14px;
        }

        .form-control {
            border: 1px solid #ff0000;
            border-radius: 4px;
        }

        .form-group .form-control {
            width: 100%;
            height: 42px;
            padding: 12px;
            background: black;
            color: #fff;
        }

        .form-group .form-control:focus-within {
            outline: 1px solid #ff0000;
        }

        .form-group label {
            color: white;
            margin-bottom: 8px !important;
            font-weight: 600;
            display: inline-block;
            font-size: 14px;
        }


        .color-org {
            color: #ff7d00;
        }

        input#confirm-password {
            width: 100%;
        }

        .futt {
            display: none;
        }

        .form-control.captch_sapce_control.border_radiusnone {
            width: 250px;
            height: 60px;
            padding: 0;
            overflow: hidden;
            border: 1px solid #ff0000;
        }

        .form-control.captch_sapce_control.border_radiusnone img {
            width: 100%;
            height: 100%;
        }

        img.img-45 {
            margin-top: 0;
            padding: 0px 16px;
            width: 150px;
            border-left: 1px solid #ff0000;
            border-right: 1px solid #ff0000;
            padding-bottom: 30px;
            padding-top: 30px;
        }

        img.imgda {
            padding-bottom: 15px;
            width: 180px !important;
            border: 1px solid #ff0000;
            margin-top: -1px;
            padding-left: 15px;
            padding-right: 15px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 16px;
        }


        .gold_star {
            color: #ff0000;
        }

        .ffirst11 {
                height: 1px;
    background: red;
    width: 100%;
    position: absolute;
    top: 380px;
        }

        .ffirst1 {
    height: 1px;
    background: red;
    width: 100%;
    position: absolute;
    top: 415px;
        }
.second-in1 {
    position: relative;
    z-index:2;
    max-width: 400px;
    width: 100%;
    margin: 0 auto;
    background: #000;
}



        p.protect-para04 {
            width: 100% !important;
            padding-left: 0px !important;
            text-align: center;
        }

        p.protect-para03 {
            color: white;
            width: max-content;
            font-size: 14px;
        }

        .container.reg {
            width: 100% !important;
        }

        .imgg-logo32 {
            text-align: center;
        }


        .password_ {
            display: flex;
        }

        .z-09 {
            width: 91px;
            font-weight: 800;
        }

        .col-md-5.m-auto {
            text-align: center;
            margin-top: 32PX;
        }

        h5.protect32 {
            height: 0px;
            text-align: center;
            color: #ff202c;
            font-size: 16px;
        }


        .karyx_text.lower_btn2 {
            color: white;
            text-align: center;
            font-weight: 800;
        }

        .pin-with {
            width: 143px;
        }

        .mb-captcha {
            display: grid !important;


}
 @media (max-width:480px){
        .second-in1{max-width:90%; width:100%}
    }
            #countdown {
                font-size: 10px;
                text-align: center;
                margin-top: 50px;
                color: #fff;
                animation: countdown 60s steps(60, end) infinite;
            }

            @keyframes fadeOutForm {
                0% {
                    opacity: 1;
                }

                100% {
                    opacity: 0.5;
                    pointer-events: none;
                }
            }

            #registrationForm {
                animation: fadeOutForm 1s forwards;
                animation-delay: 60s;
                /* Delay of one minute */
            }
            
  
    </style>
</head>

<body>
    <div class="container reg">
        <div class="ffirst11">
            
        </div>
        <div class="second-in1">
            <div class="imgg-logo32">
                <img class="img-45" src="{{ asset('assets/Dark_Alley_Logo.png')}}">
            </div>
            <div class="row">
                <div class="card_main_part register-card pt-3 pb-3 reddd">

                    <div class="card border_none">
                        <div class="card-body-mgg ">
                            <!--<h6 class="card-subtitle mb-3 fw-bold">{{ trans('auth.register') }}</h6>-->
                            @if(Session::has('error'))
                            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}
                            </p>
                            @endif
                            <form id="registrationForm" method="POST" action="{{ route('register.perform') }}"
                                class="form-card">
                                @csrf

                                <div class="form-group mb-2">
                                    <div class="username">
                                        <label for="username"
                                            class="pb-2 fw-bold label_main">{{ trans('auth.username') }} <span
                                                class="gold_star">{{ trans('auth.user_star') }} </span></label></div>
                                    <div class="username1">
                                        <input id="username" type="text"
                                            class="form-control fw-bold border_radiusnone @error('username') is-invalid @enderror"
                                            placeholder="Enter your username (case sensitive)" name="username"
                                            value="{{ old('username') }}" required autocomplete="username"></div>
                                </div>
                                @error('username')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                                @enderror

                                <div class="form-group mb-2">
                                    <div class="password_">
                                        <label for="password"
                                            class="pb-2 fw-bold label_main">{{ trans('auth.password') }} <span
                                                class="gold_star">{{ trans('auth.user_star') }} </sapn></label></div>
                                    <div class="password_1">
                                        <input id="password" type="password"
                                            class="form-control  border_radiusnone @error('password') is-invalid @enderror"
                                            name="password" placeholder="Enter your password(min 8 characters)" required
                                            autocomplete="new-password"></div>
                                </div>
                                @error('password')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                                @enderror
                                <div class="form-group mb-2">
                                    <div class="password_">
                                        <label for="confirm-password"
                                            class="pb-2 fw-bold label_main">{{ trans('auth.confirm_user_password') }}
                                            <span class="gold_star">{{ trans('auth.user_star') }} </span></label></div>
                                    <div class="password_1">
                                        <input type="password" class="form-control border_radiusnone1 fw-bold1"
                                            id="confirm-password" name="password_confirmation"
                                            placeholder="Confirm your password" required=""></div>
                                </div>
                                @error('password_confirmation')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                                @enderror
                                <div class="form-group mb-2">
                                    <label for="withdrawal-pin" class="withdrawal">Withdrawal PIN:<span
                                            class="gold_star">{{ trans('auth.user_star') }} </span></label>
                                    <input class="form-control" type="password" id="withdrawal-pin"
                                        name="withdrawal_pin" required minlength="4" maxlength="6"
                                        placeholder="Enter your 6 digit withdrawal PIN">
                                </div>

                                <div class="form-group mb-2">
                                    <label for="confirm-withdrawal-pin" class="withdrawal pin-with">Confirm Withdrawal
                                        PIN:<span class="gold_star">{{ trans('auth.user_star') }} </span></label>
                                    <input class="form-control" type="password" id="confirm-withdrawal-pin"
                                        name="confirm_withdrawal_pin" required minlength="4" maxlength="6"
                                        placeholder="Confirm your withdrawal PIN">
                                </div>

                                <div class="form-group mb-2">
                                    <label for="anti-phishing-phrase" class="withdrawal pin-with">Anti-Phishing
                                        Phrase:<span class="gold_star">{{ trans('auth.user_star') }} </span></label>
                                    <input class="form-control" type="text" id="anti-phishing-phrase"
                                        name="anti_phishing" required placeholder="Enter your APP(min 4 characters)">
                                </div>
                                <!--<div class="form-group mb-2">-->
                                <!--    <label for="reference_code" class="pb-2  fw-bold z-09">{{ trans('auth.referral') }}</label>-->
                                <!--     <div class="password_1">-->
                                <!--    <input id="reference_code" type="text" class="form-control border_radiusnone @error('reference_code') is-invalid @enderror" name="reference_code" value="{{ old('referral_code', app('request')->input('referral_code')) }}"  autocomplete="reference_code"></div>-->
                                <!--</div>-->
                                @error('reference_code')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                                @enderror
                                <div class="form-group mb-2 mb-captcha">
                                    <label for="password" class="pb-2 fw-bold label_main">Captcha<span
                                            class="gold_star">{{ trans('auth.user_star') }} </sapn> </label>

                                    <div class="form-control captch_sapce_control border_radiusnone capcha-mb-img">
                                         <img src="{{ captcha_src('inverse') }}" id="captchaImage" alt="CAPTCHA">
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="password" class="pb-2 fw-bold label_main">{{ trans('auth.captcha') }} (case sensitive)
                                        <span class="gold_star">{{ trans('auth.user_star') }} </sapn></label>
                                    <div class="password_1">
                                        <input name="captcha" id="password_11" type="text"
                                            class="form-control border_radiusnone {{ $errors->has('captcha') ? ' is-invalid' : '' }}"
                                            required placeholder="{{ trans('auth.captcha') }} "></div>
                                </div>
                                @error('captcha')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div>
                                @enderror

                                <h5 class="protect32">BOT Protection</h5>
                                <div class="low-down-timer">
                                    <p class="protect-para03"> Please wait </p>
                                    <div class="expire">
                                        <div class="timer">
                                            <div class="time-part-wrapper">
                                                <div class="time-part seconds tens">
                                                    <div class="digit-wrapper">
                                                        <span class="digit">0</span>
                                                        <span class="digit">5</span>
                                                        <span class="digit">4</span>
                                                        <span class="digit">3</span>
                                                        <span class="digit">2</span>
                                                        <span class="digit">1</span>
                                                        <span class="digit">0</span>
                                                    </div>
                                                </div>
                                                <div class="time-part seconds ones">
                                                    <div class="digit-wrapper">
                                                        <span class="digit">0</span>
                                                        <span class="digit">9</span>
                                                        <span class="digit">8</span>
                                                        <span class="digit">7</span>
                                                        <span class="digit">6</span>
                                                        <span class="digit">5</span>
                                                        <span class="digit">4</span>
                                                        <span class="digit">3</span>
                                                        <span class="digit">2</span>
                                                        <span class="digit">1</span>
                                                        <span class="digit">0</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="time-part-wrapper">
                                                <div class="time-part hundredths tens">
                                                    <div class="digit-wrapper">
                                                        <span class="digit">0</span>
                                                        <span class="digit">9</span>
                                                        <span class="digit">8</span>
                                                        <span class="digit">7</span>
                                                        <span class="digit">6</span>
                                                        <span class="digit">5</span>
                                                        <span class="digit">4</span>
                                                        <span class="digit">3</span>
                                                        <span class="digit">2</span>
                                                        <span class="digit">1</span>
                                                        <span class="digit">0</span>
                                                    </div>
                                                </div>
                                                <div class="time-part hundredths ones">
                                                    <div class="digit-wrapper">
                                                        <span class="digit">0</span>
                                                        <span class="digit">9</span>
                                                        <span class="digit">8</span>
                                                        <span class="digit">7</span>
                                                        <span class="digit">6</span>
                                                        <span class="digit">5</span>
                                                        <span class="digit">4</span>
                                                        <span class="digit">3</span>
                                                        <span class="digit">2</span>
                                                        <span class="digit">1</span>
                                                        <span class="digit">0</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <button class="expired" type="submit"> Refresh (expired)</button>

                                    </div>
                                    <p class="protect-para03 protect-para04 "> seconds to complete your registration.
                                    </p>
                                </div>
                                <!--<p class="privacy_notice fw-semibold">-->
                                <!--    <input type="checkbox" checked>-->
                                <!-- {{ trans('auth.Privacy_Notice_text') }} <br> <a href="{{ route('tnc') }}" class="text-decoration-underline">{{ trans('auth.Conditions_of_Use') }}</a>-->
                                <!--   {{ trans('auth.text_and') }}-->
                                <!--    <a href="{{ route('privacy') }}" class="text-decoration-underline"> {{ trans('auth.Privacy_Notice') }}</a>.-->
                                <!--</p>-->

                                <div class="buttons">
                                    <button id="delayedButton" type="submit"
                                        class="timer-button registratin-bt btn register">Register Now</button>
                                    <div class="karyx_text lower_btn2">
                                        <p class=" karyx_word fw-semibold text-center">
                                            {{ trans('auth.already_user') }}
                                        </p>
                                    </div>
                                    <a href="{{ route('login') }}"
                                        class="btn outline">
                                        {{ trans('auth.login_account') }}
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
        </div>

        <div class="ffirst1">
          
        </div>
    </div>
    </div>
</body>

</html>