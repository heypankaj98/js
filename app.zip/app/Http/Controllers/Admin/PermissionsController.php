<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyPermissionRequest;
use App\Http\Requests\Admin\StorePermissionRequest;
use App\Http\Requests\UpdatePermissionRequest;
use App\Models\Permission;
use App\Models\Settings;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PermissionsController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('admin_permission_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $permissions = Permission::all();

        return view('admin.permissions.index', compact('permissions'));
    }

    public function create()
    {
        abort_if(Gate::denies('admin_permission_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.permissions.create');
    }

    public function store(StorePermissionRequest $request)
    {
        $permission = Permission::create($request->all());

        return redirect()->route('admin.permissions.index');
    }

    public function edit(Permission $permission)
    {
        abort_if(Gate::denies('admin_permission_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.permissions.edit', compact('permission'));
    }

    public function update(UpdatePermissionRequest $request, Permission $permission)
    {
        $permission->update($request->all());

        return redirect()->route('admin.permissions.index');
    }

    public function show(Permission $permission)
    {
        abort_if(Gate::denies('admin_permission_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.permissions.show', compact('permission'));
    }
public function comission()
{
    // Check if the admin has the required permissions
    abort_if(Gate::denies('admin_permission_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    // Retrieve all relevant commission settings, including commission per product sale
    $commission = Settings::whereIn('key', [
        'ads_impression', 
        'ads_click', 
        'market_fee', 
        'featured_product', 
        'become_seller_fee',
        'product_sale_commission' 
    ])->pluck('value', 'key');

    // Convert the product_sale_commission to percentage format (if necessary)
    if (isset($commission['product_sale_commission'])) {
        $commission['product_sale_commission'] = $commission['product_sale_commission'] . '%'; // Add percentage sign
    }

    return view('admin.comission', compact('commission'));
}


public function comissionStore(Request $request)
{
    $request->validate([
        'ads_commission_imp' => 'numeric',
        'ads_commission_click' => 'numeric',
        'order_commission' => 'numeric',
        'featured_product_commission' => 'numeric',
        'become_seller_fee' => 'numeric',
        'product_sale_commission' => 'numeric',
    ]);

    $settings = [
        'ads_impression' => $request->ads_commission_imp,
        'ads_click' => $request->ads_commission_click,
        'market_fee' => $request->order_commission,
        'featured_product' => $request->featured_product_commission,
        'become_seller_fee' => $request->become_seller_fee,
        'product_sale_commission' => $request->product_sale_commission,
    ];

    foreach ($settings as $key => $value) {
        Settings::updateOrCreate(
            ['key' => $key], // Match based on the key column
            ['value' => $value] // Update the value column
        );
    }

    return redirect()->back()->with('success', 'Commissions saved successfully!');
}

    public function destroy(Permission $permission)
    {
        abort_if(Gate::denies('admin_permission_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $permission->delete();

        return back();
    }

    public function massDestroy(MassDestroyPermissionRequest $request)
    {
        $permissions = Permission::find(request('ids'));

        foreach ($permissions as $permission) {
            $permission->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}