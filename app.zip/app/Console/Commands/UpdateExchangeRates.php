<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Currency;
use Exception;

class UpdateExchangeRates extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:update-exchange-rates';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update exchange rates from external API';

    /**
     * Execute the console command.
     */
    public function handle(): void {
        $this->updateCurrencyRates();
        $this->updateMoneroRate();
    }

    private function updateCurrencyRates(): void {
        $apiUrl = "https://api.apilayer.com/exchangerates_data/latest?base=USD";
        $apiKey = "NSeIgUl1cA8VoeLvQlMK4dkZsmemUgwE";

        try {
            // Initialize CURL
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => $apiUrl,
                CURLOPT_HTTPHEADER => [
                    "Content-Type: text/plain",
                    "apikey: $apiKey"
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,  // Set a timeout of 30 seconds
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET"
            ]);

            // Execute the CURL request
            $response = curl_exec($curl);
            $httpStatusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);

            // Check if the response is false due to a CURL error
            if ($response === false) {
                throw new Exception('Error fetching exchange rates. Please check your network connection or API key.');
            }

            // Decode the response data
            $data = json_decode($response, true);

            // Check if the data contains the expected 'rates' field
            if (!isset($data['rates'])) {
                throw new Exception('Invalid response structure from the API.');
            }

            $rates = $data['rates'];
            $baseCurrency = $data['base'];

            foreach ($rates as $currency => $rate) {
                Currency::updateOrInsert(
                    ['currency' => $currency],
                    [
                        'rate' => $rate,
                        'updated_at' => now(),
                        'created_at' => now() // Only applied if inserting a new record
                    ]
                );
            }

            $this->info('Currency exchange rates update completed successfully.');

        } catch (Exception $e) {
            // Log the exception and display an error message
            \Log::error('Failed to update currency exchange rates: ' . $e->getMessage());
            $this->error('Failed to update currency exchange rates: ' . $e->getMessage());
        }
    }

    private function updateMoneroRate(): void {
        $apiUrl = "https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=USD";

        try {
            // Initialize CURL
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => $apiUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,  // Set a timeout of 30 seconds
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET"
            ]);

            // Execute the CURL request
            $response = curl_exec($curl);
            $httpStatusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);

            // Check if the response is false due to a CURL error
            if ($response === false) {
                throw new Exception('Error fetching Monero rate.

Please check your network connection.');
            }

            // Decode the response data
            $data = json_decode($response, true);

            // Check if the data contains the expected 'USD' field
            if (!isset($data['USD'])) {
                throw new Exception('Invalid response structure from the Monero API.');
            }

           $moneroRate = $data['USD'];
        
        // Calculate the price per USD (USD to Monero rate)
        $usdPrice = 1 / $moneroRate;

            Currency::updateOrInsert(
                ['currency' => 'XMR'],
                [
                    'rate' => $usdPrice,
                    'updated_at' => now(),
                    'created_at' => now() // Only applied if inserting a new record
                ]
            );

            $this->info('Monero exchange rate update completed successfully.');

        } catch (Exception $e) {
            // Log the exception and display an error message
            \Log::error('Failed to update Monero exchange rate: ' . $e->getMessage());
            $this->error('Failed to update Monero exchange rate: ' . $e->getMessage());
        }
    }
}
