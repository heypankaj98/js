<?php
namespace App\Models;
use Hash;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;
use App\Models\Referrals;
use Modules\Forum\Models\Category as ForumCategory;

class User extends Authenticatable {
    use HasApiTokens,
        SoftDeletes,
        HasFactory,
        Notifiable;

    protected $fillable = [
        'name',
        'username',
        'password',
        'deleted_at',
        'withdrawal_pin',
        'anti_phishing',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function isSeller(): bool {
        return $this->seller == true ? true : false;
    }

    public function isAdmin(): bool {
        return $this->admin == true ? true : false;
    }

    public function isModerator(): bool {
        return $this->moderator == true ? true : false;
    }

    public function getIsAdminAttribute() {
        return $this->roles()->where('id', 1)->exists();
    }

    public function userUserAlerts() {
        return $this->belongsToMany(UserAlert::class);
    }

    public function setPasswordAttribute($input) {
        if ($input) {
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
        }
    }
    
    
    public function sendPasswordResetNotification($token) {
        $this->notify(new ResetPassword($token));
    }

    public function roles() {
        return $this->belongsToMany(Role::class);
    }

    public function inRole(string $roleSlug) {
        return $this->roles()->where('title', $roleSlug)->count() == 1;
    }

    public function getInRole(string $roleSlug) {
        return $this->roles()->where('title', $roleSlug)->exists();
    }

    public function sellerOrders() {
    return $this->hasMany(Order::class, 'seller_id', 'id')
                        ->get();
    }

    public function totalOrders($status) {
     
        return $this->sellerOrders()->where('status', $status)->count();
        
    }

    public function products() {
        return $this->hasMany(Product::class, 'seller_id', 'id');
    }

    public function tickets() {
        return $this->hasMany(Ticket::class, 'user_id');
    }

    public function chatMessages() {
        return $this->hasMany(QaTopic::class, 'creator_id')
                        ->orWhere('receiver_id', $this->id);
    }

    public function withChatMessages($id) {
        $a = \App\Models\QaTopic::where('creator_id', $id)->where('receiver_id', Auth::id())->count();
        $b = \App\Models\QaTopic::where('creator_id', Auth::id())->where('receiver_id', $id)->count();
        //  = $this->hasMany(QaTopic::class, 'creator_id',$id)
        //        ->Where('receiver_id', $this->id);
        // $b = $this->hasMany(QaTopic::class, 'creator_id',$this->id)
        //        ->Where('receiver_id', $id);
        return $a + $b;
    }

    public function scopeAdmin($query) {   // $adminUsers = User::admin()->get();
        return $query->whereHas('roles', function ($query) {
                    $query->where('title', 'Admin');
                });
    }

    public function scopeSeller($query) {   // $sellerUsers = User::seller()->get();
        return $query->whereHas('roles', function ($query) {
                    $query->where('title', 'Seller');
                });
    }

    public function scopeModerator($query) {  //$moderatorUsers = User::moderator()->get();
        return $query->whereHas('roles', function ($query) {
                    $query->where('title', 'Moderator');
                });
    }

    public function scopeDedicatedAccessUsers($query) {
        return $query->whereHas('userMeta', function ($subquery) {
                    $subquery->where('key', 'seller_staff')
                    ->whereJsonContains('value', [auth()->user()->id]);
                });
    }

    public function getMetaValue($key) {
        $meta = $this->userMeta()->where('key', $key)->first();
        return $meta ? $meta->value : null;
    }

    public function userMeta() {
        return $this->hasMany(UserMeta::class);
    }

    public function getAttribute($key) {
        if (strpos($key, 'meta_') === 0) {
            $metaKey = substr($key, 5);
            return $this->getMetaValue($metaKey);
        }

        return parent::getAttribute($key);
    }

    public function earnedReferralPoints() {
        return Referrals::where('user_id', $this->id)->sum('earned');
    }

    public function payouts() {
        return $this->hasMany(Payout::class);
    }
    
    public function forumCategories() {
    return $this->hasMany(ForumCategory::class);
    }
}