@extends('layouts.seller.app')  @section('content')

<div class="bg-card-1 p-24 mt-4 br1">
    <div class="">
        <div class="card-header-2 w-100 mb-4">
            {{ trans('common.create') }} {{ trans('common.shipping') }} {{ trans('common.methods') }}
        </div>
        <form action="{{ route('seller.shipping-methods.store') }}" method="POST">
            @csrf
            <div class="form-group mt-3">
                <label for="name">{{ trans('common.name') }}:</label>
                <input type="text" name="name" class="form-control mt-2 @error('name') is-invalid @enderror" value="{{ old('name') }}" required>
                @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="form-group mt-3">
     <div class="form-check">
        <input type="radio" name="is_free" id="is_free_yes" class="form-check-input" value="1" {{ old('is_free') == '1' ? 'checked' : '' }}>
        <label for="is_free_yes" class="form-check-label">Free</label>
    </div>
    <div class="form-check">
        <input type="radio" name="is_free" id="is_free_no" class="form-check-input" value="0" {{ old('is_free') == '0' ? 'checked' : '' }}>
        <label for="is_free_no" class="form-check-label">Paid</label>
    </div>
                @error('is_free')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
                <div class="form-group mt-3">
                    <label for="price">{{ trans('common.price') }}:</label>
                    <input type="number" name="price" class="form-control mt-2 @error('price') is-invalid @enderror" value="{{ old('price') }}" min="0" step="0.01">
                    @error('price')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="form-group mt-3">
                <label for="delivery_time">{{ trans('common.delivery') }} {{ trans('common.time') }} [{{ trans('common.days') }}]:</label>
                <input type="number" name="delivery_time" id="delivery_time" class="form-control mt-2 @error('delivery_time') is-invalid @enderror" value="{{ old('delivery_time') }}" min="0" required>
                @error('delivery_time')
                <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group mt-3">
                <label for="availability">{{ trans('common.active') }}:</label>
                <select name="availability" id="availability" class="form-control py-0 mt-2">
                    <option value="worldwide">{{ trans('common.worldwide') }}</option>
                    <option value="except">{{ trans('common.except') }}</option>
                    <option value="limited">{{ trans('common.limited') }}</option>
                </select>
            </div>

            <div class="form-group mt-3">
                <label for="available_countries">{{ trans('common.countries') }}:</label>
                <select name="countries[]" id="countries" class="form-control form-control-textarea" multiple>
                    @foreach ($countries as $continent => $countriesByContinent)
                        <optgroup label="{{ $continent }}">
                            @foreach ($countriesByContinent as $code => $name)
                                <option value="{{ $code }}">{{ $name }}</option>
                            @endforeach
                        </optgroup>
                    @endforeach
                </select>
                @error('countries')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-main mt-3">{{ trans('common.create') }}</button>
        </form>
    </div>
</div>
@endsection

