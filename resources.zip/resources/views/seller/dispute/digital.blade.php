<div class="container  mt-4">
    <form method="POST" action="{{ route("seller.products.store") }}" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-lg-12">
                <div class="p-24 br1 br-4">
                    <div class="card-header-2 w-100 mb-4">
                        {{ trans('common.add') }} {{ trans('common.digital') }} {{ trans('common.product') }}
                    </div>
                    <div class="card-body">
                        @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                        @endif

                        <div class="row">
                            <div class="col">
                                <label for="product_name" class=" fw-bold label_main">
                                    {{ trans('common.product') }} {{ trans('common.name') }} {{ trans('auth.user_star') }}:
                                </label>
                                <input type="text" class="my-3 form-control" id="product_name" placeholder="{{ trans('common.product') }} {{ trans('common.name') }}" name="name" value="">
                                @error('name')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            <div class="col">
                                <label for="category" class=" fw-bold label_main">
                                    {{ trans('common.category') }}*:
                                </label>
                         
                                 <select class="my-3 form-select" id="Category" aria-label="Default select example" name="category">
                                                @foreach($categories as  $category)
                                                    <?php $dash = ''; ?>
                                                    <option value="{{$category->id}}" @if($category->parent_id  === null) disabled @endif>
                                                        {{ $category->name }}
                                                    </option>
                                                    @if(count($category->subcategory))
                                                        @include('partials.subcategorylist',['subcategories' => $category->subcategory])
                                                    @endif
                                                @endforeach
                                            </select>
                                @error('category')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>    
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                    <label for="description" class=" fw-bold label_main">
                                        {{ trans('common.price') }}*:
                                    </label>
                                    <input type="text" class="my-3 form-control" id="product_name" placeholder="$ 0.00" name="price" value="">
                                    @error('price')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                    @enderror
                                </div>
                            </div>
                            <div class="col">
                                <label for="description" class=" fw-bold label_main">
                                    {{ trans('common.upload') }} {{ trans('common.photo') }}*:
                                </label>
                                <br>
                                <input type="file" class="my-3 form-control" id="inputGroupFile02" name="picture">
                                @error('picture')
                                <div class="alert alert-danger" role="alert">
                                    {{ $message }}
                                </div> 
                                @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3 col-6">
                                <label for="description" class=" fw-bold label_main">
                                    {{ trans('common.product') }} {{ trans('common.description') }}*:
                                </label>
                                <textarea class="my-3 form-control" id="description" rows="5" name="description"></textarea>
                                @error('description')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                @enderror
                            </div>
                            <div class="mb-3 col-6">
                                <label class=" fw-bold label_main">
                                   {{ trans('common.product') }} {{ trans('common.buy') }}/{{ trans('common.return') }} {{ trans('common.policy') }}*:
                                </label>
                                <textarea class="my-3 form-control" id="description" rows="5" name="policy"></textarea>
                                @error('policy')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-3 col-6">
                                <label class=" fw-bold label_main">
                                    {{ trans('common.product') }} {{ trans('common.url') }}*:
                                </label>
                                <textarea class="my-3 form-control" rows="2" name="content"></textarea>
                                @error('content')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            <div class="col-6">
                                <div class="mb-3">
                                    <label class=" fw-bold label_main">{{ trans('common.qty') }}*:</label>
                                    <input type="text" class="my-3 form-control" id="product_name" name="stock" placeholder="0">
                                    @error('stock')
                                    <div class="alert alert-danger" role="alert">
                                        {{ $message }}
                                    </div> 
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="col-3 mt-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="isfeature">
                                <label class="form-check-label" for="flexSwitchCheckChecked">
                                    {{ trans('common.feature') }} {{ trans('common.product') }}
                                </label>
                            </div>
                        </div>
                        <input type="hidden" name="type" value="digital">
                        <button type="submit" class="btn btn-success mt-3">{{ trans('common.create') }} {{ trans('common.product') }}</button>
                    </div>
                </div>
            </div> 
        </div>
    </form>
</div>