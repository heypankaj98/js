<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GiftCard;

class GiftCardController extends Controller {

    /**
     * Display a listing of the resource.
     */
    public function index() {
        $giftCards = GiftCard::latest()->paginate(10);

        return view('admin.gift-cards.index', compact('giftCards'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create() {
        return view('admin.gift-cards.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {
        $request->validate([
            'code' => 'required|unique:gift_cards',
            'amount' => 'required|numeric|min:0',
            'expiration_date' => 'nullable|date_format:Y-m-d\TH:i',
        ]);

        $giftCard = new GiftCard([
            'code' => $request->input('code'),
            'amount' => $request->input('amount'),
            'expiration_date' => $request->input('expiration_date'),
        ]);
        $giftCard->save();

        return redirect()->route('admin.gift-cards.index')
                        ->with('success', 'Gift card created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(GiftCard $giftCard) {
        return view('admin.gift-cards.show', ['giftCard' => $giftCard]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(GiftCard $giftCard) {
        return view('admin.gift-cards.edit', ['giftCard' => $giftCard]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, GiftCard $giftCard) {
        $validatedData = $request->validate([
            'code' => 'required|unique:gift_cards,code,' . $giftCard->id,
            'amount' => 'required|numeric|min:0.01|max:9999.99',
            'expiration_date' => 'nullable|date_format:Y-m-d\TH:i',
            'used' => 'boolean',
        ]);

        $giftCard->update($validatedData);

        return redirect()->route('admin.gift-cards.show', $giftCard->id);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, $id) {
        $giftcard = GiftCard::findOrFail($id);
        $giftcard->delete();

        return redirect()->route('admin.gift-cards.index');
    }

    public function apply(Request $request) {
        $giftCard = GiftCard::where('code', $request->input('gift_card_code'))->first();
        if (!$giftCard) {
            return back()->withErrors(['gift_card_code' => 'Invalid gift card code']);
        }

        // check if the gift card is expired
        if ($giftCard->expiration_date && $giftCard->expiration_date->isPast()) {
            return back()->withErrors(['gift_card_code' => 'This gift card has expired']);
        }

        // apply the gift card value to the order/cart total
        // you can use the Cart or Order model in your application to implement this logic

        return redirect()->route('checkout.index')->with('success', 'Gift card applied successfully');
    }

    public function applyGiftCard(Request $request) {
        $request->validate([
            'gift_card_code' => 'required|exists:gift_cards,code|not_in:used',
        ]);

        // Apply the gift card discount to the cart or order
        // ...
    }

    public function createGiftCard(Request $request) {
        $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'quantity' => 'required|integer|min:1|max:100',
        ]);

        $giftCards = collect();
        for ($i = 0; $i < $request->quantity; $i++) {
            $giftCards->push(GiftCard::create([
                        'code' => strtoupper(Str::random(10)),
                        'amount' => $request->amount,
            ]));
        }

        return view('admin.gift-cards.index', [
            'giftCards' => $giftCards,
            'message' => __(':count gift card(s) created successfully.', ['count' => $giftCards->count()]),
        ]);
    }

}
