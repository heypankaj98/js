<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SellerMarketplace extends Model
{
    use HasFactory;

    protected $fillable = [
        'market_placename',
        'seller_name',
        'sales',
        'rating',
        'product_category',
        'user_id',
    ];
}
