<?php
namespace App\Http\Requests\Seller;

use App\Models\Product;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreProductRequest extends FormRequest {
    protected $stopOnFirstFailure = true;

    public function authorize() {
        return Gate::allows('seller_manage_products');
    }

    public function rules() {
        return [
            'name' => ['bail', 'required', 'string', 'min:5', 'max:150'],
            'type' => ['bail', 'required', 'string', 'max:10'],
            'description' => ['bail', 'required', 'string', 'min:50', 'max:7000'],
            'price' => ['bail', 'required', 'gt:0'],
            'category' => ['bail', 'required', 'integer',],
            'picture' => ['bail', 'required', 'image', 'mimes:jpeg,jpg,png,webp']
        ];
    }
}