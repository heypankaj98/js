<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http; 
use App\Models\CryptoExchange;

class UpdateCoinRates extends Command
{
    protected $signature = 'coins:update-rates';
    protected $description = 'Fetch and update coin rates from an API';

    protected $coins = [
        'monero' => 'monero',
        'bitcoin' => 'bitcoin',
    ];

    /**
     * Execute the console command.
     */
    public function handle()
    {
        foreach ($this->coins as $coinName => $coinSymbol) {
            $this->updateRatesForCoin($coinName, $coinSymbol);
        }

        $this->info('Coin rates updated successfully.');
    }

    /**
     * Update rates for a specific coin.
     *
     * @param string $coinName
     * @param string $coinSymbol
     * @return void
     */
    protected function updateRatesForCoin(string $coinName, string $coinSymbol)
    {
        $response = Http::get('https://api.coingecko.com/api/v3/simple/price', [
            'ids' => $coinName,
            'vs_currencies' => 'usd,eur,gbp',
        ]);
        // dd($response);

        if ($response->successful()) {
            $data = $response->json();

            if (isset($data[$coinName])) {
                foreach ($data[$coinName] as $currency => $rate) {
                    CryptoExchange::updateOrCreate(
                        [
                            'coin_symbol' => $coinSymbol,
                            'currency_symbol' => $currency,
                        ],
                        [
                            'rate' => $rate,
                            'timestamp' => now(), // Add timestamp if needed
                        ]
                    );
                }
            } else {
                $this->error("No data found for coin: $coinName");
            }
        } else {
            $this->error("Failed to fetch rates for coin: $coinName. Status code: " . $response->status());
        }
    }
}
