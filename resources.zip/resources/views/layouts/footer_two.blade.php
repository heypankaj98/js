<style>
footer.footertwo {
    position: fixed;
    bottom: 0;
    width: 100%;
    z-index: 9999; /* Ensure it stays above all other elements */
    background-color: #000; /* Optional: Set background color for clarity */
    border-top: 1px solid #ff0000;
    display: flex; /* Flexbox for centering */
    justify-content: center; /* Horizontally center the content */
    align-items: center; /* Vertically align the content */
    padding: 10px 0;
}

.footer_inner {
    height: 110px;
    display: flex;
    align-items: center; /* Vertically center items inside */
    justify-content: space-evenly; /* Add spacing between inner items */
    width: 100%; /* Ensure the content spans the full width */
    max-width: 1200px; /* Optional: Limit the content width for better design */
    padding: 0 20px; /* Padding for spacing */
}

ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.imge {
    width: 150px;
}

.imgee {
    width: 80px;
}

a {
    text-decoration: none;
}
.logo_market img.imge {
    max-width: 90px;
}
.mb-3.d-inline-flex.align-items-center {
    display: flex;
    align-items: center;
}

h1 {
    margin: 0;
    color: white;
}
footer.footertwo h1{line-height:18px;}
.highlight {
    color: red;
    font-weight: bold;
}
.alley-cat{display:flex; flex-wrap:wrap; gap:10px; align-items:center}
</style>
<footer class="footertwo py-3">
    <div class="footer_inner">
        <!-- Logo Section -->
        <div class="logo_market">
            <ul class="d-flex navbar-nav">
                <li class="nav-item">
                    <a class="navbar-brand m-0" href="/">
                        <img class="imge" src="{{ asset('assets/toropt.png') }}" alt="Logo" />
                    </a>
                </li>
            </ul>
        </div>
        <!-- Access Section -->
        <div class="mb-3 d-inline-flex gap-3 align-items-center">
            <img class="imgee me-3" src="{{ asset('assets/enter-icon.png') }}" alt="Access Icon" style=" width: 30px; margin-right:10px">
            <h1 class="m-0 text-start">
                <a href="https://darkalley.market" style="text-decoration: none;">
                    <span class="logo-text" style="color: orange; font-weight: bold; font-size:14px">Access</span>
                    <span class="highlight" style="color: red; font-weight: bold; font-size:14px">All Dark Alley</span>
                </a>
                <div>
                    <span class="highlight" style="color: white;font-size:12px">Mirrors. PGP Keys. Features.</span>
                </div>
            </h1>
        </div>
        <div class="alley-cat">
            <bold class="highlight" style="color: #ff0000;">Alley Cat</bold>
            <img class="imgee me-3" src="{{ asset('assets/Alley_Cat-new.png') }}" alt="Access Icon" style=" width: 90px;">
        </div>
    </div>
</footer>
