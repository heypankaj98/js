@extends('layouts.admin.master')  



@section('content')
<div class="mt-4">
<h1 class="card-header-2 w-100 mb-4">Payout Requests</h1>

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@endif

@if($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif

<div class="table-responsive br1">
    <table class="table table-bordered table-prd table-striped table-hover">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Payment Address</th>
                <th>Payment Method</th>
                <th>Amount</th>
                <th>Balance</th>
                <th>Date</th>
                <th>Status</th>
                <th>Details</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($payouts as $payout)
            <tr>
                <td>{{ $payout->user->username }}</td>
                <td>{{ $payout->payment_address }}</td>
                <td>{{ $payout->payment_method }}</td>
                <td>{{ $payout->amount }}</td>
                <td>
                    @if ($payout->payment_method === 'Bitcoin')
                    {{$payout->user->btc_balance }}
                    @elseif ($payout->payment_method === 'Monero')
                    {{ $payout->user->xmr_balance }}
                    @endif
                </td>
                <td>{{ $payout->created_at }}</td>
                <td>{{ $payout->status }}</td>
                <td>{{ $payout->details }}</td>
                <td>
                    @if ($payout->status === 'pending')
                    <form action="{{ route('admin.payouts.approve', $payout->id) }}" method="POST" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-success">Approve</button>
                    </form>
                    <form action="{{ route('admin.payouts.reject', $payout->id) }}" method="POST" class="d-inline">
                        @csrf
                        <div class="input-group">
                            <input type="text" name="reason" class="form-control" placeholder="Reason" required>
                            <button type="submit" class="btn btn-danger btn-sm br-4">Reject</button>
                        </div>
                    </form>
                    @else
                    <span class="text-muted">N/A</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7">No payout requests found.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
</div>
@endsection
