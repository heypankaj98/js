<style>
    h4.hme {
    margin-left: 25px;
}
</style>
@extends('layouts.buyer.app')     @section('content')
             <div class="banner">
    <div class="home-inn"></div>
    <div class="home-inner"><h4 class="hme">User Panel</h4>
    </div>
    <div class="text-co">In the <strong>User Panel</strong> section, you can configure all setting of your account.</div>
    <div class="text-co">You can change your avatar image, manage your PGP Public Key, Security Settings, favourite vendors ans security setting. You can also change your password, withdraw PIN or become a vendor.</div>
</div>
<h2 class="custom-title my-4">User Dashboard</h2>
<section class="bg-card-1">
    <div class="row">
        <div class="col-lg-4">
            <a class="text-decoration-none" href="{{ route('user.orders') }}">
                <div class="bg-card-2 br1 h-100">
                    <div class="">
                        <div class="row">
                            <div class="col-12">
                                <h4 class="title1 mb-0">{{ trans('common.total') }} {{ trans('common.orders') }}</h4>
                            </div>
                            <div class="col-12 text-center my-4">
                                <h2 class="card-subtitle mt-1 green-circle">
                                    {{ $orders->count() }}
                                </h2>
                            </div>
                            <div class="col-12">
                            <a class="btn btn-main text-decoration-none">{{ trans('common.view') }} {{ trans('common.all') }}</a>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-lg-4">
             <div class="bg-card-2 br1 h-100">
                <div class="">
                    <div class="row">
                        <div class="col-12">
                            <h4 class="title1 mb-0">{{ trans('common.pending') }} {{ trans('common.orders') }}</h4>
                        </div>
                        <div class="col-12 text-center my-4">
                            <h2 class="card-subtitle mt-1 blue-circle">
                                {{ $orders->count() - $orders->where('status','COMPLETED')->count() }}
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="bg-card-2 br1 h-100">
                <div class="">
                    <div class="row">
                        <div class="col">
                            <h5 class="title1 position-relative">
                                 {{ trans('common.total') }} {{ trans('common.spent') }} ({{ request()->currency }})
                                 <span class="pob-custom2">$</span>
                            </h5>
                            <h2 class="mb-0 text-center my-4">
                                {{ convertCurrency($total, request()->currency) }}  {{ request()->currency }}
                            </h2>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="">
        <div class="card-buyer br1">
            <h5 class="card-header-buyer">{{ trans('common.recent') }} {{ trans('common.orders') }}</h5>
            <div class="card-body">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-prd datatable datatable-Product text-center">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('common.no') }}.
                                    </th>
                                    <th>
                                        {{ trans('common.order') }}-{{ trans('common.id') }}
                                    </th>
                                    <th>
                                        {{ trans('common.payment') }} {{ trans('common.method') }}
                                    </th>
                                    <th>
                                        {{ trans('common.total') }} {{ trans('product.price') }}
                                    </th>
                                    <th>
                                        {{ trans('common.order') }}-{{ trans('common.date') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($orders as $key => $mainorder)
                                <tr>
                                    <td>
                                        {{ isset($a) ? ++$a : $a = 1 }}.
                                    </td>
                                    <td>
                                        {{ $key }}
                                    </td>
                                    <td> 
                                        {{ trans('common.' . $mainorder->first()->payment_method) }}
                                    </td>
                                    <td>
                                        $ {{ $mainorder->sum('total') }}
                                    </td>
                                    <td>
                                        {{ $mainorder->first()->created_at->format('M,j Y g:i A') }}
                                    </td>
                                    <td>
                                        <a class="btn btn-main btn-sm w-max-c m-auto" href="{{ route('user.order', $key) }}">
                                            {{ trans('common.view') }}
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection