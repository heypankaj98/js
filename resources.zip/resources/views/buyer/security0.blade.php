@extends('layouts.buyer.app')       @section('content')
    <div class="container my-5">
        <h1 class="text-center">User Control Panel: Become a Vendor</h1>

        <div class="mt-4">
            <p>We are very pleased that you want to become a vendor on Dark Allay and join our informal family.</p>
            <p>We offer vendors as well as customers a long-term and stable platform for decent business relationships...</p>
        </div>

        <div class="info-box">
            <h5 class="text-warning">Please read and understand the following information</h5>
            <p>In addition to the regular marketplace vendor URLs, a vendor also receives a special shop-specific and secret URL.</p>
            <ul>
                <li>Vendor account type Level 1 will be instantly converted to a vendor account.</li>
                <li>Vendor account type Level 2 will be manually verified and converted after verification.</li>
                <li>Vendor account type Level 3 has passed all tests and is seen as the vendor security.</li>
                <li>Your vendor account will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items, we recommend that you create a new account before becoming a vendor.</li>
            </ul>
        </div>

        <div class="warning-box">
            <p>There are rules on this marketplace to ensure that everything runs smoothly and securely.</p>
            <p><strong>Any attempt at fraud, fake feedbacks, etc. will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you...</p>
        </div>
        <div class="container my-5" style="background-color: #2b3035;">
        <div class="p-3 bg-warning text-center">
            <h4>Please read and understand the following information</h4>
        </div>

        <div class="p-4 bg-light">
            <p>In addition to the regular marketplace mirror URLs, a vendor gets access to special preferred and secured mirror URLs, protected by Onion Authentication, to ensure that vendors always have access to their shop.</p>
            <ul>
                <li>Vendor account type <strong class="text-danger">Level 1</strong> will be instantly converted to a vendor account.</li>
                <li>Vendor account type <strong  class="text-danger">Level 2 and 3</strong> will be converted to a vendor account after the verification process is completed.</li>
                <li>A vendor account can only sell, not purchase items - this serves the vendors security.</li>
                <li>Your customer wallet will be converted to a vendor wallet. This means, all ledger history (if exists) will be deleted.</li>
                <li>Your wallet starts new with your current balance less the paid vendor bond.</li>
                <li>The vendor bond will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items with this account, we recommend that you create a new account for becoming a vendor. The reason for that is, that other vendors can know an address or something else about you from a previous purchase.</li>
            </ul>
        </div>

        <div class="p-4 mt-4 bg-light border border-danger">
            <h5 class="text-center text-danger">There are rules on this marketplace to ensure that everything runs smoothly and secure.</h5>
            <p>Read the Marketplace Rules (<a href="#" class="text-warning">Marketplace Rules</a>) and the Dark Allay Guardian (<a href="#" class="text-warning">Dark Allay Guardian</a>).</p>
            <p><strong class="text-danger">Any attempt at fraud/scam against customers, vendor account or the marketplace, such as attempts to fake feedbacks etc, will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you and you have nothing to fear. But if you try to scam in any way - no consideration will be given! We treat everyone properly and fair and expect this in return.</p>
            <p><strong>Be faithful to us and we will never be unfaithful to you. Hell yes.</strong></p>
        </div>
    </div>


        <div class="mt-5">
            <h2 class="mb-4">Vendor Account Types</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-center">
                       <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 1</h3>
                            <p>(Unverified)</p>
                            <a href="{{ route('user.security1') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                       <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 2</h3>
                            <p>(Verified, Untrusted)</p>
                            <a href="{{ route('user.security2') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                      <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 3</h3>
                            <p>(Verified, Trusted)</p>
                            <a href="{{ route('user.security3') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
<style>
    h2{
        background-color: #ff202c;
        text-align: center;
    }
    h1{
        color: #ff7d00;
    }
</style>