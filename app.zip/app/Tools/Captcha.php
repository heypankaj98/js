<?php

namespace App\Tools;

class Captcha {

    // Generate a random captcha challenge string
    public static function generate_captcha_challenge() {
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;':\",./<>?";
        $length = 8; // Length of captcha challenge string
        $captcha_challenge = "";

        for ($i = 0; $i < $length; $i++) {
            $captcha_challenge .= $chars[rand(0, strlen($chars) - 1)];
        }

        Captcha::generate_captcha_image($captcha_challenge);
        
        return $captcha_challenge;
    }

// Generate a captcha image with the given challenge string
    public static function generate_captcha_image($captcha_challenge) {
        $image_width = 200;
        $image_height = 50;
        $font_size = 30;
        $font_angle = rand(-10, 10);
         $font_file = public_path('assets/font/ARIBL0.ttf');
        // Create a new image with a white background
        $image = imagecreatetruecolor($image_width, $image_height);
        $bg_color = imagecolorallocate($image, 255, 255, 255);
        imagefill($image, 0, 0, $bg_color);

        // Add random lines and dots to the image for noise
        $line_color = imagecolorallocate($image, 0, 0, 0);
        $dot_color = imagecolorallocate($image, 0, 0, 0);
        for ($i = 0; $i < 10; $i++) {
            imageline($image, rand(0, $image_width), rand(0, $image_height), rand(0, $image_width), rand(0, $image_height), $line_color);
            imagesetpixel($image, rand(0, $image_width), rand(0, $image_height), $dot_color);
        }

        // Add the captcha challenge string to the image with random position and color
        $text_color = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
        $text_x = rand(0, $image_width - ($font_size * strlen($captcha_challenge)));
        $text_y = rand($font_size, $image_height - $font_size);
        imagettftext($image, $font_size, $font_angle, $text_x, $text_y, $text_color, $font_file, $captcha_challenge);

        // Output the image as PNG
        header("Content-type: image/png");
        imagepng($image);

        // Free up memory
        imagedestroy($image);
    }
    
    

}
