<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique();
            $table->string('password');
            $table->string('mnemonic')->nullable();
            $table->string('reference_code')->unique();
            $table->string('pin')->nullable();
            $table->text('avatar')->nullable();
            $table->boolean('isSeller')->default(0);
            $table->boolean('isMod')->default(0);
            $table->boolean('twofa')->default(0);
            $table->boolean('vacation_mode')->default(0);
            $table->longText('pgp_key')->nullable();
            $table->timestamp('last_login')->useCurrent();
            $table->string('btc_account')->nullable();
            $table->string('monero_account')->nullable();
            $table->decimal('btc_balance', 18, 8)->default(0);
            $table->decimal('xmr_balance', 18, 8)->default(0);
            $table->decimal('ltc_balance', 18, 8)->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('users');
    }
};
