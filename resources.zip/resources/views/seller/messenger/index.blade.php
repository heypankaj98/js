@extends('seller.messenger.template')

@section('title', $title)

@section('messenger-content')


<div class="mt-4">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 ">
                <div class="bg-card-2 p-16 br1">

                    <!-- Channels -->
                    <div>
                        <h5 class="card-header-2 w-100 mb-4"> {{ trans('global.channels') }} </h5>
                        <ul class="list-unstyled chat-sidebar-1">
                            <li><a href="#"> {{ trans('global.general') }} </a></li>
                            <li><a href="#"> {{ trans('global.announcements') }} </a></li>
                        </ul>
                    </div>
                </div>

                <div class="bg-card-2 br1 mt-4">
                    <h5 class="card-header-2 w-100 mb-4s">{{ trans('global.chat_users') }}</h5>
                    <ul class="list-unstyled ">
                        @forelse($topics as $singletopic)
                        <li class="mb-2">  <a href="{{ route('seller.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                    <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">
                                    <div class="d-flex flex-column gap-1">
                                    <span>{{$singletopic->receiverOrCreator()->username}} ( {{ $singletopic->mesasgeUnreadCount() }} )</span>
                                    <p class="small mb-0 text-success">
                                        {{ trans('global.online') }}
                                        </p>
                                    </div>
                                    @endif
                                </div>
                            </a>
                        </li>
                        @empty
                      
                        {{ trans('global.no_chat_user') }}
                       
                        @endforelse
                    </ul>
                </div>

            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">
                    <h5 class="mb-0"> {{ trans('global.select_chat_user ') }}       </h5>
                </div>
                <div class="card-body">
                    <div class="chat-messages">
                        <p> {{ trans('global.select_user_for_chat') }}</p>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="bg-card-2 p-16 mb-4 br1">
                <p class="card-header-2 w-100 mb-4">Admin </p>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                    @if (auth()->user()->id != $adminuser->id)
                         @if($adminuser->withChatMessages($adminuser->id) > 0)
                    <a href="{{ route('seller.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$adminuser->username}}</span></a>
                    @else
                    <a href="{{ route('seller.messenger.newMessages', [$adminuser->id]) }}">     <span class="badge text-bg-primary">{{ $adminuser->username}}</span></a>

                    @endif
                    @endif
                    @empty
                     {{ trans('global.no_chat_and_admin_here') }}
                    @endforelse
                </ul>
            </div>
            <!-- Mod --> 
            <div class="bg-card-2 p-16 br1">
                <p class="card-header-2 w-100 mb-4">Moderator</p>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                      @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('seller.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    @else
                    <a href="{{ route('seller.messenger.newMessages', [$moduser->id]) }}">     <span class="badge text-bg-primary">{{ $moduser->username}}</span></a>
                    @endif
                    @endif
                    @empty  

                     {{ trans('global.no_chat_and_mod_user') }} 
                    @endforelse
                </ul>
            </div>
        </div>
    </div>




    @endsection

