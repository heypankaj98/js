<?php
namespace app\Traits;

use App\Models\{ Auction, Bids };
use Auth;
use Carbon\Carbon;

trait AuctionTrait
{
    private function checkAuction($id) {
        if (Auction::whereid($id)->first()->status == 'closed') {
            return true;
        }
    }
    
    private function checkbuyer($id) {
        if (Bids::whereid($id)->first()->user_id == Auth::id()) {
            return 1;
        } else {
            session()->flash('error', 'You are not allowed to access this.');
            return redirect()->back();
        }
    }
    
    private function auctionCheck() {
        $auctions = Auction::where('status', 'active')->get();

        foreach ($auctions as $auction) {
            $endtime = Carbon::parse($auction->end_time);
            $current = Carbon::now();

            if ($endtime->lt($current)){
                $max = Bids::where('auction_id',$auction->id)->max('price');
                $winner = [];
                $winners = Bids::where('auction_id',$auction->id)->where('amount',$max)->where('status','escrow')->get();
                
                foreach ($winners as $win){
                    $winner[] = $win->user_id;
                }
                
                $auction->status = 'closed';
                $auction->winner_id = $winners;
                $auction->save();
            }
        }
    }
}