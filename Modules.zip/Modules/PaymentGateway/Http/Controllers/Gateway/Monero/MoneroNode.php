<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Monero;

use Illuminate\Support\Facades\Log;
use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib\nodeRPC;
use App\Models\ExceptionModel;

class MoneroNode
{
    private $monerod;

    public function __construct()
    {
        $this->monerod = new nodeRPC([
            'host' => config('coins.monero.host'),
            'port' => config('coins.monero.port'),
            'user' => config('coins.monero.username'),
            'password' => config('coins.monero.password')
        ]);
    }

    /**
     * Check if Monero daemon is running.
     *
     * @return bool
     */
    public function isMoneroRunning(): bool
    {
        try {
            $this->monerod->get_info();
            return true;
        } catch (\Exception $exception) {
            $this->logException($exception);
            return false;
        }
    }

    /**
     * Get detailed node info.
     *
     * @return array|bool
     */
    public function getNodeInfo()
    {
      
        try {
            
            return $this->monerod->get_info();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }
    
    /**
     * Get wallet info (if applicable).
     *
     * @return array|bool
     */
    public function getWalletData()
    {
        
        try {
            return $this->monerod->get_wallet_info();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the current blockchain height.
     *
     * @return array|bool
     */
    public function getHeight()
    {
        try {
            return $this->monerod->get_height();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the synchronization status of the node.
     *
     * @return array|bool
     */
    public function getSyncInfo()
    {
        try {
            return $this->monerod->get_sync_info();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get information about the mining status.
     *
     * @return array|bool
     */
    public function getMiningStatus()
    {
        try {
            return $this->monerod->get_mining_status();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Start or stop mining.
     *
     * @param bool $start Whether to start or stop mining
     * @return array|bool
     */
    public function setMining($start = true)
    {
        try {
            return $this->monerod->set_mining($start);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get information about a specific transaction.
     *
     * @param string $txid Transaction ID
     * @return array|bool
     */
    public function getTransaction($txid)
    {
        try {
            return $this->monerod->get_transaction($txid);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get a list of all transactions in the blockchain.
     *
     * @return array|bool
     */
    public function getTransactions()
    {
        try {
            return $this->monerod->get_transactions();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the last block hash.
     *
     * @return array|bool
     */
    public function getLastBlockHash()
    {
        try {
            return $this->monerod->get_last_block_hash();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the block data.
     *
     * @param int $height Block height
     * @return array|bool
     */
    public function getBlock($height)
    {
        try {
            return $this->monerod->get_block($height);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the block header by height.
     *
     * @param int $height Block height
     * @return array|bool
     */
    public function getBlockHeaderByHeight($height)
    {
        try {
            return $this->monerod->get_block_header_by_height($height);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the block header by hash.
     *
     * @param string $hash Block hash
     * @return array|bool
     */
    public function getBlockHeaderByHash($hash)
    {
        try {
            return $this->monerod->get_block_header_by_hash($hash);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the peer list.
     *
     * @return array|bool
     */
    public function getPeerList()
    {
        try {
            return $this->monerod->get_peer_list();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get network information.
     *
     * @return array|bool
     */
    public function getNetworkInfo()
    {
        try {
            return $this->monerod->get_network_info();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get the status of the transaction pool.
     *
     * @return array|bool
     */
    public function getTxpoolStatus()
    {
        try {
            return $this->monerod->get_txpool_status();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get transactions from the transaction pool.
     *
     * @return array|bool
     */
    public function getTxpoolTransactions()
    {
        try {
            return $this->monerod->get_txpool_transactions();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Log exception and return error response.
     *
     * @param \Exception $exception
     * @return array
     */
    private function logException(\Exception $exception): array
    {
        $errorCode = 'xmr-node-' . mt_rand(1000, 9999);
        $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.';

        $exceptionLog = new ExceptionModel();
        $exceptionLog->error_code = $errorCode;
        $exceptionLog->error_message = $exception->getMessage();
        $exceptionLog->save();

        return ['error_code' => $errorCode, 'error_message' => $errorMessage];
    }
}
