<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class Transaction extends Authenticatable {

    use HasApiTokens,
        HasFactory,
        Notifiable;

    protected $fillable = [
        'sender_id',
        'receiver_id',
        'crypto_name',
        'crypto_amount',
        'created_at',
        'updated_at'
    ];

    public function sender(){
        return $this->belongsto(User::class,'sender_id');
    }
    
    public function receiver(){
        return $this->belongsto(User::class,'receiver_id');
    }
}