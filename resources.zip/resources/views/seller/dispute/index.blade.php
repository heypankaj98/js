@extends('seller.dispute.template') @section('messenger-content')

<div class="mt-4">
    <div class="row h-100">
        <div class="col-3">
            <div class="bg-card-2 d-flex flex-column h-100 chat-sidebar br1 br-4">
                <div class="">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('common.recent') }} {{ trans('common.disputes') }}</h5>
                    <ul class="list-unstyled">
                    @forelse($disputes as $dispute)
                        <li>
                            <a class="dispute-link" href="{{ route('seller.dispute.messages', [$dispute->id]) }}">
                                <div class="user_info">
                                    <img src="{{ $dispute->buyer->avatar }}"
                                        class="rounded-circle">
                                    <div class="d-flex flex-column gap-1">
                                        <span>{{ $dispute->buyer->username }}</span>
                                        <p class="small mb-0">{{ trans('common.status') }} {{ $dispute->status }}</p>
                                    </div>
                                </div>
                                <p class="small ab-p">{{ trans('common.order') }} {{ $dispute->order_id }}</p>
                            </a>
                        </li>
                        @empty
                        {{ trans('common.no') }} {{ trans('common.disputes') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-9">
            <div class="bg-card-2 br1 h-100">
                <div class="card-header-2 w-100 mb-4">
                    <div>{{ trans('common.select') }} {{ trans('common.dispute') }}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection