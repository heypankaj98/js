<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin;

use App\Http\Controllers\Controller;
use Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin\LitecoinPayment;

class ProcessController extends Controller {

    public static function isNoderunning($params = array()) {
        $node = new LitecoinPayment();
        $responce = $node->isBitcoinRunning($params);
        return $responce;
    }

    public static function createNewAccount($params = array()) {
        $node = new LitecoinPayment();
        $address = $node->createNewAccount($params);
        return $address;
    }

    public static function generateAddress($params = array()) {
        $node = new LitecoinPayment();
        $address = $node->generateAddress($params);
        return $address;
    }

    public static function getBalance($params = []) {
        $node = new LitecoinPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }

    public static function getTransactionDetail($params = []) {
        $node = new LitecoinPayment();
        $fee = $node->getTransactionDetail($params);
        return $fee;
    }
    public static function GetTransactionFee($params = []) {
        $node = new LitecoinPayment();
        $fee = $node->getBalance($params);
        return $fee;
    }

    public static function getWalletBalance($params = []) {
        $node = new LitecoinPayment();
        $balance = $node->getWalletBalance($params);
        return $balance;
    }

    public static function getWalletData($params = []) {
        $node = new LitecoinPayment();
        $data = $node->getWalletData($params);
        return $data;
    }

    public static function getWalletlisttransactions($params = []) {
        $node = new LitecoinPayment();
        $balance = $node->getWalletlisttransactions($params);
        return $balance;
    }

    public static function sendToAddress($params = []) {
        $node = new LitecoinPayment();
        $status = $node->sendToAddress($params);
        return $status;
    }

    public static function sendToMany($addressesAmounts = []) {
        $node = new LitecoinPayment();
        $status = $node->sendToMany($addressesAmounts);
        return $status;
    }

    public static function getAddressStatus($address) {
        $node = new LitecoinPayment();
        $status = $node->getaddressinfo($address);
        return $status;
    }

    public static function getBlockchainInfo() {
        $node = new LitecoinPayment();
        $status = $node->getBlockchainInfo();
        return $status;
    }

}
