@extends('layouts.admin.master')      @section('content')

    <div class="mt-4">
    <div class="card-header-2 w-100 mb-4">
                    {{ trans('cruds.product.title_singular') }} {{ trans('global.list') }}
                </div>
        <div class="col-md-12">
            <div class="bg-card-2 my-3 ">
               
                
                <div class="card-body">
                    <div class="table-responsive">
                        <table class=" table table-bordered table-prd table-striped table-hover datatable datatable-Product mb-3">
                            <thead>
                                <tr>
                                    <th>
                                        {{ trans('cruds.product.fields.id') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.name') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.type') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.vendor') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.description') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.price') }} [USD]
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.category') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.product.fields.photo') }}
                                    </th>
                                    <th>
                                        &nbsp;
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($products as $key => $product)
                                <tr data-entry-id="{{ $product->id }}">
                                    <td>
                                        {{ $product->id ?? '' }}
                                    </td>
                                    <td>
                                        {{ $product->name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $product->type ?? '' }}
                                    </td>
                                    <td>
                                        {{ $product->seller->username ?? '' }}
                                    </td>
                                    <td>
                                        {!! Str::limit($product->description , 10, ' ...') !!}
                                    </td>
                                    <td>
                                        $ {{ $product->price ?? '' }}
                                    </td>
                                    <td>
                                        {{ $product->categories->name ?? ''}}
                                    </td>
                                    <td >
                                        @if($product->photo)
                                        <a href="{{ $product->photo->getUrl() }}" target="_blank" class=" d-inline-block br-4">
                                            <img src="{{ $product->photo->getUrl('thumb') }}">
                                        </a>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @can('admin_product_show')
                                        <a class="btn btn-primary btn-sm br-4" href="{{ route('product.details', $product->id) }}">
                                            {{ trans('global.view') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_edit')
                                        <a class="btn btn-info btn-sm br-4" href="{{ route('seller.products.edit', ['product' => $product->id, 'page' => $product->type]) }}">
                                            {{ trans('global.edit') }}
                                        </a>
                                        @endcan

                                        @can('admin_product_delete')
                                        <form action="{{ route('seller.products.destroy', $product->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" class=" d-inline-block ">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                            <input type="submit" class="btn btn-danger btn-sm br-4 mt-2" value="{{ trans('global.delete') }}">
                                        </form>
                                        @endcan
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan ="8">No Products available.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                        {{ $products->links('partials.pagination') }}
                    </div>
                </div>
            </div>
        </div>
    </div>



@endsection