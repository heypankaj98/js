<?php
namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BidPaymentRequest extends FormRequest {

    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'payment_method' => 'bail|required|in:Bitcoin,Monero',
        ];
    }
}