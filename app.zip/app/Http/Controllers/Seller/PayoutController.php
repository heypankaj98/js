<?php

namespace App\Http\Controllers\Seller;

use Illuminate\Http\Request;
use App\Models\Payout;
use App\Http\Controllers\Controller;
use Auth;

class PayoutController extends Controller {

    /**
     * Display a listing of the resource.
     */
    public function index() {
        $user = Auth::user();
        $payouts = $user->payouts;

        return view('seller.payouts', compact('payouts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create() {
        return view('payouts.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {
        $request->validate([
            'payment_address' => 'required',
            'payment_method' => 'required',
            'amount' => 'required|numeric',
            'password' => [
                'required',
                function ($attribute, $value, $fail) {
                    if (!Auth::attempt(['username' => Auth::user()->username, 'password' => $value])) {
                        $fail('The password is incorrect.');
                    }
                },
            ],
        ]);
        if ($request->payment_method == 'btc') {
            if ($request->amount > auth()->user()->btc_balance) {
                return redirect()->back()->with('error', 'Insufficient BTC balance.');
            }
        }

        if ($request->payment_method == 'xmr') {
            if ($request->amount > auth()->user()->xmr_balance) {
                return redirect()->back()->with('error', 'Insufficient XMR balance.');
            }
        }


        $data = $request->all();
        $data['user_id'] = Auth::id(); // Assign the currently authenticated user's ID

        Payout::create($data);

        return redirect()->route('seller.payouts')
                        ->with('success', 'Payout created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id) {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id) {
        //
    }

}
