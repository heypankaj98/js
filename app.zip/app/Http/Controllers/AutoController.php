<?php
namespace App\Http\Controllers;

use App\Models\{ Auction, };
use Carbon\Carbon;

class AutoController
{
    public function index()   //  Auto function   
    {
        $set = Setting::firstornew();
        $set->last_auto_run = Carbon::now();
        $set->save();
        
        $this->checkAuctionDaily();
        $this->autoDeleteNotificationAfter20Days();
        $this->autoDeleteMessageAfter20Days();
        $this->autoCancelAfter72Hours();
        $this->autoFinalAfter15Days();
        
        if(Auth()->user())
        {
          return redirect()->back();
        }
        return 1;
    }
    
    protected function checkAuctionDaily() {
        $auctions = Auction::where('status','active')->get();
        
        foreach ($auctions as $auction){
            $endtime = Carbon::parse($auction->end_time);
            $current = Carbon::now();

            if ($endtime->lt($current))
            {
               return 1;
            } else {
               $auction->update(['status' => 'closed']);
            }
        }
        return 1;
    }

    
    protected function autoCancelAfter72Hours(){
        $pending = Order::where('status',1)->orwhere('status',2)->where('created_at','<',Carbon::now()->subDays(3))->get();
        
        foreach($pending as $order)
        {
            if($order->status == 1)
            {
                Order::whereid($order->id)->update(['status' => 9]);
                
                $Notify = new Notification();
                $Notify->users_id = $order->user_id;
                $Notify->desc = 'Sorry !! Your order for <b>' . $order->articles->name . '</b> is auto-cancelled, because you did not pay 3 days after order was placed' . msg();
                $Notify->save();
                
                $Notify1 = new Notification();
                $Notify1->users_id = $order->vendor_id;
                $Notify1->desc = 'Sorry !! Sale order for <b>' . $order->articles->name . '</b> by buyer <b>' . $order->users->name . '</b> is auto-cancelled, because buyer did not pay 3 days after order was placed' . msg();
                $Notify1->save();
                
                $admin = new adminnotification();
                $admin->type = 1;
                $admin->data = $order->id;
                $admin->desc = "<b>OrderID - " . $order->id . " is auto-cancelled because buyer <b>" . $order->users->name . "</b> did not pay for 3 days after order was placed. Order No. : <b>" . $order->order_number . "</b></b>.";
                $admin->save();
            }
            elseif($order->status == 2)
            {
                Order::whereid($order->id)->update(['status' => 8]);
                Escrow::where('trx',$order->order_number)->update(['status' => 3]);
                
                $Notify = new Notification();
                $Notify->users_id = $order->user_id;
                $Notify->desc = 'Sorry !! Your order for <b>' . $order->articles->name . '</b> is auto-cancelled, because vendor <b>' . $order->vendors->name . '</b> did not accept the order within 3 days. Amount is credited in your wallet' . msg();
                $Notify->save();
                
                $Notify1 = new Notification();
                $Notify1->users_id = $order->vendor_id;
                $Notify1->desc = 'Sorry !! Sale order for <b>' . $order->articles->name . '</b> by buyer <b>' . $order->users->name . '</b> is auto-cancelled, because you did not accept order within 3 days. Amount is credited in buyer wallet' . msg();
                $Notify1->save();
                
                $admin = new adminnotification();
                $admin->type = 1;
                $admin->data = $order->id;
                $admin->desc = "<b>OrderID - " . $order->id . " is auto-cancelled because seller <b>" . $order->vendors->name . "</b> did not accept order within 3 days. Amount is credited in buyer wallet. Order No. : <b>" . $order->order_number . "</b></b>.";
                $admin->save();
            }
        }
        return 1;
    }
    
    protected function autoFinalAfter15Days(){
      $pending = Order::where('status',5)->orwhere('status',3)->orwhere('status',4)->where('created_at','<',Carbon::now()->subDays(15))->get();
             
      foreach($pending as $order)
      {
        $escrow = Escrow::where('trx', $order->order_number)->firstorfail(); 
        $buyer = User::whereid($escrow->user)->firstorfail();
        $vendor = User::whereid($escrow->vendor)->firstorfail();
        $product = Article::whereid($order->article_id)->firstorfail();
        $general = Setting::firstorfail();
        $block_io = new \BlockIo\Client(env('BLOCKIO_API_KEY') , env('BLOCKIO_PIN'), 2);
        
        if (!$vendor->addrbtc)
        {
            $block_io2 = new \BlockIo\Client(env('BLOCKIO_API_KEY') , env('BLOCKIO_PIN'), 2);
            $block_io2->get_new_address(array('label' => $vendor->name, 'address_type' => 'witness_v0'));
            
            User::whereId($vendor->id)->update(['addrbtc' => 1]);
        }
        
        if($escrow->charges_btc > 0)
        {
            $getaddr1 = $block_io->get_address_by_label(array('label' => $vendor->name));
            $estFee1 = $block_io->get_network_fee_estimate(array('to_address' => $getaddr1->data->address, 'amount' => number_format($escrow->vendor_amount_btc, 8)));
            $getaddr = $block_io->get_address_by_label(array('label' => 'default'));
            $estFee2 = $block_io->get_network_fee_estimate(array('to_address' => $getaddr->data->address, 'amount' => number_format($escrow->charges_btc, 8)));
            
            $feepaid = bcadd($estFee1->data->blockio_fee,$estFee1->data->estimated_min_custom_network_fee, 8);
            $feepaid = bcadd($feepaid,'0.000005',8);
            $feetoadmin = bcsub(number_format($escrow->charges_btc,8), $feepaid, 8);
            $feetoadmin = bcsub($feetoadmin, number_format($estFee2->data->blockio_fee,8), 8);
            $feetoadmin = bcsub($feetoadmin, number_format($estFee2->data->estimated_min_custom_network_fee,8), 8);
            $est = bcadd($estFee1->data->estimated_min_custom_network_fee,'0.000005',8);

            $prepare_transaction = $block_io->prepare_transaction(array('amounts' => number_format($escrow->vendor_amount_btc, 8) ,'priority'=>'custom','custom_network_fee' => $est, 'from_labels' => $buyer->name , 'to_labels' => $vendor->name));
            $summarize_prepared_transaction = $block_io->summarize_prepared_transaction($prepare_transaction);
            $create_and_sign_transaction = $block_io->create_and_sign_transaction($prepare_transaction);
            $block_io->submit_transaction(array('transaction_data' => $create_and_sign_transaction));
            
            Escrow::where('trx', $order->order_number)->update(['status' => 2]);
            User::whereid($escrow->vendor)->update(['total_sales' => $vendor->total_sales + ($product->price * $order->quantity)]);
            Order::whereid($order->id)->update(['status' => 6]);
            
            $userNotification = new Notification();
            $userNotification->users_id = $order->user_id;
            $userNotification->desc = 'Your order for '.$order->articles->name.' is autofinalised, since 15 days are passed after order was shipped. Escrow payment sent to vendor successfullly.';
            $userNotification->save();
            
            $Notification = new Notification();
            $Notification->users_id = $order->vendor_id;
            $Notification->desc = 'Order no #'.$order->id.' is autofinalised. Escrow payment sent to you successfully and reflected in wallet.';
            $Notification->save();
            
            $admin = new adminnotification();
            $admin->type = 1;
            $admin->data = $order->id;
            $admin->desc = "<b>OrderID - " . $order->id . " is auto-finalised. Seller - <b>" . $order->vendors->name . "</b>. Buyer - <b>" . $order->users->name . "</b>. Order Number - <b>" . $order->order_number . "</b></b>.";
            $admin->save();
            
            $left= 0;
        
            if($escrow->charges_btc > 0.00000000)
            {
                if ($order->fixed_charge)
                {
                     $general->total_fixed_charge += $order->fixed_charge;
                     $left += $order->fixed_charge;
                }

                if ($order->feature_charge)
                {
                    $general->total_featured_charge += $order->feature_charge;
                    $left += $order->feature_charge;
                }

                if($left > 0)
                {
                    $new = usdtobtc($left);

                    $general->total_commission_charge += bcsub($feetoadmin,$new,8);
                    $general->save();
                }
            }
            
            try {
                $prepare_transaction = $block_io->prepare_transaction(array('amounts' => number_format($feetoadmin, 8) ,'priority'=>'custom','custom_network_fee' => $estFee2->data->estimated_min_custom_network_fee , 'from_labels' => $buyer->name , 'to_labels' => env('LABEL_ADMIN') ));
                $summarize_prepared_transaction = $block_io->summarize_prepared_transaction($prepare_transaction);
                $create_and_sign_transaction = $block_io->create_and_sign_transaction($prepare_transaction);
                $block_io->submit_transaction(array('transaction_data' => $create_and_sign_transaction));
                
                Order::whereid($order->id)->update(['fee_paid' => 1]);
            }
            catch (\Exception $e)
            {
                $admin = new adminnotification();
                $admin->type = 1;
                $admin->data = $order->id;
                $admin->desc = "<b>OrderID - <b>" . $order->id . "</b> is auto-finalised, but fee was not paid. Order Number - <b>" . $order->order_number . "</b></b>.";
                $admin->save();
            }
        }
        else
        {
            $getaddr1 = $block_io->get_address_by_label(array('label' => $vendor->name));
            $estFee1 = $block_io->get_network_fee_estimate(array('to_address' => $getaddr1->data->address, 'amount' => number_format($escrow->vendor_amount_btc, 8)));
            $est = bcadd($estFee1->data->estimated_min_custom_network_fee, '0.000005',8);
            
            $prepare_transaction = $block_io->prepare_transaction(array('amounts' => bcsub(number_format($escrow->vendor_amount_btc, 8),$est,8) ,'priority'=>'custom', 'custom_network_fee' => $est, 'from_labels' => $buyer->name , 'to_labels' => $vendor->name ));
            $summarize_prepared_transaction = $block_io->summarize_prepared_transaction($prepare_transaction);
            $create_and_sign_transaction = $block_io->create_and_sign_transaction($prepare_transaction);
            $block_io->submit_transaction(array('transaction_data' => $create_and_sign_transaction));
            
            Escrow::where('trx', $order->order_number)->update(['status' => 2]);
            User::whereid($escrow->vendor)->update(['total_sales' => $vendor->total_sales + ($product->price * $order->quantity)]);
            Order::whereid($order->id)->update(['status' => 6]);
            
            $userNotification = new Notification();
            $userNotification->users_id = $order->user_id;
            $userNotification->desc = 'Your order for '.$order->articles->name.' is autofinalised, since 15 days are passed after order was shipped. Escrow payment sent to vendor successfullly.';
            $userNotification->save();
            
            $Notification = new Notification();
            $Notification->users_id = $order->vendor_id;
            $Notification->desc = 'Order no #'.$order->id.' is autofinalised. Escrow payment sent to you successfully and reflected in wallet.';
            $Notification->save();
            
            $admin = new adminnotification();
            $admin->type = 1;
            $admin->data = $order->id;
            $admin->desc = "<b>OrderID - " . $order->id . " is auto-finalised. Seller - <b>" . $order->vendors->name . "</b>. Buyer - <b>" . $order->users->name . "</b>. Order Number - <b>" . $order->order_number . "</b></b>.";
            $admin->save();
            
            $left= 0;
            
            if($escrow->charges_btc > 0.00000000)
            {
                if ($order->fixed_charge)
                {
                     $general->total_fixed_charge += $order->fixed_charge;
                     $left += $order->fixed_charge;
                }

                if ($order->feature_charge)
                {
                    $general->total_featured_charge += $order->feature_charge;
                    $left += $order->feature_charge;
                }

                if($left > 0)
                {
                    $new = usdtobtc($left);

                    $general->total_commission_charge += bcsub($feetoadmin,$new,8);
                    $general->save();
                }
            }
        }
      }
      return 1;
    }
    
    protected function autoDeleteNotificationAfter20Days(){
        Notification::where('read_status',1)->where('created_at','<',Carbon::now()->subDays(20))->delete();
        return 1;
    }
    
    protected function autoDeleteMessageAfter20Days(){
        Message::where('created_at','<',Carbon::now()->subDays(20))->delete();
        return 1;
    }
     
    protected function vendorLevelCheckDaily(){
        $vendor = User::where('role_id',3)->get();

        foreach($vendor as $single)
        {
          if($single->total_sales < 2500 && $single->level != 1)
          {
              User::whereid($single->id)->update(['level' => 1]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 1 of vendors.' . msg();
              $Notification->save();
            
          }
          elseif($single->total_sales >= 2500 && $single->total_sales < 8500 && $single->level != 2)
          {
              User::whereid($single->id)->update(['level' => 2]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 2 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor '<b>" . $single->name . "</b>' has completed the sales worth more than $2500 and promoted to vendor level 2.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 8500 && $single->total_sales < 12500 && $single->level != 3)
          {
              User::whereid($single->id)->update(['level' => 3]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 3 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor '<b>" . $single->name . "</b>' has completed the sales worth more than $6500 and promoted to vendor level 3.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 12500 && $single->total_sales < 17500 && $single->level != 4)
          {
              User::whereid($single->id)->update(['level' => 4]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 4 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor '<b>" . $single->name . "</b>' has completed the sales worth more than $ 9000 and promoted to vendor level 4.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 17500 && $single->total_sales < 23500  && $single->level != 5)
          {
              User::whereid($single->id)->update(['level' => 5]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 5 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor'<b> " . $single->name . "</b>' has completed the sales worth more than $12500 and promoted to vendor level 5.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 23500 && $single->total_sales < 30000  && $single->level != 6)
          {
              User::whereid($single->id)->update(['level' => 6]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 6 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor'<b> " . $single->name . "</b>' has completed the sales worth more than $15,500 and promoted to vendor level 6.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 30000 && $single->total_sales < 45000  && $single->level != 7)
          {
              User::whereid($single->id)->update(['level' => 7]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 7 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor'<b> " . $single->name . "</b>' has completed the sales worth more than $ 19,000 and promoted to vendor level 7.</b>";
              $admin->save();
              
          }
          elseif($single->total_sales >= 45000  && $single->level != 8)
          {
              User::whereid($single->id)->update(['level' => 8]);
              
              $Notification = new Notification();
              $Notification->users_id = $single->id;
              $Notification->desc = 'Congratulations !! You are now on Level 8 of vendors.' . msg();
              $Notification->save();
              
              $admin = new adminnotification();
              $admin->type = 3;
              $admin->data = $single->id;
              $admin->desc = "<b>Vendor'<b> " . $single->name . "</b>' has completed the sales worth more than $25,000 and promoted to vendor level 8.</b>";
              $admin->save();
          }
        }
        return 1;
    }
}