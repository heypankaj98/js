
@extends('layouts.admin.master')     
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            @if (session('success'))
            <div id="alert_message" class="alert alert-success alert-block">
                <strong>{{session('success')}}</strong>
            </div>
            @endif
            @if (session('error'))
            <div id="alert_message" class="alert alert-danger alert-block">
                <strong>{{ session('error') }}</strong>
            </div>
            @endif

            <div class="container py-5 px-4">
                <form>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Charge Name</th>
                                <th scope="col">Charges</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($settings as $setting)
                            <tr>
                                <th scope="row">{{$setting->id}}</th>
                                <td>{{$setting->key}}</td>
                                <td><input type="text" name="{{$setting->key}}" class="form-control" value="{{$setting->value}}" id="exampleInputPassword1"> </td>
                                <td></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>


                    <button type="submit" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
