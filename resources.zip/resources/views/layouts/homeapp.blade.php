<!doctype html>
<html lang="en" >
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="icon" type="image/x-icon" href="{{ asset('assets/Dark_Alley_Logo.png') }}">
    <title>{{ trans('global.site_title') }}</title>
    <link href="{{ asset('css/bootstrap-5.3/css/bootstrap.css') }}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
    <link href="{{ asset('css/kk.css') }}" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="{{ asset('css/main.css') }}">
</head>
<body>
    <div class="">
        <header class="c-home-header">
            @include('partials.navbar')
        </header>
<div class="container">
    <div class="custome-row">
        @include('partials.category')
        <main class="content-bar-row deshboard_right_main">
            @yield("content")
        </main>
    </div>
    </div>

@include('layouts.pagefooter')
</div>
</body>
</html>
