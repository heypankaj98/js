<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Ticket;
use App\Models\TicketLabel;
use App\Models\TicketMessage;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use App\Http\Requests\TicketRequest;
use Illuminate\Database\Eloquent\Builder;
use App\Models\TicketCategory;
//use App\Notifications\AssignedTicketNotification;
//use App\Notifications\NewTicketCreatedNotification;
use Auth;
use App\Notifications\UserTicketNotification;
class TicketController extends Controller {

    public function index(Request $request): View {
        $tickets = Ticket::where('user_id', Auth::id())->with('user', 'categories', 'labels', 'assignedToUser')
                ->latest()
                ->paginate();
  
        
        return view('buyer.tickets', compact('tickets'));
    }

    public function create(): View {
        $labels = TicketLabel::get()->pluck('name', 'id');

        $categories = TicketCategory::get()->pluck('name', 'id');

        $users = User::orderBy('username')->get();
        return view('buyer.ticketcreate', compact('labels', 'categories', 'users'));
    }

    public function store(TicketRequest $request) {
      

      
        $ticket = auth()->user()->tickets()->create($request->only('title', 'message', 'status', 'priority', 'assigned_to','catagery','photo'));
       
//   if ($request->hasFile('attachments')) {
   
//     if ($input['attachments']) {
//         // Store the uploaded image directly to $ticket->photo
//         $mediaItem = $ticket->addMedia(storage_path('tmp/uploads/' . basename($input['attachments'])))->toMediaCollection('photo');

//         // Update $ticket->photo with the saved media item
//         $ticket->photo = $mediaItem->getUrl(); // Assuming 'getUrl()' gives the URL of the saved media
//         $ticket->save();
//     }
// }

//        $ticket->attachCategories($request->input('categories'));
//
//        $ticket->attachLabels($request->input('labels'));
//        $users = User::whereHas('roles', function ($query) {
//                    $query->whereIn('title', ['Admin', 'Modrator']);
//                })->get();

        if ($request->input('assigned_to')) {
//            $ticket->assignedToUser($request->input('assigned_to'));
//            User::find($request->input('assigned_to'))->notify(new AssignedTicketNotification($ticket));
        } else {
//            auth()->user()->notify(new UserTicketNotification($ticket));
            User::whereHas('roles', function ($query) {
                $query->whereIn('title', ['Admin', 'Moderator']);
            })->each(fn($user) => $user->notify(new UserTicketNotification($ticket)));
        }


        if (!is_null($request->input('attachments'))) {
            foreach ($request->input('attachments') as $file) {
                $ticket->addMediaFromDisk($file, 'public')->toMediaCollection('tickets_attachments');
            }
        }
        auth()->user()->notify(new UserTicketNotification($ticket));
          $ticketMessage = new TicketMessage();
         $ticketMessage->user_id=$ticket->user_id;
         $ticketMessage->ticket_id=$ticket->id;
         $ticketMessage->message=$ticket->message;
         $ticketMessage->save();
        return to_route('user.tickets.index');
    }


  

 public function TicketReply(Request $request, $id) {
     
          $user_id = Auth::id();
         $ticketMessage = new TicketMessage();
         $ticketMessage->user_id=$user_id;
         $ticketMessage->ticket_id=$id;
         $ticketMessage->message=$request->reply;
         $ticketMessage->save();
         return redirect()->back();
  }



    public function show(Ticket $ticket): View {
      $tickets = $ticket->load(['media', 'messages' => fn($query) => $query->latest()]);
  
        return view('buyer.tickets.show', compact('tickets'));
    }

public function edit(Ticket $ticket): View
{
    // Fetch all tickets belonging to the same user
    $tickets = Ticket::where('user_id', $ticket->user_id)->get();
    $ticket->load('categories', 'labels', 'assignedToUser');
    $labels = TicketLabel::get()->pluck('name', 'id');
     $categories = TicketCategory::get()->pluck('name', 'id');

        $users = User::orderBy('username')->get();

    return view('buyer.tickets.edit', compact('ticket', 'tickets','labels','categories','users'));
}

public function update(TicketRequest $request, Ticket $ticket) {
 $ticket->update($request->only('title', 'message', 'status', 'priority', 'assigned_to'));

        $ticket->categories($request->input('categories'));

        $ticket->labels($request->input('labels'));

        if ($request->input('assigned_to')) {
//            $ticket->assignedToUser($request->input('assigned_to'));
//            User::find($request->input('assigned_to'))->notify(new AssignedTicketNotification($ticket));
        } else {
//            auth()->user()->notify(new UserTicketNotification($ticket));
            User::whereHas('roles', function ($query) {
                $query->whereIn('title', ['Admin', 'Moderator']);
            })->each(fn($user) => $user->notify(new UserTicketNotification($ticket)));
        }

    

        return to_route('user.tickets.index');
    }

    public function destroy(Ticket $ticket) {
        $this->authorize('delete', $ticket);

        $ticket->delete();
       

        return to_route('user.tickets.index');
    }

    public function upload(Request $request) {
        $path = [];

        if ($request->file('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('tmp', 'public');
            }
        }

        return $path;
    }
    
    

    public function close(Ticket $ticket) {
        $this->authorize('update', $ticket);

        $ticket->close();

        return to_route('user.tickets.show', $ticket);
    }

    public function reopen(Ticket $ticket) {
        $this->authorize('update', $ticket);

        $ticket->reopen();

        return to_route('user.tickets.show', $ticket);
    }

    public function archive(Ticket $ticket) {
        $this->authorize('update', $ticket);

        $ticket->archive();

        return to_route('user.tickets.show', $ticket);
    }

}
