<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Ethereum;

use App\Http\Controllers\Controller;
use Modules\PaymentGateway\Http\Controllers\Gateway\Ethereum\EthereumPayment;
use App\Http\Controllers\Gateway\PaymentController;
use App\Models\Deposit;

class ProcessController extends Controller {


    public function process($deposit) {
        $node = new EthereumPayment();
        dd($node);
    }

    public static function generateAddress($params = array()) {
        $node = new EthereumPayment();
        $address = $node->createNewAddress($params);
        dd($address);
        return $address;
    }

    public static function getBalance($params = []) {
        $node = new EthereumPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }

    public static function getWalletBalance($params = []) {
        $node = new EthereumPayment();
        $balance = $node->getWalletBalance($params);
        return $balance;
    }

    public static function getWalletlisttransactions($params = []) {
        $node = new EthereumPayment();
        $balance = $node->getWalletlisttransactions($params);
        return $balance;
    }

    public static function sendToAddress($toAddress, $amount) {
        $node = new EthereumPayment();
        $status = $node->sendToAddress($toAddress, $amount);
        return $status;
    }

    public static function sendToMany($addressesAmounts = []) {
        $node = new EthereumPayment();
        $status = $node->sendToMany($addressesAmounts);
        return $status;
    }

    public static function getAddressStatus($address) {
        $node = new EthereumPayment();
        $status = $node->getaddressinfo($address);
        return $status;
    }

}