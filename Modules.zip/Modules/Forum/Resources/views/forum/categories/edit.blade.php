@extends('forum::layouts.master')

@section('content')
<form action="{{ route('forum-categories.update', $category) }}" method="POST">
    @csrf
    @method('PUT')
    <label for="title">Title:</label>
    <input type="text" name="title" id="title" value="{{ $category->title }}" required>
    <button type="submit">Update Category</button>
</form>


@endsection
