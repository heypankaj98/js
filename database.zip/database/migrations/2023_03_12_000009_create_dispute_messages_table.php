<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDisputeMessagesTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void 
     */
    public function up() {
        Schema::create('dispute_messages', function (Blueprint $table) {
             $table->bigIncrements('id');
            $table->unsignedBigInteger('dispute_id');
            $table->unsignedBigInteger('user_id');
            $table->text('message');
            $table->timestamps();

            $table->foreign('dispute_id')->references('id')->on('disputes');
            $table->foreign('user_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('dispute_messages');
    }

}
