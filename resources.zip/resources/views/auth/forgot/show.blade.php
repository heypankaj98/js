<style>
    .container-fluid {
        height: 45vh;
    }

    .futt {
        display: none;
    }
    .border04{
        border-radius: 4px !important;
    margin: 16px 0 12px;
    }
    .forgot_main{
        background-color: rgba(255, 255, 255, .1);
        padding: 48px !important;
        border-radius: 8px;
    }
    .btn-main{
        border-radius: 4px !important;
    }
    .btn-main:hover{
        background-color: #ff202c !important;
    }
</style>
@extends('layouts.auth') @section('content')

@if(Session::has('error'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
@endif

<div class="row justify-content-center">
    <div class="col-md-4  forgot_main">
        <h2 class="inner-for">{{ trans('auth.forgot') }}</h2>
        <div class="alert alert-warning border04">
            <b>{{ trans('auth.note_word') }}:</b> {{ trans('auth.forgot_note') }}
        </div>
        <div class="mt-5 text-center">
            <p>{{ trans('auth.recover_it') }}</p>
            <!--<form method="GET" action="/forgotpassword/pgp">
                <div class="form-group text-center">
                    <div class="row">
                        <button type="submit" class="btn btn-outline-primary btn-block">PGP</button>
                    </div>
                </div>
            </form>-->
            <div class="card_main_part">
                <form class="card-body form_card" method="GET" action="{{route('forgot.password.mnemonic')}}">
                    <div class="form-group text-center">
                        <div class="row w-100">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-main m-auto">
                                    {{ trans('auth.Mnemonic') }}
                                </button>
                            </div>
                        </div>



                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--<div class="col-md-4 text-center">
        <h2>Forgot your PGP?</h2>
        <div class="alert alert-warning">
            Note that you will not be able to use PGP from previous PGP.
        </div>
        <div class="mt-3">
            <p>Please choose how to recover it</p>

            <form method="GET" action="{{route('forgot.pgp.mnemonic')}}">
                <div class="form-group text-center">
                    <div class="row">
                        <button type="submit" class="btn btn-outline-primary btn-block">Mnemonic</button>
                    </div>
                </div>
            </form>
        </div>
    </div>-->
</div>
@endsection