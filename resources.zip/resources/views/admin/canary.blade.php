@extends('layouts.admin.master')     
@section('content')

<div class="mt-4 br1 p-24 br-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
            @endif

            <form method="POST" action="{{ route('admin.canery.update') }}">
                @csrf
                <div class="form-group">
                    <label for="canary"> {{ trans('global.canery')}} </label>
                    <textarea class="form-control form-control-textarea mt-2" id="canary" name="canary" rows="5">{{$canary}}</textarea>
                </div>
                <button type="submit" class="btn btn-main mt-3">{{ trans('global.update_canery')}} </button>
            </form>
        </div>
    </div>
</div>

@endsection