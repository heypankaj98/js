<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use App\Models\Payout;

class AutoApprovePayouts extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'payouts:auto-approve';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Automatically approve pending payouts after 5 days and check user balance.';

    /**
     * Execute the console command.
     */
    public function handle() {
        // Fetch the pending payouts that need to be auto-approved
        $pendingPayouts = Payout::where('status', Payout::STATUS_PENDING)
                ->where('created_at', '<=', now()->subDays(5))
                ->get();

        foreach ($pendingPayouts as $payout) {
            // Check if the user has sufficient balance
            if ($payout->user->btc_balance >= $payout->amount) {
                $payment_method = $payout->payment_method; // Replace with the code to determine the payment method
                $received = PayWay::sendToAddress($payment_method, [
                            'address' => $payout->payment_address,
                            'amount' => $payout->amount,
                            'tag' => $payout->user->username,
                ]);

                if (isset($received['error_code'])) {
                    $payout->status = Payout::STATUS_REJECTED;
                    $payout->details = 'Error code: ' . $received['error_code'] . ' Message: ' . $received['error_message'];
                    $payout->save();
                } else {
                    // Update the payout status to 'approved'
                    if ($payout->payment_method === 'Bitcoin') {
                        $payout->user->btc_balance -= $payout->amount;
                        $payout->user->save(); // Save the user model
                    } elseif ($payout->payment_method === 'Monero') {
                        $payout->user->xmr_balance -= $payout->amount;
                        $payout->user->save(); // Save the user model
                    }

                    $payout->status = Payout::STATUS_APPROVED;
                    $payout->save();

                    // Perform any additional actions after approving the payout
                }
            } else {
                // Set the payout status to 'rejected' if the user has insufficient balance
                $payout->status = Payout::STATUS_REJECTED;
                $payout->details = 'Insufficient balance';
                $payout->save();
            }
        }

        $this->info('Auto-approval of payouts completed.');
    }

}
