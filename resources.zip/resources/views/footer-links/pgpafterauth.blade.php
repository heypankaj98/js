@extends('footer-links.layout')
@section('content')

<div class="container-fluid bg-grey">
    <div class="text-center">
        <br>
        <h2 class="title">{{ trans('global.site_title') }} - {{ trans('footer.pgp') }}</h2>
        <br>
        <h6 class="text-light"><a href="{{route('home')}}" class="decoration text-light">{{ trans('global.home') }}</a>&nbsp;\&nbsp;{{ trans('footer.pgp') }}</h6>
    </div>
    <br>
</div>
<div class="container-fluid">
    <div class="row">
        <main class="col-md-12 ms-sm-auto col-lg-9 px-md-4 deshboard_right_main">
            <section class="blog-section pt-120 pb-120">
                <div class="container">
                    <div class="row gy-5 justify-content-between">
                        <div class="col-lg-12">
                            <div class="post__details">
                                <br><pre>-----BEGIN PGP PUBLIC KEY BLOCK-----
Comment: This is Shopzo Market's Official PGP Key

xsFNBGSZSmsBEADXbeEhy775dZ9bKhJ48mlVux6IPoxdsi+5oAov+N7FV4L/uOMb
DvR1QO1NvzQEnv971XbxU4letCgQfc1J0l6VbcjOQqxJ/VOVHjy9zjTTwZ0vV4Ez
wgtSTP6kTiH+HXCvRvOIAo4K17NTNs7gSrkrCmtlHVqexbZMKOJwF9EP/pDadAM9
fsoDEx3ttC7bKKRnWrgqYHaYW+KgIhjicwrEufbEof9JgobxZnmQAU2+/4mroqG9
LP2n+0yVwngvjE+eppiUCPFBGXGsD9FblePOlTaLio5L3YisaCP5nBKFPoc1n6mX
aMydV54YmdFnuw8+WCgJSr75Rve6DXDnOt6DvytZa48hw4FC+3J+50y7x0e+BWAv
NRopjUzYp82CX2haXxktfxVUkapO6aFr2B/FNW2K7JdHVBiC91jWrA/vtt7A1hUG
MBut5Os+E1V23ANoaDlVjHpTAYLBis/knG0114MfxOpx5grakY9z59D8SYNRXZ/k
fHtk9+dJi6y0PWCogV7CcyBuDdram4pYyRzSs2Q5USoTcIXk9p51MFPSlc15pPvF
Iacd0UC1BdGvy0NpDSCMsTGjEmrF/wk6jJAftGtaoO5bQ75XFXDyLUmbCV1tlaez
C68ZwX2YDN8AYtH6rsBbBNldtPaSHz3LrMB07JebGvk0QYfjH9L0YCc7mQARAQAB
zR5TaG9wem8gPHNob3B6b0Bwcm90b25tYWlsLmNvbT7CwXoEEwEKACQFAmSZSmsC
Gy8DCwkHAxUKCAIeAQIXgAMWAgECGQEFCQAAAAAACgkQ/2DAdE6qZyI6ng/+MMg0
pb9MdxBGw41cs/0FdgjrNbSLFFMXpeNi4lTK+RM57ppSi+SDHFi2iJYBxzPrbpS5
cKmDbWuJ9AT0KrvXELcgYHSDpW2531zLG8scSQr0skMdfeeprojNKDil1/TEp27P
Lj7ySpcMpPbqELxtvHszn/fveY4DFqQUf+Xo7q/EgyijvxhiUtp1vxayH7hJ2g9P
oX3XM+qBkCk5b86Yz2npgR/ETOVega8/EMTEtz+wNknWh/RyfioVYt8hZBGxBbXx
F9F0MeuwqnFgx2Iw6sk8KJCQLYyZKmGhSVeDUuS/S6NDo/kvwltrvGZMgyf/34kZ
tv3yUD0s9k1WRsR0+eJfElGKYrCwMLdCCEX//HoObqtXFFMbVznkzdH8XLy0Vl7l
cTsQR/x1jHlDmuZpIEmke5RynZcDue4MktK0XNi1Nsg/8MJdKEzY006a8nFcpkT7
puLQc1JK1WG41uba4rAcBpJQsxguXtuKkjlDvdhGMI95B1CkEhELfO8Za4S6qx5/
3iRuYPOl72cXSLM/3bOtyTEyZPSBl4YC7q/tsVJwoOxrTjokuP386XKzVStRB+SV
lbhb4HaVAr21eDtlW9z/fUgQVtyejI4l7kPH/Gh4hLyVChFhm5qCxcWMnNNCfppX
xRAzegfLvuH6xxqgHkkmJI+Jy60Ui6yFgBrKhUDOwU0EZJlKawEQANaNbc18PoMQ
RFhzfZyZLkJWzt9rWH6+6tpBqcv1PaoEXb6Hlkgc8ujcvlknH2ww6/0QHqztx2XP
DvKTDLkdtnAASgnxqj4BuG3LW+49/tghuXgOYwdL4QkIbULA14nyCrPrn5jphODL
9+aRzJJwvjOXziUsr2hZjWrsRoWY6lxIS93P5xyT94/Xxl9V6pbmQoXrmaTGnIWf
BML3vYXhiRA8VqUJPbKxYtQ3kwKPuDtoypKINrl89RzFYRTlFavnK/WQ9g4CMrUF
gCPX8S+dTQ7HGz9GXfgnZF8LXsZ4MMmQSG9yaQJVvXatYEvfElYxvQk/97e9UVwN
ADtvTobvYD6fYQCyzzDiFPbLVjMMIokgj9FFXQJ2hynx/Qtm+hia2qTqfuAbv3nS
K5vikpAbB6MmF0faSX2O701L0VSrJAvr/TqSUdZwl+DCIQjQlBfhQeEfKJ6pBd4m
9CJK6Qe3wUEKglIRIq2PjTdxm4UZJ4CaPVJT8wmf8jDpv4bpyzt6UIt0hpnDznPj
zCPheF+ACTxkkYgMz8g29wAJgWjmJPv5WKoEprgPnluUkYUO5Hoi+ZwEEJWGWs3I
bsv0uXSVns0+3REJz+S1i8cDZuQPfqHWyft6kuERa+/GpN1VSpoqnDmVA3MUziP3
o6hu41F0bBCy8CWMeJUQz9dGCkBJj3ivABEBAAHCw4QEGAEKAA8FAmSZSmsFCQAA
AAACGy4CKQkQ/2DAdE6qZyLBXSAEGQEKAAYFAmSZSmsACgkQToBaCsnfqTdMahAA
t5mC3eSit1jNWC+W7E0T9TF3I9YSyQe+fSYFix2FKvrmyQ9mOVmIj4eSqy2W5qeb
9/i7xRqgEE/cSBeN2j7cV5mahVeoSEoHgZuVD4/Uovxlx6WHOcb/MpycxKiPXfFs
hmjDzu//09tdQL7ZBSSdRF7ZzZYamEi4rtdvCqX4+GUg8J+TYIkBYJUdJDeQZcSE
zsI8p1eqw2CyQQjiWvKHgWFboHC99aHExVIfcNgJWk1pDDpAKdBBaePbLTPWpc7/
yPx3WrGJx1j9Dxxj8LDjFf44e4zUH+15iFCCCgIeKuNEY29Y4xnWXeWoCwAmsaOq
5Uz55HW41gekX/prb0ROXgn0dQBxV0wVMEGHu9l/wPqgzJUv5NrJEcWZd+zd+AKH
mszkU+gWuIKQVGGsBzp8r5eXTr6971taXeAcEXwa/GakkXXhc+TuFwM17yTsp6XN
Xe1fQcYKQmYG7lwNgSCpMnpM8N3r58rTieXfpRogVRDWlWtKawTHPxWnzP4Wjowm
3RVM51VRo3FlXcL86Urd8W2E5yB6onEc/nfjQKvrYN162Mr4ScrrGkoQpgSVrhUc
NAD91h5S1mHo51EP7uN0jp56A0EAxTPuSKeLC6X5FxMVURYo7F2nASpLOSFpY8i9
nmI9lyly23b2DxWz0WHWC14q0seDZsxKhHdYgRLIYjLCshAAyn0u/JvefJPy9z5i
b1atp9yTzzDkTpmdkTEtK682VLAMYtijeA6Kz32xI0Eeh0AFxSItKunBnuHZlaw7
qnlLKZ3zUwSzBB+87DiOJVnzV9RpxnDO2fvlNPmyNc1ZuAvZ6dysVdGviq5TpLp+
PYHcTmnhwJJ4bqCKlwOtMlP5t67qVvPQ7xctXTj7SyCz/MDR1TlyFoX2h5SkLJnb
KfOTFskTqRHBiSuqjVXcGj+/NT4Bv6mvPHjxChvJEObGkWh5RgTg0O4qnyX3nw6b
JffPPzBElV49mqJEzlzIKYw85geES86iLnpOXhR9h3TcVUstzZvSTg8RLZImk9vb
xfDXvmQ8QcRlohJ7pQPrTvQxIspFVsnoT+lMfB8UmwbVjm1JoHh46XWQsFuGgQmJ
m874gM8n5Rup26jT7QmZGp46cxNPbJnWa+y7BTDvz7FqHF2vste1l/FG/fjisfaX
qDRTwzwROdBpIkaRSMX9Sd8fNyBrNbkz7YmHjXPO4FgezwIcl3NKD1JSwT8Fi0mM
0LDtomqdpq6VOy+l3y67ypoMTj23rYIIm4Kzozcf13CShSPWB8/i/MU7Oe7TH2WD
PlFA7JOIpfzza0s1fkZA1hzWcZ4dV6c6YNkUXavC7et8cIPqxqGlEUgGPbamdtU9
XkaJRTDUgdx4DOmbhtj3/mXXksvOwU0EZJlKawEQAMVfpb2g2xqxOdUCLsrWG0lW
aqn+wY00vEEOqhu/hnAB62K6kOhE+o+2wJ7+DZ8opLd0LGv7LDQoyuBPsASR0FeG
9AurlldYw4nhrmfq+85bHPtEPm0oZwp/44fTQ20KI0d1Rx8EC0K6cQjLZ08r2Ty8
qNcr9+Xk5ZtShwG2YVR05/wsp3SpbmOylOICaVrPJ+brBSBAK/Ip2J8n9vQRzDdO
FPH1YjKilswcwmywanlqUtjW7TNDetN/eUNKUE2sZ7ZloG6QF8BKEuFD3eGcrh3X
kWBSjFI5nusvkfV4kprKrNeg9069DQ46/ThERhkLgyhQRDQRkzTgYenRVJdtG9OF
Gpk9CD6ZpaXFFa7pbW72/jXCX4TqwGO1IXlXJl0UN3V3GtCF7f0Mcn2T+TMGaOVo
QjdhRF0NxjKV+rq5ZC9ptaasXo8d7LpuqmJD2NnpuCAaLavp+eUyjONAXnc1RT+Z
GMu55VZwRnUlJpbSsye7ymTUokofmhh++I81907HnKpCbFcqqiB9oVe3JA3+nr4f
o4A9kkT8KEmB46eugS4jr1OLBaj1mHUDZZtGy1LhguqBZZWOBUzWKNFGZxpOD0pH
Y9ayOSNg2N6wdffnMqGrO5MIQwtFCp3JQNiTc/kgG6CPATYJB2Bo+y+7J6aPweTC
WlFMppjWlv5MeMMZtkDTABEBAAHCw4QEGAEKAA8FAmSZSmsFCQAAAAACGy4CKQkQ
/2DAdE6qZyLBXSAEGQEKAAYFAmSZSmsACgkQGN8neNBTdlwQwQ/+N5TUneNr5qTm
3Q/7R6FKSl9nCYqQ0pvazMMw48QXFR5a6ecLK7NtveDehUyhgQ9CM18k/TcTROQz
n40gFSQDm0HwPOUQ4KPdv7SjsGrk8clSXZM8I1fShvwCkdbctK0syudHtiz+xKcq
TKjT9AEglKm3LK+hAXIFiyfAiu7hgbjj5xjdGR9w9Ph5D0n2kd1kWu7adhtdfXWa
N4+hsUitp28jcmxLwBcoML5As6n00KTLYKAASzruSX83lAqr/UDcRtxZFvgU6e4I
j8398IoL9s0ohIDkZ+Qyi+WswK75CSOgQS+1Yy1ST68s0HKcGl3D71t6eK5r8zx/
w/lFuaM/dds/sbbkZhs2yY2qM4wrW6tCRU0QRsL1Wo0voaUGrKTlyNNvXacsNkEf
a/gBLSftXYb4HcY10cyoLFKxpCAUt6nFcm6xlm5VjkIDY0PxQsEgYosbqf6IbWjC
aBQ9XJj0srfYfylNj6eQvlBdGBW61rJqna1xjW2XW6GC7tIUCmn3/4Abvkjw65z/
+EekGA1Dku5H7A+SylJ0nMNKZYG/fKLaIPiCqOUCodmH1mOUP4VLdKZVXJ2zqmbW
Re+/MeK7FVPnZiLtEL+UNQkFv6dplWjvbMEC1w1yh02L5y/cmgCBkOL8g10irz8a
eyYM+EjJMTrtyO9qLMnGrLURKe94E0gS1A/7B/gLVPb7bxBjgsl3YdiopQ2TiQKF
eqpoO2Tgw4AgcTH2u2FKbWwFW/oBn5L9QLUdvgDME1DglJsKT9XFfdrjOcCsC8j8
FpX5h+kBrZcqY+bQ170XR8Amuh9QGN867RjAMXTTiCsRzQPaEZcijiumymJrI4PE
d1sFg+P5aNpfEf/77RwKD6WfOvxqGdhGpOpI5YC/xuJvPUFXP+plwu23he3SLFJg
rzybP6AMmPjxnuMeUfPe7yFHWqDLW2z9MUI9PVrjCStUUaLbKqBkU/xPofj7wLes
Fbh3/jZYEBn/N6XjqLWapvl0acQJFjZm6eOtneLzCHw9m7rYkRXLG1cNMJBP+8M6
OLRB/0LhGS4Z/J1RAVe+lWLntSx9YG5g6RDIXGGgpsuSJcvp6s9TNr4y3+9Z2mZs
sGf9YFuxWiuZbXTuCOKYl8ABfaWyMsp8/qePkhXbk9SgnNo8YSyLwMtH54Z9XAKd
1ixhp/CdQvKvySgncrXvx2K8IOH8Znqw/qzcYVSVvQsyEzraKun3xuwS0k/S1Ua5
+shlQUx2zLOKUynS+n82UC5NRZNWZ+ZEfllieEAaqBQbYN0XpxCJ0NqeuZX/NAzk
kUrL5HHuNCQMIWNLajgeuffat8qfVr3f8bVx98s4NOMLryMa0QCUoqYV5SPiUy08
nF0SZn6qrT0/+Ho=
=GJTC
-----END PGP PUBLIC KEY BLOCK-----</pre>
<br>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>
</div>
@endsection