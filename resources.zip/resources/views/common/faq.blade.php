@extends('layouts.homeapp')
@section('content')
<html lang="en">

<head>
    <style>
    .py-24{padding-top:24px; padding-bottom:24px}
        .arrow1 {
            margin-top: -2px;
        }

        th {
            font-weight: 900;
        }

       

        dd {
            color: #ddd;
            margin-bottom: 20px;
        }

        dt {
            margin-bottom: 10px;
        }

        li {
            margin-top: 5px;
        }

        .img-fluid {
            max-width: 17%;
            height: auto;
        }

        .info-header {
            background-color: #2a3135;
            color: white;
            padding: 10px;
            font-weight: bold;
            border-radius: 4px
        }

        .info-body,
        .qa-body {
            background-color: #2a3135;
            color: white;
            padding: 24px;
            margin-top: 20px;
            border-radius: 4px
        }

        .question {
            font-weight: bold;
            margin-bottom: 8px;
            color: #ff7d00;
        }
.bg-card-1 p, .bg-card-1 li, .bg-card-1 dd {
    font-size: 12px;
}
        .answer {
            margin-bottom: 20px;
            line-height: 1.5; 
            font-size: 12px;
    letter-spacing: 0.03em;
    font-weight: 300;
        }
.bg-card-2 .bg-card-1 {
    border: 1px solid #ff0000;
    text-align: center;
    padding: 5px;
    font-size: 14px; font-weight: 700;
}
        .highlight {
            font-weight: bold;
            color: #ff7d00;
        }
    </style>
</head>

<body>
    <div class="bg-card-1 py-24">
        <div class="title-box mb-3"><h1>Dark Allay Market FAQ</h1></div>
        
        <div class="bg-card-2 mt-4">
            <h4 class="bg-card-1">
                Questions & Answers (Common)
            </h4>
            <div class="">
                <div class="question">
                    Q: What is the difference between Dark Alley Market and other marketplaces?
                </div>
                <div class="answer">
                    <strong>A:</strong> Dark Alley Market was created under the premise to stay forever. We wanted a
                    great and a fair marketplace.
                    <br>We created this marketplace to make a difference.
                    <br>Vendors can build a real existence for their business, can carefree grow and flourish and this
                    forever.
                    <br>This is the key for their future business and a safe place for every customer to purchase their
                    favorite goods.
                    <br>If you want to know more, just visit the <span class="highlight">About Us</span> section for
                    detailed information.
                    <br><span class="highlight">Be faithful to us and we will never be unfaithful to you. Hell
                        yes.</span>
                </div>
                <div class="question">
                    Q: Why is Dark Alley Market more secure and how does the Dark Alley Guardian with the integrated
                    Strike-System work?
                </div>
                <div class="answer">
                    <strong>A:</strong> First, Dark Alley Market only operates special multi-layer encrypted servers and
                    services.
                    <br>Further, the whole marketplace was hand-coded and especially developed for this purpose.
                    <br>Dark Alley Market works according to the whitelist principle.
                    <br>Every function has been designed for maximum security. In addition, the Dark Alley Guardian with
                    the integrated Strike-System was created to guarantee the highest level of security.
                    <br>Take a look and learn more about the <span class="highlight">Dark Alley Guardian</span>.
                </div>
                <div class="question">
                    Q: What is the magic of The Administration?
                </div>
                <div class="answer">
                    <strong>A:</strong> At Dark Alley Market, the member is still king, as it should be.
                    <br>The Administration is more than something special, just like a touch of magic.
                    <br>All our servers and services are designed to detect any type of errors immediately and inform
                    The Administration.
                    <br>You can be sure that if there should ever occur a technical error, The Administration has been
                    informed and fixes this.
                    <br>The same applies to our user support.
                    <br>All support queries are processed within a short time, usually in a few hours.
                    <br>Depending on the effort, it can sometimes take longer but we try to keep these times as short as
                    possible.
                </div>
                <div class="question">
                    Q: What can The Administration prosecute and see?
                </div>
                <div class="answer">
                    <strong>A:</strong> The Administration is The Administration, Savvy?
                    <br>Every input of everyone on Dark Alley Market can be viewed by The Administration and when we say
                    everything of everyone, we mean it.
                    <br>But just because we can do it, doesn't mean we do it.
                    <br>We respect the privacy of our members.
                    <br>You can encrypt every sensitive data with PGP through Dark Alley Market or by yourself.
                    <br>Everything that is not encrypted with PGP can be viewed by The Administration.
                    <br>And to make it clear, this is simply just a technical fact.
                    <br>Every website you browse on clearnet or darknet can do that (and they actually collect it!).
                    <br>Although our servers are multi-layer encrypted, sensitive data is removed periodically and you
                    can already be sure that no data on Dark Alley Market systems will ever leak or be accessible to
                    authorities or unauthorized persons, use PGP on top of all that and know that you are safe!
                </div>
                <div class="question">
                    Q: What is the Cataclysm Protocol and what has it to do with the canary?
                </div>
                <div class="answer">
                    <strong>A:</strong> The Cataclysm Protocol comes into force if the canary, which is updated by
                    Lucifer at least every 13 days, is expired.
                    <br>The Cataclysm Protocol performs three levels, which will be automatically executed by The Master
                    Control Program.
                    <br><span class="highlight">Level 1:</span>
                    <br>Initiation Level 1: If the canary is expired.
                    <br>Duration Level 1: 5 days.
                    <br>Deposits: Disabled.
                    <br>Purchases: Disabled.
                    <br>Minimum withdraw limit: Disabled.
                    <br><span class="highlight">Level 2:</span>
                    <br>Initiation Level 2: 5 days after Level 1 was initiated.
                    <br>Duration Level 2: 21 days.
                    <br>Vendor Bonds: Will be refunded to their wallets.
                    <br>Fulfilled Orders: Will be finalized.
                    <br>Disputes: Will be settled with split 50/50 to vendor and customer.
                    <br>Pending donations: Will be transferred to Charities.
                    <br>Pending withdraws waiting for approval: Will be executed.
                    <br>Future Withdraws: Will be automatically executed.
                    <br><span class="highlight">Level 3:</span>
                    <br>Initiation Level 3: 21 days after Level 2 was initiated.
                    <br>Dark Alley Market: All servers and services will automatically shutdown.
                    <br>Of course, we hope that nothing will ever happen to Lucifer and The Administration and that the
                    canary will always be updated.
                    <br>Our members can have peace of mind that their funds which are currently on the marketplace, will
                    be accessible for withdraw before the marketplace shuts down after 26 days of a canary expiration.
                </div>
                <div class="question">
                    Q: What kind of items are prohibited to trade on Dark Alley Market?
                </div>
                <div class="answer">
                    <strong>A:</strong> You can see by the categories, what items are allowed to trade. Nevertheless the
                    following items are prohibited:
                    <br>Child- or animal pornography or any resources that might lead to it.
                    <br>Trafficking humans, animals or any body parts.
                    <br>Fentanyl or any other deadly poison or any biohazard items.
                    <br>Any kind of weapons, explosives or chemicals to produce explosives.
                    <br>Contract Killing or violent products or services.
                    <br>If you are not sure if an item is prohibited, ask before you create and try to trade this item.
                </div>
                <div class="question">
                    Q: What are the consequences if a vendor or customer violates the Marketplace Rules?
                </div>
                <div class="answer">
                    <strong>A:</strong> Depending on the type of the violation, there can be anything, from a warning to
                    a ban.
                    <br>But there are violations that are dealt with radically. If vendors fake feedback or customers
                    try to scam for example, the account will be banned and vendor bonds or wallet balances will be
                    retained.
                    <br>If you are a decent vendor or customer, you have nothing to fear.
                    <br>If vendors and/or customers try to scam each other or the marketplace in any way - no
                    consideration will be given!
                    <br>We treat everyone properly and fair and expect this in return.
                </div>
                <div class="question">
                    Q: What do I have to do to secure my account?
                </div>
                <div class="answer">
                    <strong>A:</strong> Supply your PGP Public Key to the marketplace (2FA Security (User Control
                    Center)) and enable 2FA.
                    <br>Make sure, that you use a secure software to control your PGP stuff like GnuPG or OpenPGP.
                    <br>Use a 4096 Bit RSA encryption to generate your PGP Keys.
                    <br>Never share your username or password with anyone.
                    <br>Never share your PGP Private Key with anyone.
                    <br>If you need help, take a look into the Information Center (PGP (Information Center))
                    <br>Never leave your computer or device unattended while logged in. Always logout before leaving
                    your computer or device.
                    <br>2FA ensures that only you can login and use your account. This prevents someone else from
                    accessing your account on Dark Alley Market.
                </div>
                <div class="question">
                    Q: Why is Two-Factor-Authentication (2FA) only available by using PGP?
                </div>
                <div class="answer">
                    <strong>A:</strong> PGP is the only secure solution. That's it.
                </div>
                <div class="question">
                    Q: Are there helpful tutorials on how to use PGP, do a purchase etc and how stuff works on Dark
                    Alley Market?
                </div>
                <div class="answer">
                    <strong>A:</strong> Sure, just take a look at the Information Center (Information Center)
                </div>
                <div class="question">
                    Q: Why is there a marketplace commission for customers and not only for vendors?
                </div>
                <div class="answer">
                    <strong>A:</strong> Vendors and customers both benefit from using a decent marketplace. Sharing the
                    costs is only fair.
                    <br>We see no reason why just one party should pay for everything alone, regardless of how low our
                    marketplace commissions are.
                </div>
                <div class="question">
                    Q: Are there any fees for deposits or withdrawals?
                </div>
                <div class="answer">
                    <strong>A:</strong> Dark Alley Market does not charge any fees for deposits or withdraws besides the
                    current estimated network (miner) fee for withdraws.
                    <br>The withdraw fees (network miner) will be determined when the withdraw is released to these
                    conditions:
                    <br>Monero (XMR): Normal transaction priority (1x fee) with current estimated network fee rate.
                    <br>Bitcoin (BTC): Target (ETA) within 5 blocks with current estimated network fee rate.
                </div>
                <div class="question">
                    Q: How do deposits or withdraws work and how long do they usually take?
                </div>
                <div class="answer">
                    <strong>A:</strong> Simply as usual. Just open My Wallet (My Wallet) and deposit or withdraw your
                    favorite crypto currency.
                    <br>The minimum amount for deposit or withdraw is (USD) $ 10.00.
                    <br>If your deposit is less than (USD) $ 10.00 it will not be credited to your wallet and the funded
                    address will be unusable.
                    <br>Please notice:
                    <br>All withdraws will be manually checked by The Administration several times a day.
                    <br>It can take up to 24 hours for funds to be released.
                    <br>However, we try to keep these times as short as possible.
                    <br>We want to guarantee that everything runs smoothly and secure, which is in everyone's
                    fundamental interest.
                    <br>For the safety of all users, manually checked withdraws are linked to the canary. If the canary
                    would ever expire, all withdraws will be automatically executed.
                </div>
                <div class="question">
                    Q: What are the timeframes for auto-finalize and is there a difference between physical and digital
                    goods?
                </div>
                <div class="answer">
                    <strong>A:</strong> Yes, the auto-finalize time for physical items is 14 days and 48 hours for
                    digital items.
                </div>
                <div class="question">
                    Q: What is Auto-Feedback and how does it work?
                </div>
                <div class="answer">
                    <strong>A:</strong> Well, it's actually really simple:
                    <br>After a customer has placed an order and the vendor has fulfilled it, the next step is to either
                    finalize the order (if the customer has received it, checked all items and everything is okay) - or
                    - to initiate a dispute (in case the customer hasn't received the order or something is wrong with
                    it).
                    <br>If everything is fine, as it will be in most cases, the customer finalizes the order, releasing
                    funds in escrow.
                    <br>The customer has now 7 days for escrow items or 55 days for Finalize Early (FE) items (or orders
                    which include FE-items) to leave feedback before all sensitive data will be removed from the
                    purchases/sales histories. This is for the safety of all users.
                    <br>If the customer has finalized the order and leaves no feedback in these time frames, we assume
                    that everything went well and the customer just forgot to leave feedback (or otherwise the customer
                    wouldn't have finalized the order and initiated a dispute).
                    <br>Customers contacted us quite often to let us know that they simply forgot to leave feedback and
                    after the order was removed, they were unable to do so. To solve this, we have implemented the
                    auto-feedback function.
                    <br>The auto-feedback function leaves a positive feedback without any text after the time frame of 7
                    or 55 days has passed since the order was finalized and the customer did not leave feedback. Now the
                    customer can leave his feedback as usual in the time frame available, but if he forgets to do so,
                    this will be done automatically.
                    <br>The time frame for physical items can be extended if the order is not delivered within 55 days.
                </div>
                <div class="question">
                    Q: Is there an auto logout (session expired)?
                </div>
                <div class="answer">
                    <strong>A:</strong> Yes, your session gets invalid after 2 hours of inactivity or when you logout or
                    close your browser.
                    <br>For security reasons, you have to resolve the DDoS 2-Factor-Protection again after 2 hours.
                </div>
                <div class="question">
                    Q: I feel that the connection is sometimes slower than usual, what can I do here?
                </div>
                <div class="answer">
                    <strong>A:</strong> Every time you connect to the Tor network you get a new circuit with new relays
                    assigned. You may be routed through slow Tor relays. Unfortunately, we have no control over this and
                    it is not up to us. All you can do is to get a new Tor Circuit. Simply click in your Tor Browser's
                    settings on Get new Tor Circuit. You won't be logged out of the Dark Alley Market when getting a new
                    circuit.
                </div>
                <div class="question">
                    Q: Why can feedback not be changed afterwards?
                </div>
                <div class="answer">
                    <strong>A:</strong> A customer should always give feedback without reservation. We don't want that a
                    vendor tries to persuade a customer to change feedback after it was given. A vendor can always post
                    a response to a given feedback, there is no need to change it.
                </div>
                <div class="question">
                    Q: Can a vendor see all customer profiles?
                </div>
                <div class="answer">
                    <strong>A:</strong> No, vendors can only view customer profiles if the customer has placed an order
                    with the vendor.
                </div>
            </div>
        </div>
        <div class=" mt-4">
            <div class="bg-card-2">
                <div class="bg-card-1">
                    Vendor Badges
                </div>
                <div class="card-body">
                    <table class="table table-prd table-bordered">
                        <thead>
                            <tr>
                                <th>Badge</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><img src="assets/shield.png" alt="Badge 1" class="img-fluid"></td>
                                <td>
                                    Trusted vendor through The Administration after intensive check and minimum amount
                                    of positive feedback or trusted vendor with 300 positive feedbacks of max. three
                                    other marketplaces combined.
                                </td>
                            </tr>
                            <tr>
                                <td><img src="assets/anchor.png" alt="Badge 2" class="img-fluid"></td>
                                <td>The vendor owns his personal review thread at <strong>The Hub</strong>.</td>
                            </tr>
                            <tr>
                                <td><img src="assets/animal.png" alt="Badge 3" class="img-fluid"></td>
                                <td>The vendor supports Charities with a percentage of every sale.</td>
                            </tr>
                            <tr>
                                <td><img src="assets/diamond.png" alt="Badge 4" class="img-fluid"></td>
                                <td>Violet Diamond. The vendor has more than 5000 sales (assigned manually by Lucifer).
                                </td>
                            </tr>
                            <tr>
                                <td><img src="assets/fire.png" alt="Badge 5" class="img-fluid"></td>
                                <td>Firefist. The vendor has more than 8000 sales (assigned manually by Lucifer).</td>
                            </tr>
                            <tr>
                                <td><img src="assets/two.png" alt="Badge 6" class="img-fluid"></td>
                                <td>Add or remove vendor from favorites.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <div class=" mt-4">
            <div class="bg-card-2">
                <div class="bg-card-1">
                    Reputation Customers
                </div>
                <div class="card-body">
                    <table class="table table-prd table-bordered">
                        <thead>
                            <tr>
                                <th>Reputation Tier</th>
                                <th>Completed Purchases (Given Feedback)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="bg-secondary text-white">Reputation 0</td>
                                <td>0 - 4</td>
                            </tr>
                            <tr>
                                <td class="bg-primary text-white">Reputation 1</td>
                                <td>5 - 14</td>
                            </tr>
                            <tr>
                                <td class="bg-success text-white">Reputation 2</td>
                                <td>15 - 24</td>
                            </tr>
                            <tr>
                                <td class="bg-info text-white">Reputation 3</td>
                                <td>25 - 34</td>
                            </tr>
                            <tr>
                                <td class="bg-warning text-dark">Reputation 4</td>
                                <td>35 - 44</td>
                            </tr>
                            <tr>
                                <td class="bg-danger text-white">Reputation 5</td>
                                <td>45 - 54</td>
                            </tr>
                            <tr>
                                <td class="bg-secondary text-white">Reputation 6</td>
                                <td>55 - 64</td>
                            </tr>
                            <tr>
                                <td class="bg-primary text-white">Reputation 7</td>
                                <td>65 - 74</td>
                            </tr>
                            <tr>
                                <td class="bg-success text-white">Reputation 8</td>
                                <td>75 - 84</td>
                            </tr>
                            <tr>
                                <td class="bg-info text-white">Reputation 9</td>
                                <td>85 - 94</td>
                            </tr>
                            <tr>
                                <td class="bg-warning text-dark">Reputation 10</td>
                                <td>95 - 299</td>
                            </tr>
                            <tr>
                                <td class="bg-dark text-white">Demon Customer</td>
                                <td>300 - ∞</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class=" mt-4">
            <div class="bg-card-2">
                <div class="bg-card-1">
                    Vendor-Specific Questions
                </div>
                <dl>
                    <dt>What are the requirements to become a vendor?</dt>
                    <dd>We have only a few requirements:
                        <ul>
                            <li>Provide a valid and verified PGP Public Key.</li>
                            <li>Be a member in good standing for at least 3 weeks.</li>
                            <li>Have an active and verified email address.</li>
                            <li>Accept the Dark Alley Market Terms and Conditions.</li>
                            <li>Have at least 10 completed orders as a customer.</li>
                        </ul>
                    </dd>

                    <dt>How can I become a featured vendor on Dark Alley Market?</dt>
                    <dd>Becoming a featured vendor requires:
                        <ul>
                            <li>A minimum of 100 completed orders.</li>
                            <li>A positive reputation score.</li>
                            <li>Active participation in the marketplace community.</li>
                        </ul>
                        Contact the Dark Alley Market Administration to apply for featured vendor status.</dd>

                    <dt>How can I handle disputes with customers?</dt>
                    <dd>Disputes are handled by the Dark Alley Market Dispute Resolution Team. If you encounter a
                        dispute,
                        provide all relevant evidence and communicate clearly with the customer. If the dispute cannot
                        be
                        resolved amicably, it will be escalated to the Dispute Resolution Team for a final decision.
                    </dd>

                    <dt>What happens if I have a technical issue with my vendor account?</dt>
                    <dd>Contact the Dark Alley Market technical support team immediately. Provide a detailed description
                        of the
                        issue and any relevant evidence. The support team will assist you in resolving the technical
                        issue as
                        quickly as possible.</dd>

                    <dt>How do I maintain a good reputation on Dark Alley Market?</dt>
                    <dd>Maintain a high level of customer service, deliver products as described, and resolve disputes
                        promptly.
                        Positive feedback from customers and adherence to Dark Alley Market policies will help you build
                        and
                        maintain a good reputation.</dd>
                </dl>
            </div>

            <div class="bg-card-2 mt-4">
                <div class="bg-card-1">
                    Customer-Specific Questions
                </div>
                <dl>
                    <dt>How can I safely make a purchase on Dark Alley Market?</dt>
                    <dd>Ensure you only purchase from vendors with a good reputation and positive feedback. Use PGP
                        encryption
                        for all communications with vendors. Review the vendor’s terms and conditions before making a
                        purchase.
                        If you have any concerns, contact customer support before completing the transaction.</dd>

                    <dt>What should I do if I encounter a problem with a purchase?</dt>
                    <dd>Contact the vendor first to resolve the issue. If the vendor is unresponsive or the issue cannot
                        be
                        resolved, file a dispute through the Dark Alley Market Dispute Resolution Team. Provide all
                        relevant
                        evidence and communicate clearly to facilitate a resolution.</dd>

                    <dt>How can I leave feedback for a vendor?</dt>
                    <dd>After completing a transaction, you can leave feedback through the Dark Alley Market Marketplace
                        feedback system. Ensure your feedback is honest and provides constructive information to help
                        other
                        customers make informed decisions.</dd>

                    <dt>What should I do if I forget my account password?</dt>
                    <dd>Use the “Forgot Password” feature on the login page to reset your password. You will need access
                        to the
                        email address associated with your account. If you encounter any issues, contact Dark Alley
                        Market
                        support for assistance.</dd>

                    <dt>How do I update my personal information?</dt>
                    <dd>Log in to your Dark Alley Market account and navigate to the “Account Settings” section. Here,
                        you can
                        update your personal information, including your email address and PGP key. Make sure to save
                        any
                        changes you make.</dd>
                </dl>
            </div>

            <div class="bg-card-2 mt-4">
                <div class="bg-card-1">
                    Reputation Tiers and Vendor Badges
                </div>
                <dl>
                    <dt>What are the reputation tiers on Dark Alley Market?</dt>
                    <dd>Dark Alley Market has several reputation tiers based on vendor and customer feedback:
                        <ul>
                            <li>Newcomer: Just joined Dark Alley Market with no or minimal feedback.</li>
                            <li>Trusted: Positive feedback from several transactions.</li>
                            <li>Experienced: High volume of transactions with consistently positive feedback.</li>
                            <li>Elite: Outstanding reputation with a long history of positive feedback and exceptional
                                service.
                            </li>
                        </ul>
                    </dd>

                    <dt>How can I earn badges as a vendor?</dt>
                    <dd>Badges are awarded based on performance and contributions to the marketplace. Common badges
                        include:
                        <ul>
                            <li>Top Seller: Awarded for high sales volume.</li>
                            <li>Customer Favorite: Given for outstanding customer service.</li>
                            <li>Community Contributor: Recognizes active participation in the marketplace community.
                            </li>
                        </ul>
                        To earn badges, consistently deliver high-quality products and service, and actively engage with
                        the
                        marketplace community.</dd>

                    <dt>How can I view my reputation and badges?</dt>
                    <dd>Your reputation and badges can be viewed on your vendor profile page. Regularly check your
                        profile to
                        monitor your reputation tier and any new badges you may have earned.</dd>
                </dl>
            </div>
        </div>

    </div>


</body>

</html>
@endsection