@extends('layouts.buyer.app')       @section('content')

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12 col-12">
            <h5 class="mt-4"> <span class="p-2 bg-light shadow rounded text-success"> Version 1.3.0</span> - 1st April, 2023</h5>
            <ul class="list-unstyled mt-3">
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added Notifications</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added <b>Monero</b> Payment system</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Updated <b>Admin Panel</b></li>
            </ul>
          
            <h5 class="mt-4"> <span class="p-2 bg-light shadow rounded text-success"> Version 1.2.0</span> - 24th March, 2023</h5>
            <ul class="list-unstyled mt-3">
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added Two-Factor Authorization</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added PGP Authorization</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Product Type <b>Auction</b> Used</li>
            </ul>
            
            <h5 class="mt-4"> <span class="p-2 bg-light shadow rounded text-success"> Version 1.1.0</span> - 15th March, 2023</h5>
            <ul class="list-unstyled mt-3">
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Latest Update SVG Design Icons</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added <b>Bitcoin</b> Payment system</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added Colors scheme</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Added Theme switch</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Fixed some responsive issues</li>
            </ul>
      

            <h5 class="mt-4"> <span class="p-2 bg-light shadow rounded text-success"> Version 1.0</span> - 1st March, 2023</h5>
            <ul class="list-unstyled mt-3">
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Initial Released</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Latest <b>Laravel 10.8</b> used</li>
                <li class="text-muted ml-3"><i class="mdi mdi-circle-medium mr-2"></i>Latest <b>Bootstrap 5.4</b> used</li>
            </ul>
          
        </div>
    </div>
</div>
@endsection