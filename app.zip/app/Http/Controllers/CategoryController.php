<?php
namespace App\Http\Controllers;

use App\Models\ProductCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function show($id)
    {
        $category = ProductCategory::findOrFail($id);
        $products = $category->products; // Or include any additional logic
        return view('category.show', compact('category', 'products'));
    }
}
