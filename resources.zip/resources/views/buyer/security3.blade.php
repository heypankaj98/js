@extends('layouts.buyer.app')       @section('content')
    <div class="container my-5">
        <h1 class="text-center">User Control Panel: Become a Vendor</h1>

        <div class="mt-4">
            <p>We are very pleased that you want to become a vendor on Dark Allay and join our informal family.</p>
            <p>We offer vendors as well as customers a long-term and stable platform for decent business relationships...</p>
        </div>

        <div class="info-box">
            <h5 class="text-warning">Please read and understand the following information</h5>
            <p>In addition to the regular marketplace vendor URLs, a vendor also receives a special shop-specific and secret URL.</p>
            <ul>
                <li>Vendor account type Level 1 will be instantly converted to a vendor account.</li>
                <li>Vendor account type Level 2 will be manually verified and converted after verification.</li>
                <li>Vendor account type Level 3 has passed all tests and is seen as the vendor security.</li>
                <li>Your vendor account will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items, we recommend that you create a new account before becoming a vendor.</li>
            </ul>
        </div>

        <div class="warning-box">
            <p>There are rules on this marketplace to ensure that everything runs smoothly and securely.</p>
            <p><strong>Any attempt at fraud, fake feedbacks, etc. will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you...</p>
        </div>
        <div class="container my-5" style="background-color: #2b3035;">
        <div class="p-3 bg-warning text-center">
            <h4>Please read and understand the following information</h4>
        </div>

        <div class="p-4 bg-light">
            <p>In addition to the regular marketplace mirror URLs, a vendor gets access to special preferred and secured mirror URLs, protected by Onion Authentication, to ensure that vendors always have access to their shop.</p>
            <ul>
                <li>Vendor account type <strong class="text-danger">Level 1</strong> will be instantly converted to a vendor account.</li>
                <li>Vendor account type <strong  class="text-danger">Level 2 and 3</strong> will be converted to a vendor account after the verification process is completed.</li>
                <li>A vendor account can only sell, not purchase items - this serves the vendors security.</li>
                <li>Your customer wallet will be converted to a vendor wallet. This means, all ledger history (if exists) will be deleted.</li>
                <li>Your wallet starts new with your current balance less the paid vendor bond.</li>
                <li>The vendor bond will always be displayed in your My Wallet overview.</li>
                <li>If you have already bought items with this account, we recommend that you create a new account for becoming a vendor. The reason for that is, that other vendors can know an address or something else about you from a previous purchase.</li>
            </ul>
        </div>

        <div class="p-4 mt-4 bg-light border border-danger">
            <h5 class="text-center text-danger">There are rules on this marketplace to ensure that everything runs smoothly and secure.</h5>
            <p>Read the Marketplace Rules (<a href="#" class="text-warning">Marketplace Rules</a>) and the Dark Allay Guardian (<a href="#" class="text-warning">Dark Allay Guardian</a>).</p>
            <p><strong class="text-danger">Any attempt at fraud/scam against customers, vendor account or the marketplace, such as attempts to fake feedbacks etc, will be punished with a ban.</strong></p>
            <p>If you want to build a decent business, this is the right place for you and you have nothing to fear. But if you try to scam in any way - no consideration will be given! We treat everyone properly and fair and expect this in return.</p>
            <p><strong>Be faithful to us and we will never be unfaithful to you. Hell yes.</strong></p>
        </div>
    </div>


        <div class="mt-5">
            <h2 class="mb-4">Vendor Account Types</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-center">
                     <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 1</h3>
                            <p>(Unverified)</p>
                            <a href="{{ route('user.security1') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                    <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 2</h3>
                            <p>(Verified, Untrusted)</p>
                            <a href="{{ route('user.security2') }}" class="btn btn-warning">View Conditions</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center">
                   <div class="card-body" style="border:1px solid #ff202d;">
                            <h3>Level 3</h3>
                            <p>(Verified, Trusted)</p>
                            <a href="{{ route('user.security3') }}" class="btn btn-warning" style="background-color:#ff202c;">View Conditions</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       <div class="container my-5">
     <h2>Conditions and requirements for vendor account type: Level 3</h2>
    
    <p><strong>Attention:</strong> BEFORE you open a vendor account, please read and understand the following information:</p>
    
    <ol>
        <li>The necessary conditions will be checked by The Administration.</li>
        <li>Your PGP Public Key must be supplied on the Dark Allay Marketplace.</li>
        <li>You are required to have at least 300 provable sales from a maximum of three other marketplaces combined.</li>
        <li>You have to provide the marketplaces where you are currently active as vendor with the profile URLs or you need a Premium Account on DarkNet Trust (<strong>DarkNet Trust ?!</strong>) with your assigned PGP Public Key and with the linked markets to your DNT Premium Account that we can see your stats.</li>
    </ol>
    
    <p><strong>Notice:</strong> If the provable data belongs to another (old) PGP Public Key as the PGP Public Key that you have supplied on Dark Allay, please also send that PGP Public Key and a Signed PGP Message (belonging to this PGP Public Key) with your request.</p>
    
    <ol>
        <li>There is no vendor bond.</li>
        <li>The vendor marketplace commission for every sale is between 4% to 3%, depending on the classified reputation tier at verification and decreases to 2% with increasing reputation.</li>
        <li>The vendor account becomes trusted status and gets a higher reputation tier after verification.</li>
        <li>The reputation tier is based on the provable provided information.</li>
        <li>Finalize Early (FE) option can be instantly available, according to our assessment. If it is not instantly available, the time to availability is faster than Level 2 vendor account type.</li>
        <li>There are no listing limits.</li>
        <li>Historical vendor feedback with recon will be integrated during the verification process. For DarkNet Trust historical feedback integration, it is necessary that you have a premium account there. This can also be added later if there was no premium account at the verification process, but must be requested by the vendor.</li>
        <li>The vendor's account (supplied PGP Public Key) is integrated with DarkNet Trust.</li>
    </ol>
    
    <p><strong>The conditions are not negotiable.</strong></p>
    


            <div class="d-flex justify-content-between">
                <a href="{{ route('buyer.wallet') }}" class="btn btn-light">View: My Wallet</a>
                <a href="/" class="btn btn-light">Back to: Home</a>
            </div>
        </div>
    </div>
    </div>
@endsection
<style>
    h2{
        background-color: #ff202c;
        text-align: center;
    }
      h1{
        color: #ff7d00;
    }
</style>