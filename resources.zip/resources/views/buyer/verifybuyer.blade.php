@extends('layouts.buyer.app')       
@section('content')
<div class="bg-card-1 security_page mt-4">
    <div class="row">

    @if(auth()->user()->pgp_key)
        <a href="{{ route('user.security2') }}" class="btn btn-primary">Move to step 2</a>
        
        <div class="mb-4 col-md-12">
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.current') }} {{ trans('common.pgp') }} {{ trans('common.key') }}
                </div>
                <div class="card-body">
                    <textarea class="form-control-textarea" disabled rows="5">{{ auth()->user()->pgp_key ?? auth()->user()->pgp_key }}</textarea>
                </div>
            </div>
        </div>
    @endif

    @if(session()->has('verification_name') && session()->get('verification_name') == 'confirm_new_pgp_key')
   <div class="h5 card-header-2 w-100 mb-4">You can Edit/Change your PGP Key Before Verifying.</div>

       <div class="mb-4 col-md-12">
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">
                EDIT PGP KEY
                </div>
                <div class="card-body">
                    <form action="{{ route('post.becomevendor') }}" method='post'>
                        @csrf

                        @if(Session::has('error'))
                            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        @endif
                        <textarea class="form-control-textarea" name="pgp_key" rows="15" >{{ session()->get('pgp_key') }}</textarea>
                        <div class="info-message">* {{ trans('messages.decrypt_message') }}</div>
                        <button type="submit" class="btn btn-main mt-3">
                           Edit PGP Key
                        </button>
                    </form>
                </div>
            </div>
        </div>  
        
        
        
        
        <div class="mb-4 col-md-12">
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.verify') }} {{ trans('common.pgp') }} {{ trans('common.key') }} {{ trans('common.encrypted') }} {{ trans('common.code') }}
                </div>
                <div class="card-body">
                    <form action="{{ route('put.changepgpkey') }}" method="post">
                        @csrf
                        @method('PUT')
                        <textarea class="form-control-textarea" name="pgp_key" disabled rows="5">{{ session()->get('encrypted_message') }}</textarea>
                        <div class="row">
                            <div class="col-12">
                                <label class="mt-2">{{ trans('common.verification') }} {{ trans('common.code') }} *</label>
                                <input type="text" class="form-control" name="verification_code" placeholder="{{ trans('common.verification') }} {{ trans('common.code') }}">
                            </div>
                            <div class="col-auto">
                                <button class="btn text-bg-success m-1" type="submit">{{ trans('common.verify') }}</button>
                                <a href="{{ route('cancelpgpkey') }}" class="btn text-bg-main mt-3">{{ trans('common.cancel') }}</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @else
        <div class="mb-4 col-md-12">
            <div class="bg-card-2 h-100 br1">
                <div class="card-header-2 w-100 mb-4">
                 ADD PGP KEY
                </div>
                <div class="card-body">
                    <form action="{{ route('post.becomevendor') }}" method='post'>
                        @csrf

                        @if(Session::has('error'))
                            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                        @endif
                        <textarea class="form-control-textarea" name="pgp_key" rows="5" >{{ old('pgp_key') }}</textarea>
                        <div class="info-message">* {{ trans('messages.decrypt_message') }}</div>
                        <button type="submit" class="btn btn-main mt-3">
                           Add PGP Key
                        </button>
                    </form>
                </div>
            </div>
        </div>
    @endif

</div>
</div>
@endsection
