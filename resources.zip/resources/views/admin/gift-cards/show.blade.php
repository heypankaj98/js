@extends('layouts.admin.master')
@section('content')
    <div class="mt-4">
        <div class="">
        <div class="row">
        <div class="card-header-2 w-100 mb-4">{{ $giftCard->code }}</div>
            <div class="col-md-12">
           
                <div class="bg-card-2 br1">
                   

                    <div class="card-body">
                        <h5 class="card-title mb0-3">Gift Card Details</h5>

                        <p class="card-text">Amount: <span class="color-accent-2">{{ $giftCard->amount }}</span></p>

                        <p class="card-text">Expiration Date: <span class="color-accent-2">{{ $giftCard->expiration_date ? $giftCard->expiration_date : 'N/A' }}</span></p>

                        @if ($giftCard->used)
                            <p class="card-text">This gift card has already been used.</p>
                        @else
                            <p class="card-text">This gift card has not yet been used.</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        </div>
        
    </div>
@endsection


