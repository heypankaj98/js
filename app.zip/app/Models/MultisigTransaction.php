<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MultisigTransaction extends Model
{
    use HasFactory;
    protected $table = 'multisig_transactions';

    protected $fillable = [
        'multisig_address',
        'multisig_redeem',
        'multisig_amount',
        'listing_id',
        'buyer_id',
        'seller_id',
    ];
}
