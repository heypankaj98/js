<div class="sidebar-menu-content">
    

<h1 class="btn btn-warning w-100 sidebar-title">
    {{ trans('common.user') }} {{ trans('common.panel') }}
</h1>

<div class="sidebar-container">
    <ul class="siddebar-menu">
        <li>
            <ul class="ds-nav-dropdown-items">
                <li class="nav-item">
                   <a href="{{ route('user.dashboard') }}" class="nav-link {{ Route::is('user.dashboard') ? 'text-primary' : '' }}">
<img src="{{ asset('assets/dashboard.png')}}"  alt="alt"/>
<!--<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABmJLR0QA/wD/AP+gvaeTAAABdElEQVQ4jc2UzStEYRSHfy8jwyzIalZKPmbKRrEYsVB2wsbewpKNTIitvZKdJMrCn2CjJpGyUaRQYqjJhpUwyGNzpq7XnQ87v7qd3nOe83Xf7pX+u1ypIJCQNCCp2VxZSRnn3NWfugB9wCHFtQ/0VlpsHvgE3oB1YBjoABLACLAB5I1Jlys2bROcAO0luCRwauxUMajTOp8DjRVs0gRc2CbJMGAH+AJ6ShRpAHaBJTunLGfbB2PAK7AXUqQLWAM2gTNbMx2IZ4AXoC6Y1G/grFesDXj2bnjVYxbMn5KkKvPHzWa9AcckxSSNSpo0353HFHLikhSxw7vZqAc/mR0KNH/0mMKq+eDYSRt72VunHjgKrHsARD1mxWJtQacDboF7oMZLiACD9lR7sVogB1zLFzAXdjGlBCxazkzB5wLBqKQTSa2SxiUdl6mXkrQl6VJSt3Mu/4uw7/WBypX78e4U8vsCWiRNSKrxY54+JG04527KcP9M32Nut9WErk2BAAAAAElFTkSuQmCC" alt="Icon with white stroke">-->
    {{ trans('common.dashboard') }}
</a>

                </li>
                <li class="nav-item">
                    <a href="{{ route('user.profile.index') }}" class="nav-link {{ Route::is('user.profile.index') ? 'text-primary' : '' }}">
             <img src="{{ asset('assets/user (1).png')}}"  alt="alt"/>   
                    {{ trans('common.profile') }}
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('user.orders') }}" class="nav-link {{ Route::is('user.orders') ? 'text-primary' : '' }} ">
             <img src="{{ asset('assets/shopping-bag.png')}}"  alt="alt"/>    
                     {{ trans('common.orders') }}
                    </a>
                </li>
                <!--<li class="nav-item">-->
                <!--    <a href="{{ route('user.bids.index') }}" class="nav-link {{ Route::is('user.bids.index') ? 'text-primary' : '' }} ">-->
                <!--        <b>&#9900;</b> {{ trans('common.bids') }}-->
                <!--    </a>-->
                <!--</li>-->
                <li class="nav-item">
                    <a href="{{route('messenger.index')}}" class="nav-link {{ Route::is('messenger.index') ? 'text-primary' : '' }}">
               <img src="{{ asset('assets/chatting.png')}}"  alt="alt"/>     
                     {{ trans('common.messages') }}
                        @php($unread = \App\Models\QaTopic::unreadCount())
                        @if($unread > 0)
                            <strong>( {{ $unread }} )</strong>
                        @endif
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{route('user.profile.settings')}}" class="nav-link {{ Route::is('user.profile.settings') ? 'text-primary' : ''}}">
                         <img src="{{ asset('assets/setting.png')}}"  alt="alt"/>    
                     {{ trans('common.settings') }}
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{route('dispute')}}" class="nav-link {{ Route::is('dispute') ? 'text-primary' : '' }}">
                         <img src="{{ asset('assets/dispute.png')}}"  alt="alt"/>    
                    {{ trans('common.disputes') }}
                    </a>
                </li>
                    <li class="nav-item">
                    <a href="{{route('buyer.wallet')}}" class="nav-link {{ Route::is('dispute') ? 'text-primary' : '' }}">
                             <img src="{{ asset('assets/wallet1.png')}}"  alt="alt"/>         
                   Wallet
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{route('user.profile.security')}}" class="nav-link {{ Route::is('user.profile.security') ? 'text-primary' : '' }}">
                    <img src="{{ asset('assets/veri.png')}}"  alt="alt"/>     
                    {{ trans('common.security') }}
                    </a>
                </li>
                <li>
                    <a href="{{ route('transactions') }}" class="nav-link {{ Route::is('transactions') ? 'text-primary' : '' }}">
                     <img src="{{ asset('assets/transaction.png')}}"  alt="alt"/>  
                     {{ trans('common.transactions') }}
                    </a>
                </li>
                <li>
                    <a href="{{route('user.tickets.index')}}" class="nav-link {{ Route::is('user.tickets.index') ? 'text-primary' : '' }} ">
                    <img src="{{ asset('assets/ticket.png')}}"  alt="alt"/>   
                     {{ trans('common.tickets') }}
                    </a>
                </li>
                <li>
                    <a href="{{ route('user.gift-cards.index') }}" class="nav-link {{ Route::is('user.gift-cards.index') ? 'text-primary' : '' }} ">
                    <img src="{{ asset('assets/gift-card.png')}}"  alt="alt"/> 
                    {{ trans('common.cards') }}
                    </a>
                </li>
                <!--  <li>-->
                <!--    <a href="{{ route('user.widthwral') }}" class="nav-link {{ Route::is('user.widthwral') ? 'text-primary' : '' }} ">-->
                <!--        <b>&#9900;</b> Withdrawal-->
                <!--    </a>-->
                <!--</li>-->
                                  <li>
                    <a href="{{ route('user.addaderss') }}" class="nav-link {{ Route::is('user.addaderss') ? 'text-primary' : '' }} ">
 <img src="{{ asset('assets/bill.png')}}"  alt="alt"/> 

                    Payment Address
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <hr>


    <form action="{{ route('logout') }}" class="form-horizontal form-horizontal1" method="POST">
        @csrf
        <div class="form-group text-center">
            <button class="dropdown-item" type="submit">{{ trans('common.logout') }} <b>&#10132;</b></button>
        </div>
    </form>
</div>
</div>