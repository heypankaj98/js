@extends('layouts.seller.app')

@section('content')

<div class="p-24 br1 br-4 mt-4">
    <h2 class="card-header-2 w-100 mb-4">Questions for Your Product</h2>

    <div class="table-responsive">
        <table class="table table-prd table-bordered">
            <thead>
                <tr>
                    <th> {{ trans('global.question') }} </th>
                    <th>{{ trans('global.answer') }}</th>
                    <th>{{ trans('global.action') }} </th>
                </tr>
            </thead>
            <tbody>
                @foreach ($product->questions as $question)
                <tr>
                    <td>{{ $question->question }}</td>
                    <td>{{ $question->answer ?: 'No answer yet' }}</td>
                    <td> 
                        @if ($question->answer)
                        <form action="{{ route('seller.questions.delete', $question->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this question?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-xs btn-danger">{{ trans('global.delete') }} </button>
                        </form>
                        @else
                        <form action="{{ route('seller.questions.answer', $question->id) }}" method="POST">
                            @csrf
                            <textarea name="answer" rows="4" class="form-control" placeholder="Enter your answer..."></textarea><br>
                            <button type="submit" class="btn btn-xs btn-primary"> {{ trans('global.submit_answer') }}</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

</div>

@endsection
