<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductQA;

class ProductQAController extends Controller {

    public function store(Request $request, $productId) {
        $request->validate([
            'question' => 'required',
        ]);

        $question = new ProductQA();
        $question->user_id = auth()->user()->id;
        $question->product_id = $productId;
        $question->question = $request->input('question');
        $question->save();

        return redirect()->back()->with('success', 'Question submitted successfully.');
    }

}
