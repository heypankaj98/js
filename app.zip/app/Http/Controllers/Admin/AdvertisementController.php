<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Advertisement;
use App\Rules\FileTypeValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use Gate;
use Symfony\Component\HttpFoundation\Response;

class AdvertisementController extends Controller {

    use MediaUploadingTrait;

    public function index(Request $request) {
         abort_if(Gate::denies('admin_ads_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $pageTitle = "All Advertisements";
        $emptyMessage = "No data found";
        $ads = Advertisement::latest()->paginate(10);
//        dd($ads->first()->getMedia('photo')->first()->getUrl());
        return view('admin.ads.index', compact('pageTitle', 'ads', 'emptyMessage'));
    }

    public function store(Request $request) {
        $request->validate([
            'name' => 'required|max:60',
            'adsize' => 'required|in:540x984,779x80,300x250',
            'redirect_url' => ['required_if:type,1', $request->redirect_url ? 'url' : ''],
            'picture' => ['bail', 'required', 'image', 'mimes:jpeg,jpg,png,webp'],
        ]);

        $advr = new Advertisement();
        $advr->name = $request->name;

        $advr->redirect_url = $request->redirect_url ? $request->redirect_url : null;
        $advr->size = $request->adsize;
        list($width, $height) = explode('x', $request->adsize);
        $request->request->add(['width' => $width]);
        $request->request->add(['height' => $height]);
        $advr->status = $request->status ? 1 : 2;
        $advr->save();
        $input['picture'] = $this->storeMedia($request, 'picture');

        if ($input['picture']) {
            $advr->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
        }

//        $path = imagePath()['advertisement']['path'];
//
//        if ($request->adimage) {
//            list($width, $height) = getimagesize($request->adimage);
//            $size = $width . 'x' . $height;
//            if ($request->size != $size) {
//                $notify[] = ['error', 'Sorry image size has to be ' . $request->size];
//                return back()->withNotify($notify);
//            }
//            try {
//                $advr->image = uploadImage($request->adimage, $path);
//            } catch (\Exception $exp) {
//                $notify[] = ['error', 'Image could not be uploaded.'];
//                return back()->withNotify($notify);
//            }
//        }

        $notify[] = ['success', 'Advertisement has been added'];
        return back()->withNotify($notify);
    }

    public function edit($id) {
        abort_if(Gate::denies('admin_ads_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $pageTitle = "Advertisement Update";
        $ad= Advertisement::findOrFail($id);
        return view('admin.ads.edit', compact('pageTitle', 'ad'));
    }

    public function create() {
      
                  abort_if(Gate::denies('ads_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
                  
        return view('admin.ads.create');
    }

   public function update(Request $request, $id)
{
    $advr = Advertisement::findOrFail($id);
    $request->validate([
        'name' => 'required|max:60',
        'adsize' => 'required|in:540x984,779x80,300x250',
        'redirect_url' => ['required_if:type,1', $request->redirect_url ? 'url' : ''],
        'picture' => ['bail', 'nullable', 'image', 'mimes:jpeg,jpg,png,webp'],
    ]);

    $advr->name = $request->name;
    $advr->redirect_url = $request->redirect_url ? $request->redirect_url : null;
    $advr->size = $request->adsize;
    $advr->status = $request->status ? 1 : 2;
    $advr->save();

    if ($request->hasFile('picture')) {
        // Delete the previous image from the media collection (optional)
        $advr->clearMediaCollection('photo');

        // Upload and save the new image
        $input['picture'] = $this->storeMedia($request, 'picture');
        if ($input['picture']) {
            $advr->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
        }
    }

    $notify[] = ['success', 'Advertisement has been updated'];
    return back()->withNotify($notify);
}


public function delete(Request $request, $id) {
  
    $request->validate([
        'id' => 'required|exists:advertisement,id'
    ]);

    $ads = Advertisement::findOrFail($id);

    $ads->delete();

    $notify[] = ['success', 'Advertisement has been deleted'];
    return back()->withNotify($notify);
}

    public function adclicked($id) {
        $ads = Advertisement::where('id', decrypt($id))->firstOrFail();
        $ads->click += 1;
        $ads->save();
        return redirect($ads->redirect_url);
    }

}
