@extends('seller.messenger.template')
@section('title', $topic->subject)

@section('messenger-content')


<div class="mt-4">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 ">
                <div class="bg-card-2 p-16 mb-4 br1">

                    <div>
                        <h5 class="card-header-2 w-100 mb-4">{{ trans('global.channels') }}</h5>
                        <ul class="list-unstyled chat-sidebar-1">
                            <li><a href="#">{{ trans('global.general') }}</a></li>
                            <li><a href="#">{{ trans('global.announcements') }}</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Users -->

                <div class="bg-card-2 p-16 br1 h-100">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('global.chat_users') }}</h5>
                    <ul class="list-unstyled">
                        @forelse($topics as $singletopic)
                        <li class="mb-2 {{ request()->is("seller.messenger/".$singletopic->id) ? "active" : "" }}" >  <a href="{{ route('seller.messenger.showMessages', [$singletopic->id]) }}">
                                <div class="user_info">
                                    @if($singletopic->receiverOrCreator() !== null && !$singletopic->receiverOrCreator()->trashed())
                                    <img src="{{$singletopic->receiverOrCreator()->avatar}}"   class="rounded-circle">
                                    <div class="d-flex flex-column gap-1">
                                    <span>{{$singletopic->receiverOrCreator()->username}} ( {{ $singletopic->mesasgeUnreadCount() }} ) </span>
                                    <p class="small mb-0 text-success">
                                        {{ trans('global.online') }}
                                        </p>
                                    </div>
                                    @endif
                                </div>
                            </a>
                        </li>
                        @empty
                       {{ trans('global.no_chat_user') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <!-- Chat content -->
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">
                    <h5 class="mb-0">Chat with {{$topic->receiverOrCreator()->username}}</h5>
                </div>
                <div class="bg-card-1">
                    <div class="chat-messages">

                        @foreach($topic->messages as $message)
                        @if($message->sender_id == Auth::user()->id)
                        <div class="message sent">
                            <div class="message-content mw-100  ">
                                <div class="message-header small">
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text">
                                    {{ $message->content }}
                                </div>
                                @if ($message->hasMedia('photo'))
                                <div class="message-text">
                                    <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                        <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                        @else

                        <div class="message received">

                            <div class="message-content mw-100 ">
                                <div class="message-header small">
                                    <img src="{{$message->sender->avatar}}" class="rounded-circle">
                                    <span class="username">{{$message->sender->username}}</span>
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text mw-100">
                                    {{ $message->content }}
                                </div>
                                @if ($message->hasMedia('photo'))
                                <div class="message-text">
                                    <a href="{{$message->getMedia('photo')->first()->getUrl() }}" target="_blank" style="display: inline-block">
                                        <img src="{{ $message->getMedia('photo')->first()->getUrl('thumb') }}">
                                    </a>
                                </div>
                                @endif
                            </div>
                        </div>
                        @endif
                        @endforeach
                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">

                    <form action="{{ route("seller.messenger.reply", [$topic->id]) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group mb-0">
                            <div class="input-group">
                                <input type="file" class="form-control-file" name="picture"  accept="image/*">
                                <textarea type="text" class="form-control-textarea" name="content" placeholder="Type your message..."> </textarea>
                                <button type="submit" class="btn btn-main w-100">{{ trans('global.send') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->
            <div class="bg-card-2 mt-auto mb-4 p-16 br1">
               <h5 class="card-header-2 w-100 mb-4"> {{ trans('global.admin_users') }} </h5>
                <ul class="list-unstyled">
                    @forelse($adminUsers as $adminuser)
                    @if (auth()->user()->id != $adminuser->id)
                    @if($adminuser->withChatMessages($adminuser->id) > 0)
                    <a href="{{ route('seller.messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$adminuser->username}}</span></a>

                    <!--                        <li>  <a href="{{ route('messenger.showMessages', [$adminuser->chatMessages->first()->id]) }}">
                                                    <div class="user_info">
                                                        @if($adminuser->chatMessages->first()->receiverOrCreator() !== null && !$adminuser->chatMessages->first()->receiverOrCreator()->trashed())
                                                        <span>{{$adminuser->chatMessages->first()->receiverOrCreator()->username}} </span>
                                                        <p class="small">online</p>
                                                        @endif
                                                    </div>
                                                </a>
                                            </li>-->
                    @else
                    <a href="{{ route('seller.messenger.newMessages', [$adminuser->id]) }}">     <span class="badge text-bg-primary">{{ $adminuser->username}}</span></a>

                    <!--                        <li>  <a href="{{ route('messenger.newMessages', [$adminuser->id]) }}">
                                                    {{ $adminuser->username}}
                                                </a>
                                            </li>-->
                    @endif
                    @endif
                    @empty
                     {{ trans('global.no_chat_and_admin_here') }} 
                    @endforelse
                </ul>
            </div>
            <!-- Mod --> 
            <div class="bg-card-2 mt-auto p-16 br1">
               <h5 class="card-header-2 w-100 mb-4"> {{ trans('global.mod_users') }} </h5>
                <ul class="list-unstyled">
                    @forelse($moderatorUsers as $moduser)
                    @if (auth()->user()->id != $moduser->id)
                    @if($moduser->withChatMessages($moduser->id) > 0)
                    <a href="{{ route('seller.messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">     <span class="badge text-bg-primary">{{$moduser->username}}</span></a>

                    <!--                    <li>  <a href="{{ route('messenger.showMessages', [$moduser->chatMessages->first()->id]) }}">
                                                <div class="user_info">
                                                    @if($moduser->chatMessages->first()->receiverOrCreator() !== null && !$moduser->chatMessages->first()->receiverOrCreator()->trashed())
                                                    <span>{{$moduser->chatMessages->first()->receiverOrCreator()->username}}</span>
                                                    <p class="small">online</p>
                                                    @endif
                                                </div>
                                            </a>
                                        </li>-->
                    @else
                    <a href="{{ route('seller.messenger.newMessages', [$moduser->id]) }}">     <span class="badge text-bg-primary">{{ $moduser->username}}</span></a>
                    <!--                    <li>  <a href="{{ route('messenger.newMessages', [$moduser->id]) }}">
                                                {{ $moduser->username}}
                                            </a>
                                        </li>-->
                    @endif
                    @endif
                    @empty
                    {{ trans('global.no_chat_and_mod_user') }}  
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>





@stop