<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dark Alley Market - Categories</title>
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <style>
        body {
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
        }

        .menu-wrapper {
            padding: 0px;
        }

        .menu-item {
            margin-bottom: 10px;
        }

        .menu-item-header {
            display: flex;
            align-items: center;
            background-color: #597B8D;
            padding: 6px 10px;
            border-radius: 4px 4px 0 0;
            cursor: pointer;
            transform: none;
            margin: 0;
            width: 100%;
            height: auto;
            text-align: center;
            border-bottom: 1px solid #008C00;
            margin-bottom: 15px;
        }
nav#sidebarMenu label.menu-item-header:hover{background:#FF0000}
        .menu-item-link {
            text-decoration: none;
            color: black;
            transform: none;
        }

        .expand-toggle {
            margin-right: 10px;
        }

        .menu-item-link {
            color: #fff;
            text-decoration: none;
            flex-grow: 1;

        }

        .submenu-list .menu-item-link {
            color: black;
    margin-left: 7px;
    padding: 4px 12px;
    display: block;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    height: auto;
    background: white;
    transform: skew(202deg);
    width: 94%;
    text-align: center;
    font-size: 14px;
        }
        .submenu-list .menu-item-link span{transform: skew(-202deg); display:block}
        .submenu-list .menu-item-link:hover{
            background: #FF7D00;
            color:#000;
            
        }

        .back-color-green1,
        .back-color-green2,
        .back-color-green3 {
            background-color: #dc3545;
            border-radius: 50%;
            padding: 5px;
            color: #fff;
        }

        .submenu-list {
            padding-left: 0px;
            margin-top: 5px;
        }

        .submenu-item {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <nav id="sidebarMenu" class="sidebar-menu col-md-12 col-lg-3 d-md-block">
        <div class="sidebar-menu-content">
            <div class="menu-wrapper">
                <div class="menu-item">
                    <label class="menu-item-header">
                        
                        <a href="#" class="menu-item-link">Marketplace</a>
                    </label>
                    <ul class="submenu-list list-unstyled">
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>News Archive</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>FAQ</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Marketplace Rules</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Find Us Here</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Mirror URLs</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>PGP Public Keys</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Dark Alley Guardian</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>About Us</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Charities</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Development / Changelog</span></a></li>
                    </ul>
                </div>
                <!-- Vendor Information -->
                <div class="menu-item">
                    <label class="menu-item-header">
                        
                        <a href="#" class="menu-item-link">Vendor Information</a>
                    </label>
                    <ul class="submenu-list list-unstyled">
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>My Vendor Shop: Screenshots </span></a>
                        </li>
                    </ul>
                </div>
                <!-- Partnerships -->
                <div class="menu-item">
                    <label class="menu-item-header">
                        
                        <a href="#" class="menu-item-link"><span>Partnerships</span></a>
                    </label>
                    <ul class="submenu-list list-unstyled">
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Breaking Bad</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Tape News: Exclusive Interview</span></a>
                        </li>
                    </ul>
                </div>
                <!-- Help / Tutorials -->
                <div class="menu-item">
                    <label class="menu-item-header">
                        
                        <a href="#" class="menu-item-link">Help / Tutorials</a>
                    </label>
                    <ul class="submenu-list list-unstyled">
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>PGP</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>2FA Security</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>Crypto Wallets</span></a></li>
                        <li class="submenu-item"><a href="#" class="menu-item-link"><span>DarkDotNet</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</body>

</html>