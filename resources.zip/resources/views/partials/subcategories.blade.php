{{-- subcategories partial --}}
@php  $indent = 0; $indent++; @endphp
<ul class="list-group">
    @foreach($subcategories as $subcategory)
        <li class="list-group-item pl-{{ $indent }}">
           <a href="{{ route('products.by.category', $subcategory) }}"> {{ $subcategory->name }} ( {{$subcategory->totalProducts()}} )</a> 
            @if(count($subcategory->subcategory))
                @include('partials.subcategories', ['subcategories' => $subcategory->subcategory])
            @endif
        </li>
    @endforeach
</ul>