@extends('footer-links.layout')
@section('content')

<div class="container-fluid bg-grey">
    <div class="text-center">
        <br>
        <h2 class="title">{{ trans('global.site_title') }} - {{ trans('footer.vendor_rules') }}</h2>
        <br>
        <h6 class="text-light"><a href="{{route('home')}}" class="decoration text-light">{{ trans('global.home') }}</a>&nbsp;\&nbsp;{{ trans('footer.vendor_rules') }}</h6>
    </div>
    <br>
</div>
<div class="container-fluid">
    <div class="row">
        <main class="col-md-12 ms-sm-auto col-lg-9 px-md-4 deshboard_right_main">
            <section class="blog-section pt-120 pb-120">
                <div class="container">
                    <div class="row gy-5 justify-content-between">
                        <div class="col-lg-12">
                            <div class="post__details">
                                <br> {!! trans('footer.vendor_rules_data') !!}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>
</div>
@endsection