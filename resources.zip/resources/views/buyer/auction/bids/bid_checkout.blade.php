@extends('layouts.nosidebar')       @section('content')

@if(Session::has('error'))
    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
@endif

<div class="container mt-4">
    <div class="row g-5">
        <div class="col-md-7 col-lg-8">
            <h4 class="my-4">{{ trans('global.your_bid_price') }}  </h4>
            <div class="row my-4">
                <div class="col">
                    <input class="btn btn-light col-4 f40" value="$ {{ $buy_price }}" disabled>
                </div>
            </div>
            <hr>
            <form class="needs-validation" action="{{ route('user.auction.bid.checkout', $auction->id) }}" method="POST">
                @csrf
                
                @if(Session::has('error'))
                    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('error') }}</p>
                @endif
                
                <h4 class="my-3">{{ trans('global.choose_a_payment') }} </h4>
                <div class="my-3">
                    @foreach(config('coins.coin_list') as $index => $coin)
                        <div class="form-check">
                            <input id="credit" name="payment_method" type="radio" class="form-check-input" value="{{$coin}}" checked required>
                            <label class="form-check-label" for="credit">{{$coin}} [{{$index}}]</label>
                        </div>
                    @endforeach
                </div>
                <small>{{ trans('global.note_bid_will_be_make') }} </small>
                <hr>
                <button class="w-100 btn btn-primary btn-lg" type="submit">{{ trans('global.place_a_bid') }} </button>
            </form>
        </div>
    </div>
</div>

@endsection