<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class QaMessage extends Model implements HasMedia {

    use InteractsWithMedia;

    protected $fillable = [
        'topic_id',
        'sender_id',
        'content',
        'read_at',
    ];
    protected $dates = [
        'sent_at',
    ];

    public function topic() {
        return $this->belongsTo(QaTopic::class);
    }

    public function sender() {
        return $this->hasOne(User::class, 'id', 'sender_id')->withTrashed();
    }

    public function registerMediaConversions(Media $media = null): void {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
    }

    public function getPhotoAttribute() {
        $file = $this->getMedia('photo')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
        }
        return $file;
    }

}
