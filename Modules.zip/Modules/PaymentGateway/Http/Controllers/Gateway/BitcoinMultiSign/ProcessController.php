<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\BitcoinMultiSign;

use App\Http\Controllers\Controller;
use Modules\PaymentGateway\Http\Controllers\Gateway\BitcoinMultiSign\BitcoinPayment;

class ProcessController extends Controller {

    public static function generateAddress($params) {
        $node = new BitcoinPayment();
        $address = $node->generateAddress($params);
        return $address;
    }

    public static function getaddressinfo($params) {
        
        $node = new BitcoinPayment();
        
        $address = $params['address'];
        
        $address_info = $node->getaddressinfo($address);
       
        return $address_info;
    }

    public static function getBalance($params = []) {
        $node = new BitcoinPayment();
        $balance = $node->getBalance($params);
        return $balance;
    }

    public static function getTransactionFee($params = []) {
        $node = new BitcoinPayment();
        $fee = $node->getBalance($params);
        return $fee;
    }

    // Create a multisig address
//$publicKeys = ['public_key1', 'public_key2', 'public_key3'];
//$requiredSignatures = 2;
//$address = createMultiSigAddress($publicKeys, $requiredSignatures);

    public static function createMultiSigAddress($params) {
      
        $publicKeys = $params['pub_keys_array'];
        $requiredSignatures = $params['required_signatures'];
        $node = new BitcoinPayment();
        $address = $node->createMultiSigAddress($publicKeys, $requiredSignatures);
        return $address;
    }

//     Create a multisig transaction
//$transactionInputs = [
//    ['address' => 'sender_address', 'amount' => 0.5]
//];
//$transactionOutputs = [
//    ['address' => 'receiver_address', 'amount' => 0.5]
//];
//$rawTransaction = createMultiSigTransaction($transactionInputs, $transactionOutputs, $requiredSignatures);


    public static function createMultiSigTransaction($params) {
        $node = new BitcoinPayment();
        $rawTransaction = $node->createMultiSigTransaction($params);
        return $rawTransaction;
    }

    // Sign a multisig transaction
//$privateKeys = ['private_key1', 'private_key2'];
//$signedTransaction = signMultiSigTransaction($rawTransaction, $privateKeys);

    public static function signMultiSigTransaction($params) {
        $node = new BitcoinPayment();
        $signedTransaction = $node->signMultiSigTransaction($params);
        return $signedTransaction;
    }



    public static function dumpPrivateKey($params) {
        $node = new BitcoinPayment();
        $private_key = $node->dumpPrivateKey($params);
        return $private_key;
    }

    public static function getAddressFromPublicKey($params) {
        $node = new BitcoinPayment();
        $private_key = $node->getAddressFromPublicKey($params);
        return $private_key;
    }

    public static function getMultisigTxId($params) {
        $node = new BitcoinPayment();
        $private_key = $node->getMultisigTxId($params);
        return $private_key;
    }

    public static function createRawTransaction($params) {
        $node = new BitcoinPayment();
        $private_key = $node->createRawTransaction($params);
        return $private_key;
    }

    public static function listunspent($params) {
        $node = new BitcoinPayment();
        $private_key = $node->listunspent($params);
        return $private_key;
    }
    // Send a multisig transaction
//$txid = sendMultiSigTransaction($signedTransaction);

    public static function sendMultiSigTransaction($signedTransaction) {
        $node = new BitcoinPayment();
        $txid = $node->sendMultiSigTransaction($signedTransaction);
        return $txid;
    }
    public static function sendrawtransaction($signedTransaction) {
        $node = new BitcoinPayment();
        $txid = $node->sendrawtransaction($signedTransaction);
        return $txid;
    }
}
