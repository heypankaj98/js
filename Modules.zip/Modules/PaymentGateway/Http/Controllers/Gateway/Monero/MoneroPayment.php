<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Monero;

use Modules\PaymentGateway\Http\Controllers\Gateway\Monero\MoneroLib\walletRPC;
use App\Models\ExceptionModel;

class MoneroPayment
{
    private $monerod;

    public function __construct()
    {
        $this->monerod = new walletRPC([
            'host' => config('coins.monero.wallet_host'),
            'port' => config('coins.monero.wallet_port'),
            'user' => config('coins.monero.wallet_username'),
            'password' => config('coins.monero.wallet_password')
        ]);
    }

    /**
     * Validate Monero address.
     *
     * @param string $address
     * @throws \Exception
     */
    public function validateAddress($address)
    {
        $result = $this->monerod->validate_address($address);
        if (!$result['valid']) {
            throw new \Exception('The address entered is invalid!');
        }
    }

    /**
     * Create a new Monero account for the registered user.
     *
     * @param string|null $tag
     * @return array
     */
   public function createNewAccount($params = null): array
{
    try {
       
        $tag=$params['username'];
        $account = $this->monerod->create_account($tag);
   
        
        // Label the account using the account index
          $this->monerod->tag_accounts(array($account['account_index']), $tag);
        
        return [
            'account_index' => $account['account_index'], 
            'address' => $account['address'],
        ];
    } catch (\Exception $exception) {
       
        
        return $this->logException($exception);
    }
}
 


    /**
     * Create a new Monero address.
     *
     * @param string|null $paymentID
     * @return array
     */
    public function createNewAddress($tag = null)
    { 
        
         try {
             if(!$tag){
                $account_index=0; 
             }else{
                $tag = $tag['username'];
  
             $accounts = $this->monerod->get_accounts($tag);

                $account_index= $accounts['subaddress_accounts'][0]['account_index'];
             }    
        $result= $this->monerod->create_address($account_index,$tag);
            return $result['address'];
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get wallet balance.
     *
     * @return float
     */
    public function getWalletBalance()
{
    try {
        // Fetch all accounts
        $accounts = $this->monerod->get_accounts();

        // Initialize a variable to hold the total balance
        $totalBalance = 0;

        // Loop through each account and add its balance to the total
        foreach ($accounts['subaddress_accounts'] as $account) {
            // Fetch the balance for each account
            $balance = $this->monerod->get_balance($account['account_index']);
            $totalBalance += $balance['balance'];
        }

        // Convert from atomic units to full Monero units (divide by 1e12)
        return (float)$totalBalance / 1e12;
    } catch (\Exception $exception) {
        return $this->logException($exception);
    }
}


    /**
     * Get detailed wallet info.
     *
     * @return array
     */
    public function getWalletData()
    {
        try {
            return $this->monerod->get_wallet_info();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get balance from a certain account.
     *
     * @param array|null $params
     * @return float|array
     */
    public function getBalance(array $params = null)
    { 
        try {
            if (isset($params['tag'])) {
                $tag = $params['tag'];
                $account = $this->monerod->get_accounts($tag);
       
                // $this->getAddressBalance($params);
                return number_format($account['total_balance'] * 1e-12, 5);
            }
            throw new \InvalidArgumentException('Missing required parameter: tag.');
        } catch (\Exception $exception) {
          
            return $this->logException($exception);
        }
    }
    
    
    
    /**
     * Calculate the balance of a specific address.
     *
     * @param string $address
     * @return float
     */
    public function getAddressBalance($params)
{
    $address = $params['address'];

    try {
        // Get the address index
        $addressIndex = $this->monerod->get_address_index($address);
      
        if (empty($addressIndex['index'])) {
            throw new \Exception('Address not found.');
        }

        // Fetch the transactions involving the address
        $transactions = $this->monerod->get_transactions();
        

        $balance = 0.0;

        // Iterate through the incoming transactions
        if (!empty($transactions['in'])) {
            foreach ($transactions['in'] as $tx) {
                // Check if the address matches
                if ($tx['address'] === $address) {
                    $balance += $tx['amount'];
                }
            }
        }

        // Deduct the outgoing transactions if any
        if (!empty($transactions['out'])) {
            foreach ($transactions['out'] as $tx) {
                // Check if the address matches
                if ($tx['address'] === $address) {
                    $balance -= $tx['amount'];
                }
            }
        }

        // Convert from smallest unit (piconero) to Monero
        return $balance / 1e12;

    } catch (\Exception $exception) {
       
        // Log and return exception
        return $this->logException($exception);
    }
}



    /**
     * Transfer Moneros.
     *
     * @param array $params
     * @return array
     */
   public function transfer(array $params): array
{
    try {
        $toAddress = $params['address'] ?? null;
        $amount = $params['amount'] ?? 0.0;
        $accountTag = $params['tag'] ?? null;

        if (is_null($toAddress)) {
            throw new \InvalidArgumentException('Missing required parameter: address.');
        }

        // Fetch accounts information
        $result = $this->monerod->get_accounts($accountTag);

        // Debug the result (you may remove this in production)
       
        // Check if 'subaddress_accounts' key exists and is an array
        if (!isset($result['subaddress_accounts']) || !is_array($result['subaddress_accounts'])) {
            throw new \RuntimeException('Invalid response format or empty accounts list.');
        }

        $accounts = $result['subaddress_accounts'];

        // Find account with non-zero balance
        $accountIndexes = array_column($accounts, 'account_index');
        $nonEmptyAccounts = array_filter($accounts, function($account) {
            return $account['balance'] > 0;
        });

        if (empty($nonEmptyAccounts)) {
            throw new \RuntimeException('No account with non-zero balance found.');
        }

        // Choose the first account with a non-zero balance (or implement other logic if needed)
        $firstNonEmptyAccount = reset($nonEmptyAccounts);
        $accountIndex = $firstNonEmptyAccount['account_index'];

        $subaccountIndexes=[];

    

            return $this->monerod->transfer($amount , $toAddress, $accountIndex, $subaccountIndexes);
        } catch (\Exception $exception) {
            
            return $this->logException($exception);
        }
    }
    
    public function primary_transfer(array $params): array
{ 
//   $result = $this->monerod-> get_account_tags();

  
    //  $result = $this->monerod->get_accounts($params['label']);
   $result= $this->getAccountAddresses($params['account_index']);
     $addresses = $result['addresses'] ?? [];
   

        // Filter addresses to get used ones and extract their indices
        $subaddrIndices = array_filter(array_map(function($address) {
            return $address['used'] ? $address['address_index'] : null;
        }, $addresses));
      $subaddrIndices = array_values($subaddrIndices);
     
    
    try {
        $toAddress = $params['address'] ?? null;
        $amount = $params['amount'] ?? 0.0;
        $accountIndex = $params['account_index'] ?? 0;
        $subaddrIndices =  [0];
        $priority = $params['priority'] ?? 0;
        $ringSize = $params['ring_size'] ?? 7;
        $getTxKey = $params['get_tx_key'] ?? true;
     
        // Execute the transfer using the Monero JSON-RPC API
        $result = $this->monerod->primary_transfer($amount,$toAddress,$accountIndex,$subaddrIndices);
     
        // Return the result of the transfer
        return $result;
    } catch (\Exception $exception) {
       
        
        // Log the exception and return an error message
        $this->logException($exception);
        return [
            'error' => true,
            'message' => $exception->getMessage()
        ];
    }
}
    

    /**
     * Get the address for a specific account.
     *
     * @param int $accountIndex
     * @return string
     */
    public function getAddress($accountIndex)
    {
        try {
            $result = $this->monerod->get_address($accountIndex);
            return $result['address'];
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Label an address.
     *
     * @param int $index
     * @param string $label
     * @return array
     */
    public function labelAddress($index, $label)
    {
        try {
            return $this->monerod->label_address($index, $label);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Get transactions from the wallet.
     *
     * @return array
     */
    public function getTransactions()
    {
        try {
            return $this->monerod->get_transactions();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }
      public function getAccountTransactions($accountIndex)
    {
        try {
            return $this->monerod->getAccountTransactions($accountIndex);
        } catch (\Exception $exception) {
            dd($exception);
            return $this->logException($exception);
        }
    }
    
      public function getAccountAddresses($accountIndex)
    {
        try {
            return $this->monerod->getAccountAddresses($accountIndex);
        } catch (\Exception $exception) {
            dd($exception);
            return $this->logException($exception);
        }
    }
    
    
    
   public function getAllAccountsInfo()
    {
        try {
            return $this->monerod->getAllAccountsInfo();
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }
    /**
     * Get the index of a specific address.
     *
     * @param string $address
     * @return array
     */
    public function getAddressIndex($address)
    {
        try {
            return $this->monerod->get_address_index($address);
        } catch (\Exception $exception) {
            return $this->logException($exception);
        }
    }

    /**
     * Log exception and return error response.
     *
     * @param \Exception $exception
     * @return array
     */
    private function logException(\Exception $exception): array
    {
      
        $errorCode = 'xmr-wallet-' . mt_rand(1000, 9999);
        $errorMessage = 'An error occurred. Please create a support ticket with ERROR CODE ' . $errorCode . '.';

        $exceptionLog = new ExceptionModel();
        $exceptionLog->error_code = $errorCode;
        $exceptionLog->error_message = $exception->getMessage();
        $exceptionLog->save();

        return ['error_code' => $errorCode, 'error_message' => $errorMessage];
    }
}
