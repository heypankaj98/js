@extends('layouts.seller.app')      @section('content')

<div class="bg-card-1">
<h2 class="custom-title my-4">Products</h2>
    <div class="row justify-content-center">
        <div class="col-md-12">
            
            @can('seller_manage_products')
                <div class="row">
                    <div class="dropdown">
                        <button class="btn btn-main d-flex gap-3 align-items-center dropdown-toggle" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                            {{ trans('common.add') }} {{ trans('common.product') }}
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="{{ route("seller.products.create", ['page' => 'digital']) }}">
                                {{ trans('common.digital') }}
                            </a>
                            <a class="dropdown-item" href="{{ route("seller.products.create", ['page' => 'physical']) }}">
                                {{ trans('common.physical') }}
                            </a>
                        </ul>
                    </div>
                </div>
            @endcan

            <div class="bg-card-2 mb-4 br1 mt-4">
                <div class="card-header-2 w-100 mb-4">
                    {{ trans('common.product') }} {{ trans('common.list') }}
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-prd table-striped table-hover datatable datatable-Product mb-4">
                            <thead>
                                <tr>
                                    <th>
                                         {{ trans('common.id') }}
                                    </th>
                                    <th>
                                         {{ trans('common.name') }}
                                    </th>
                                    <th>
                                         {{ trans('common.type') }}
                                    </th>
                                    <th>
                                         {{ trans('common.price') }}
                                    </th>
                                    <th>
                                         {{ trans('common.category') }}
                                    </th>
                                    <th>
                                        Clone Product
                                    </th>
                                    <th>
                                         {{ trans('common.photo') }}
                                    </th>
                                    <th class="text-center">
                                        {{ trans('common.action') }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($products as $key => $product)
                                    <tr data-entry-id="{{ $product->id }}">
                                        <td>
                                            {{ $product->id ?? '' }}
                                        </td>
                                        <td>
                                            {{ $product->name ?? '' }}
                                        </td>
                                        <td>
                                            {{ isset($product->type) ? trans('common.' . $product->type) : '' }}
                                        </td>
                                        <td>
                                            $ {{ $product->price ?? '' }}
                                        </td>
                                        <td>
                                            {{ $product->categories->name  ?? '' }}
                                        </td>
                                        <td>
                                        <form action="{{ route('seller.products.clone', $product->id) }}" method="POST"
                                            style="display:inline;">
                                            @csrf
                                            <button type="submit" class="btn btn-primary custom-btn btn-sm"
                                                style="margin-top:35px; background-color:#32CD32">Clone Product</button>
                                        </form>
                                    </td>
                                        <td>
                                            @if($product->photo)
                                            <a href="{{ $product->photo->getUrl() }}" target="_blank" class="d-block text-center">
                                                <img class="br-4" src="{{ $product->photo->getUrl('thumb') }}">
                                            </a>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="text-center">
                                            @can('seller_manage_products')
                                                <a class="btn btn-primary btn-sm br-4" href="{{ route('product.details', $product->id) }}">
                                                    {{ trans('common.view') }}
                                                </a>
                                            @endcan
                                            
                                            @can('seller_manage_products')
                                                <a class="btn btn-info btn-sm br-4" href="{{ route('seller.products.edit', ['product' => $product->id, 'page' => $product->type]) }}">
                                                    {{ trans('common.edit') }}
                                                </a>
                                            @endcan
    
                                            @can('admin_product_delete')
                                                <form action="{{ route('seller.products.destroy', $product->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');"  class="d-inline-block">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                                    <input type="submit" class="btn btn-danger btn-sm br-4" value="{{ trans('common.delete') }}">
                                                </form>
                                            @endcan
    
                                            <a class="btn btn-light btn-sm br-4" href="{{ route('seller.questions', $product->id) }}">
                                                {{ trans('common.view') }} {{ trans('common.qna') }}
                                            </a>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-center" colspan="100%">
                                            {{ trans('common.no') }} {{ trans('common.products') }}.
                                        </td>
                                    </tr>
                                @endforelse
                                
                            </tbody>
                        </table>
                        {{ $products->links('partials.pagination') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection