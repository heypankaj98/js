@extends('layouts.buyer.app')

@section('content')

<div class="mt-4">
    <div class="row">
        <div class="col-md-6">
            <div class="bg-card-2 br1">
                <div class="card-header-2 w-100 mb-4">Edit Address</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('user.adderss.update') }}">
                        @csrf
                        @method('POST')

                        <div class="form-group">
                            <label for="coin">Select Type</label>
                             <select class="form-control py-0 my-3" id="currency" name="coin">
                                <option value="btc_address">Bitcoin (BTC)</option>
                                <option value="xmr_address">Monero (XMR)</option>
                                <option value="ltc_address">Litecoin (LTC)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="addresses">Edit Address</label>
                            <input type="text" class="form-control my-3" id="addresses" name="addresses" value="" required>
                        </div>
                        <button type="submit" class="btn btn-main">Update Address</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
