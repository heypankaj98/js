<?php
namespace App\Http\Controllers\Seller;

use Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SellerMarketplace;

class SellerMarketplaceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth'); 
    }

    // Method to store a new marketplace
    public function store(Request $request)
    {
        // Ensure the user is authenticated
        $user = Auth::user();

        // Check if the user is logged in
        if (!$user) {
            return redirect()->route('login')->with('error', 'You must be logged in to add a marketplace.');
        }

        // Check the count of records the user has added
        $recordCount = SellerMarketplace::where('user_id', $user->id)->count();

        // Restrict the user if they have added 5 or more records
        if ($recordCount >= 5) {
            return redirect()->back()->with('error', 'You can only add up to 5 marketplaces.');
        }

        // Validate request
        $request->validate([
            'market_placename' => 'required|string|max:255',
            'seller_name' => 'required|string|max:255',
            'sales' => 'required|integer|min:0',
            'rating' => 'required|numeric|min:0|max:5',
            'product_category' => 'nullable|string|max:255',
        ]);

        // Store in database, including the user_id
        SellerMarketplace::create([
            'user_id' => $user->id,  // Assign the authenticated user's ID
            'market_placename' => $request->market_placename,
            'seller_name' => $request->seller_name,
            'sales' => $request->sales,
            'rating' => $request->rating,
            'product_category' => $request->product_category,
        ]);

        // Redirect with success message
        return redirect()->back()->with('success', 'Marketplace added successfully!');
    }

    // New method to display all marketplaces for the authenticated user
    public function showMarketplaces()
    {
        // Get the authenticated user
        $user = Auth::user();

        // Fetch marketplaces associated with the authenticated user
        $marketplaces = SellerMarketplace::where('user_id', $user->id)->get();

        // Return the view with the data
        return view('seller.marketplaces', compact('marketplaces'));
    }

    // Method to render a verify page (unchanged from your original code)
    public function getVerified()
    {
        return view('seller.verify');
    }
}
