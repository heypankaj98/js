@extends('layouts.nosidebar')
@section('content')

<div class="container">
   <div class="verification_section my-5 my-3 p-2 p-lg-5 radius-5 reset_password_section">
        <div class="row">
            <div class="col">
                <h5 class="card-title fw-bold pb-4 mb-5">{{ trans('footer.condition_of_use') }} | {{ trans('global.site_title') }}</h5>
            </div>
        </div>
        <div class="verification-market-right col-md-12 pe-3 pe-md-5">
            <div class="margin_auto border_none">
                <div class="p-0">
                    <div class="form_reset_main">   
                        <p class="text-20 fw-semibold">{{ trans('footer.effective') }}: [9-{{ trans('global.jul') }}-2023]</p>
                        <div class="form-group mb-3">
                            <i>&emsp;Welcome to <b>Shopzo Market</b>! These Conditions of Use govern your use of our website and services. By accessing or using <b>Shopzo Market</b>, you agree to be bound by these conditions. Please read them carefully before using our services.</i><br><br>
                            <b>Account Registration<br>
                            1.1</b> To use all features of <b>Shopzo Market</b>, you may need to create an account. You must provide information during the registration process and keep your account information up to date. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.<br><br>
                            <b>1.2</b> You must be at least 18 years old to create an account and use our services. If you are under 18, you may use <b>Shopzo Market</b> only with the involvement of a parent or guardian.<br><br>
                            <b>Product Listings and Orders<br>
                            2.1 Shopzo Market</b> acts as a platform for sellers to list and sell their products. We strive to ensure the accuracy and completeness of the product listings, but we do not guarantee the availability, quality, or legality of the products listed on our platform. Any purchase you make through <b>Shopzo Market</b> is solely between you and the seller.<br><br>
                            <b>2.2</b> When placing an order, you agree to provide accurate and complete information, and to comply with any additional terms and conditions specified by the seller.<br><br>
                            <b>2.3 Shopzo Market</b> reserves the right to refuse or cancel any order for any reason, such as if the product is out of stock, if there are inaccuracies in the listing, or if there is suspicious or fraudulent activity associated with the order.<br><br>
                            <b>Vendor Rules<br>
                            3.1</b> You may use <b>Shopzo Market</b> only for a purpose and in accordance with these Conditions of Use. You agree not to engage in any activity that:<br><br>
                                <b>a).</b> You will be the sole owner of this account.<br>
                                <b>b).</b> You will not engage in artificially enhancing your feedback scores.<br>
                                <b>c).</b> You will not have more than one vendor account.<br>
                                <b>d).</b> You will not keep buyers' personal information after a transaction.<br>
                                <b>e).</b> You will not ask for FE unless you have been granted permission.<br>
                                <b>f).</b> You will not sell or promote items listed under forbidden goods.<br><br>
                            <b>3.2</b> In addition Vendors are expected to:<br>
                                <b>a).</b> Charge reasonable shipping and handling costs.<br>
                                <b>b).</b> Specify shipping costs and handling time in the listing.<br>
                                <b>c).</b> Follow through on your return policy.<br>
                                <b>d).</b> Respond to buyers' questions promptly.<br>
                                <b>e).</b> Be helpful, friendly, and professional throughout a transaction.<br>
                                <b>f).</b> Make sure the item is delivered to the buyer as described in the listing.<br>
                                <b>e).</b> Encrypt communication between you and the buyer where possible.<br><br>
                            <b>3.3</b> An One-time deposit of 1500 USD in XMR/LTC/BTC to be deducted from your account.<br><br>
                            <b>3.4</b> Forfeit the ability to buy any product using this account.<br><br>
                            <b>3.5</b> Provide a PGP key in your public profile.<br><br>
                            <b>Intellectual Property<br>
                            4.1</b> All content on <b>Shopzo Market</b>, including but not limited to text, graphics, logos, images, audio clips, and software, is the property of <b>Shopzo Market</b> or its licensors and is protected by intellectual property laws. You may not use, reproduce, distribute, or modify any content from <b>Shopzo Market</b> without prior written permission from <b>Shopzo Market</b>.<br><br>
                            <b>Limitation of Liability<br>
                            5.1 Shopzo Market</b>, its admin, and their respective mediators, or agents will be liable for any direct, indirect, incidental, consequential, or punitive damages arising out of or relating to your use of Shopzo Market or any products purchased through it.<br><br>
                            <b>Termination<br>
                            6.1 Shopzo Market</b> may terminate or suspend your access to the website and services, without prior notice or liability, for any reason, including if you violate these Conditions of Use.<br><br>
                            <b>Changes to the Conditions of Use<br>
                            7.1 Shopzo Market</b> reserves the right to modify or update these Conditions of Use at any time. Any changes will be effective immediately upon posting the updated conditions on the website. It is your responsibility to review these conditions periodically.<br><br>
                            <b>Forbidden Goods<br>
                            8.1</b> Market have some rules and Forbidden goods<br>
                            <b>1.</b> Guns<br>
                            <b>2.</b> Revenge porn<br>
                            <b>3.</b> Selling personal data collected from other D.N website<br>
                            <b>4.</b> Poisons<br>
                            <b>5.</b> Explosives<br>
                            <b>6.</b> Assassination services<br>
                            <b>7.</b> Anything related with kids.  (Space Travels is only for amateur)<br><br>
                            If you have any questions or concerns about these Conditions of Use, please contact us at [<span class="text-primary">shopzo@protonmail.com</span>].<br><br>
                            <i>By using <b>Shopzo Market</b>, you agree to abide by these Conditions of Use.</i>
                            @guest
                            <div class="karyx_main">
                                <div class="create_btn mt-2">
                                    <a href="{{ route('login') }}" class="fw-semibold text-decoration-none btn_create text-center d-block"> 
                                        <svg xmlns="http://www.w3.org/2000/svg" class="me-2" width="19" height="8" viewBox="0 0 19 8" fill="none">
                                         <path d="M0.646447 4.35355C0.451184 4.15829 0.451184 3.84171 0.646447 3.64645L3.82843 0.464465C4.02369 0.269203 4.34027 0.269203 4.53553 0.464465C4.7308 0.659727 4.7308 0.976309 4.53553 1.17157L1.70711 4L4.53553 6.82843C4.7308 7.02369 4.7308 7.34027 4.53553 7.53553C4.34027 7.73079 4.02369 7.73079 3.82843 7.53553L0.646447 4.35355ZM19 4.5L1 4.5L1 3.5L19 3.5L19 4.5Z" fill="#01509F"/>
                                        </svg>
                                        {{ trans('auth.login_account') }}
                                    </a>
                                </div>
                            </div>
                            @endguest
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection