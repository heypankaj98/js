<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Access Queue - Market</title>
    <meta charset="UTF-8">
    <meta content="width=device-width,initial-scale=1" name="viewport">
    <meta http-equiv="refresh" content="20">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <style>
        body {
            line-height: 1;
            font-family: "Inter", sans-serif;
            color: #fff;
            background-color: #000;
            overflow: hidden;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            text-align: center;
            min-height: 100%;
            position: relative;
            height: 100vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .logo img.imgda {
            max-width: 150px;
        }

        h3 {
            padding-top: 20px; font-size: 14px;
        }

        .safest {
            font-weight: 700;
        }

        .refresh1 {
            font-weight: 800;
        }

        .d-f {
            display: flex;
            align-items: center;
            justify-content: center;
        }

.loader {
  width: 40px;
  aspect-ratio: 1.154;
  display: grid;
  background: conic-gradient(from 149deg at top, #0000, #597B8D 1deg 60deg, #0000 61deg);
  animation: l14 2s infinite cubic-bezier(0.5,500,0.5,-500);
  transform-origin: top;
}

.loader:before,
.loader:after {
  content: "";
  grid-area: 1/1;
  background: conic-gradient(from 149deg at top, #0000, #ff0000 1deg 60deg, #0000 61deg);
  transform-origin: inherit;
  animation: inherit;
}

.loader:after {
  background: conic-gradient(from 149deg at top, #0000, #ff7d00 1deg 60deg, #0000 61deg);
  animation-timing-function: cubic-bezier(0.5,800,0.5,-800);
}

@keyframes l14{
  100% {transform: rotate(0.2deg)}
}

    </style>
</head>

<body>
    <div class="container d-f">
        <div class="logo">
            <img class="imgda" src="{{ asset('assets/Dark_Alley_Logo.png') }}" alt="Dark Alley Logo">
        </div>
        <h3>2X DDoS Protection</h3>
        <p style="color:#F18834; line-height:1.2; font-size:14px">
            Make sure your Tor Browser is set <br />
            to the <span class="safest">SAFEST</span> security level.
        </p>
        <div></div>
        <div class="loader"></div>
        <div></div>

        
        <p><span class="refresh1" style="font-size:14px;">Do not refresh the page,</span> you will be redirected...</p>
    </div>
</body>

</html>
