<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use App\Models\Ticket;
use App\Models\TicketLabel;
use App\Models\TicketMessage;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Auth;
use App\Notifications\UserTicketNotification;
class UsersController extends Controller {

    public function index() {
        abort_if(Gate::denies('admin_user_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $users = User::withTrashed()->with(['roles'])->get();

        return view('admin.users.index', compact('users'));
    }

    public function create() {
        abort_if(Gate::denies('admin_user_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roles = Role::pluck('title', 'id');

        return view('admin.users.create', compact('roles'));
    }

    public function store(StoreUserRequest $request) {
        $user = User::create($request->all());
        $user->roles()->sync($request->input('roles', []));

        return redirect()->route('admin.users.index');
    }

//   public function edit(User $user) {
      
//         abort_if(Gate::denies('admin_user_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

//         $roles = Role::pluck('title', 'id');
//         $selected_user=$user;
        
//         $selected_user->load('roles');
        
 
//         return view('admin.users.edit', compact('roles', 'selected_user'));
//     }

    public function update(UpdateUserRequest $request, User $user) {
      
        $user->update($request->all());
        $user->roles()->sync($request->input('roles', []));
        if ($request->input('roles') && in_array(3, $request->input('roles'))) {
            $user->isSeller = 1;
            $user->twofa = 1;
       }
         if ($request->input('roles') && in_array(17, $request->input('roles'))) {
     $user->fe_Seller = 1;
            $user->save();
    }
          $user->featured=$request->featured;
            $user->save();
        return redirect()->route('admin.users.index');
    }

public function show(User $user) {
    abort_if(Gate::denies('admin_user_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

    // Define selected_user as a separate user
    $selected_user = User::findOrFail($user->id);  // or some other logic

    return view('admin.users.show', compact('user', 'selected_user'));
}

    public function destroy(User $user) {
        abort_if(Gate::denies('admin_user_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $user->delete();

        return back();
    }

    public function massDestroy(MassDestroyUserRequest $request) {
        $users = User::find(request('ids'));

        foreach ($users as $user) {
            $user->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function recoverAccount($id) {
        $user = User::withTrashed()->findOrFail($id);

        if ($user->trashed()) {
            $user->restore();
            return redirect()->route('admin.users.show', $user->id)->with('success', 'User account has been recovered.');
        }
        return redirect()->route('admin.users.show', $user->id)->with('warning', 'User account is already active.');
    }
    
    
    
 public function indexticket(Request $request) {

    $tickets = Ticket::where('assigned_to', 1)->get();

    return view('admin.tickets.index', compact('tickets'));
}

  public function ticketshow($ticket) {
     
        $user_id = Auth::id();
   
        $tickets = Ticket::findOrFail($ticket);
        return view('admin.tickets.show', compact('tickets','user_id'));
    }   
    
    
    
  public function ticketReply(Request $request, $id) {
    
         $user_id = Auth::id();
         $ticketMessage = new TicketMessage();
         $ticketMessage->user_id=$user_id;
         $ticketMessage->ticket_id=$id;
         $ticketMessage->message=$request->reply;
         $ticketMessage->save();
         
         $tickets = Ticket::findOrFail($id);
      
         $tickets->is_resolved=$request->is_resolved;
         $tickets->is_locked=$request->is_locked;
       
          $tickets->save();
          
         return redirect()->back();
  }   
    // public function loginAsUser($userId)
    // {
       
    //     // Find the user by ID
    //     $user = User::find($userId);
       
    //     // Check if the user exists and if the admin is authorized
    //     if ($user) {
    //         // Log in the user
    //         Auth::login($user);

    //         // Redirect to a specific route after logging in
    //         return redirect()->route('home'); // Adjust the route as needed
    //     }

    //     // Handle cases where the user doesn't exist or the admin is not authorized
    //     return redirect()->back()->withErrors(['User not found or unauthorized']);
    // }
    
    

}
