@extends('layouts.seller.app')      @section('content')

<div class="">
<h2 class="custom-title my-4">Balance</h2>
    <div class="row row-cards-one">
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.total') }} {{ trans('common.balance') }}!</h5>
                    <span class="number"></span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main w-100">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.escrow') }} {{ trans('common.balance') }}!</h5>
                    <span class="number"> </span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main w-100">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="bg-card-2 h-100 br1">
                <div class="left d-flex flex-column gap-3">
                    <h5 class="title1">{{ trans('common.disputes') }} {{ trans('common.balance') }}!</h5>
                    <span class="number"></span>
                    <a href="{{route('seller.orders')}}" class="btn btn-main w-100">
                        {{ trans('common.view') }} {{ trans('common.all') }}
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 