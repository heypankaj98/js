<?php
namespace Coderflex\LaravelTicket\Database\Factories;

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Create auctions table
        Schema::create('auctions', function (Blueprint $table)
        {
            $table->bigIncrements('id');
            $table->string('type', 10)->default('physical');
            $table->string('name', 255);
            $table->string('status', 10)->default('active');
            $table->text('description');
            $table->text('policy')->nullable();
            $table->text('picture');
            $table->unsignedBigInteger('category');
            $table->datetime('start_time');
            $table->datetime('end_time');
            $table->unsignedTinyInteger('isfeature')->default(0);
            $table->unsignedSmallInteger('stock');
            $table->string('product_measure', 191)->nullable();
            $table->unsignedDecimal('reserve_price', 8, 2);
            $table->unsignedDecimal('increment', 8, 2)->nullable();
            $table->unsignedDecimal('current_price', 8, 2)->nullable();
            $table->unsignedDecimal('max', 8, 2)->nullable();
            $table->json('winner_id')->nullable();
            $table->unsignedBigInteger('seller_id');
            $table->text('content')->nullable();
            $table->timestamps();

            $table->foreign('category')->references('id')->on('product_categories');
            $table->foreign('seller_id')->references('id')->on('users');
        });

        // Create bids table
        Schema::create('bids', function (Blueprint $table) {
          $table->bigIncrements('id');
            $table->unsignedBigInteger('auction_id');
            $table->unsignedBigInteger('user_id');
            $table->decimal('amount', 8, 2);
            $table->string('status', 10)->default('waiting');
            $table->string('payment_method', 10)->nullable();
            $table->text('payment_address')->nullable();
            $table->unsignedDecimal('crypto_total', 12, 8)->default(0.00000000);
            $table->unsignedDecimal('total_received', 12, 8)->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            $table->foreign('auction_id')->references('id')->on('auctions');
            $table->foreign('user_id')->references('id')->on('users');
            
        });
    }
    
    public function down()
    {
        Schema::dropIfExists('bids');
        Schema::dropIfExists('auctions');
    }
};