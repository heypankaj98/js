<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\Seller\CreateAuctionRequest;
use Auth,Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{ ProductCategory, Auction};

class AuctionController extends Controller{
    
    use MediaUploadingTrait;
    
    public function index(){
        abort_if(Gate::denies('admin_product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $auction = Auction::where('seller_id',Auth::id())->paginate(config('setting.pagination'));
        
        return view('seller.auctions.index', compact('auction'));
    }
    
    public function create()
    {
        abort_if(Gate::denies('admin_product_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        
        $categories = ProductCategory::get();
        
        return view('seller.auctions.create', compact('categories'));
    }
    
    public function store(CreateAuctionRequest $request){
        if (isset($request->custom_product_measure)){
            $request->request->add(['product_measure' => $request->custom_product_measure]);
        }

        $request->request->add(['seller_id' => Auth::id()]);
        $request->request->add(['current_price' => $request->reserve_price + ($request->increment ?? 0)]);
        $auction = Auction::create($request->all());
        
        $input['picture'] = $this->storeMedia($request, 'picture');

        if ($input['picture'])
        {
            $auction->addMedia(storage_path('tmp/uploads/' . basename($input['picture'])))->toMediaCollection('photo');
        }
        
        return redirect()->route('seller.auction.index');
    }
    
    public function edit(Auction $auction) {
        abort_if(Gate::denies('admin_product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('seller.auctions.edit', compact('auction'));
    }
    
    public function update(UpdateAuctionRequest $request, Auction $auction) {
        $auction->update($request->all());

        if ($request->input('picture', false)) {
            if (!$auction->photo || $request->input('picture') !== $auction->photo->file_name) {
                if ($auction->photo) {
                    $auction->photo->delete();
                }
                $auction->addMedia(storage_path('tmp/uploads/' . basename($request->input('picture'))))->toMediaCollection('photo');
            }
        } elseif ($auction->photo) {
            $auction->photo->delete();
        }

        return redirect()->route('seller.auction.index');
    }
    
    public function destroy(Auction $auction) {
        abort_if(Gate::denies('admin_product_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $auction->delete();
        $auction->bids()->delete();

        return back();
    }
}