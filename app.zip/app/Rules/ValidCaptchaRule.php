<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Support\Facades\Session;

class ValidCaptchaRule implements Rule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
     public function passes($attribute, $value)
    {
        // Retrieve the CAPTCHA string stored in the session
        $captcha = session('captcha');
      
        // Compare the user's input with the stored CAPTCHA string
        return $value === $captcha;
    }

    public function message()
    {
        return 'The CAPTCHA is invalid.';
    }
}
