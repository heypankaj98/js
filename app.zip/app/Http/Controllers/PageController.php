<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
 public function Mirrors() {
    return view('pages.mirrors');
    
}
 public function Pgp() {
     
    return view('pages.pgp');
    
}
  
  
  
}
