<?php

namespace Database\Seeders;

use App\Models\ProductCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductCategoriesTableSeeder extends Seeder {

    public function run() {
        $categories = [
            [
                'id' => 1,
                'parent_id' => null,
                'name' => 'Drink',
                'description' => Str::random(15),
            ],
            [
                'id' => 2,
                'parent_id' => null,
                'name' => 'Physical',
                'description' => Str::random(15),
            ],
            [
                'id' => 3,
                'parent_id' => 1,
                'name' => 'Soft',
                'description' => Str::random(15),
            ],
        ];

        ProductCategory::insert($categories);
    }

}
