<?php

namespace Modules\Jabber\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\Jabber\Http\Controllers\Lib\Options;
use Modules\Jabber\Http\Controllers\Lib\XmppClient;
use Modules\Jabber\Http\Controllers\Lib\Xml\Stanzas\Stanza;

class BotController extends Controller {

    protected $server;
    protected $port;
    protected $username;
    protected $password;
    protected $resource;
//    private $options;
    private $jabber;

    public function __construct() {
        // Set up XMPP connection details
        $this->server = '68.183.65.127';
        $this->port = 5280;
        $this->username = 'username';
        $this->password = 'password';

        $options = new Options();
        $options
                ->setHost($this->server)
                ->setPort($this->port)
                ->setUsername($this->username)
                ->setPassword($this->password);

        $this->jabber = new XmppClient($options);
        $this->jabber->connect();
        $this->jabber->iq->getRoster();

        $sender = $this->username . '@' . $this->server;
        $recipient = 'darkwebdeveloper@jabb3r.org';


        $this->jabber->message->send('Hello world', 'darkwebdeveloper@jabb3r.org');
//        (new self)->sendRawXML($client);
        
        do {
    $response = $this->jabber->message->receive();
    if($response)
        echo print_r($response);
} while (true);
        


        do {
            $response = $this->jabber->getResponse();
            dd($response);
            $this->jabber->prettyPrint($response);
            dd($response);
        } while (true);

        $this->jabber->disconnect();
    }

    public function sendRawXML(XmppClient $client) {
        do {
            $response = $this->jabber->getResponse();
            $this->jabber->prettyPrint($response);

            // if you provide a function name here, (i.e. getRoster ...arg)
            // the function will be called instead of sending raw XML
            $line = readline("\nEnter XML: ");

            if ($line == 'exit') {
                break;
            }

            $parsedLine = explode(' ', $line);

            if (method_exists($client, $parsedLine[0])) {
                if (count($parsedLine) < 2) {
                    $client->{$parsedLine[0]}();
                    continue;
                }
                $client->{$parsedLine[0]}($parsedLine[1]);
                continue;
            }

            if (@simplexml_load_string($line)) {
                $client->send($line);
                continue;
            }

            echo "This is not a method nor a valid XML";
        } while ($line != 'exit');
    }

    public static function Test() {
        
    }

}
