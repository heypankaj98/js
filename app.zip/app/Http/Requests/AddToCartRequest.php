<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\{
    Product,
    ShippingMethod
};

class AddToCartRequest extends FormRequest {

    public function authorize() {
        return auth()->check();
    }

    public function rules() {
        return [
            'quantity' => 'required',
        ];
    }

    public function add(Product $product, $request) {
        $user = auth()->user();
//        if ($product->seller_id == $user->id) {
//            throw new \Exception('You can not buy your product!');
//        }
        if ($request->quantity > $product->stock) {
            throw new \Exception('You have put more then stock quantity!');
        }
        if ($product->seller->vacation_mode) {
            throw new \Exception('You can not buy this product seller is on Vacation!');
        }
        #Get offer
        $offer = null;
        $offer_discount = null;
        $eligible_methods = null;
        if ($product->type == 'physical') {
            $offer = unserialize($product->wdiscount);
            $shipping_ids = unserialize($product->shipping_method);
            $country = $request->country;
            session()->put('delivery_location', $country);

            if ($shipping_ids) {
                $shippingMethods = ShippingMethod::wherein('id', $shipping_ids)->get();
                $isEligible = false;
                $eligible_methods = $this->get_eligible_shipping_methods($country, $shippingMethods);
                foreach ($shippingMethods as $shippingMethod) {
                    if ($shippingMethod->availability == 'limited') {
                        if (in_array($country, json_decode($shippingMethod->countries, true))) {
                            $isEligible = true;
                            break;
                        }
                    } elseif ($shippingMethod->availability == 'except') {
                        if (!in_array($country, json_decode($shippingMethod->countries, true))) {
                            $isEligible = true;
                            break;
                        }
                    } else {
                        $isEligible = true;
                        break;
                    }
                }

                if (!$isEligible) {
                    throw new \Exception('The seller is not eligible to ship this product to your country ' . $country . '  address!');
                }
            }

            if ($offer) {
                $max = max(array_keys($offer));
                $min = min(array_keys($offer));
                foreach ($offer as $key => $discount_offer) {
                    $needle = range($min, $max);
                    if (array_intersect(array($request->quantity), $needle)) {
                        $offer_discount = $discount_offer;
                    } else {
                        $offer_discount = null;
                    }
                }
                if ($offer_discount) {
                    $discount_price = $product->price * $request->quantity - ( $product->price * $request->quantity * $offer_discount / 100 );
                } else {
                    $discount_price = $product->price * $request->quantity;
                }
            } else {
                $discount_price = $product->price * $request->quantity;
            }
        } else {
            $discount_price = $product->price * $request->quantity;
        }

        #Get all products from the cart or return an empty array
        $products = session()->has('cart') ? session()->get('cart') : [];
        #Checks if the product already exists in the cart and if it does, just update it
        foreach ($products as $index => $productCart) {
            if ($productCart['product_id'] == $product->id) {
                unset($products[$index]);
            }
        }

        session()->put('cart', $products);
        session()->push('cart', [
            'product_id' => $product->id,
            'product_name' => $product->name,
            'seller_id' => $product->seller->id,
            'quantity' => $request->quantity,
            'price' => $discount_price,
            'shipping_methods' => $eligible_methods,
//            'delivery_price' => $delivery->price,
//            'delivery_method' => $delivery->name.' - '.$delivery->days.' day(s)',
            'total' => $discount_price
        ]);
        return redirect()->route('user.cart');
    }

    public function get_eligible_shipping_methods($country, $shipping_methods) {
        $eligible_methods = array();
        foreach ($shipping_methods as $method) {
            $availability = $method['availability'];
            $countries = json_decode($method['countries'], true);
            // Check if the method is available worldwide
            if ($availability === 'worldwide') {
                $eligible_methods[] = $method;
                continue;
            }

            // Check if the method is available in the user's country
            if ($availability === 'except' && !in_array($country, $countries)) {
                $eligible_methods[] = $method;
                continue;
            }

            // Check if the method is available in limited countries and the user's country is in the list
            if ($availability === 'limited' && in_array($country, $countries)) {
                $eligible_methods[] = $method;
                continue;
            }
        }

        return $eligible_methods;
    }

}
