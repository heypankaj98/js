<?php
namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Requests\{ BidRequest, BidPaymentRequest };
use App\Notifications\OrderCreateNotification;
use Auth, DB, Gate;
use Symfony\Component\HttpFoundation\Response;
use App\Models\{ ProductCategory, Auction, Bids, Order };
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class AuctionController extends Controller{
    
    use MediaUploadingTrait;
    
    private function checkbuyer($id) {
        if (Bids::whereid($id)->first()->user_id == Auth::id()) {
            return 1;
        } else {
            session()->flash('error', 'You are not allowed to access this.');
            return redirect()->back();
        }
    }
    
    public function view($id)      //  View Auction Page to all user
    {
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:auctions,id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        
        $bids = Bids::where('auction_id', $id)->get();
        $auction = Auction::whereid($id)->firstOrFail();
        $categories = ProductCategory::get();

        return view('buyer.auction.auction', compact('auction','categories','bids'));
    }
    
    public function index()     // View all bids by buyer
    {
        abort_if(Gate::denies('admin_product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $bids = Bids::where('user_id', Auth::id())->paginate(config('setting.pagination'));
        $a = 1;
        return view('buyer.auction.bids.index', compact('bids','a'));
    }
    
    public function viewSingle($id)
    {
        $validator = Validator::make(['id' => $id], [
                    'id' => 'required|exists:bids,id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        $this->checkbuyer($id);
        $bid = Bids::whereid($id)->first();

        if ($bid->status == 'waiting')
        {
            if ($bid->payment_address)
            {
                $received = PayWay::getBalance($bid->payment_method, ['address' => $bid->payment_address]);
                
                if($received >= $bid->crypto_total){
                    $bid->update(['status' => 'escrow','total_received' => $received]);
                    session()->flash('success', 'Payment received successfully. Thank you.');
                }
                
                return view('buyer.auction.bids.bid', compact('bid','received'));
            }
        }
        
        return view('buyer.auction.bids.bid', compact('bid'));
    }
    
    public function buyBid(BidRequest $request, $id)
    {
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:auctions,id',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        $auction = Auction::whereid($id)->firstOrFail();

        if($auction->increment){
            if ($request->price < $auction->current_price + $auction->increment) {
                session()->flash('error', 'Your bid should not be lower than the current price.');
                return redirect()->back();
            }
        }else{
            if ($request->price <= $auction->current_price) {
                session()->flash('error', 'Your bid should not be lower than the current price.');
                return redirect()->back();
            }
        }
        
        $new = new Bids();
        $new->auction_id = $id;
        $new->user_id = Auth::id();
        $new->amount = $request->price;
        $new->save();
        
        session()->flash('success', 'Your bid is received. To place the bid, complete the payment.');

        return redirect(route('user.bid.view',$new->id));
    }
    
    public function generatePayment(BidPaymentRequest $request, $id) {
        $validator = Validator::make(['id' => $id], [
                    'id' => 'required|exists:bids,id',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
        $this->checkbuyer($id);

        $bid = Bids::whereid($id)->first();
        $address = PayWay::generateAddress($request->payment_method);

        if ($address && is_string($address))
        {
            $bid->update(['payment_method' => $request->payment_method, 'payment_address' => $address, 'crypto_total' => convert($bid->amount, $request->payment_method)]);
            session()->flash('success', 'Payment address generated successfully. Please pay required amount on generated address below.');
        } else {
            session()->flash('error', 'Payment not generated ask Admin to help.');
        }
        return redirect()->back();
    }
    
    public function buyAuction(Request $request, $id) {         // View Checkout Page by Buy now auction
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:auctions,id',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        $auction = Auction::whereid($id)->firstOrFail();
        $buy_price = $auction->max;
        $categories = ProductCategory::whereNull('parent_id')->get();

        return view('buyer.auction_checkout', compact('auction', 'buy_price', 'categories'));
    }

    public function checkoutBuyAuction(Request $request, $id) {
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:auctions,id',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }
  
        $address = $request->input('address');
        $paymentMethod = $request->input('payment_method');
        $currency = $request->input('currency');
        $exchangeRate = $request->input('exchange_rate');

        $auction = Auction::whereid($id)->firstOrFail();
        $trx = Str::random(10);
        $buyer = Auth::id();
        
        try {
            DB::beginTransaction();
            
            $order = new Order;
            $order->order_id = $buyer . $trx;
            $order->isauction = 1;
            $order->product_id = $auction->id;
            $order->buyer_id = $buyer;
            $order->seller_id = $auction->seller_id;
            $order->payment_method = $paymentMethod;
            $order->address = $address;
            $order->quantity = $auction->stock;
            $order->total = $auction->max;
            $order->save();
            
            DB::commit();

            $auction->seller->notify(new OrderCreateNotification($order));
            
            return redirect()->route('user.orders')->with('success', 'Auction Order is created success.');
        } catch (RequestException $requestException) {
            DB::rollBack();

            dd($requestException);

            redirect()->back()->with('error', $requestException->getMessage());
        } catch (\Exception $e) {
            DB::rollBack();
            dd($e);
            \Illuminate\Support\Facades\Log::error($e->getMessage());

            redirect()->back()->with('error', $e->getMessage());
        }
    }
}