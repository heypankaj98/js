<?php
namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Hash,Auth;
use Carbon\Carbon;
use App\Tools\PGP;
use App\Models\User;
use Laravolt\Avatar\Facade as Avatar;
use Illuminate\Support\Facades\Lang;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;
use App\Tools\Mnemonic;

class LoginRequest extends FormRequest {

    public function authorize() {
        return !auth()->check();
    }

    public function rules() {
        return [
            'username' => 'required|alpha_num|min:4|max:20|exists:users,username',
            'password' => 'required|min:8|max:80',
            'captcha' => 'required|captcha'
        ];
    }

    public function messages() {
        return [
            'username.min' => Lang::get('messages.username_min'),
            'password.min' => Lang::get('messages.password_min'),
            'captcha.captcha' => Lang::get('messages.captcha'),
        ];
    }

    public function login() {
        
        $user = User::where('username', $this->username)->first();
        if (is_null($user) or!Hash::check($this->password, $user->password)) {
            throw new \Exception(trans('messages.incorrect_credentials'));
        }
        if (!$user->mnemonic) {
            $mnemonic = (new Mnemonic())->generate(config('marketplace.mnemonic_length'));

            session()->put('mnemonic_key', $mnemonic);
            $user->mnemonic = bcrypt(hash('sha256', $mnemonic));
            $user->save();
            return redirect()->route('show.mnemonic');
        }

        if (!$user->avatar) {
            $user->avatar = Avatar::create($this->username)->setDimension(100, 100)->toBase64();
        }
        $lifetime = 60;
        config(['session.lifetime' => $lifetime]);
        Auth::login($user);
        session()->regenerate();
        $user->last_login = Carbon::now();

        if (!$user->btc_account) {
            $btcAccount = PayWay::createNewAccount("Bitcoin", ['username' => $user->username]);
            $user->btc_account = $btcAccount;
        }
        if (!$user->monero_account) {
            // Create a new Monero account and tag it with the username
            $moneroAccount = PayWay::createNewAccount("Monero", ['username' => $user->username]);
            $user->monero_account = $moneroAccount;
        }
        $user->save();
        if (!is_null($user->pgp_key) && $user->twofa == 1) {
            PGP::verification($user->pgp_key, 'verify_login'); #Create new verification
            return redirect()->route('verifylogin');
        }
        return redirect()->route('user.home');
    }
}