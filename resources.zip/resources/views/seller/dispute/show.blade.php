@extends('seller.dispute.template')
@section('title', $singledispute->order_id)

@section('messenger-content')


<div class="mt-4">
    <div class="row h-100">
        <div class="col-md-3">
            <!-- Sidebar -->
            <div class="d-flex flex-column h-100 chat-sidebar br1 br-4">
                <!-- Users -->

                <div class="bg-card-2 p-16 h-100">
                    <h5 class="card-header-2 w-100 mb-4">{{ trans('common.recent') }} {{ trans('common.disputes') }}</h5>
                    <ul class="list-unstyled">
                    @forelse($disputes as $dispute)
                        <li>
                            <a class="dispute-link" href="{{ route('seller.dispute.messages', [$dispute->id]) }}">
                                <div class="user_info">
                                    <img src="{{$dispute->buyer->avatar}}"
                                        class="rounded-circle">
                                    <div class="d-flex flex-column gap-1">
                                        <span>{{ $dispute->buyer->username }}</span>
                                        <p class="small mb-0">{{ trans('common.status') }} {{ $dispute->status }}</p>
                                    </div>
                                </div>
                                <p class="small ab-p">{{ trans('common.order') }} {{ $dispute->order_id }}</p>
                            </a>
                        </li>
                        @empty
                        {{ trans('global.old_disputes') }}
                        @endforelse
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <!-- Chat content -->
            <div class="bg-card-2 br1">
                <div class="">

                    <h5 class="card-header-2 w-100 mb-4">{{ trans('global.chat_with') }}  {{$singledispute->buyer->username}} {{ trans('global.for_order') }}   {{$singledispute->order_id }} status:{{$singledispute->status }}</h5>

                </div>
                <div class="card-body">
                    <div class="chat-messages">

                        @foreach($singledispute->messages() as $message)
                        @if($message->user_id == Auth::user()->id)
                        <div class="message sent">
                            <div class="message-content mw-100  ">
                                <div class="message-header small">
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @else
                        <div class="message received">

                            <div class="message-content mw-100 ">
                                <div class="message-header small">
                                     <img src="{{$message->sender->avatar}}" class="rounded-circle">
                                    <span class="username">{{$message->sender->username}}</span>
                                    <span class="timestamp">{{ $message->created_at->diffForHumans() }}</span>
                                </div>
                                <div class="message-text mw-100">
                                    {{ $message->message }}
                                </div>
                            </div>
                        </div>
                        @endif
                        @endforeach 
                        <!-- more messages... -->
                    </div>
                </div>
                <div class="card-footer">

                    <form action="{{ route("seller.dispute.reply", [$singledispute->id]) }}" method="POST">
                        @csrf
                        <div class="form-group mb-0">
                            <div class="input-group">
                                  <input type="hidden" name="dispute_id" value="{{$singledispute->id}}" />
                                <input type="text" class="form-control" name="content" placeholder="Type your message...">
                                    <button type="submit" class="btn btn-main">{{ trans('global.send') }} </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-2">

            <!-- Users -->

        </div>
    </div>
</div>






<style>
    .chat-sidebar {
        height: 500px;
        overflow-y: auto;
    }

    .chat-sidebar ul {
        padding-left: 0;
    }

    .chat-sidebar li {
        margin-bottom: 10px;
    }


    .chat-sidebar a.active {
        background-color: #007bff;
        color: #fff;
    }
    .chat-sidebar li.active >a{
        background-color: #007bff;
        color: #fff;
    }

    .message {
        display: block;
        clear: both;
        margin-bottom: 10px;
    }

    .message-content {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 4px;
        max-width: 70%;
    }

    .message-text {
        margin: 5px 0;
    }

    .message-timestamp {
        font-size: 0.8em;
        color: #999;
    }

    .message.sent {
        float: right;
    }



    .message.sent .message-timestamp {
        text-align: right;
    }

    .message.received {
        float: left;
    }

    .message.received .message-content {
        background-color: #f2f2f2;
        color: #333;
        float: left;
    }

    .message.received .message-timestamp {
        text-align: left;
    }

    .chat-messages {
        max-height: 500px;
        overflow-y: auto;
    }

    .card-footer form {
        display: flex;
        flex-direction: column;
    }

    .card-footer form .input-group {
        flex-direction: row;
        align-items: center;
    }

    .card-footer form .form-control {
        border: none;
        border-radius:1px;
    }
    img.rounded-circle {
        max-height: 36px;
    }

</style>



@stop