@extends('layouts.homeapp')
@section('content')
<style>
	#content-pos {
		line-height: 1.5;
	}
</style>
<div class="bg-card-1 p-24 br1 mt-4">
	<div id="content-pos" class="">
		<div id="content">
			<div class="re-ov">
				<div class="section-layout-line"></div>
				<h4 class="d-flex align-items-center gap-2 card-header-2 w-100 mb-4"><img src="{{ asset('assets/button_mirrors.gif') }}" style="width:30px; height:30px" alt=""> Dark Alley Mirrors</h4>
				<div class="section-label-description">
					In the <b>Dark Alley Mirrors</b> section, you can find the Mirror URLs of the Kerberos
					Marketplace.<br>
					You can select a Mirror URL by <b><i>one-click</i></b> for <b><i>copy &amp; paste</i></b> or
					download the PGP Signed Message.<br><br>
					It is recommended that you save the Mirror URLs, so that you always be secure and not open a
					Phishing-URL from somewhere.
				</div>
				<hr>
				<div class="section-action ">
					<div class="section-action-label bg-card-1"><b>Dark Alley Marketplace:</b> Mirror (URLs)</div>
					<div class="re">
						<b>ALWAYS verify the correct Dark Alley Mirror URL.</b><br><br>
						You can simply do this by checking the first 3 characters (highlighted in green) after the
						mirror letter for Onion Network URLs.<br><br>
						Custom Onion URLs were calculated (and the effort to do so increases with each character).<br>
						The twelfth character needs millennia to calculate.<br>
						So it's perfectly sufficient if you check the first 3 characters after the mirror letter to
						verify the correct Onion Mirror URL.<br><br>
						You can select a Onion Mirror URL by <b><i>one-click</i></b> for <b><i>copy &amp; paste</i></b>
						or download the PGP Signed Message.<br><br>
						Memorize the URL <a href="https://kerberos.market/" class="ftks kerberos-market-tcc"
							title="Kerberos Marketplace information website (Open in new tab)"
							target="_blank">Darkalley.market<img src="/gfx/nt.png" class="nt14" alt="" width="16"
								height="16"></a> for latest information about our Dark Alley Marketplace or on connection
						problems.
					</div>
					<div class="re">
						<div class="re" style="height: 20px;"></div>
						<table class="table-prd table-bordered w-100">
							<tbody>
								<tr>
									<td style="width: 270px;">
										<div class="re" style="height: 3px;"></div><b>Description</b>
									</td>
									<td ><b>Secure Clearnet (SCN) URL</b></td>
								</tr>
								<tr>
									<td>INFORMATION <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING
											<span style="color: #131313;">- SCN</span></span></td>
									<td class="tnlt"><span class="courier"
											style="user-select: all;">darkalley.market</span></td>
								</tr>
							</tbody>
						</table>
						<div class="re" style="height: 20px;"></div>
						<table class="table-prd table-bordered w-100">
							<tbody>
								<tr>
									<td style="width: 270px;">
										<div class="re" style="height: 3px;"></div><b>Mirror Description</b>
									</td>
									<td ><b>Onion Network (TOR) / I2P URLs</b></td>
								</tr>
								<tr>
									<td>ALPHA <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">a</span><span
												class="ftgn">zmn</span>frjinmftp3im3cr7hw4nxbavm4ngofn64g24be7h3kqd.onion</span>
									</td>
								</tr>
								<tr>
									<td>BRAVO <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">b</span><span
												class="ftgn">kts</span>3ulupqzjoxxo6xkwp4tllf36v5a3kbeemkwfw263y3ad.onion</span>
									</td>
								</tr>
								<tr>
									<td>CHARLIE <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">c</span><span
												class="ftgn">wus</span>5qit6l32wmg3hz6j3zverf33moas3wjcgaatchililqd.onion</span>
									</td>
								</tr>
								<tr>
									<td>DELTA <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">d</span><span
												class="ftgn">kgf</span>sepwkotclwpuc4iviucasicwgssv6zgcw3d5xa3tdwad.onion</span>
									</td>
								</tr>
								<tr>
									<td>ECHO <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">e</span><span
												class="ftgn">mtk</span>eqh7pznmv3negqhudxk5po3awdazx5fqgizttr6xeiid.onion</span>
									</td>
								</tr>
								<tr>
									<td>FOXTROT <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">f</span><span
												class="ftgn">wju</span>irbckcfspamq3wv3nfk6blusvabbtnsatiezm2uyfzid.onion</span>
									</td>
								</tr>
								<tr>
									<td>GOLF <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">g</span><span
												class="ftgn">zhu</span>w5oagmbzjecz5m3c2bmpg3mns6ty7ofwwk67kviswkad.onion</span>
									</td>
								</tr>
								<tr>
									<td>HOTEL <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING</span>
									</td>
									<td class="tnrt"><span class="courier" style="user-select: all;">Dark Alley<span
												class="ftks">h</span><span
												class="ftgn">z5i</span>6au475yf63msi2llgxxf4obr4hvjq7hdmphec4t2j7ad.onion</span>
									</td>
								</tr>
								<tr>
									<td>PAPA <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING
											<span style="color: #131313;">- I2P</span></span></td>
									<td class="tnlt"><span class="courier"
											style="user-select: all;">kmuxk7gi5qlmjtvvpldagyudlll2boy7hz6tfyhxzghp5uvlcjzq.b32.i2p</span>
									</td>
								</tr>
								<tr>
									<td>X-RAY <span class="brs5"
											style="font-size: 12px; line-height: 16px; padding: 4px 8px; border-radius:2px; background-color: #48a935;">WORKING
											<span style="color: #131313;">- TOR</span></span></td>
								
								</tr>
							</tbody>
						</table>
						<a class="bg-card-1 d-flex gap-2 align-items-center p-2 mt-4" download style="background-color: #000 !important;" href="/file_pgp/Kerberos-Mirrors_PGP-SIGNED-MESSAGE.txt" target="_blank">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
								fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
								stroke-linejoin="round" class="feather feather-download">
								<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
								<polyline points="7 10 12 15 17 10"></polyline>
								<line x1="12" y1="15" x2="12" y2="3"></line>
							</svg>
							<span>Dark-Alley-Mirrors_PGP-SIGNED-MESSAGE.txt</span>
						</a>
					</div>
				</div>
				<div class="ae zx990">
					<a href="/home/" title="Back to: Home"><button class="btn-main " type="button"
							value="Back to: Home">Back to: Home</button></a>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection