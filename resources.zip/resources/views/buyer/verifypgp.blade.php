@extends('layouts.buyer.app')       @section('content')
<form action="{{ route('user.storePgpKey') }}" method="POST">
    @csrf
    <div class="form-group">
        <label for="decrypted_message">Decrypted Message:</label>
        <textarea id="decrypted_message" class="form-control" rows="4" readonly>{{ $decryptedMessage }}</textarea>
    </div>
    <div class="form-group">
        <label for="verification_input">Enter Verification Code:</label>
        <input type="text" id="verification_input" name="verification_input" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Verify and Save PGP Key</button>
</form>
@endection

