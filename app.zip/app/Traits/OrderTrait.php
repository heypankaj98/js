<?php

namespace app\Traits;

use App\Models\Order;
use Carbon\carbon;

trait OrderTrait {

    private function markAsProcessing($id) {
        Order::whereid($id)->update(['status' => 'processing']);
        session()->flash('success', "Order status changed to Processing !");
    }

    private function markAsShipped($id, $date) {
        Order::whereid($id)->update(['status' => 'shipped', 'delivered_at' => $date]);
        session()->flash('success', "Order status changed to Shipped !");
    }

    private function markAsDelivered($id) {
        Order::whereid($id)->update(['status' => 'delivered']);
        session()->flash('success', "Order status changed to Delivered !");
    }

    private function markAsCompleted($id) {
        Order::whereid($id)->update(['status' => 'completed', 'delivered_at' => Carbon::now()]);
        session()->flash('success', "Order is completed. Thank you !");
    }

    private function markAsDisputed($id) {
        Order::whereid($id)->update(['status' => 'dispute', 'delivered_at' => Carbon::now()]);
        session()->flash('success', "Order is market as disputed. Thank you !");
    }

    private function markAsRefund($id) {
        Order::whereid($id)->update(['status' => 'refund', 'delivered_at' => Carbon::now()]);
        session()->flash('success', "Order is market as disputed. Thank you !");
    }

}
