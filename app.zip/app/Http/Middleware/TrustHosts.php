<?php

namespace App\Http\Middleware;

use Illuminate\Http\Middleware\TrustHosts as Middleware;
use Illuminate\Http\Response;

class TrustHosts extends Middleware {

    /**
     * Get the host patterns that should be trusted.
     *
     * @return array<int, string|null>
     */
    public function hosts(): array {
        return [
            $this->allSubdomainsOfApplicationUrl(),
        ];
    }

    public function configureSecureHeaders(Headers $headers): void {
        $headers->add('X-Frame-Options', 'DENY');
    }

}
