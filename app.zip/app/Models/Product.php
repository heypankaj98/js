<?php
namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Illuminate\Database\Eloquent\Builder;

class Product extends Model implements HasMedia {
    use SoftDeletes, InteractsWithMedia, HasFactory;

    public $table = 'products';

    protected $appends = ['photo'];

    protected $dates = ['created_at', 'updated_at', 'deleted_at'];

    protected $fillable = [
        'name',
        'description',
        'policy',
        'price',
        'picture',
        'content',
        'stock',
        'type',
        'shipping_method',
        'wdiscount',
        'product_measure',
        'seller_id',
        'category',
        'isfeature',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $with = ['categories', 'seller', 'media'];

    protected function serializeDate(DateTimeInterface $date) {
        return $date->format('Y-m-d H:i:s');
    }

    public function registerMediaConversions(Media $media = null): void {
        $this->addMediaConversion('thumb')->fit('crop', 50, 50);
        $this->addMediaConversion('preview')->fit('crop', 120, 120);
    }

    public function orders() {
        return $this->hasMany(Order::class);
    }

    public function categories() {
        return $this->belongsTo(ProductCategory::class, 'category', 'id');
        // For multiple categories: return $this->belongsToMany(ProductCategory::class);
    }

    public function getPhotoAttribute() {
        $file = $this->getMedia('photo')->last();
        if ($file) {
            $file->url = $file->getUrl();
            $file->thumbnail = $file->getUrl('thumb');
            $file->preview = $file->getUrl('preview');
            return $file;
        }
        return null;
    }

    public function seller() {
        return $this->belongsTo(User::class, 'seller_id', 'id');
    }

    public function reviews() {
        return $this->hasMany(ProductReview::class);
    }

    public function shippingMethod() {
        return $this->belongsTo(ShippingMethod::class);
    }

    public function questions() {
        return $this->hasMany(ProductQA::class, 'product_id');
    }

    // Scope for featured products
    public function scopeFeatured(Builder $query) {
        return $query->where('isfeature', true);
    }
}
