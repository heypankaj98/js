@extends('forum::layouts.master')

@section('content')

@foreach ($posts as $post)
<div @if (! $post->trashed())id="post-{{ $post->sequence }}"@endif
    class="post card mb-2 {{ $post->trashed() || $thread->trashed() ? 'deleted' : '' }}"
    :class="{ 'border-primary': selectedPosts.includes({{ $post->id }}) }">
    <div class="card-header">
        @if (! isset($single) || ! $single)
        <span class="float-end">
            <a href="{{ route('thread.show', $post) }}">#{{ $post->sequence }}</a>
            @if ($post->sequence != 1)
            @can ('deletePosts', $post->thread)
            @can ('delete', $post)
            <input type="checkbox" name="posts[]" :value="{{ $post->id }}" v-model="selectedPosts">
            @endcan
            @endcan
            @endif
        </span>
        @endif

        {{ $post->authorName }}

        <span class="text-muted">
            <time class="timestamp" datetime="{{ $post->created_at }}" title="{{ $post->created_at->toDayDateTimeString() }}">{{ $post->created_at->diffForHumans() }}</time>
            @if ($post->hasBeenUpdated())
            ({{ trans('forum::general.last_updated') }}
            <time class="timestamp" datetime="{{ $post->updated_at }}" title="{{ $post->updated_at->toDayDateTimeString() }}">{{ $post->updated_at->diffForHumans() }}</time>

            @endif
        </span>
    </div>
    <div class="card-body">
        @if ($post->parent !== null)
        <div class="card mb-2" style="border-color: #eee;">
            <div class="card-body">
                <div class="mb-2">
                    <span class="float-end">
                        <a href="{{ route('thread.show', $post) }}" class="text-muted">#{{ $post->sequence }}</a>
                    </span>
                    <strong>{{ $post->authorName }}</strong> <span class="text-muted">{{ $post->posted }}</span>
                </div>
                {!! \Illuminate\Support\Str::limit($post->content) !!}
            </div>
        </div>

        @endif

        @if ($post->trashed())
        @can ('viewTrashedPosts')
        {{$post->content}}
        <br>
        @endcan
        <span class="badge rounded-pill bg-danger">{{ trans('forum::general.deleted') }}</span>
        @else
        {{$post->content}}
        @endif

        @if (! isset($single) || ! $single)

        <div class="text-end">
            
            @if (! $post->trashed())
            <a href="{{ route('post.show', $post) }}" class="card-link text-muted">{{ trans('forum::general.permalink') }}</a>
            @if ($post->sequence != 1)
            @can ('deletePosts', $post->thread)
            @can ('delete', $post)
            <a href="{{ route('post.confirm-delete', $post) }}" class="card-link text-danger">{{ trans('forum::general.delete') }}</a>
            @endcan
            @endcan
            @endif
            @can ('edit', $post)
            <a href="{{ route('post.edit', $post) }}" class="card-link">{{ trans('forum::general.edit') }}</a>
            @endcan
            @can ('reply', $post->thread)
            <a href="{{ route('post.create', $post) }}" class="card-link">{{ trans('forum::general.reply') }}</a>
            @endcan
            @else
            @can ('restorePosts', $post->thread)
            @can ('restore', $post)
            <a href="{{ route('post.confirm-restore', $post) }}" class="card-link">{{ trans('forum::general.restore') }}</a>
            @endcan
            @endcan
            @endif
            @endif
        </div>
    </div>
</div>
@endforeach

<!-- Quick Reply -->


<div class="card mb-2">
    <div class="card-body">
        <form action="{{ route('post.store') }}" method="POST">
            @csrf
            <input type="hidden" name="thread_id" value="{{ $thread->id }}">
            <div class="mb-3">
                <label for="content" class="form-label">{{ trans('forum::general.reply') }}</label>
                <textarea class="form-control" id="content" name="content" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">{{ trans('forum::general.reply') }}</button>
        </form>
    </div>
</div>

@endsection
