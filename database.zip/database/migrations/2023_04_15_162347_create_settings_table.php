<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSettingsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key');
            $table->string('value');
        });

        DB::table('settings')->insert([
            [
                'key' => 'become_seller_fee',
                'value' => 400,
            ],
            [
                'key' => 'market_fee',
                'value' => 1,
            ],
            [
                'key' => 'featured_product',
                'value' => 10,
            ],
            [
                'key' => 'ads_click',
                'value' => 0.7,
            ],
            [
                'key' => 'ads_impression',
                'value' => 0.02,
            ],
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('settings');
    }

}
