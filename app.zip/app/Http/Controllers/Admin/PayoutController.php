<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\Payout;
use App\Http\Controllers\Controller;
use Auth;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class PayoutController extends Controller {

    /**
     * Display a listing of the resource.
     */
    public function index() {
        $payouts = Payout::all();
        return view('admin.payouts.index', compact('payouts'));
    }

    public function approvePayout(Request $request, $payoutId) {
        $payout = Payout::findOrFail($payoutId);
        $user = $payout->user;

        if ($payout->payment_method === 'Bitcoin' && $user->btc_balance < $payout->amount) {
            return redirect()->route('admin.payouts.index')
                            ->with('error', 'Insufficient BTC balance. Payout cannot be approved.');
        } elseif ($payout->payment_method === 'Monero' && $user->xmr_balance < $payout->amount) {
            return redirect()->route('admin.payouts.index')
                            ->with('error', 'Insufficient XMR balance. Payout cannot be approved.');
        }

        $payment_method = $payout->payment_method;
        $received = PayWay::sendToAddress($payment_method, [
                    'address' => $payout->payment_address,
                    'amount' => $payout->amount,
                    'tag' => $payout->user->username,
        ]);

        if (isset($received['error_code'])) {
            $payout->status = Payout::STATUS_REJECTED;
            $payout->details = 'Error code: ' . $received['error_code'] . ' Message: ' . $received['error_message'];
            $payout->save();
        } else {
            // Update the payout status to 'approved'
            if ($payout->payment_method === 'Bitcoin') {
                $user->btc_balance -= $payout->amount;
            } elseif ($payout->payment_method === 'Monero') {
                $user->xmr_balance -= $payout->amount;
            }

            $user->save();
            $payout->status = Payout::STATUS_APPROVED;
            $payout->save();
        }
        return redirect()->route('admin.payouts')
                        ->with('success', 'Payout approved successfully.');
    }

    public function rejectPayout(Request $request, $payoutId) {
        $validatedData = $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $payout = Payout::findOrFail($payoutId);
        // Perform any necessary authorization checks here
        // For example, check if the authenticated user is an admin
        // Update the payout status to 'rejected' and save the reason
        $payout->status = Payout::STATUS_REJECTED;
        $payout->details = $validatedData['reason'];
        $payout->save();

        return redirect()->route('admin.payouts')
                        ->with('success', 'Payout rejected successfully.');
    }

}
