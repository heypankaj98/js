@extends('layouts.buyer.app')
@section('content')
<div class="">
    <div class="row">
        <div class="col-md-12">
            <div class="bg-card-1 mt-4 p-24 br1">
                <h5 class="card-header-buyer"> {{ trans('product.create_ticket')}}</h5>
                <div class="card-body">
                    <form action="{{ route('user.tickets.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3 row flex-column gap-2">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Title</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="title" value="{{ old('title') }}">
                            </div>
                        </div>
                        <div class="mb-3 row flex-column gap-2">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">{{ trans('product.Title')}} </label>
                            <div class="col-sm-12">
                                <textarea id="message" name="message" class="form-control-textarea" required>{{ old('message') }}</textarea>
                            </div>
                        </div>
                        <fieldset class="mb-3 row flex-column gap-2">
                            <legend class="col-form-label col-sm-2 pt-0"> {{ trans('product.Labels')}}</legend>
                            <div class="col-sm-12">
                                @foreach($labels as $id => $name)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="labels[]" id="label-{{ $id }}" value="{{ $id }}" @checked(in_array($id, old('labels', [])))>
                                    <label class="form-check-label" for="gridCheck1">
                                        {{ $name }}
                                    </label>
                                </div>
                                @endforeach
                            </div>
                        </fieldset>
                        <fieldset class="mb-3 row flex-column gap-2">
                            <legend class="col-form-label col-sm-2 pt-0">{{ trans('product.Categories')}}</legend>
                            <div class="col-sm-12">
                                @foreach($categories as $id => $name)
                                <div class="mt-1 inline-flex space-x-1">
                                    <input class="form-check-input" type="checkbox" name="categories[]" id="category-{{ $id }}" value="{{ $id }}" @checked(in_array($id, old('categories', [])))>
                                    <label class="form-check-label" for="categories[]">
                                        {{ $name }}
                                    </label>
                                </div>
                                @endforeach
                            </div>
                        </fieldset>
                        <fieldset class="mb-3 row flex-column gap-2">
                            <legend class="col-form-label col-sm-2 pt-0"> {{ trans('product.Roles')}}</legend>
                            <div class="col-sm-12">
                                <select name="assigned_to" id="assigned_to" class="form-control py-0">
                                    <option value="">-- SELECT USER --</option>
                                    @foreach($users as $key => $user)
                                    @if($user->getInRole('Admin'))
                                    <option value="{{ $key }}" @selected(old('assigned_to', []))>Admin => {{ $user->username }}</option>
                                    @endif
                                    @if($user->getInRole('Moderator'))
                                    <option value="{{ $key }}" @selected(old('assigned_to', []))>Moderator => {{ $user->username }}</option>
                                    @endif
                                    @if($user->getInRole('Seller'))
                                    <option value="{{ $key }}" @selected(old('assigned_to', []))>Seller => {{ $user->username }}</option>
                                    @endif
                                    @endforeach
                                </select>
                            </div>
                        </fieldset>
                        <div class="mt-4">
                            <input type="file" name="attachments[]" multiple class="form-control">
                        </div>
                         

                        <button type="submit" class="btn btn-main w-100 mt-3">Create Ticket</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection 