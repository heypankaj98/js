@extends('layouts.nosidebar')   @section('content')
<style>
  .ttop {
    padding-top: 15px !important;
}
</style>
<div class="container">
    <div class="verification_section my-5 my-3 p-2 p-lg-5 radius-5">
        <div class="row">
            <div class="col">
                <h5 class="card-title fw-bold pb-4 mb-5">{{ trans('auth.set_up') }}</h5>
            </div>
        </div>
        
        <div class="row">
            <div class="verification col-md-6">
                <div class="varifiction_inner border_none offset-right-lg-5">
                    <div class="p-0">
                        <h6 class="card-subtitle mb-2 text-center m-auto pb-2 pb-lg-3 seed_text ttop">
                            {{ trans('auth.let_make_text') }}
                        </h6>
                        @if(Session::has('error'))
                            <p class="alert alert-info">{{ Session::get('error') }}</p>
                        @endif
                    </div>
                </div>
            </div>
            <div class="verification-market-right col-md-6 ">
                <div class="margin_auto border_none varifiction_inner">
                    <div class="p-0">
                        @if(Session::has('error'))
                            <p class="alert alert-info">{{ Session::get('error') }}</p>
                        @endif
                        <div class="col-md-12">
                            @if (session('success'))
                                <div id="alert_message" class="alert alert-success alert-block">
                                    <strong>{{ session('success') }}</strong>
                                </div>
                            @endif

                            @if ($errors->any())
                                <div id="alert_message" class="alert alert-danger alert-block">
                                    <strong>{{ trans('auth.validation') }}:</strong>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        </div>
                        <form method="POST" action="{{ route('mnemonic.post') }}">
                            @csrf
                            <div class="form-group">
                                <textarea class="text-center p-4 w-100" rows="12" name="mnemonic" placeholder="{{ trans('auth.mnemonic_here') }}">{{ session()->get('encrypted_message') }}</textarea>
                                <p class="text-red text_part_verify text-left mt-2 text-14">{{ trans('auth.paste_warning') }}</p>
                            </div>
                            <div class=" verify_btn row ">
                                <div class="text-start mt-2 back_button_varify col-lg-6 col-md-12 ">
                                    <a href="{{ url()->previous() }}" class=" btn verify_btn text-decoration-none text-center d-block">
                                        {{ trans('auth.back_btn') }}
                                    </a>
                                </div>
                                <div class="text-start mt-2  col-lg-6  col-md-12 ">
                                    <button type="submit" class="btn-success btn col-md-12 text-decoration-none">
                                        {{ trans('auth.verify') }} {{ trans('auth.Mnemonic') }}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection