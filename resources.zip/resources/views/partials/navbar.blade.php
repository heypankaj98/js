    <style>
        /* Apply the transform effect to the logo image */
        .logo-img {
            display: block;
            margin: 0 auto;
            transition: transform 0.3s cubic-bezier(0.4, 0, 1, 1);
        }
        .bold-text {
    font-weight: bold;
}
strong.st{
    color: white !important;
}

        .logo-img:hover {
            transform: rotateY(20deg);
            /* Adjust the angle to your liking */
        }
        .into-2{
            color: #ff7d00;
        }

        /* Ensure the hover-text stays hidden by default */
        .hover-text {
            font-size: 13px;
            width: max-content;
            display: none;
            position: absolute;
            top: 100%;
            /* Adjust as needed */
            left: 0;
            padding: 24px;
            z-index: 100;
            border-radius: 4px
        }

        /* Show the hover-text when hovering over the parent container .balance */
        .balance:hover .hover-text {
            display: block;
        }

        /* Ensure the hover-text stays visible when hovering over it */
        .hover-text:hover {
            display: block;
        }
  .language-dropdown:hover .dropdown-menu {
        display: block;
    }

    .language-dropdown .dropdown-menu div {
        transition: background-color 0.3s;
    }
        .icon-currency {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .icon-currency svg {
            width: 22px;
            height: 22px;
            fill: #fff;
            background: #fd7c00;
            padding: 4px;
            border-radius: 24px;
        }

        .img-c {
            width: 22px;
            height: 22px;
            border-radius: 24px;
        }
        .header-top{
    	border-top: 1px solid #FF0000;
	border-bottom: 1px solid #FF0000;
	    margin: 12px 0;
}
 .red-dark{
        margin-left: 4px;
        margin-right: 2px;
    }
     .red-dark{
        margin-left: 4px;
        margin-right: 2px;
    }
.header-top .container{display:flex; flex-wrap:wrap;}
.blank-box{max-width:218px; width:100%}
    </style>
<div class="header-top">
       <div class="container">
           <div class="blank-box"></div>
           <div class="header-top-text">
               <h6>Always get access by Visiting <span> </span><a class="" target="_blank" href="https://darkalley.market">
                <span class="red-dark"> darkalley.market </span><span class="red-dark"></span>
            </a>
            to find all trusted Tor Mirrors, I2P & Secured Clearnet URL's</h6>
           </div>
       </div> 
</div>
    <div class="amazon_header header-2">
        
        <div class="amazon_header_top">
            <div class="container">
                <div class="containerr">
                    <div class="web-logo">
                        <a href="/">
                            <img class="logo-img" src="{{ asset('assets/Dark_Alley_Logo.png')}}" alt="alt" /></a>
                    </div>
                    <div class="dividend">
                        <div class="div-uppar">
                            <div class="inner-wrap">
                                <div class="inner-uppar">
                                    <div class="home1">
                                        <a href="/" class="link-item"> <img class="home-img icons"
                                                src="{{ asset('assets/Home.png')}}" alt="alt">
                                            <span>{{ trans('auth.home_link')}}</span></a>
                                    </div>
                                      @if (auth()->check())
                                    <form action="{{ route('logout') }}" class="form-ac mb-0" method="POST">
                                        @csrf
                                        <div class="logout">
                                            <button type="submit" class="link-item link-item-btn">
                                                <img class="logout-img icons" src="{{ asset('assets/Log_out.png') }}"
                                                    alt="Logout Icon">
                                                <span> {{ trans('auth.Logout') }}</span>
                                            </button>
                                        </div>
                                    </form>
                                    @endif
                                    @seller
                                    <div class="balance" style="position: relative;">
                                        <a href="{{ route('seller.balances') }}" class="link-item"
                                            style="display: inline-block;">
                                            <img class="blnce-img icons" src="{{ asset('assets/Balance.png') }}"
                                                alt="alt">
                                            <span> My Balance:  <span  class="into-2">USD
                                                    {{ number_format($user->btc_balance + $user->xmr_balance, 2) }}</span></span>
                                        </a>
                                        
                                    </div>

                                    @endseller
                                  @if (!in_array(auth()->id(), [1, 55]))
                                    <div class="mt-3">
                                    <ul style="list-style:none;" class="nav-link">
<li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="currencyDropdown" role="button" data-toggle="dropdown"
                    aria-expanded="false">
                    <span>
                       <span class="into-2 bold-text">My Fiat </span><span class="mt-2">{{ session('currency', 'USD') }}</span>
                    </span>
                </a>
                <ul class="dropdown-menu mb-2 m-w-max" aria-labelledby="currencyDropdown">
                    <li><a class="dropdown-item" href="{{route('change_currency','USD')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/usa.png') }}"></i> USD</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','EUR')}}"><i
                                class="bi bi-currency-euro"><img src="{{ asset('assets/euro.png') }}"></i> EUR</a></li>
                   <li><a class="dropdown-item" href="{{route('change_currency','GBP')}}"><i
                                class="bi bi-currency-pound"> <img src="{{ asset('assets/gbp.png') }}"></i> GBP</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','AUD')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/aud.png') }}"></i> AUD</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','INR')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/inr.png') }}"></i> INR</a></li>
                  <li><a class="dropdown-item" href="{{route('change_currency','CAD')}}"><i
                                class="bi bi-currency-dollar">  <img src="{{ asset('assets/cad.png') }}"></i> CAD</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','JPY')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/yen.png') }}"></i> JPY</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','CHF')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/cnf.png') }}"></i> CHF</a></li>
                    <li><a class="dropdown-item" href="{{route('change_currency','CNH')}}"><i
                                class="bi bi-currency-dollar"><img src="{{ asset('assets/cnh.png') }}"></i> CNH</a></li>
                </ul>
            </li>
            </ul></div>
@endif
@if (!auth()->user()->isSeller && !in_array(auth()->user()->id, [1, 55]))
<div class="d-flex">
    <div class="vendor-btn ms-auto">
        <div class="btn-bv p-1" style="">
            <a href="{{route('user.become')}}" class="become-vendor">
                <strong class="st">Become a Vendor</strong>
            </a>
        </div>
    </div>
</div>
@endif
@if(auth()->check() && !in_array(auth()->user()->id, [1, 55]) && auth()->user()->isSeller == 1)
    <div class="become-vendr">
       

        <div class="arrow-container">
            <div class="arrow">
              
                <div class="shaft">
                    <!-- Seller Reputation -->
                    <span class="arrow-text">{{ getSellerReputationTier() }}</span>
                </div>
                <div class="tail"></div>
            </div>
        </div>
    </div>
@elseif(auth()->check() && !in_array(auth()->user()->id, [1, 55]) && auth()->user()->isSeller == 0)
<!--@include('partials.feedback-summary')-->


 <div class="become-vendr">
    <div class="arrow-container">
        <div class="arrow">
            <div class="shaft">
                <!-- User Reputation -->
                <span class="arrow-text">Reputation ({{ getUserReputation(auth()->user()->id) }})</span>
            </div>
            <div class="tail"></div>
        </div>
    </div>
</div>
@endif



                                        </div>
                            </div>

    

                            <div class="right-side">
                                <div class="text1 py-2">
                                    <div class="in-txt">
                                        <div class="head5 ">
                                            @if (auth()->check())
                                            <h5><strong>Welcome :</strong> {{ Auth::user()->username }}</h5>
@if (auth()->user()->roles->contains('id', 1))
    <h5><strong>Account Type :</strong> Admin</h5>
@elseif (auth()->user()->isSeller == '1')
    <h5><strong>Account Type :</strong> Vendor</h5>
@else
    <h5><strong>Account Type :</strong> Buyer</h5>
@endif



                                        </div>





                                        @endif
                                    </div>
                                </div>
                                @if (auth()->check())
    @php
        // Fetch all roles for the authenticated user
        $userRoles = auth()->user()->roles->pluck('id')->toArray();
        $dashboardRoute = '';

        if (in_array(1, $userRoles)) { // Admin Role
            $dashboardRoute = route('admin.home');
        } elseif (in_array(3, $userRoles)) { // Seller Role
            $dashboardRoute = route('seller.dashboard');
        } elseif (in_array(2, $userRoles)) { // Buyer/User Role
            $dashboardRoute = route('user.dashboard');
        }
    @endphp

    <div class="right-side-img">
        <a href="{{ $dashboardRoute }}">
            @if (Auth::user()->avatar)
             <img src="{{ Str::startsWith(Auth::user()->avatar, 'avatars/') 
    ? asset('storage/' . Auth::user()->avatar) 
    : asset('assets/mystery-avatar.png') }}" 
    alt="Avatar" 
    class="profle_image" 
    width="75" 
    height="75">

            @endif
        </a>
    </div>

                                @endif
                            </div>
                        </div>
                        <div class="div-lower">
                            <div class="lower-one">
                                <div class="wallet">
                                    <a href="{{ route('buyer.wallet') }}" class="link-item">
                                        <span>My Wallet</span>
                                        <img class="wallet-img icons" src="{{ asset('assets/Wallet.png')}}" alt="alt">
                                    </a>
                                </div>
                                @if(auth()->check() && auth()->user()->isSeller)
                                <div class="advertise">
                                    <a href="#" class="link-item">
                                        <img class="advertising icons" src="{{ asset('assets/ads.png')}}" alt="alt">
                                        <span>Advertising</span>
                                    </a>
                                </div>
                                <div class="store">
                                    <a href="#" class="link-item">
                                        <img class="advertising icons" src="{{ asset('assets/enter-icon.png')}}" alt="alt">
                                        <span>My Store</span>
                                    </a>
                                </div>
                                @endif
                            </div>

                            <div class="lower-two">
                             @if (!in_array(auth()->id(), [1, 55]))
    @if (auth()->user()->isSeller)
        <div class="sales">
            <a class="nav-link link-item {{ Route::is('seller.orders') ? 'active' : '' }}" href="{{ route('seller.orders') }}">
                <span>My Sales</span>
                <img class="purchases-img icons" src="{{ asset('assets/Purchases.png') }}" alt="alt">
            </a>
        </div>
    @else
        <div class="purchases">
            <a href="{{ route('user.orders') }}" class="link-item">
               <span>My Purchases</span>
                 <img class="purchases-img icons" src="{{ asset('assets/Purchases.png') }}" alt="alt">
            </a>
        </div>
    @endif
@endif

                                <div class="security  @if (!in_array(auth()->id(), [1, 55])) left-icon @endif @if (auth()->user()->isSeller) left-icon @endif   ">
                                    <a href="{{ route('twofa') }}" class="link-item">
                                        <img class="security-img icons " src="{{ asset('assets/2f_secure.png')}}" alt="alt">
                                        <span>2FA Security</span>
                                        <img class="security-img icons @if (auth()->user()->isSeller) hide @endif" src="{{ asset('assets/2f_secure.png')}}" alt="alt">
                                    </a>
                                </div>

                            </div>
                            <div class="lower-three">
                             <div class="user-panel">
    @if (auth()->check())
        @php
            // Fetch all roles for the authenticated user
            $userRoles = auth()->user()->roles->pluck('id')->toArray(); 
        @endphp

        @if (in_array(1, $userRoles)) {{-- Admin Role --}}
            <a href="{{ route('admin.home') }}" 
               class="panel-link link-item {{ request()->routeIs('admin.home') ? 'active' : '' }}">
                <span>Admin Dashboard</span>
                <img class="user-img icons" src="{{ asset('assets/User_Panel.png') }}" alt="Admin Panel">
            </a>
        @elseif (in_array(3, $userRoles)) {{-- Seller Role --}}
            <a href="{{ route('seller.dashboard') }}" 
               class="panel-link link-item {{ request()->routeIs('seller.dashboard') ? 'active' : '' }}">
                <span>Seller Dashboard</span>
                 <img class="user-img icons" src="{{ asset('assets/User_Panel.png') }}" alt="Seller Panel">
            </a>
        @else (in_array(2, $userRoles)) {{-- User/Buyer Role --}}
            <a href="{{ route('user.dashboard') }}" 
               class="panel-link link-item {{ request()->routeIs('user.dashboard') ? 'active' : '' }}">
                <span>My User Panel</span>
                 <img class="user-img icons" src="{{ asset('assets/User_Panel.png') }}" alt="User Panel">
            </a>
        @endif
    @endif
</div>
                                <div class="faq">
                                    <a href="{{ route('faq') }}" class="link-item">
                                        <img class="faq-img icons" src="{{ asset('assets/FAQs.png')}}" alt="alt">
                                        <span>FAQ</span>
                                    </a>
                                </div>

                                <div class="info">
                                    <a href="{{ route('infocenter') }}" class="link-item">
                                        <img class="info-img icons" src="{{ asset('assets/About.png')}}" alt="alt">
                                        <span>Info Center</span>
                                    </a>
                                </div>
                                <div class="support">
                                    <a href="{{ route('support') }}" class="link-item">
                                        <img class="support-img icons" src="{{ asset('assets/Support.png')}}" alt="alt">
                                        <span><strong>Support </strong>& Mail</span>
                                    </a>
                                </div>
                                <div class="search">
                                    <a href="#" class="search-link link-item">
                                        <img class="search-img icons" src="{{ asset('assets/Search.png')}}"
                                            alt="Search">
                                        <span><strong>Search:</strong> Items/Vendor</span>
                                    </a>
                                    <div class="search-dropdown">
                                        <form class="c-search-form d-flex align-items-center"
                                            action="{{ route('search.index') }}" method="GET">
                                            <input type="text" class="form-control" id="searchinput" name="query"
                                                placeholder="Search...">
                                        </form>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="arrow1">
            <div class="container">
                <div class="leftt"></div>
                <div class="leftt1"></div>


                <div class="rightt">
                    <div class="rightt-in"></div>
                    <div class="rightt-inn">
                        <h4 class="nav-h4">Welcome To Dark Allay Market</h4>
                    </div>

                    <div class="rightt-innn">
                        <h4 class="phase">Your Anti Phishing Phase Is: {{$user->anti_phishing}}</h4>
                    </div>

                </div> -->
            </div>
            <div class="header-bottom">
                <div class="container">
                <div class="header-divider"></div>
                <div class="header-spacer"></div>
                <div class="header-divider"></div>
                <div class="header-spacer-2"><span>Welcome To Dark Allay Market</span></div>
                <div class="header-spacer-3"><span style="color:white">Your Anti Phishing Phrase Is: </span>{{$user->anti_phishing}}</div>
                <div class="header-spacer-4">
    <span style="color:white">
       <b>Last Login: </b> 
        <span class="orange">
            {{ \Carbon\Carbon::parse($user->last_login)->setTimezone('UTC')->format('Y-m-d H:i:s T') }}
        </span>
    </span>
</div>

                </div>
            </div>
    </div>