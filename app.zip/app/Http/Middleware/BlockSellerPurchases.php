<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class BlockSellerPurchases
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Check if the user is authenticated and if they are a seller
        if (Auth::check() && Auth::user()->role === 'seller') {
            // Redirect sellers away from purchase pages or deny access
            return redirect()->route('home')->with('error', 'Sellers are not allowed to purchase products.');
        }

        return $next($request);
    }
}
