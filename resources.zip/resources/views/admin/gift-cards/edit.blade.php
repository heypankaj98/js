@extends('layouts.admin.master')

@section('content')
    <div class="mt-4">
    <div class="card-header-2 w-100 mb-4">Edit Gift Card</div>
        <div class="bg-card-2 br1">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form action="{{ route('admin.gift-cards.update', $giftCard->id) }}" method="POST">
                            {{ csrf_field() }}
                            {{ method_field('PUT') }}

                            <div class="form-group mt-3">
                                <label for="code">Code:</label>
                                <input type="text" class="form-control mt-2" id="code" name="code" value="{{ old('code', $giftCard->code) }}">
                            </div>

                            <div class="form-group mt-3">
                                <label for="amount">Amount:</label>
                                <input type="number" step="0.01" class="form-control mt-2" id="amount" name="amount" value="{{ old('amount', $giftCard->amount) }}">
                            </div>

                            <div class="form-group mt-3">
                                <label for="expiration_date">Expiration Date:</label>
                                <input type="datetime-local" class="form-control mt-2" id="expiration_date" name="expiration_date" value="{{ old('expiration_date', $giftCard->expiration_date ? $giftCard->expiration_date: '') }}">
                            </div>

                            <div class="form-group mt-3">
                                <label for="used">Used:</label>
                                <input type="checkbox" class="form-control mt-2" id="used" name="used" {{ old('used', $giftCard->used) ? 'checked' : '' }}>
                            </div>

                            <button type="submit" class="btn btn-main w-100 mt-3">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
       
    </div>
@endsection
