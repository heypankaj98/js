<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order;
use App\Models\OrderPayment;
use Carbon\Carbon;
use Modules\PaymentGateway\Http\Controllers\PaymentGatewayController as PayWay;

class CheckPendingPayments extends Command
{
    protected $signature = 'payments:check-pending';
    protected $description = 'Check for pending payments and update balances';

    public function handle()
    {
        // Get all orders with 'waiting' status
        $orders = Order::where('status', 'waiting')->get();
      
        foreach ($orders as $order) {
         
             if ($order->buyer && $order->buyer->trashed()) {
              
                $this->error("Buyer for order {$order->order_id} is deleted.");
                continue;
            }
              if (!$order->buyer || !$order->buyer->username) {
                $this->error("Buyer for order {$order->order_id} is not a valid user.");
                continue;
            }


            if ($order->seller && $order->seller->trashed()) {
                $this->error("Seller for order {$order->order_id} is deleted.");
                continue;
            }
            
            $orderPayment = $order->orderPayment()->first();

            if ($orderPayment) {
                $payment_method = $order->payment_method;
                $payment_address = $orderPayment->payment_address;
                $username = $order->buyer->username;
                $received = 0;

                try {
                    // Fetch payment balance based on the payment method
                    if ($payment_method === 'Bitcoin') {
                        $received = PayWay::getBalance($payment_method, ['address' => $payment_address, 'tag' => $username]);
                    } elseif ($payment_method === 'Monero') {
                        $received = PayWay::getAddressBalance($payment_method, ['address' => $payment_address, 'tag' => $username]);
                    }

                    // Ensure the received amount is numeric
                    if (!is_numeric($received)) {
                        throw new \Exception("Received value is not numeric: " . json_encode($received));
                    }

                    // Check if payment has been received
                    if ($received >= $orderPayment->amount) {
                        // Update order and payment status
                        $order->update(['status' => 'escrow']);
                        $orderPayment->update([
                            'status' => 'PAID',
                            'total_received' => $received,
                            'paid_at' => Carbon::now(),
                        ]);

                        $this->info('Payment received for order ID: ' . $order->id);
                    } else {
                        $this->info('Payment still pending for order ID: ' . $order->id);
                    }

                } catch (\Exception $e) {
                    // Log the error for debugging
                    \Log::error("Error processing order ID: {$order->id}. Message: " . $e->getMessage());
                    $this->error('Error processing payment for order ID: ' . $order->id . '. Check logs for details.');
                }
            }
        }

        return 0;
    }
}
