<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('gift_cards', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique();

            $table->decimal('amount');
            $table->decimal('payable_amount');
            $table->dateTime('expiration_date')->nullable();
            $table->boolean('used')->default(false);
            $table->unsignedBigInteger('user_id')->nullable();
            $table->string('status')->default('payment_pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('gift_cards');
    }
};
