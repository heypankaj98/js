<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Imagick;

class DDoSCheck {
    protected $throttle;

    public function __construct(ThrottleRequests $throttle) {
        $this->throttle = $throttle;
    }

    public function handle($request, Closure $next) {
        if ($this->hasExceededRefreshLimit()) {
            return redirect()->route('loginfailed'); // Redirect to loginfailed route if refresh limit exceeded
        }

        if (!$this->isCaptchaValidationComplete()) {
            $cssCoordinates = $this->validateCaptcha($request);
            if ($cssCoordinates !== true) {
                return new Response(view('captcha')->with('cssCoordinates', $cssCoordinates)->render(), 429);
            }
        }

        if ($this->isCaptchaValidationComplete()) {
            if ($request->is('ddos_check')) {
                return redirect('/'); // Redirect to the homepage if CAPTCHA validation is complete
            }
            return $next($request); // Proceed with the request
        }
    }

    private function isCaptchaValidationComplete() {
        return session()->has('validatedddos');
    }

    private function validateCaptcha($request) {
        $expectedValue = session('captcha_text');
        $expectedValue_second = session('captcha_text_second_position');

        if ($request->isMethod('post')) {
            $inputValue = strtoupper($request->input('c1') . $request->input('c2') . $request->input('c3') . $request->input('c4') . $request->input('c5'));
            $inputValue_second = strtoupper($request->input('captha2_first') . $request->input('captha2_second') . $request->input('captha2_third'));

            if ($inputValue == $expectedValue && $this->verifySecondCaptcha($inputValue_second, $expectedValue_second)) {
                session(['validatedddos' => true]);
                return true;
            } else {
                $cssCoordinates = $this->generateCssCoordinates();
                return $cssCoordinates; // Return the coordinates for display in the view
            }
        } else {
            $cssCoordinates = $this->generateCssCoordinates();
            return $cssCoordinates;
        }
    }

    private function verifySecondCaptcha($inputValue, $expectedValue) {
        $word = '';
        foreach ($expectedValue as $value) {
            $word .= $value;
        }

        return $inputValue === $word;
    }

    private function hasExceededRefreshLimit() {
        $refreshLimit = 10;
        $timeWindow = 30; // seconds

        // Get the current timestamp
        $currentTimestamp = time();

        // Retrieve the session data for refresh timestamps
        $refreshTimestamps = session()->get('refresh_timestamps', []);

        // Filter out timestamps older than the time window
        $refreshTimestamps = array_filter($refreshTimestamps, function ($timestamp) use ($currentTimestamp, $timeWindow) {
            return ($currentTimestamp - $timestamp) <= $timeWindow;
        });

        // Add the current timestamp to the array
        $refreshTimestamps[] = $currentTimestamp;

        // Store the updated timestamps in the session
        session(['refresh_timestamps' => $refreshTimestamps]);

        // Check if the number of timestamps exceeds the refresh limit
        return count($refreshTimestamps) > $refreshLimit;
    }

    private function generateCssCoordinates() {
   
     $characters = '1369ACEGPRVS';
      $coordinates = [
  '1' => ['x' => 4, 'y' => 81],
  '3' => ['x' => 39, 'y' => 18],
  '3' => ['x' => 46, 'y' => 42],
  '6' => ['x' => 64, 'y' => 21],
  '6' => ['x' => 63, 'y' => 19],
  '9' => ['x' => 61, 'y' => 61],
  'A' => ['x' => 50, 'y' => 80],
  'A' => ['x' => 46, 'y' => 82],
  'C' => ['x' => 20, 'y' => 30],
  'C' => ['x' => 20, 'y' => 38],
  'E' => ['x' => 0, 'y' => 0],
  'E' => ['x' => 63, 'y' => 80],
  'G' => ['x' => 87, 'y' => 17],
  'P' => ['x' => 18, 'y' => 60],
  'P' => ['x' => 53, 'y' => 20],
  'P' => ['x' => 25, 'y' => 61],
  'R' => ['x' => 8, 'y' => 58],
  '3' => ['x' => 88, 'y' => 42],
  'V' => ['x' => 43, 'y' => 35],
  'V' => ['x' => 62, 'y' => 39],
  'S' => ['x' => 63, 'y' => 1],
 ];
 
    // Shuffle the characters
    $shuffledCharacters = substr(str_shuffle($characters), 0, 5);
    $shuffledCharacterSecond = substr(str_shuffle($characters), 0, 5);
    

    // Displaying the coordinates for each character
    // foreach (str_split($shuffledCharacters) as $char) {
    //   echo "$char: x = {$coordinates[$char]['x']}, y = {$coordinates[$char]['y']}"; 
    // }

    // Output the CSS for the shuffled characters
    $cssCoordinates = '';
    foreach (str_split($shuffledCharacters) as $i => $char) {
        $x = $coordinates[$char]['x'];
        $y = $coordinates[$char]['y'];

        $cssCoordinates .= "input[name=c" . ($i + 1) . "]:focus ~ .border-row-outer .image {
            background-position: -{$x}px -{$y}px;
        }\n";
    }

    // Save the image
    $imagePath = 'output.png'; // Set your desired output image path

    // Output the CSS
    $imageCss = "
    .image {
        width: 20px;
        height: 20px;
        transform-origin: center;
        transform: scale(6);
        transition: all 0.2s ease-in;
       
        margin: auto;
        margin-bottom: 60px;
        margin-top: 80px;
      
    }\n";

    // Save CSS and image path in sessions
    Session::put('cssCoordinates', $cssCoordinates);
    Session::put('captcha_image', $imageCss);
    Session::put('captcha_text', $shuffledCharacters);
    
$positions = array_rand(str_split($shuffledCharacterSecond), 3);

        $captchaTextSecondPosition = [];
        foreach ($positions as $position) {
            $captchaTextSecondPosition[$position + 1] = $shuffledCharacterSecond[$position]; // Adding 1 to position to make it 1-based index
        }

        $image = new Imagick();
        $image->newImage(150, 100, new \ImagickPixel('transparent'));
        $image->setImageFormat('png');

        $draw = new \ImagickDraw();
        $draw->setFontSize(20);
        $draw->setFillColor(new \ImagickPixel('white'));  // Color for the characters

     
        foreach (str_split($shuffledCharacterSecond) as $position => $char) {
            $x = $position * 30;
            $y = 100; // Fixed y-coordinate for demonstration
            $draw->annotation($x, $y, $char);
        }

   // Set arrow color to red
        $arrowColor = new \ImagickPixel('red');
        $draw->setStrokeColor($arrowColor);
        $draw->setStrokeWidth(1);  // Arrow thickness


        // Create arrows (downward triangle)
        foreach (str_split($shuffledCharacterSecond) as $position => $char) {
            if (in_array($char, $captchaTextSecondPosition)) {
                $x = $position * 30 + 5;  // Base X-coordinate of the triangle
                $y = 80;  // Base Y-coordinate of the triangle
                
                $trianglePath = new \ImagickDraw();
                $trianglePath->setStrokeColor($arrowColor);
                $trianglePath->setFillColor($arrowColor);
                $trianglePath->setStrokeWidth(1);

                $trianglePath->pathStart();
                $trianglePath->pathMoveToAbsolute($x, $y);
                $trianglePath->pathLineToAbsolute($x + 5, $y - 10);
                $trianglePath->pathLineToAbsolute($x - 5, $y - 10);
                $trianglePath->pathLineToAbsolute($x, $y);

                $image->drawImage($trianglePath);
            }
        }
        $image->drawImage($draw);

        // Generate Base64 image
        $image->setImageFormat('png');
        $base64Image = base64_encode($image->getImageBlob());

        $image->clear();
        $image->destroy();

        // Save image and Base64 in session
        Session::put('captcha_second_image', $base64Image);
        Session::put('captcha_text_second', $shuffledCharacterSecond);
        Session::put('captcha_text_second_position', $captchaTextSecondPosition);

        return $cssCoordinates; 
  
        
}


}
