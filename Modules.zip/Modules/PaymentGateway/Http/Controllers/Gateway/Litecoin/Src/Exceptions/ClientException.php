<?php

namespace Modules\PaymentGateway\Http\Controllers\Gateway\Litecoin\Src\Exceptions;

use RuntimeException;

class ClientException extends RuntimeException
{
}
