@extends('layouts.homeapp')
@section('content')

@if($totalReviews > 0)
    <div class="feedback-summary">
        <p><strong>Average Rating:</strong> {{ number_format($averageRating, 2) }}</p>
        <p><strong>Total Reviews:</strong> {{ $totalReviews }}</p>
        <ul>
            <li><strong>Positive:</strong> {{ $positiveCount }} ({{ number_format(($positiveCount / $totalReviews) * 100, 2) }}%)</li>
            <li><strong>Neutral:</strong> {{ $neutralCount }} ({{ number_format(($neutralCount / $totalReviews) * 100, 2) }}%)</li>
            <li><strong>Negative:</strong> {{ $negativeCount }} ({{ number_format(($negativeCount / $totalReviews) * 100, 2) }}%)</li>
        </ul>
    </div>
@else
    <p>No reviews available for this seller yet.</p>
@endif

@endsection