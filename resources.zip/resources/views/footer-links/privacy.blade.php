@extends('layouts.nosidebar')
@section('content')

<div class="container">
   <div class="verification_section my-5 my-3 p-2 p-lg-5 radius-5 reset_password_section">
        <div class="row">
            <div class="col">
                <h5 class="card-title fw-bold pb-4 mb-5">{{ trans('footer.privacy') }} | {{ trans('global.site_title') }}</h5>
            </div>
        </div>
        <div class="verification-market-right col-md-12 pe-3 pe-md-5">
            <div class="margin_auto border_none">
                <div class="p-0">
                    <div class="form_reset_main">   
                        <p class="text-20 fw-semibold">{{ trans('footer.effective') }}: [9-{{ trans('global.jul') }}-2023]</p>
                        <div class="form-group mb-3">
                            <i>&emsp;At Shopzo Market, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our services. By accessing or using our services, you acknowledge that you have read, understood, and agree to be bound by the terms of this Privacy Policy.</i><br><br>
                            <b>Information We Collect</b><br>
                            <b>1.1</b> Non-Personal Information: We only collect non-personal information about you regarding use of our services, such as your name, profile photo and cookies. This information is collected as you sign up with our services.<br><br>
                            <b>Use of Information</b><br>
                            <b>2.1</b> We use the information we collect to provide, maintain, and improve our services, personalize your experience, process transactions, and communicate with you. We may also use your information to send you promotional offers, newsletters, or other marketing communications, unless you have opted out of receiving such communications.<br><br>
                            <b>2.2</b> We may aggregate and anonymize non-personal information for statistical and analytical purposes, which helps us understand trends, preferences, and usage patterns to enhance our services.<br><br>
                            <b>Information Sharing</b><br>
                            <b>3.1</b> We never share your personal information with any third parties who assist us in operating our business, providing our services, or conducting our operations.<br><br>
                            <b>3.2</b> We never disclose your information if required by law, regulation, legal process, or governmental request, or if we believe in good faith that such disclosure is necessary to protect our rights, safety, or property, or the rights, safety, or property of others.<br><br>
                            <b>Data Security</b><br>
                            <b>4.1</b> We employ industry-standard security measures to protect your information from unauthorized access, alteration, disclosure, or destruction. However, please be aware that no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.<br><br>
                            <b>Third-Party Links</b><br>
                            <b>5.1</b> Our services no links to third-party websites or services that are not operated or controlled by us. We encourage you to review the privacy policies of any third-party sites you visit.<br><br>
                            <b>Children's Privacy</b><br>
                            <b>6.1</b> Our services are not intended for use by individuals under the age of 18. We do not knowingly collect personal information from children. If you believe we may have inadvertently collected personal information from a child, please contact us immediately, and we will take appropriate measures to remove that information.<br><br>
                            <b>Changes to this Privacy Policy</b><br>
                            <b>7.1</b> We reserve the right to modify this Privacy Policy at any time. Any changes will be effective immediately upon posting the updated Privacy Policy. We encourage you to review this Privacy Policy periodically to stay informed about how we collect, use, and protect your information.<br><br>
                            <b>Contact Us</b><br>
                            <b>8.1</b> If you have any questions, concerns, or requests regarding this Privacy Policy or our privacy practices, please contact us at [<span class="text-primary">shopzo@protonmail.com</span>].<br><br>
                            <i>By using our services, you consent to the collection, use, and disclosure of your information as described in this Privacy Policy.</i>
                            @guest
                            <div class="karyx_main">
                                <div class="create_btn mt-2">
                                    <a href="{{ route('login') }}" class="fw-semibold text-decoration-none btn_create text-center d-block"> 
                                        <svg xmlns="http://www.w3.org/2000/svg" class="me-2" width="19" height="8" viewBox="0 0 19 8" fill="none">
                                         <path d="M0.646447 4.35355C0.451184 4.15829 0.451184 3.84171 0.646447 3.64645L3.82843 0.464465C4.02369 0.269203 4.34027 0.269203 4.53553 0.464465C4.7308 0.659727 4.7308 0.976309 4.53553 1.17157L1.70711 4L4.53553 6.82843C4.7308 7.02369 4.7308 7.34027 4.53553 7.53553C4.34027 7.73079 4.02369 7.73079 3.82843 7.53553L0.646447 4.35355ZM19 4.5L1 4.5L1 3.5L19 3.5L19 4.5Z" fill="#01509F"/>
                                        </svg>
                                        {{ trans('auth.login_account') }}
                                    </a>
                                </div>
                            </div>
                            @endguest
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection