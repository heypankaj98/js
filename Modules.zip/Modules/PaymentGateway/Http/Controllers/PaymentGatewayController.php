<?php

namespace Modules\PaymentGateway\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class PaymentGatewayController extends Controller {

    public function deposit() {
        return view('paymentgateways::index');
    }

    public static function isNoderunning($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';

        $data = $new::isNoderunning($para);
     
        return $data;
    }

    public static function createNewAccount($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::createNewAccount($para);
        return $data;
    }

    public static function generateAddress($paymentMethod = 'Bitcoin', $para = array()) { 

        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        $data = $new::generateAddress($para);
        
        return $data;
    }

    public static function getaddressinfo($paymentMethod = 'Bitcoin', $para = array()) { //DONE

      $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
   
        if (!class_exists($new)) {
            
            throw new \Exception("Invalid payment method: $paymentMethod  ");
        }
        $data = $new::getaddressinfo($para);
        
        return $data;
    }

    public static function getBalance($paymentMethod = 'Bitcoin', $para = array()) { 
        //DONE
    
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        $data = $new::getBalance($para);
  
        return $data;
    }
    public static function getWalletlisttransactions($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        $data = $new::getWalletlisttransactions($para);
        return $data;
    }

    public static function getTransactionDetail($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        $data = $new::getTransactionDetail($para);
        return $data;
    }

    public static function getTransactionFee($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        $data = $new::getTransactionFee($para);
        return $data;
    }

    public static function getWalletBalance($paymentMethod = 'Bitcoin', $para = array()) {
       //DONE
        $new = '\\' . __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }
        
        $data = $new::getWalletBalance($para);

        return $data;
    }

    public static function getWalletData($paymentMethod = 'Bitcoin', $para = array()) {
        
        //DONE
     
        $new = '\\' . __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getWalletData($para);
        
        return $data;
    }

    public static function getAddressByLabel($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = '\\' . __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAddressByLabel($para);
        return $data;
    }

    public static function getEstimate($paymentMethod = 'Bitcoin', $para = array()) { // DONE
        $new = '\\' . __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getEstimate($para);
        return $data;
    }

    public static function isValidAddress($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::isValidAddress($para);
        return $data;
    }

    public static function archieveAddress($paymentMethod = 'Bitcoin', $para = array()) { //DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::archieveAddress($para);
        return $data;
    }

    public static function sendToAddress($paymentMethod = 'Bitcoin', $para = array()) { 

        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }

        $data = $new::sendToAddress($para);
       
        return $data;
    }
     public static function primary_transfer($paymentMethod = 'Bitcoin', $para = array()) { 

        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        if (!class_exists($new)) {
            throw new \Exception("Invalid payment method: $paymentMethod");
        }

        $data = $new::primary_transfer($para);
       
        return $data;
    }

    public static function sendToLabel($paymentMethod = 'Bitcoin', $para = array()) { // DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::sendToLabel($para);
        return $data;
    }

    public static function isAddressCreated($paymentMethod = 'Bitcoin', $para = array()) { // DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::isAddressCreated($para);
        return $data;
    }

    public static function getBlockchainInfo($paymentMethod = 'Bitcoin', $para = array()) { // DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getBlockchainInfo($para);
        return $data;
    }

    public static function gettransactioncount($paymentMethod = 'Bitcoin', $para = array()) { // DONE
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::gettransactioncount($para);
        return $data;
    }

    public static function createMultiSigAddress($paymentMethod = 'Bitcoin', $para = array()) {
      
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::createMultiSigAddress($para);
        
        return $data;
    }

    public static function createMultiSigTransaction($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::createMultiSigTransaction($para);
        return $data;
    }

    public static function dumpPrivateKey($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::dumpPrivateKey($para);
        return $data;
    }

    public static function getAddressFromPublicKey($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAddressFromPublicKey($para);
        return $data;
    }

    public static function getMultisigTxId($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getMultisigTxId($para);
        return $data;
    }

    public static function createRawTransaction($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::createRawTransaction($para);
        return $data;
    }

    public static function signMultiSigTransaction($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::signMultiSigTransaction($para);
        return $data;
    }

    public static function listunspent($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::listunspent($para);
        return $data;
    }

    public static function sendrawtransaction($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::sendrawtransaction($para);
        return $data;
    }
     public static function getAddressBalance($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAddressBalance($para);
        return $data;
    }
      public static function getAllAccountsInfo($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAllAccountsInfo($para);
        return $data;
    }
     public static function getAccountTransactions($paymentMethod = 'Bitcoin', $para = array()) {
      
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAccountTransactions($para);
        
        return $data;
    }
     public static function getAccountAddresses($paymentMethod = 'Bitcoin', $para = array()) {
        $new = __NAMESPACE__ . '\\' . 'Gateway\\' . $paymentMethod . '\\ProcessController';
        $data = $new::getAccountAddresses($para);
        return $data;
    }

}
