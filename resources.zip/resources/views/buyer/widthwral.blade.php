@extends('layouts.buyer.app')     @section('content')
@if ($errors->any())

<div class="alert alert-danger">

<ul> 
@foreach ($errors->all() as $error)

<li>{{ $error }}</li>

@endforeach 
</ul> 
</div> 
@endif
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">User Balances</div>

                <div class="card-body">
                    <p><strong>Balances:</strong></p>
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Bitcoin (BTC)
                            <span class="badge badge-primary badge-pill">{{ number_format($user->btc_balance, 8) }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Monero (XMR)
                            <span class="badge badge-primary badge-pill">{{ number_format($user->xmr_balance, 8) }}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Litecoin (LTC)
                            <span class="badge badge-primary badge-pill">{{ number_format($user->ltc_balance, 8) }}</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header">Withdraw Funds</div>

                <div class="card-body">
                    <form action="{{ route('user.widthwral.update') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="currency">Select Currency:</label>
                            <select class="form-control" id="currency" name="coin">
                                <option value="btc_balance">Bitcoin (BTC)</option>
                                <option value="xmr_balance">Monero (XMR)</option>
                                <option value="ltc_balance">Litecoin (LTC)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount to Withdraw:</label>
                            <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter amount" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Withdraw</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection